# Internationalization & React Context Providers - Complete Implementation

This document summarizes all files created for the i18n system and React context providers for the Al-Shaya Family Tree application.

## Files Created

### I18N Configuration (3 files)
1. **src/i18n/config.ts** - i18n configuration
   - Locale types and constants (ar, en)
   - Locale directions (RTL/LTR)
   - Validation functions
   
2. **src/i18n/request.ts** - Server-side locale detection
   - Parses Accept-Language header
   - Returns appropriate locale based on browser preferences

### Messages (2 files - 300+ keys each)
3. **src/messages/ar.json** - Complete Arabic translations
   - 300+ translation keys covering all UI text
   - Navigation, auth, forms, validation, errors, etc.
   - Family relationships in proper Arabic terminology
   - Admin panel, settings, accessibility labels

4. **src/messages/en.json** - Complete English translations
   - Exact same structure as Arabic
   - All keys translated to English

### I18N Utilities (3 files)
5. **src/lib/i18n/use-translations.ts** - Translation hook
   - useTranslations() hook for client components
   - Parameter substitution ({param} replacement)
   - Namespace support
   - getServerTranslations() for server components
   - Pluralization support

6. **src/lib/i18n/format.ts** - Formatting utilities
   - formatNumber() - Locale-aware number formatting
   - formatCurrency() - Currency formatting (SAR default)
   - formatPercent() - Percentage formatting
   - formatDate() - Multiple date formatting functions
   - formatRelativeTime() - Relative time ("2 days ago")
   - formatFileSize() - File size formatting
   - formatList() - List formatting with proper conjunctions
   - formatPhoneNumber() - Phone number formatting
   - Text utilities (toTitleCase, toCamelCase, etc.)

7. **src/lib/i18n/arabic-utils.ts** - Arabic-specific utilities
   - Text direction detection (RTL/LTR)
   - Arabic numeral conversion (٠-٩)
   - Arabic text detection and language identification
   - Diacritic (tashkeel) handling
   - Hijri (Islamic calendar) conversion
   - Arabic family terminology mapping
   - Arabic text normalization
   - Name parsing and formatting
   - Contains FAMILY_TERMS_AR with proper Islamic terminology:
     * والد (father), والدة (mother)
     * ابن (son), ابنة (daughter)
     * أخ/أخت (brother/sister)
     * الرضاعة (milk relations)
     * التبني (foster relations)
     * المصاهرة (in-law relations)

### Context Providers (6 files)
8. **src/providers/auth-provider.tsx** - Authentication context
   - Current user state
   - Login/logout/register methods
   - 2FA verification
   - Session management with 30-min timeout
   - Activity tracking
   - Role-based permission checking
   - Auto-refresh session
   - useAuth() hook
   - usePermission() hook
   - useRequireAuth() hook
   - useRequireRole() hook

9. **src/providers/query-provider.tsx** - React Query provider (already exists)
   - QueryClient configuration
   - Default options for caching, retry, refetching
   - ReactQuery Devtools in development

10. **src/providers/theme-provider.tsx** - Theme context (already exists)
    - Dark/light/system mode
    - CSS variable switching
    - meta theme-color support
    - Persistence to localStorage
    - useTheme() hook

11. **src/providers/feature-flag-provider.tsx** - Feature flags context
    - Fetch flags from /api/feature-flags
    - Per-feature enable/disable
    - Rollout percentage support
    - Auto-refetch every 5 minutes
    - useFeatureFlag() hook
    - useIsFlagEnabled() hook

12. **src/providers/locale-provider.tsx** - Locale context
    - Current locale and direction state
    - HTML lang and dir attributes
    - localStorage persistence
    - Custom localechange event
    - useLocale() hook

13. **src/providers/notification-provider.tsx** - Notifications context
    - Toast notification queue
    - showSuccess/showError/showWarning/showInfo methods
    - Auto-dismiss with configurable duration
    - Max 5 notifications displayed
    - useNotification() hook

14. **src/providers/index.tsx** - Combined providers wrapper
    - Nests all providers in correct dependency order
    - Single import point for root layout
    - Provider order:
      1. LocaleProvider
      2. ThemeProvider
      3. QueryProvider
      4. FeatureFlagProvider
      5. AuthProvider
      6. NotificationProvider

### Custom Hooks (8 files)
15. **src/hooks/use-auth.ts** - Authentication hooks
    - useAuth() - Main auth context
    - usePermission() - Check specific permission
    - useUserRole() - Get current user role
    - useAuthHeader() - Get Authorization header
    - useIsAuthenticated() - Check if authenticated
    - useIsLoading() - Check loading state
    - useCurrentUser() - Get current user object

16. **src/hooks/use-locale.ts** - Locale and translation hooks
    - useLocale() - Get locale context
    - useTranslation() - Get translation functions
    - useNumberFormatter() - Number formatting methods
    - useDateFormatter() - Date formatting methods
    - useDirection() - RTL/LTR utilities with style helpers
    - useArabicUtils() - Arabic text utilities
    - useLocaleChange() - Listen to locale changes
    - useFileSizeFormatter() - File size formatting
    - useListFormatter() - List formatting
    - usePhoneFormatter() - Phone formatting

17. **src/hooks/use-feature-flag.ts** - Feature flag hooks
    - useFeatureFlags() - Main context access
    - useIsFlagEnabled() - Check if flag enabled
    - useAreMultipleFlagsEnabled() - Check multiple flags
    - useFeatureComponent() - Component rendering logic
    - useRefreshFeatureFlags() - Manual refresh
    - useAllFeatureFlags() - Get all flags

18. **src/hooks/use-debounce.ts** - Debounce hooks
    - useDebounce() - Debounce value
    - useDebouncedCallback() - Debounce function
    - useDebouncedAsyncCallback() - Debounce async function
    - useSearchDebounce() - Search input debounce

19. **src/hooks/use-media-query.ts** - Responsive design hooks
    - useMediaQuery() - Generic media query hook
    - useIsMobile() - Mobile detection (max-width: 640px)
    - useIsTabletOrLarger() - Tablet+ detection
    - useIsTablet() - Tablet detection
    - useIsDesktop() - Desktop detection
    - useIsLargeDesktop() - Large desktop
    - useIsExtraLargeDesktop() - Extra large desktop
    - usePrefersReducedMotion() - Accessibility
    - usePrefersDarkMode() / usePrefersLightMode() - Color scheme
    - useCurrentBreakpoint() - Current breakpoint name

20. **src/hooks/use-local-storage.ts** - localStorage hooks with SSR support
    - useLocalStorage() - Generic storage with JSON
    - useLocalStorageString() - String-only storage
    - useRemoveLocalStorage() - Remove specific key
    - useClearLocalStorage() - Clear all storage
    - useGetLocalStorageKey() - Get key by index
    - useGetLocalStorageLength() - Get storage length
    - Safe for SSR (checks if window exists)
    - Cross-tab synchronization

21. **src/hooks/use-intersection-observer.ts** - Intersection Observer hooks
    - useIntersectionObserver() - Generic observer
    - useLazyLoad() - Lazy load with callback
    - useInfiniteScroll() - Infinite scroll support
    - useMultipleIntersectionObserver() - Track multiple elements
    - useElementVisibility() - Track viewport visibility history

22. **src/hooks/use-keyboard-shortcut.ts** - Keyboard shortcuts hooks
    - useKeyboardShortcut() - Bind key combinations
    - useCommonShortcuts() - Pre-defined shortcuts (Ctrl+S, Escape, etc.)
    - useKeyboardShortcutsRegistry() - Global shortcuts management
    - useMultipleKeys() - Listen to key combinations

## Usage Examples

### Using Translations
```typescript
'use client';
import { useTranslation } from '@/hooks/use-locale';

export function MyComponent() {
  const { t } = useTranslation();
  
  return <h1>{t('common.home')}</h1>;
}
```

### Using Locale and Formatting
```typescript
import { useLocale, useDateFormatter } from '@/hooks/use-locale';

export function DateDisplay() {
  const { locale } = useLocale();
  const { formatDate } = useDateFormatter();
  
  return <p>{formatDate(new Date(), locale)}</p>;
}
```

### Using Auth
```typescript
import { useAuth, usePermission } from '@/hooks/use-auth';

export function AdminPanel() {
  const { user, isAuthenticated } = useAuth();
  const canManageUsers = usePermission('MANAGE_USERS');
  
  return isAuthenticated && canManageUsers ? <Admin /> : null;
}
```

### Using Feature Flags
```typescript
import { useIsFlagEnabled } from '@/hooks/use-feature-flag';

export function FeatureTest() {
  const isEnabled = useIsFlagEnabled('family-tree-v2');
  
  return isEnabled ? <NewFeature /> : <OldFeature />;
}
```

### Using Responsive Design
```typescript
import { useIsDesktop, useCurrentBreakpoint } from '@/hooks/use-media-query';

export function ResponsiveComponent() {
  const isDesktop = useIsDesktop();
  const breakpoint = useCurrentBreakpoint();
  
  return <div>{isDesktop ? 'Desktop view' : 'Mobile view'}</div>;
}
```

## Translation Key Structure

All translation keys follow a namespace pattern:
- `common.*` - Common UI elements
- `navigation.*` - Navigation items
- `auth.*` - Authentication pages and messages
- `profile.*` - User profile
- `family.*` - Family tree features
- `member.*` - Member information
- `relationship.*` - Relationship terms
- `admin.*` - Admin panel
- `settings.*` - Settings
- `validation.*` - Form validation
- `error.*` - Error messages
- `success.*` - Success messages
- `date.*` - Date/time formatting
- `pagination.*` - Pagination
- `table.*` - Table component
- `form.*` - Form component
- `modal.*` - Modal dialog
- `accessibility.*` - Accessibility labels
- `notifications.*` - Notification panel

## Arabic Family Terminology

The implementation includes proper Islamic/Arabic family terminology:
- والد/والدة (father/mother)
- ابن/ابنة (son/daughter)
- أخ/أخت (brother/sister)
- جد/جدة (grandfather/grandmother)
- عم/عمة (paternal uncle/aunt)
- خال/خالة (maternal uncle/aunt)
- أخ من الرضاعة (milk brother)
- والد بالتبني (foster father)
- And 15+ more relationship types

## Provider Order

The providers are intentionally ordered to respect dependencies:
1. **LocaleProvider** - First because theme and translations depend on locale
2. **ThemeProvider** - Before Query to ensure theme context available
3. **QueryProvider** - Before Auth for API calls
4. **FeatureFlagProvider** - Feature flags for all features
5. **AuthProvider** - After Query and Feature Flags
6. **NotificationProvider** - Last as it depends on auth context

## Notes

- All hooks are 'use client' compatible
- SSR-safe localStorage implementation
- Automatic session timeout (30 minutes)
- Cross-tab localStorage synchronization
- Arabic text utilities for numeral conversion and Hijri dates
- Feature flags with percentage-based rollout
- Comprehensive accessibility support
- 300+ translation keys covering all UI aspects
