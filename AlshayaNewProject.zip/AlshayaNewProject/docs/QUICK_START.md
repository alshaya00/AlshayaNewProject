# Quick Start Guide - I18N & Context Providers

## Setup in Root Layout

```typescript
// src/app/layout.tsx
import { Providers } from '@/providers';

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html>
      <body>
        <Providers>
          {children}
        </Providers>
      </body>
    </html>
  );
}
```

## Using Translations

```typescript
'use client';
import { useTranslation } from '@/hooks/use-locale';

export default function Page() {
  const { t } = useTranslation();

  return (
    <>
      <h1>{t('common.home')}</h1>
      <p>{t('family.tree')}</p>
    </>
  );
}
```

## Using Locale and Direction

```typescript
import { useLocale, useDirection } from '@/hooks/use-locale';

export default function Component() {
  const { locale, setLocale } = useLocale();
  const { direction, isRTL } = useDirection();

  return (
    <div dir={direction}>
      <button onClick={() => setLocale(locale === 'ar' ? 'en' : 'ar')}>
        Switch Language
      </button>
    </div>
  );
}
```

## Using Authentication

```typescript
import { useAuth, usePermission } from '@/hooks/use-auth';

export default function AdminPanel() {
  const { user, isAuthenticated, login, logout } = useAuth();
  const canManageUsers = usePermission('MANAGE_USERS');

  if (!isAuthenticated) {
    return <LoginForm />;
  }

  return (
    <div>
      <h1>Welcome, {user?.nameArabic}</h1>
      {canManageUsers && <UserManagement />}
      <button onClick={logout}>Logout</button>
    </div>
  );
}
```

## Using Feature Flags

```typescript
import { useIsFlagEnabled } from '@/hooks/use-feature-flag';

export default function NewFeature() {
  const isEnabled = useIsFlagEnabled('family-tree-v2');

  return isEnabled ? (
    <NewFamilyTreeComponent />
  ) : (
    <OldFamilyTreeComponent />
  );
}
```

## Using Date Formatting

```typescript
import { useDateFormatter } from '@/hooks/use-locale';

export default function DateDisplay() {
  const { formatDate, formatRelativeTime } = useDateFormatter();

  return (
    <div>
      <p>{formatDate(new Date())}</p>
      <p>{formatRelativeTime(new Date(Date.now() - 3600000))}</p>
    </div>
  );
}
```

## Using Toast Notifications

```typescript
import { useNotification } from '@/providers/notification-provider';

export default function MyComponent() {
  const { showSuccess, showError } = useNotification();

  const handleSave = async () => {
    try {
      // Save logic
      showSuccess('Saved successfully!');
    } catch (error) {
      showError('Failed to save');
    }
  };

  return <button onClick={handleSave}>Save</button>;
}
```

## Using Responsive Design

```typescript
import { useIsDesktop, useCurrentBreakpoint } from '@/hooks/use-media-query';

export default function ResponsiveComponent() {
  const isDesktop = useIsDesktop();
  const breakpoint = useCurrentBreakpoint();

  return (
    <div>
      {isDesktop ? (
        <DesktopLayout />
      ) : (
        <MobileLayout />
      )}
      <p>Current breakpoint: {breakpoint}</p>
    </div>
  );
}
```

## Using localStorage

```typescript
import { useLocalStorage } from '@/hooks/use-local-storage';

export default function PreferencesComponent() {
  const [theme, setTheme] = useLocalStorage<'light' | 'dark'>('theme', 'light');

  return (
    <button onClick={() => setTheme(theme === 'light' ? 'dark' : 'light')}>
      Current theme: {theme}
    </button>
  );
}
```

## Using Debounce

```typescript
import { useSearchDebounce } from '@/hooks/use-debounce';

export default function SearchComponent() {
  const { searchValue, setSearchValue, debouncedSearchValue } = useSearchDebounce('', 500);

  useEffect(() => {
    // Search with debouncedSearchValue
    console.log('Searching for:', debouncedSearchValue);
  }, [debouncedSearchValue]);

  return (
    <input
      value={searchValue}
      onChange={(e) => setSearchValue(e.target.value)}
      placeholder="Search..."
    />
  );
}
```

## Using Keyboard Shortcuts

```typescript
import { useCommonShortcuts } from '@/hooks/use-keyboard-shortcut';

export default function EditorComponent() {
  const { useCtrlS, useEscapeKey } = useCommonShortcuts();

  useCtrlS(() => {
    console.log('Saving...');
  });

  useEscapeKey(() => {
    console.log('Cancel');
  });

  return <editor />;
}
```

## Using Lazy Loading

```typescript
import { useLazyLoad } from '@/hooks/use-intersection-observer';

export default function LazyImage() {
  const { ref, isLoaded } = useLazyLoad(() => {
    console.log('Image is in viewport');
  });

  return (
    <div ref={ref}>
      {isLoaded && <img src="..." alt="..." />}
    </div>
  );
}
```

## Arabic Text Utilities

```typescript
import { useArabicUtils } from '@/hooks/use-locale';

export default function ArabicComponent() {
  const { 
    convertToArabicNumerals,
    gregorianToHijri,
    getArabicFamilyTerm,
    parseArabicName
  } = useArabicUtils();

  return (
    <div>
      <p>{convertToArabicNumerals('2024')}</p>
      <p>{gregorianToHijri(new Date())}</p>
      <p>{getArabicFamilyTerm('father')}</p>
    </div>
  );
}
```

## Environment Setup

Create `.env.local` if needed:
```
NEXT_PUBLIC_API_URL=http://localhost:3000
```

## Translation Keys Reference

Navigate through these namespaces:
- `common.*` - Common UI elements
- `navigation.*` - Navigation items
- `auth.*` - Authentication
- `family.*` - Family tree features
- `member.*` - Member information
- `relationship.*` - Relationship types
- `admin.*` - Admin features
- `settings.*` - Settings
- `validation.*` - Form validation
- `error.*` - Error messages
- `success.*` - Success messages

