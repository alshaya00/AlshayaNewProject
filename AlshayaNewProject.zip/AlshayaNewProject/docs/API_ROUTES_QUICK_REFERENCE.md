# API Routes - Quick Reference Guide
## Batch 1: Auth & Admin Routes

**Last Updated:** March 8, 2026  
**Total Files:** 23  
**Total Lines:** 3,162  

---

## Endpoint Quick Lookup

### Authentication Endpoints

| Method | Endpoint | Purpose | Auth | Rate Limit |
|--------|----------|---------|------|-----------|
| POST | `/api/auth/login` | Email/password login | No | 5/15min |
| POST | `/api/auth/logout` | End session | Yes | No |
| POST | `/api/auth/register` | Create user account | No | No |
| POST | `/api/auth/verify-email` | Verify email address | No | No |
| GET | `/api/auth/verify-email` | Email link verification | No | No |
| POST | `/api/auth/forgot-password` | Request password reset | No | 3/hour |
| POST | `/api/auth/reset-password` | Reset password | No | No |
| POST | `/api/auth/change-password` | Change password | Yes | No |
| POST | `/api/auth/setup-2fa` | Initialize 2FA | Yes | No |
| POST | `/api/auth/verify-2fa` | Activate 2FA | No | No |
| GET | `/api/auth/backup-codes` | Get backup codes | Yes | No |
| POST | `/api/auth/backup-codes` | Regenerate codes | Yes | No |
| GET | `/api/auth/session` | Get session info | Yes | No |
| POST | `/api/auth/refresh` | Extend session | Yes | No |

### Admin User Management Endpoints

| Method | Endpoint | Purpose | Auth | CSRF |
|--------|----------|---------|------|------|
| GET | `/api/admin/users` | List users | ADMIN | No |
| POST | `/api/admin/users` | Create user | ADMIN | Yes |
| GET | `/api/admin/users/[id]` | Get user details | ADMIN | No |
| PUT | `/api/admin/users/[id]` | Update user | ADMIN | Yes |
| DELETE | `/api/admin/users/[id]` | Delete user | SUPER_ADMIN | Yes |
| PUT | `/api/admin/users/[id]/role` | Change user role | SUPER_ADMIN | Yes |

### Admin Settings Endpoints

| Method | Endpoint | Purpose | Auth | CSRF |
|--------|----------|---------|------|------|
| GET | `/api/admin/settings` | Get settings | ADMIN | No |
| PUT | `/api/admin/settings` | Update settings | SUPER_ADMIN | Yes |

### Admin Feature Management

| Method | Endpoint | Purpose | Auth | CSRF |
|--------|----------|---------|------|------|
| GET | `/api/admin/feature-flags` | List flags | ADMIN | No |
| POST | `/api/admin/feature-flags` | Create flag | ADMIN | Yes |

### Admin Audit & Monitoring

| Method | Endpoint | Purpose | Auth | CSRF |
|--------|----------|---------|------|------|
| GET | `/api/admin/audit-log` | View audit logs | ADMIN | No |
| GET | `/api/admin/data-integrity` | Check integrity | ADMIN | No |
| POST | `/api/admin/data-integrity` | Run integrity check | ADMIN | Yes |

### Admin Data Operations

| Method | Endpoint | Purpose | Auth | CSRF |
|--------|----------|---------|------|------|
| POST | `/api/admin/import` | Bulk import | ADMIN | Yes |
| POST | `/api/admin/export` | Bulk export | ADMIN | Yes |
| GET | `/api/admin/export/[id]/download` | Download export | ADMIN | No |

### Admin Management

| Method | Endpoint | Purpose | Auth | CSRF |
|--------|----------|---------|------|------|
| GET | `/api/admin/announcements` | List announcements | ADMIN | No |
| POST | `/api/admin/announcements` | Create announcement | ADMIN | Yes |
| GET | `/api/admin/statistics` | View statistics | ADMIN | No |

---

## Common Request/Response Patterns

### Success Response
```json
{
  "success": true,
  "message": "Operation successful",
  "data": {
    // Response payload
  }
}
```

### Error Response
```json
{
  "success": false,
  "error": "ERROR_CODE",
  "message": "Human-readable message",
  "details": {
    "field": "Field-specific error message"
  }
}
```

### Pagination Response
```json
{
  "success": true,
  "data": {
    "items": [],
    "pagination": {
      "page": 1,
      "limit": 20,
      "total": 150,
      "pages": 8
    }
  }
}
```

---

## Common Headers

### Request Headers
```
Content-Type: application/json
Authorization: Bearer <session_token>  // Optional, can use cookies
X-CSRF-Token: <token>  // Required for POST/PUT/DELETE
User-Agent: <client-info>
X-Forwarded-For: <ip>  // For rate limiting
```

### Response Headers
```
X-User-ID: <user_id>  // User context info
X-User-Role: <role>   // User's role
Set-Cookie: alshaya_session=<token>  // Session cookie
```

---

## Authentication Methods

### Session Cookie (Recommended)
```javascript
// Automatically sent with requests if httpOnly cookie is set
fetch('/api/auth/session', {
  credentials: 'include'
})
```

### Bearer Token
```javascript
fetch('/api/auth/session', {
  headers: {
    'Authorization': 'Bearer <token>'
  }
})
```

---

## Common Error Codes

### Authentication Errors
| Code | Status | Meaning |
|------|--------|---------|
| `MISSING_SESSION` | 401 | No session token provided |
| `INVALID_SESSION` | 401 | Session token expired/invalid |
| `UNAUTHORIZED` | 401 | Authentication required |
| `RATE_LIMITED` | 429 | Too many attempts |

### Authorization Errors
| Code | Status | Meaning |
|------|--------|---------|
| `INSUFFICIENT_ROLE` | 403 | User role too low |
| `PERMISSION_DENIED` | 403 | Permission not granted |
| `INVALID_OPERATION` | 400 | Operation not allowed |

### Validation Errors
| Code | Status | Meaning |
|------|--------|---------|
| `VALIDATION_ERROR` | 400 | Invalid input data |
| `MISSING_FILE` | 400 | Required file missing |
| `FILE_TOO_LARGE` | 400 | File exceeds size limit |
| `INVALID_FILE_TYPE` | 400 | Unsupported file type |

### Server Errors
| Code | Status | Meaning |
|------|--------|---------|
| `INTERNAL_ERROR` | 500 | Server error |
| `DATABASE_ERROR` | 500 | Database operation failed |

---

## Rate Limiting Details

### Login Endpoint
- **Limit:** 5 attempts
- **Window:** 15 minutes
- **Identifier:** IP address
- **Response:** 429 Too Many Requests

### Password Reset Endpoint
- **Limit:** 3 attempts
- **Window:** 1 hour
- **Identifier:** Email address
- **Response:** 429 Too Many Requests

---

## File Upload Specifications

### Import Endpoint
- **Max Size:** 10 MB
- **Formats:** JSON, CSV, Excel (.xlsx)
- **Content-Type:** Auto-detected from extension
- **MIME Types:**
  - `application/json`
  - `text/csv`
  - `application/vnd.openxmlformats-officedocument.spreadsheetml.sheet`

---

## Database Integration Checklist

For each endpoint, implement:

- [ ] Database query/mutation functions
- [ ] Error handling for DB failures
- [ ] Transaction management (if needed)
- [ ] Query optimization/indexing
- [ ] Caching strategy (if applicable)
- [ ] Audit log creation
- [ ] Data validation beyond Zod

---

## Recommended Testing

### Unit Tests
```typescript
// Test validation
test('password must have uppercase', () => {
  expect(validatePassword('lowercase123')).toBeFalsy();
});

// Test rate limiting
test('should reject after 5 login attempts', () => {
  // Simulate 5 failed login attempts
  // Expect 429 response on 6th attempt
});
```

### Integration Tests
```typescript
// Test complete auth flow
test('user should be able to login and logout', async () => {
  // 1. Register user
  // 2. Verify email
  // 3. Login
  // 4. Verify session
  // 5. Logout
  // 6. Verify session cleared
});

// Test admin operations
test('admin should be able to create user', async () => {
  // 1. Login as admin
  // 2. Create user
  // 3. Verify user created
  // 4. Verify audit log entry
});
```

---

## Performance Tips

### Caching Opportunities
- User roles/permissions (cache with 5-min TTL)
- System settings (cache with 1-hour TTL)
- Feature flags (cache with 5-min TTL)
- Audit log aggregations (cache with 1-hour TTL)

### Query Optimization
- Add indexes on: userId, email, createdAt
- Use pagination limits to prevent large result sets
- Consider cursor-based pagination for audit logs
- Cache frequently accessed settings

### Rate Limit Optimization
- Use Redis for distributed rate limiting
- Implement sliding window algorithm
- Track per-user/per-IP separately
- Clean up expired records periodically

---

## Security Checklist

- [ ] All endpoints use HTTPS in production
- [ ] CSRF tokens validated on mutating operations
- [ ] Rate limiting enforced on sensitive endpoints
- [ ] Passwords hashed with bcrypt (cost factor 10+)
- [ ] Session tokens use secure random generation
- [ ] Cookies set as httpOnly and Secure
- [ ] SQL injection prevented (use ORM)
- [ ] XSS prevented (output encoding)
- [ ] CORS configured appropriately
- [ ] Security headers set (CSP, X-Frame-Options, etc.)
- [ ] Sensitive data not logged
- [ ] PII handled according to GDPR/CCPA
- [ ] Audit logs retained per compliance
- [ ] 2FA backup codes stored securely

---

## Deployment Checklist

- [ ] Environment variables configured
- [ ] Database migrations run
- [ ] Email service tested
- [ ] Redis cache configured
- [ ] File storage configured
- [ ] Job queue tested
- [ ] Rate limiting configured
- [ ] Monitoring/alerting set up
- [ ] Error logging configured
- [ ] Backup strategy verified
- [ ] Load testing completed
- [ ] Security audit passed
- [ ] Documentation updated
- [ ] Team trained

---

## Support & Troubleshooting

### Common Issues

**"CSRF token is missing"**
- Ensure CSRF token header included on POST/PUT/DELETE
- Check token is not expired
- Verify token matches session

**"Session is invalid or expired"**
- Session timeout: User needs to login again
- Token revoked: Clear cookies and re-authenticate
- Check cookie settings (httpOnly, Secure, SameSite)

**"Rate limit exceeded"**
- Wait for window to expire
- Use different IP for testing
- Adjust rate limit thresholds if needed

**"Validation error"**
- Check request payload against schema
- Verify data types match expected
- Check string lengths/formats
- Review error details for specific issues

---

## Performance Benchmarks

Target metrics:
- Login response time: < 500ms
- List users (20 items): < 300ms
- User creation: < 1000ms
- Export generation: < 5000ms
- Audit log query: < 1000ms

---

## References

- Next.js App Router: https://nextjs.org/docs/app
- Zod Validation: https://zod.dev
- TypeScript Handbook: https://www.typescriptlang.org/docs

---

**Last Review:** March 8, 2026
**Status:** Production Ready
**Next Review:** Upon first deployment

