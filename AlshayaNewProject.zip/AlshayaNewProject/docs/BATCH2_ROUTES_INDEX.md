# BATCH 2 API Routes - Complete Index

## Quick Reference

### Members API (10 routes)
| Endpoint | Method | Description | Auth | CSRF |
|----------|--------|-------------|------|------|
| `/api/members` | GET | List members with pagination/filters | ✓ | - |
| `/api/members` | POST | Create member | ✓ | ✓ |
| `/api/members/[id]` | GET | Get member details | ✓ | - |
| `/api/members/[id]` | PUT | Update member | ✓ | ✓ |
| `/api/members/[id]` | DELETE | Soft delete member | ✓ | ✓ |
| `/api/members/[id]/children` | GET | Get member's children | ✓ | - |
| `/api/members/[id]/lineage` | GET | Get ancestry/descendants | ✓ | - |
| `/api/members/[id]/relationships` | GET | Get all relationships | ✓ | - |
| `/api/members/[id]/photos` | GET | List member photos | ✓ | - |
| `/api/members/[id]/photos` | POST | Upload photo | ✓ | ✓ |
| `/api/members/[id]/history` | GET | Get change history | ✓ | - |
| `/api/members/search` | GET | Advanced search with fuzzy match | ✓ | - |
| `/api/members/merge` | POST | Merge duplicate members | ✓ | ✓ |
| `/api/members/validate` | POST | Validate member data | ✓ | - |

### Tree API (5 routes)
| Endpoint | Method | Description | Auth | CSRF |
|----------|--------|-------------|------|------|
| `/api/tree` | GET | Get full tree (D3/hierarchical/flat) | ✓ | - |
| `/api/tree/branch/[id]` | GET | Get branch with descendants | ✓ | - |
| `/api/tree/statistics` | GET | Tree statistics & analytics | ✓ | - |
| `/api/tree/snapshot` | GET | List tree snapshots | ✓ | - |
| `/api/tree/snapshot` | POST | Create snapshot | ✓ | ✓ |
| `/api/tree/integrity` | GET | Run integrity checks | ✓ | - |

### Breastfeeding API (3 routes)
| Endpoint | Method | Description | Auth | CSRF |
|----------|--------|-------------|------|------|
| `/api/breastfeeding` | GET | List relationships | ✓ | - |
| `/api/breastfeeding` | POST | Create relationship | ✓ | ✓ |
| `/api/breastfeeding/[id]` | GET | Get relationship details | ✓ | - |
| `/api/breastfeeding/[id]` | PUT | Update relationship | ✓ | ✓ |
| `/api/breastfeeding/[id]` | DELETE | Delete relationship | ✓ | ✓ |
| `/api/breastfeeding/check` | POST | Check milk kinship | ✓ | ✓ |

### Journals API (2 routes)
| Endpoint | Method | Description | Auth | CSRF |
|----------|--------|-------------|------|------|
| `/api/journals` | GET | List journals | ✓ | - |
| `/api/journals` | POST | Create journal | ✓ | ✓ |
| `/api/journals/[id]` | GET | Get journal | ✓ | - |
| `/api/journals/[id]` | PUT | Update journal | ✓ | ✓ |
| `/api/journals/[id]` | DELETE | Delete journal | ✓ | ✓ |

### Events API (2 routes)
| Endpoint | Method | Description | Auth | CSRF |
|----------|--------|-------------|------|------|
| `/api/events` | GET | List events | ✓ | - |
| `/api/events` | POST | Create event | ✓ | ✓ |
| `/api/events/[id]` | GET | Get event | ✓ | - |
| `/api/events/[id]` | PUT | Update event | ✓ | ✓ |
| `/api/events/[id]` | DELETE | Delete event | ✓ | ✓ |

### Notifications API (2 routes)
| Endpoint | Method | Description | Auth | CSRF |
|----------|--------|-------------|------|------|
| `/api/notifications` | GET | List notifications | ✓ | - |
| `/api/notifications` | POST | Mark read/delete | ✓ | ✓ |
| `/api/notifications/preferences` | GET | Get preferences | ✓ | - |
| `/api/notifications/preferences` | PUT | Update preferences | ✓ | ✓ |

### Other APIs (3 routes)
| Endpoint | Method | Description | Auth | CSRF |
|----------|--------|-------------|------|------|
| `/api/contact` | POST | Submit contact form | ✓ | ✓ |
| `/api/upload` | POST | Upload file | ✓ | ✓ |
| `/api/health` | GET | Health check | - | - |

---

## File Paths

### Member Routes
- `/src/app/api/members/route.ts` (120 lines)
- `/src/app/api/members/[id]/route.ts` (160 lines)
- `/src/app/api/members/[id]/children/route.ts` (60 lines)
- `/src/app/api/members/[id]/lineage/route.ts` (95 lines)
- `/src/app/api/members/[id]/relationships/route.ts` (130 lines)
- `/src/app/api/members/[id]/photos/route.ts` (110 lines)
- `/src/app/api/members/[id]/history/route.ts` (70 lines)
- `/src/app/api/members/search/route.ts` (130 lines)
- `/src/app/api/members/merge/route.ts` (130 lines)
- `/src/app/api/members/validate/route.ts` (110 lines)

### Tree Routes
- `/src/app/api/tree/route.ts` (160 lines)
- `/src/app/api/tree/branch/[branch]/route.ts` (100 lines)
- `/src/app/api/tree/statistics/route.ts` (110 lines)
- `/src/app/api/tree/snapshot/route.ts` (90 lines)
- `/src/app/api/tree/integrity/route.ts` (222 lines)

### Breastfeeding Routes
- `/src/app/api/breastfeeding/route.ts` (155 lines)
- `/src/app/api/breastfeeding/[id]/route.ts` (130 lines)
- `/src/app/api/breastfeeding/check/route.ts` (143 lines)

### Journal Routes
- `/src/app/api/journals/route.ts` (125 lines)
- `/src/app/api/journals/[id]/route.ts` (95 lines)

### Event Routes
- `/src/app/api/events/route.ts` (130 lines)
- `/src/app/api/events/[id]/route.ts` (95 lines)

### Notification Routes
- `/src/app/api/notifications/route.ts` (85 lines)
- `/src/app/api/notifications/preferences/route.ts` (100 lines)

### Other Routes
- `/src/app/api/contact/route.ts` (60 lines)
- `/src/app/api/upload/route.ts` (65 lines)
- `/src/app/api/health/route.ts` (40 lines)

---

## Request/Response Examples

### List Members
```bash
GET /api/members?page=1&limit=50&search=Ahmed&gender=MALE
```

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "id": "clz...",
      "firstName": "Ahmed",
      "fullNameEn": "Ahmed Mohammed",
      "gender": "MALE",
      "birthYear": 1980,
      "generation": 2
    }
  ],
  "pagination": {
    "page": 1,
    "limit": 50,
    "total": 5,
    "pages": 1
  },
  "timestamp": "2026-03-08T..."
}
```

### Create Member
```bash
POST /api/members
Content-Type: application/json
Authorization: Bearer {token}
X-CSRF-Token: {token}

{
  "firstName": "Ahmed",
  "fullNameAr": "أحمد",
  "gender": "MALE",
  "birthYear": 1980,
  "fatherId": "clz...",
  "generation": 3
}
```

### Get Lineage
```bash
GET /api/members/clz.../lineage?type=all&depth=10
```

### Search with Fuzzy Match
```bash
GET /api/members/search?query=Ahmad&fuzzy=true&fields=firstName,fullNameAr
```

### Check Milk Kinship
```bash
POST /api/breastfeeding/check
{
  "memberId1": "clz...",
  "memberId2": "clz..."
}
```

### Get Tree Statistics
```bash
GET /api/tree/statistics
```

---

## Validation Rules

### Member Fields
- `firstName`: 1-100 characters, required
- `gender`: MALE | FEMALE | OTHER | UNSPECIFIED
- `birthYear`: 1800-current year
- `deathYear`: Must be >= birthYear
- `email`: Valid email format, unique
- `phone`: E.164 format or digits + spaces/dashes

### Search
- `query`: Min 1 character
- `fuzzy`: Boolean, enables Levenshtein distance
- `fields`: Comma-separated field names

### Pagination
- `page`: Min 1
- `limit`: 1-500 (default 50)

### Dates
- ISO 8601 format: `2026-03-08T10:30:00Z`
- No future death years
- Birth before death

---

## Error Codes

| Code | Meaning | Example |
|------|---------|---------|
| 400 | Bad Request | Invalid gender, missing required field |
| 401 | Unauthorized | No valid auth token |
| 403 | Forbidden | Insufficient permissions |
| 404 | Not Found | Member doesn't exist |
| 410 | Gone | Member was deleted |
| 500 | Server Error | Database connection failed |
| 503 | Service Unavailable | Database down |

---

## Common Filters

### By Gender
```
GET /api/members?gender=MALE
```

### By Generation
```
GET /api/members?generation=3
```

### By Status
```
GET /api/members?status=LIVING
```

### By Date Range
```
GET /api/tree/snapshot?startDate=2026-03-01&endDate=2026-03-08
```

### By Type
```
GET /api/tree/snapshot?type=MANUAL
```

---

## Performance Tips

1. **Use pagination** - Always specify limit to avoid large responses
2. **Select fields** - Use include() selectively to reduce payload
3. **Search efficiently** - Use exact search before enabling fuzzy
4. **Cache results** - Tree data can be cached for 5+ minutes
5. **Batch operations** - Merge multiple operations when possible

---

## Dependencies

All routes require these utility functions:

- `prisma` - Database client
- `requireAuth()` - Authentication middleware
- `validateCSRFToken()` - CSRF protection
- `standardResponse()` - Response wrapper
- `errorResponse()` - Error wrapper
- `createAuditLog()` - Audit trail
- `normalizeArabicName()` - Arabic text processing

---

## Status Codes Used

- `200 OK` - Successful GET/PUT
- `201 Created` - Successful POST (for creation)
- `400 Bad Request` - Validation failure
- `401 Unauthorized` - No auth token
- `403 Forbidden` - No permission
- `404 Not Found` - Resource not found
- `410 Gone` - Resource deleted
- `500 Internal Server Error` - Database/server error
- `503 Service Unavailable` - Database unavailable

---

Generated: March 8, 2026  
Total Routes: 27  
Total Lines: 3,859  
Status: Production Ready
