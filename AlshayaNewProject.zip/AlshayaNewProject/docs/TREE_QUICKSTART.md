# Family Tree Visualization - Quick Start Guide

## Installation

### 1. Ensure D3.js is installed
```bash
npm install d3
```

### 2. Files are already in place at
```
src/components/tree/
├── FamilyTree.tsx              # Main component
├── TreeControls.tsx             # Control panel
├── TreeLegend.tsx              # Color legend
├── TreeLink.tsx                # Connection lines
├── TreeMiniMap.tsx             # Overview map
├── TreeNode.tsx                # Individual nodes
├── TreeSearch.tsx              # Search interface
├── types.ts                    # TypeScript types
├── index.ts                    # Barrel export
├── hooks/
│   ├── useTreeData.ts          # Data hook
│   ├── useTreeZoom.ts          # Zoom hook
│   └── useTreeLayout.ts        # Layout hook
├── utils/
│   └── tree-helpers.ts         # Utility functions
└── README.md                   # Full documentation
```

## Basic Usage

### Simple Implementation
```tsx
'use client';

import { FamilyTree } from '@/components/tree';
import type { FamilyMember } from '@/lib/types';
import { useEffect, useState } from 'react';

export default function FamilyTreePage() {
  const [members, setMembers] = useState<FamilyMember[]>([]);

  useEffect(() => {
    fetch('/api/family-members')
      .then(res => res.json())
      .then(setMembers);
  }, []);

  return (
    <div className="h-screen">
      <FamilyTree
        members={members}
        height={window.innerHeight}
      />
    </div>
  );
}
```

### With Selection Handler
```tsx
export default function FamilyTreePage() {
  const [members, setMembers] = useState<FamilyMember[]>([]);
  const [selected, setSelected] = useState<FamilyMember | null>(null);

  return (
    <div className="space-y-4">
      <FamilyTree
        members={members}
        onSelectMember={setSelected}
        highlightedId={selected?.id}
      />

      {selected && (
        <div className="p-4 bg-white rounded-lg shadow">
          <h2>{selected.firstName}</h2>
          <p>{selected.fullNameAr}</p>
        </div>
      )}
    </div>
  );
}
```

## Common Customizations

### Change Default Layout
```tsx
<FamilyTree
  members={members}
  defaultLayout="horizontal"  // or 'vertical', 'radial'
/>
```

### Change Default Colors
```tsx
<FamilyTree
  members={members}
  defaultColorMode="lineage"  // or 'generation', 'gender'
/>
```

### Hide Controls or Legend
```tsx
<FamilyTree
  members={members}
  showControls={false}
  showLegend={false}
/>
```

### Custom Height
```tsx
<FamilyTree
  members={members}
  height={1000}  // pixels
/>
```

### Highlight a Member
```tsx
<FamilyTree
  members={members}
  highlightedId="member-123"
/>
```

### Current User Indicator
```tsx
<FamilyTree
  members={members}
  currentUserId="current-user-id"
/>
```

## Advanced Usage

### Using Individual Components
```tsx
import {
  TreeControls,
  TreeLegend,
  TreeSearch,
  TreeMiniMap,
} from '@/components/tree';

export default function CustomTree() {
  return (
    <div className="relative h-screen">
      <svg ref={svgRef} className="w-full h-full">
        {/* Your custom rendering */}
      </svg>

      <TreeControls
        onZoomIn={() => {}}
        onZoomOut={() => {}}
        currentZoom={1}
      />

      <TreeLegend colorMode="generation" />

      <TreeSearch
        members={members}
        onResultSelect={(member) => {}}
      />

      <TreeMiniMap
        nodes={nodes}
        viewportWidth={800}
        viewportHeight={600}
        currentZoom={1}
        currentPanX={0}
        currentPanY={0}
      />
    </div>
  );
}
```

### Using Hooks
```tsx
import {
  useTreeData,
  useTreeZoom,
  useTreeLayout,
} from '@/components/tree';

export default function CustomImplementation() {
  const { treeData, members, loading } = useTreeData();
  const { nodes, links, bounds } = useTreeLayout(treeData);
  const { currentZoom, zoomIn, zoomOut } = useTreeZoom(svgRef, gRef, nodes);

  return (
    <div>
      {loading && <p>Loading...</p>}
      <button onClick={zoomIn}>Zoom In</button>
      <button onClick={zoomOut}>Zoom Out</button>
      <p>Current zoom: {Math.round(currentZoom * 100)}%</p>
    </div>
  );
}
```

### Using Utilities
```tsx
import {
  buildTreeHierarchy,
  searchTreeNodes,
  exportTreeAsJSON,
  getDescendants,
} from '@/components/tree';

const tree = buildTreeHierarchy(members);
const results = searchTreeNodes(members, 'Ahmed');
const json = exportTreeAsJSON(tree);
const descendants = getDescendants(tree);
```

## API Endpoints Needed

Your backend should provide:

### Get All Members
```
GET /api/family-members
Response: FamilyMember[]
```

### Get Branch Members
```
GET /api/family-members?branchHeadId=member-id
Response: FamilyMember[]
```

Example response:
```json
[
  {
    "id": "member-1",
    "firstName": "أحمد",
    "fullNameAr": "أحمد بن محمد",
    "generation": 2,
    "gender": "Male",
    "birthYear": 1960,
    "fatherId": null,
    "sonsCount": 3,
    "daughtersCount": 2,
    "photoUrl": "/photos/member-1.jpg",
    "city": "الرياض"
  }
]
```

## Styling Customization

### Override Colors
Edit `FamilyTree.tsx`:
```tsx
const GENERATION_COLORS = {
  1: {
    primary: '#your-color',
    secondary: '#lighter-shade',
    gradient: ['#color1', '#color2'] as [string, string],
  },
  // ... more generations
};
```

### Tailwind Configuration
Ensure Tailwind CSS is configured in your `tailwind.config.ts`:
```ts
export default {
  content: [
    './src/components/tree/**/*.{js,ts,jsx,tsx}',
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
```

## Troubleshooting

### Tree Not Displaying
1. Check if `members` array is populated
2. Verify API endpoint is returning data
3. Check browser console for JavaScript errors
4. Ensure D3.js is installed

### Performance Issues
- Reduce number of members with filters
- Use incremental loading hook for large datasets
- Disable animations on mobile
- Try horizontal layout for wide shallow trees

### SVG Not Rendering
- Check SVG width/height props
- Verify ref is properly connected
- Check for CSS overflow issues
- Clear browser cache

### Search Not Working
- Verify members array has `firstName` field
- Check search query is not empty
- Ensure `onResultSelect` callback is defined
- Check fuzzy matching threshold (>0.4)

## Performance Tips

### For Large Trees (5,000+ nodes)
```tsx
// Use virtual rendering
const { visibleNodes, expandAll } = useIncrementalTreeData();

// Implement pagination
const [page, setPage] = useState(0);
const pageSize = 100;
const paginatedMembers = members.slice(page * pageSize, (page + 1) * pageSize);
```

### Mobile Optimization
```tsx
<FamilyTree
  members={members}
  height={window.innerHeight}
  defaultLayout="vertical"
  showControls={true}
  showLegend={true}
/>
```

### Caching
```tsx
// Cache fetched data
const cache = new Map();

const fetchMembers = async (id: string) => {
  if (cache.has(id)) return cache.get(id);
  const data = await fetch(`/api/family-members?id=${id}`).then(r => r.json());
  cache.set(id, data);
  return data;
};
```

## Testing

### Example Jest Test
```tsx
import { render, screen } from '@testing-library/react';
import { FamilyTree } from '@/components/tree';

const mockMembers = [
  {
    id: '1',
    firstName: 'Ahmed',
    generation: 1,
    gender: 'Male',
    // ... other fields
  },
];

test('renders family tree', () => {
  render(<FamilyTree members={mockMembers} />);
  expect(screen.getByText('Ahmed')).toBeInTheDocument();
});
```

## Export Features

### Export as PNG
Click the export button and select PNG. Requires canvas support.

### Export as SVG
Select SVG for vector format (scalable, editable in graphic programs).

### Export as JSON
Get structured data for processing or import elsewhere.

## Keyboard Shortcuts

- `+` : Zoom in
- `-` : Zoom out
- `0` : Reset view
- `F` : Fit to screen
- `Ctrl+F` or `Cmd+F` : Open search

## Browser DevTools Tips

### Debug D3 Transforms
```js
// In console:
d3.selectAll('.nodes circle').style('fill', 'red');
d3.selectAll('.links path').style('stroke-width', '5px');
```

### Inspect Tree Data
```js
// In console:
console.log(treeData);
console.log(nodes);
console.log(links);
```

### Performance Monitoring
```js
// Check rendering performance
console.time('tree-render');
// ... tree renders
console.timeEnd('tree-render');
```

## Support

For issues or questions:
1. Check the full README.md in `/src/components/tree/`
2. Review the component prop interfaces in types.ts
3. Check helper function documentation in tree-helpers.ts
4. Review React hooks documentation in hooks/

## Next Steps

1. Import FamilyTree in your page component
2. Connect your API endpoint
3. Test with sample data
4. Customize colors and layout as needed
5. Deploy with confidence - code is production-ready!

---

**Ready to go!** The tree visualization is fully functional and can be used immediately. Refer to README.md for advanced customization and features.
