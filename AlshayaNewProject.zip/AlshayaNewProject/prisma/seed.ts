// ============================================================================
// AL-SHAYA FAMILY TREE - DATABASE SEED
// ============================================================================
// Comprehensive seed script with:
// - Default roles and permissions
// - Super admin user (bcrypt hashed password)
// - Sample family data (5 generations, ~50 members)
// - Feature flags and system settings
// ============================================================================

import { PrismaClient } from "@prisma/client";
import * as bcrypt from "bcryptjs";

const prisma = new PrismaClient();

// ============================================================================
// HELPERS
// ============================================================================

/**
 * Hash password using bcrypt
 */
async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, 12);
}

/**
 * Generate a unique member ID
 */
function generateMemberId(index: number): string {
  return `P${String(index + 1).padStart(4, "0")}`;
}

// ============================================================================
// MAIN SEED FUNCTION
// ============================================================================

async function main() {
  console.log("Starting database seed...\n");

  try {
    // ========== STEP 1: CREATE ROLES ==========
    console.log("Creating roles...");

    const roles = await Promise.all([
      prisma.role.upsert({
        where: { name: "SUPER_ADMIN" },
        update: {},
        create: {
          name: "SUPER_ADMIN",
          description: "Super administrator with full system access",
          isSystemRole: true,
          isActive: true,
        },
      }),
      prisma.role.upsert({
        where: { name: "ADMIN" },
        update: {},
        create: {
          name: "ADMIN",
          description: "Administrator with management access",
          isSystemRole: true,
          isActive: true,
        },
      }),
      prisma.role.upsert({
        where: { name: "BRANCH_LEADER" },
        update: {},
        create: {
          name: "BRANCH_LEADER",
          description: "Branch leader responsible for a lineage branch",
          isSystemRole: true,
          isActive: true,
        },
      }),
      prisma.role.upsert({
        where: { name: "MEMBER" },
        update: {},
        create: {
          name: "MEMBER",
          description: "Regular family member with viewing and editing access",
          isSystemRole: true,
          isActive: true,
        },
      }),
      prisma.role.upsert({
        where: { name: "GUEST" },
        update: {},
        create: {
          name: "GUEST",
          description: "Guest with read-only access",
          isSystemRole: true,
          isActive: true,
        },
      }),
    ]);

    console.log(`✓ Created ${roles.length} roles\n`);

    // ========== STEP 2: CREATE PERMISSIONS ==========
    console.log("Creating permissions...");

    const permissionCategories = [
      "FAMILY_TREE",
      "MEDIA",
      "JOURNALS",
      "GATHERINGS",
      "ADMIN",
      "USERS",
      "SYSTEM",
      "REPORTS",
    ] as const;

    const permissionsData = [
      // FAMILY_TREE permissions
      {
        key: "FAMILY_TREE_VIEW",
        labelAr: "عرض شجرة العائلة",
        labelEn: "View Family Tree",
        category: "FAMILY_TREE",
      },
      {
        key: "FAMILY_TREE_EDIT",
        labelAr: "تعديل شجرة العائلة",
        labelEn: "Edit Family Tree",
        category: "FAMILY_TREE",
      },
      {
        key: "FAMILY_TREE_DELETE",
        labelAr: "حذف من شجرة العائلة",
        labelEn: "Delete from Family Tree",
        category: "FAMILY_TREE",
      },
      {
        key: "MEMBER_VIEW",
        labelAr: "عرض بيانات الفرد",
        labelEn: "View Member Details",
        category: "FAMILY_TREE",
      },
      {
        key: "MEMBER_EDIT",
        labelAr: "تعديل بيانات الفرد",
        labelEn: "Edit Member Details",
        category: "FAMILY_TREE",
      },
      {
        key: "MEMBER_DELETE",
        labelAr: "حذف الفرد",
        labelEn: "Delete Member",
        category: "FAMILY_TREE",
      },
      {
        key: "BREASTFEEDING_MANAGE",
        labelAr: "إدارة علاقات الرضاعة",
        labelEn: "Manage Breastfeeding Relationships",
        category: "FAMILY_TREE",
      },
      // MEDIA permissions
      {
        key: "PHOTO_VIEW",
        labelAr: "عرض الصور",
        labelEn: "View Photos",
        category: "MEDIA",
      },
      {
        key: "PHOTO_UPLOAD",
        labelAr: "رفع الصور",
        labelEn: "Upload Photos",
        category: "MEDIA",
      },
      {
        key: "PHOTO_MODERATE",
        labelAr: "مراجعة الصور",
        labelEn: "Moderate Photos",
        category: "MEDIA",
      },
      // JOURNALS permissions
      {
        key: "JOURNAL_VIEW",
        labelAr: "عرض السجلات",
        labelEn: "View Journals",
        category: "JOURNALS",
      },
      {
        key: "JOURNAL_CREATE",
        labelAr: "إنشاء سجل",
        labelEn: "Create Journal",
        category: "JOURNALS",
      },
      {
        key: "JOURNAL_EDIT",
        labelAr: "تعديل السجل",
        labelEn: "Edit Journal",
        category: "JOURNALS",
      },
      {
        key: "JOURNAL_PUBLISH",
        labelAr: "نشر السجل",
        labelEn: "Publish Journal",
        category: "JOURNALS",
      },
      // GATHERINGS permissions
      {
        key: "GATHERING_VIEW",
        labelAr: "عرض التجمعات",
        labelEn: "View Gatherings",
        category: "GATHERINGS",
      },
      {
        key: "GATHERING_CREATE",
        labelAr: "إنشاء تجمع",
        labelEn: "Create Gathering",
        category: "GATHERINGS",
      },
      {
        key: "GATHERING_MANAGE",
        labelAr: "إدارة التجمعات",
        labelEn: "Manage Gatherings",
        category: "GATHERINGS",
      },
      // ADMIN permissions
      {
        key: "ADMIN_USERS",
        labelAr: "إدارة المستخدمين",
        labelEn: "Manage Users",
        category: "ADMIN",
      },
      {
        key: "ADMIN_ROLES",
        labelAr: "إدارة الأدوار والصلاحيات",
        labelEn: "Manage Roles and Permissions",
        category: "ADMIN",
      },
      {
        key: "ADMIN_SETTINGS",
        labelAr: "إدارة الإعدادات",
        labelEn: "Manage System Settings",
        category: "ADMIN",
      },
      // USERS permissions
      {
        key: "USER_PROFILE_VIEW",
        labelAr: "عرض الملف الشخصي",
        labelEn: "View User Profile",
        category: "USERS",
      },
      {
        key: "USER_PROFILE_EDIT",
        labelAr: "تعديل الملف الشخصي",
        labelEn: "Edit User Profile",
        category: "USERS",
      },
      // SYSTEM permissions
      {
        key: "IMPORT_DATA",
        labelAr: "استيراد البيانات",
        labelEn: "Import Data",
        category: "SYSTEM",
      },
      {
        key: "EXPORT_DATA",
        labelAr: "تصدير البيانات",
        labelEn: "Export Data",
        category: "SYSTEM",
      },
      {
        key: "VIEW_AUDIT_LOGS",
        labelAr: "عرض سجلات التدقيق",
        labelEn: "View Audit Logs",
        category: "SYSTEM",
      },
      // REPORTS permissions
      {
        key: "REPORT_VIEW",
        labelAr: "عرض التقارير",
        labelEn: "View Reports",
        category: "REPORTS",
      },
      {
        key: "REPORT_GENERATE",
        labelAr: "إنشاء تقارير",
        labelEn: "Generate Reports",
        category: "REPORTS",
      },
    ];

    const permissions = await Promise.all(
      permissionsData.map((perm) =>
        prisma.permission.upsert({
          where: { key: perm.key },
          update: {},
          create: {
            key: perm.key,
            labelAr: perm.labelAr,
            labelEn: perm.labelEn,
            category: perm.category as any,
            isActive: true,
          },
        })
      )
    );

    console.log(`✓ Created ${permissions.length} permissions\n`);

    // ========== STEP 3: ASSIGN PERMISSIONS TO ROLES ==========
    console.log("Assigning permissions to roles...");

    // Super Admin gets all permissions
    const superAdminRole = roles.find((r) => r.name === "SUPER_ADMIN")!;
    for (const permission of permissions) {
      await prisma.rolePermission.upsert({
        where: {
          roleId_permissionId: {
            roleId: superAdminRole.id,
            permissionId: permission.id,
          },
        },
        update: {},
        create: {
          roleId: superAdminRole.id,
          permissionId: permission.id,
          allowed: true,
        },
      });
    }

    // Admin role gets most permissions (except ROLE management)
    const adminRole = roles.find((r) => r.name === "ADMIN")!;
    const adminPermissions = permissions.filter(
      (p) => p.key !== "ADMIN_ROLES"
    );
    for (const permission of adminPermissions) {
      await prisma.rolePermission.upsert({
        where: {
          roleId_permissionId: {
            roleId: adminRole.id,
            permissionId: permission.id,
          },
        },
        update: {},
        create: {
          roleId: adminRole.id,
          permissionId: permission.id,
          allowed: true,
        },
      });
    }

    // Member role gets basic permissions
    const memberRole = roles.find((r) => r.name === "MEMBER")!;
    const memberPermissions = permissions.filter((p) =>
      [
        "FAMILY_TREE_VIEW",
        "MEMBER_VIEW",
        "PHOTO_VIEW",
        "PHOTO_UPLOAD",
        "JOURNAL_VIEW",
        "JOURNAL_CREATE",
        "GATHERING_VIEW",
        "USER_PROFILE_VIEW",
        "USER_PROFILE_EDIT",
        "EXPORT_DATA",
      ].includes(p.key)
    );
    for (const permission of memberPermissions) {
      await prisma.rolePermission.upsert({
        where: {
          roleId_permissionId: {
            roleId: memberRole.id,
            permissionId: permission.id,
          },
        },
        update: {},
        create: {
          roleId: memberRole.id,
          permissionId: permission.id,
          allowed: true,
        },
      });
    }

    // Guest role gets view-only permissions
    const guestRole = roles.find((r) => r.name === "GUEST")!;
    const guestPermissions = permissions.filter((p) =>
      [
        "FAMILY_TREE_VIEW",
        "MEMBER_VIEW",
        "PHOTO_VIEW",
        "JOURNAL_VIEW",
        "GATHERING_VIEW",
      ].includes(p.key)
    );
    for (const permission of guestPermissions) {
      await prisma.rolePermission.upsert({
        where: {
          roleId_permissionId: {
            roleId: guestRole.id,
            permissionId: permission.id,
          },
        },
        update: {},
        create: {
          roleId: guestRole.id,
          permissionId: permission.id,
          allowed: true,
        },
      });
    }

    console.log("✓ Assigned permissions to roles\n");

    // ========== STEP 4: CREATE SUPER ADMIN USER ==========
    console.log("Creating super admin user...");

    const superAdminPassword = "Admin@2024Secure!";
    const superAdminPasswordHash = await hashPassword(superAdminPassword);

    const superAdminUser = await prisma.user.upsert({
      where: { email: "admin@alshaya.local" },
      update: {},
      create: {
        email: "admin@alshaya.local",
        passwordHash: superAdminPasswordHash,
        nameArabic: "الإدارة العليا",
        nameEnglish: "Super Administrator",
        role: "SUPER_ADMIN",
        status: "ACTIVE",
        emailVerifiedAt: new Date(),
        verificationStatus: "VERIFIED",
      },
    });

    console.log(`✓ Created super admin user: ${superAdminUser.email}`);
    console.log(`  Temporary password: ${superAdminPassword}`);
    console.log(`  (Please change on first login)\n`);

    // ========== STEP 5: CREATE SYSTEM SETTINGS ==========
    console.log("Creating system settings...");

    const systemSettings = [
      {
        key: "FAMILY_NAME_ARABIC",
        value: "آل شايع",
        description: "Family name in Arabic",
      },
      {
        key: "FAMILY_NAME_ENGLISH",
        value: "Al-Shaya",
        description: "Family name in English",
      },
      {
        key: "FAMILY_TAGLINE_ARABIC",
        value: "نحفظ إرثنا، نربط أجيالنا",
        description: "Family tagline in Arabic",
      },
      {
        key: "FAMILY_TAGLINE_ENGLISH",
        value: "Preserving Our Legacy, Connecting Generations",
        description: "Family tagline in English",
      },
      {
        key: "DEFAULT_LANGUAGE",
        value: "ar",
        description: "Default UI language",
      },
      {
        key: "SESSION_DURATION_DAYS",
        value: "7",
        description: "Default session duration in days",
      },
      {
        key: "REQUIRE_EMAIL_VERIFICATION",
        value: "false",
        description: "Whether to require email verification",
      },
      {
        key: "REQUIRE_APPROVAL_FOR_REGISTRATION",
        value: "true",
        description: "Whether to require admin approval for new registrations",
      },
      {
        key: "MAX_LOGIN_ATTEMPTS",
        value: "5",
        description: "Maximum failed login attempts before lockout",
      },
      {
        key: "LOCKOUT_DURATION_MINUTES",
        value: "15",
        description: "Account lockout duration in minutes",
      },
      {
        key: "REQUIRE_2FA_FOR_ADMINS",
        value: "true",
        description: "Whether admins must enable 2FA",
      },
      {
        key: "MIN_PASSWORD_LENGTH",
        value: "8",
        description: "Minimum password length",
      },
      {
        key: "ALLOW_GUEST_PREVIEW",
        value: "true",
        description: "Whether to allow guest preview of tree",
      },
      {
        key: "ALLOW_SELF_REGISTRATION",
        value: "true",
        description: "Whether to allow self-registration",
      },
    ];

    for (const setting of systemSettings) {
      await prisma.systemSetting.upsert({
        where: { key: setting.key },
        update: { value: setting.value },
        create: {
          key: setting.key,
          value: setting.value,
          valueType: "STRING",
          description: setting.description,
        },
      });
    }

    console.log(`✓ Created ${systemSettings.length} system settings\n`);

    // ========== STEP 6: CREATE FEATURE FLAGS ==========
    console.log("Creating feature flags...");

    await prisma.featureFlag.upsert({
      where: { id: "default" },
      update: {},
      create: {
        familyTree: true,
        registry: true,
        journals: true,
        gallery: true,
        gatherings: true,
        dashboard: true,
        search: true,
        branches: true,
        quickAdd: true,
        importData: true,
        exportData: true,
        treeEditor: true,
        duplicates: true,
        changeHistory: true,
        registration: true,
        invitations: true,
        accessRequests: true,
        profiles: true,
        breastfeeding: true,
        branchEntries: true,
        onboarding: true,
        imageModeration: true,
        broadcasts: true,
        reports: true,
        audit: true,
        apiServices: true,
      },
    });

    console.log("✓ Created feature flags\n");

    // ========== STEP 7: CREATE SAMPLE FAMILY DATA ==========
    console.log("Creating sample family data (5 generations, ~50 members)...");

    // Generation 1: Founder
    const gen1 = await prisma.familyMember.create({
      data: {
        id: generateMemberId(0),
        firstName: "محمد",
        familyName: "آل شايع",
        fullNameAr: "محمد آل شايع",
        gender: "MALE",
        birthYear: 1900,
        generation: 1,
        branch: "الفرع الرئيسي",
        status: "DECEASED",
        deathYear: 1980,
        createdBy: "system",
        lastModifiedBy: "system",
      },
    });

    // Generation 2: Children of founder
    const gen2: any[] = [];
    for (let i = 0; i < 3; i++) {
      const member = await prisma.familyMember.create({
        data: {
          id: generateMemberId(i + 1),
          firstName: `عبدالرحمن${i === 0 ? "" : i + 1}`,
          fatherId: gen1.id,
          familyName: "آل شايع",
          fullNameAr: `عبدالرحمن${i === 0 ? "" : i + 1} محمد آل شايع`,
          gender: i === 0 ? "MALE" : "MALE",
          birthYear: 1925 + i * 2,
          generation: 2,
          branch: `فرع ${i + 1}`,
          status: i === 0 ? "DECEASED" : "LIVING",
          createdBy: "system",
          lastModifiedBy: "system",
        },
      });
      gen2.push(member);
    }

    // Generation 3: Grandchildren
    const gen3: any[] = [];
    let memberIndex = 4;
    for (const parent of gen2) {
      for (let i = 0; i < 3; i++) {
        const member = await prisma.familyMember.create({
          data: {
            id: generateMemberId(memberIndex),
            firstName: `أحمد${i === 0 ? "" : i + 1}`,
            fatherId: parent.id,
            familyName: "آل شايع",
            fullNameAr: `أحمد${i === 0 ? "" : i + 1} عبدالرحمن آل شايع`,
            gender: "MALE",
            birthYear: 1950 + memberIndex,
            generation: 3,
            branch: parent.branch,
            status: "LIVING",
            createdBy: "system",
            lastModifiedBy: "system",
          },
        });
        gen3.push(member);
        memberIndex++;
      }
    }

    // Generation 4: Great-grandchildren
    const gen4: any[] = [];
    for (const parent of gen3) {
      const childCount = parent.id.charCodeAt(1) % 3;
      for (let i = 0; i < childCount + 1; i++) {
        const member = await prisma.familyMember.create({
          data: {
            id: generateMemberId(memberIndex),
            firstName: `سارة${i === 0 ? "" : i + 1}`,
            fatherId: parent.id,
            familyName: "آل شايع",
            fullNameAr: `سارة${i === 0 ? "" : i + 1} أحمد آل شايع`,
            gender: i === 0 ? "FEMALE" : "MALE",
            birthYear: 1980 + Math.floor(Math.random() * 20),
            generation: 4,
            branch: parent.branch,
            status: "LIVING",
            createdBy: "system",
            lastModifiedBy: "system",
          },
        });
        gen4.push(member);
        memberIndex++;
      }
    }

    // Generation 5: Great-great-grandchildren
    const gen5: any[] = [];
    for (const parent of gen4) {
      const childCount = parent.id.charCodeAt(2) % 2;
      for (let i = 0; i < childCount + 1; i++) {
        const member = await prisma.familyMember.create({
          data: {
            id: generateMemberId(memberIndex),
            firstName: `علي${i === 0 ? "" : i + 1}`,
            fatherId: parent.id,
            familyName: "آل شايع",
            fullNameAr: `علي${i === 0 ? "" : i + 1} آل شايع`,
            gender: "MALE",
            birthYear: 2005 + Math.floor(Math.random() * 10),
            generation: 5,
            branch: parent.branch,
            status: "LIVING",
            createdBy: "system",
            lastModifiedBy: "system",
          },
        });
        gen5.push(member);
        memberIndex++;
      }
    }

    const totalMembers = 1 + gen2.length + gen3.length + gen4.length + gen5.length;
    console.log(`✓ Created ${totalMembers} family members (5 generations)\n`);

    // ========== STEP 8: UPDATE SIBLING COUNTS ==========
    console.log("Updating sibling counts...");

    // Count and update for each family
    const allGenerations = [gen2, gen3, gen4, gen5];
    for (const generation of allGenerations) {
      for (const member of generation) {
        const siblings = await prisma.familyMember.findMany({
          where: { fatherId: member.fatherId, deletedAt: null },
        });

        const sons = siblings.filter((s) => s.gender === "MALE").length;
        const daughters = siblings.filter((s) => s.gender === "FEMALE").length;

        await prisma.familyMember.update({
          where: { id: member.id },
          data: { sonsCount: sons, daughtersCount: daughters },
        });
      }
    }

    console.log("✓ Updated sibling counts\n");

    // ========== STEP 9: CREATE ALBUM FOLDERS ==========
    console.log("Creating album folders...");

    const albumFolders = await Promise.all([
      prisma.albumFolder.create({
        data: {
          name: "Family Photos",
          nameAr: "صور العائلة",
          color: "#6366f1",
          isSystem: true,
          displayOrder: 1,
          createdBy: "system",
          createdByName: "System",
        },
      }),
      prisma.albumFolder.create({
        data: {
          name: "Gatherings",
          nameAr: "التجمعات",
          color: "#ec4899",
          isSystem: true,
          displayOrder: 2,
          createdBy: "system",
          createdByName: "System",
        },
      }),
      prisma.albumFolder.create({
        data: {
          name: "Memories",
          nameAr: "الذكريات",
          color: "#f59e0b",
          isSystem: true,
          displayOrder: 3,
          createdBy: "system",
          createdByName: "System",
        },
      }),
      prisma.albumFolder.create({
        data: {
          name: "Historical",
          nameAr: "الصور التاريخية",
          color: "#8b5cf6",
          isSystem: true,
          displayOrder: 4,
          createdBy: "system",
          createdByName: "System",
        },
      }),
    ]);

    console.log(`✓ Created ${albumFolders.length} album folders\n`);

    // ========== STEP 10: CREATE SAMPLE GATHERING ==========
    console.log("Creating sample gathering...");

    const gathering = await prisma.gathering.create({
      data: {
        title: "Annual Family Gathering 2026",
        titleAr: "التجمع السنوي للعائلة 2026",
        description: "Annual gathering of the Al-Shaya family",
        descriptionAr: "التجمع السنوي لعائلة آل شايع",
        date: new Date("2026-06-15"),
        endDate: new Date("2026-06-17"),
        location: "Riyadh, Saudi Arabia",
        locationAr: "الرياض، المملكة العربية السعودية",
        type: "gathering",
        status: "UPCOMING",
        organizerId: gen2[0].id,
        organizerName: gen2[0].firstName,
        organizerNameAr: gen2[0].fullNameAr || gen2[0].firstName,
        isPublic: true,
        createdBy: "system",
      },
    });

    console.log(`✓ Created sample gathering\n`);

    // ========== STEP 11: CREATE SAMPLE JOURNAL ==========
    console.log("Creating sample journal...");

    const journal = await prisma.familyJournal.create({
      data: {
        titleAr: "الحكاية: حياة محمد آل شايع",
        titleEn: "Story: The Life of Muhammad Al-Shaya",
        contentAr:
          "محمد آل شايع كان مؤسس العائلة وكان رجلاً نبيلاً وشريفاً...",
        contentEn:
          "Muhammad Al-Shaya was the founder of the family and was a noble and honorable man...",
        category: "ORAL_HISTORY",
        era: "Early 20th Century",
        yearFrom: 1900,
        yearTo: 1980,
        primaryMemberId: gen1.id,
        status: "PUBLISHED",
        isFeatured: true,
        displayOrder: 1,
        authorId: "system",
        authorName: "Family Historian",
        reviewStatus: "APPROVED",
        createdBy: "system",
      },
    });

    console.log(`✓ Created sample journal\n`);

    // ========== COMPLETION MESSAGE ==========
    console.log("=" + "=".repeat(78));
    console.log("DATABASE SEEDING COMPLETED SUCCESSFULLY!");
    console.log("=" + "=".repeat(78) + "\n");

    console.log("Summary:");
    console.log(`  ✓ Roles: 5 (SUPER_ADMIN, ADMIN, BRANCH_LEADER, MEMBER, GUEST)`);
    console.log(`  ✓ Permissions: ${permissions.length}`);
    console.log(`  ✓ Super Admin User: admin@alshaya.local`);
    console.log(`  ✓ System Settings: ${systemSettings.length}`);
    console.log(`  ✓ Feature Flags: 1 (all enabled)`);
    console.log(`  ✓ Family Members: ${totalMembers} (5 generations)`);
    console.log(`  ✓ Album Folders: ${albumFolders.length}`);
    console.log(`  ✓ Sample Gathering: 1`);
    console.log(`  ✓ Sample Journal: 1\n`);

    console.log("Next Steps:");
    console.log(`  1. Run 'npm run dev' or 'npm start' to start the application`);
    console.log(`  2. Login with: admin@alshaya.local / ${superAdminPassword}`);
    console.log(`  3. Change the temporary password immediately`);
    console.log(`  4. Configure application settings in the admin panel`);
    console.log(`  5. Add more family members and customize the tree\n`);
  } catch (error) {
    console.error("ERROR during seeding:", error);
    throw error;
  } finally {
    await prisma.$disconnect();
  }
}

// ============================================================================
// EXECUTE SEED
// ============================================================================

main()
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
