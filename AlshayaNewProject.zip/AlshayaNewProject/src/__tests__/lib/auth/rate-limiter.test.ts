import {
  checkRateLimit,
  resetRateLimit,
  getRateLimitInfo,
  clearAllRateLimits,
  createRateLimitResponse,
  formatRateLimitError,
  RATE_LIMIT_CONFIG,
} from '@/lib/auth/rate-limiter';

describe('Rate Limiter', () => {
  beforeEach(() => {
    clearAllRateLimits();
    jest.clearAllMocks();
  });

  describe('checkRateLimit', () => {
    it('should allow first attempt', () => {
      const result = checkRateLimit('user-123', 'login');

      expect(result.allowed).toBe(true);
      expect(result.remaining).toBe(RATE_LIMIT_CONFIG.login.maxAttempts - 1);
    });

    it('should allow multiple attempts within limit', () => {
      const identifier = 'user-123';
      const maxAttempts = RATE_LIMIT_CONFIG.login.maxAttempts;

      for (let i = 0; i < maxAttempts; i++) {
        const result = checkRateLimit(identifier, 'login');
        expect(result.allowed).toBe(true);
      }
    });

    it('should block after exceeding max attempts', () => {
      const identifier = 'user-123';
      const maxAttempts = RATE_LIMIT_CONFIG.login.maxAttempts;

      // Make max + 1 attempts
      for (let i = 0; i <= maxAttempts; i++) {
        checkRateLimit(identifier, 'login');
      }

      const result = checkRateLimit(identifier, 'login');
      expect(result.allowed).toBe(false);
      expect(result.remaining).toBe(0);
      expect(result.blockedUntil).toBeDefined();
    });

    it('should apply exponential backoff', () => {
      const identifier = 'user-123';
      const maxAttempts = RATE_LIMIT_CONFIG.login.maxAttempts;

      // Exceed limit twice
      for (let i = 0; i < maxAttempts + 2; i++) {
        checkRateLimit(identifier, 'login');
      }

      const result = checkRateLimit(identifier, 'login');
      expect(result.retryAfter).toBeDefined();
      expect(result.retryAfter).toBeGreaterThan(0);
    });

    it('should track remaining attempts correctly', () => {
      const identifier = 'user-123';
      const maxAttempts = RATE_LIMIT_CONFIG.login.maxAttempts;

      for (let i = 0; i < maxAttempts; i++) {
        const result = checkRateLimit(identifier, 'login');
        expect(result.remaining).toBe(maxAttempts - (i + 1));
      }
    });

    it('should reset after time window expires', (done) => {
      const identifier = 'user-123';
      const windowMs = 100; // Short window for testing

      // This test would need to modify the rate limiter's internal window
      // For now, we test the behavior with actual window times
      const result1 = checkRateLimit(identifier, 'login');
      expect(result1.remaining).toBeLessThan(RATE_LIMIT_CONFIG.login.maxAttempts);

      setTimeout(() => {
        const result2 = checkRateLimit(identifier, 'login');
        // After window expires, remaining should be reset
        expect(result2.remaining).toBeLessThan(RATE_LIMIT_CONFIG.login.maxAttempts);
        done();
      }, 10);
    });

    it('should work with different limit types', () => {
      const identifier = 'user-123';

      const loginResult = checkRateLimit(identifier, 'login');
      expect(loginResult.remaining).toBe(RATE_LIMIT_CONFIG.login.maxAttempts - 1);

      const otpResult = checkRateLimit(identifier, 'otpVerification');
      expect(otpResult.remaining).toBe(RATE_LIMIT_CONFIG.otpVerification.maxAttempts - 1);
    });

    it('should have separate tracking per identifier', () => {
      const result1 = checkRateLimit('user-1', 'login');
      const result2 = checkRateLimit('user-2', 'login');

      expect(result1.remaining).toBe(result2.remaining);
    });

    it('should handle OTP verification limits', () => {
      const identifier = 'otp-123';
      const maxAttempts = RATE_LIMIT_CONFIG.otpVerification.maxAttempts;

      for (let i = 0; i < maxAttempts; i++) {
        const result = checkRateLimit(identifier, 'otpVerification');
        expect(result.allowed).toBe(true);
      }

      const result = checkRateLimit(identifier, 'otpVerification');
      expect(result.allowed).toBe(false);
    });

    it('should handle password reset limits', () => {
      const identifier = 'reset-123';
      const maxAttempts = RATE_LIMIT_CONFIG.passwordReset.maxAttempts;

      for (let i = 0; i < maxAttempts; i++) {
        const result = checkRateLimit(identifier, 'passwordReset');
        expect(result.allowed).toBe(true);
      }

      const result = checkRateLimit(identifier, 'passwordReset');
      expect(result.allowed).toBe(false);
    });

    it('should handle registration limits', () => {
      const identifier = 'email@example.com';
      const maxAttempts = RATE_LIMIT_CONFIG.registration.maxAttempts;

      for (let i = 0; i < maxAttempts; i++) {
        const result = checkRateLimit(identifier, 'registration');
        expect(result.allowed).toBe(true);
      }

      const result = checkRateLimit(identifier, 'registration');
      expect(result.allowed).toBe(false);
    });

    it('should track blocked duration correctly', () => {
      const identifier = 'user-123';
      const maxAttempts = RATE_LIMIT_CONFIG.login.maxAttempts;

      // Exceed limit
      for (let i = 0; i <= maxAttempts; i++) {
        checkRateLimit(identifier, 'login');
      }

      const result = checkRateLimit(identifier, 'login');
      expect(result.blockedUntil).toBeDefined();
      expect(result.blockedUntil).toBeGreaterThan(Date.now());
    });

    it('should return retry-after in seconds', () => {
      const identifier = 'user-123';
      const maxAttempts = RATE_LIMIT_CONFIG.login.maxAttempts;

      for (let i = 0; i <= maxAttempts; i++) {
        checkRateLimit(identifier, 'login');
      }

      const result = checkRateLimit(identifier, 'login');
      expect(result.retryAfter).toBeDefined();
      expect(typeof result.retryAfter).toBe('number');
      expect(result.retryAfter).toBeGreaterThan(0);
    });
  });

  describe('resetRateLimit', () => {
    it('should reset attempts for identifier', () => {
      const identifier = 'user-123';

      checkRateLimit(identifier, 'login');
      checkRateLimit(identifier, 'login');

      resetRateLimit(identifier);

      const result = checkRateLimit(identifier, 'login');
      expect(result.remaining).toBe(RATE_LIMIT_CONFIG.login.maxAttempts - 1);
    });

    it('should allow new attempts after reset', () => {
      const identifier = 'user-123';
      const maxAttempts = RATE_LIMIT_CONFIG.login.maxAttempts;

      // Exceed limit
      for (let i = 0; i <= maxAttempts; i++) {
        checkRateLimit(identifier, 'login');
      }

      let result = checkRateLimit(identifier, 'login');
      expect(result.allowed).toBe(false);

      // Reset and try again
      resetRateLimit(identifier);
      result = checkRateLimit(identifier, 'login');
      expect(result.allowed).toBe(true);
    });

    it('should not affect other identifiers', () => {
      const identifier1 = 'user-1';
      const identifier2 = 'user-2';

      checkRateLimit(identifier1, 'login');
      checkRateLimit(identifier2, 'login');

      resetRateLimit(identifier1);

      const result = checkRateLimit(identifier2, 'login');
      expect(result.remaining).toBeLessThan(RATE_LIMIT_CONFIG.login.maxAttempts);
    });
  });

  describe('getRateLimitInfo', () => {
    it('should return null for unknown identifier', () => {
      const info = getRateLimitInfo('unknown-123');
      expect(info).toBeNull();
    });

    it('should return attempt info for known identifier', () => {
      const identifier = 'user-123';
      checkRateLimit(identifier, 'login');

      const info = getRateLimitInfo(identifier);
      expect(info).not.toBeNull();
      expect(info?.count).toBe(1);
    });

    it('should track attempt count', () => {
      const identifier = 'user-123';

      checkRateLimit(identifier, 'login');
      checkRateLimit(identifier, 'login');

      const info = getRateLimitInfo(identifier);
      expect(info?.count).toBe(2);
    });

    it('should return last attempt time', () => {
      const identifier = 'user-123';
      const before = new Date();

      checkRateLimit(identifier, 'login');

      const info = getRateLimitInfo(identifier);
      expect(info?.lastAttemptTime).toBeDefined();
      expect(info?.lastAttemptTime?.getTime()).toBeGreaterThanOrEqual(before.getTime());
    });

    it('should return block time after exceeding limit', () => {
      const identifier = 'user-123';
      const maxAttempts = RATE_LIMIT_CONFIG.login.maxAttempts;

      for (let i = 0; i <= maxAttempts; i++) {
        checkRateLimit(identifier, 'login');
      }

      const info = getRateLimitInfo(identifier);
      expect(info?.blockedUntil).toBeDefined();
      expect(info?.blockedUntil).toBeGreaterThan(new Date());
    });
  });

  describe('clearAllRateLimits', () => {
    it('should clear all rate limits', () => {
      checkRateLimit('user-1', 'login');
      checkRateLimit('user-2', 'login');

      clearAllRateLimits();

      const info1 = getRateLimitInfo('user-1');
      const info2 = getRateLimitInfo('user-2');

      expect(info1).toBeNull();
      expect(info2).toBeNull();
    });

    it('should allow fresh attempts after clear', () => {
      const identifier = 'user-123';
      const maxAttempts = RATE_LIMIT_CONFIG.login.maxAttempts;

      for (let i = 0; i <= maxAttempts; i++) {
        checkRateLimit(identifier, 'login');
      }

      clearAllRateLimits();

      const result = checkRateLimit(identifier, 'login');
      expect(result.allowed).toBe(true);
    });
  });

  describe('createRateLimitResponse', () => {
    it('should create response for allowed attempt', () => {
      const result = checkRateLimit('user-123', 'login');
      const response = createRateLimitResponse(result);

      expect(response.headers['X-RateLimit-Remaining']).toBe(result.remaining.toString());
      expect(response.body).toBeNull();
    });

    it('should create response for blocked attempt', () => {
      const identifier = 'user-123';
      const maxAttempts = RATE_LIMIT_CONFIG.login.maxAttempts;

      for (let i = 0; i <= maxAttempts; i++) {
        checkRateLimit(identifier, 'login');
      }

      const result = checkRateLimit(identifier, 'login');
      const response = createRateLimitResponse(result);

      expect(response.body).not.toBeNull();
      expect(response.body?.error).toBeDefined();
      expect(response.body?.retryAfter).toBeDefined();
    });

    it('should include retry-after header when blocked', () => {
      const identifier = 'user-123';
      const maxAttempts = RATE_LIMIT_CONFIG.login.maxAttempts;

      for (let i = 0; i <= maxAttempts; i++) {
        checkRateLimit(identifier, 'login');
      }

      const result = checkRateLimit(identifier, 'login');
      const response = createRateLimitResponse(result);

      expect(response.headers['Retry-After']).toBeDefined();
    });

    it('should have remaining count in headers', () => {
      const result = checkRateLimit('user-123', 'login');
      const response = createRateLimitResponse(result);

      expect(response.headers['X-RateLimit-Remaining']).toBe('4');
    });
  });

  describe('formatRateLimitError', () => {
    it('should format error in English', () => {
      const identifier = 'user-123';
      const maxAttempts = RATE_LIMIT_CONFIG.login.maxAttempts;

      for (let i = 0; i <= maxAttempts; i++) {
        checkRateLimit(identifier, 'login');
      }

      const result = checkRateLimit(identifier, 'login');
      const error = formatRateLimitError(result, 'en');

      expect(error).toContain('Too many attempts');
      expect(error).toContain('minute');
    });

    it('should format error in Arabic', () => {
      const identifier = 'user-123';
      const maxAttempts = RATE_LIMIT_CONFIG.login.maxAttempts;

      for (let i = 0; i <= maxAttempts; i++) {
        checkRateLimit(identifier, 'login');
      }

      const result = checkRateLimit(identifier, 'login');
      const error = formatRateLimitError(result, 'ar');

      expect(error).toContain('تم تجاوز');
      expect(error).toContain('دقيقة');
    });

    it('should handle default locale (Arabic)', () => {
      const identifier = 'user-123';
      const maxAttempts = RATE_LIMIT_CONFIG.login.maxAttempts;

      for (let i = 0; i <= maxAttempts; i++) {
        checkRateLimit(identifier, 'login');
      }

      const result = checkRateLimit(identifier, 'login');
      const error = formatRateLimitError(result);

      expect(error).toContain('تم تجاوز');
    });

    it('should return empty string for allowed attempt', () => {
      const result = checkRateLimit('user-123', 'login');
      const error = formatRateLimitError(result, 'en');

      expect(error).toBe('');
    });

    it('should pluralize minutes correctly', () => {
      const identifier = 'user-123';
      const maxAttempts = RATE_LIMIT_CONFIG.login.maxAttempts;

      for (let i = 0; i <= maxAttempts; i++) {
        checkRateLimit(identifier, 'login');
      }

      const result = checkRateLimit(identifier, 'login');
      const error = formatRateLimitError(result, 'en');

      expect(error).toMatch(/minute[s]?/);
    });

    it('should include retry duration in message', () => {
      const identifier = 'user-123';
      const maxAttempts = RATE_LIMIT_CONFIG.login.maxAttempts;

      for (let i = 0; i <= maxAttempts; i++) {
        checkRateLimit(identifier, 'login');
      }

      const result = checkRateLimit(identifier, 'login');
      const error = formatRateLimitError(result, 'en');

      if (result.retryAfter) {
        const minutes = Math.ceil(result.retryAfter / 60);
        expect(error).toContain(minutes.toString());
      }
    });
  });

  describe('Config values', () => {
    it('should have valid login config', () => {
      expect(RATE_LIMIT_CONFIG.login.maxAttempts).toBeGreaterThan(0);
      expect(RATE_LIMIT_CONFIG.login.windowMs).toBeGreaterThan(0);
      expect(RATE_LIMIT_CONFIG.login.backoffMs).toBeGreaterThan(0);
      expect(RATE_LIMIT_CONFIG.login.backoffMultiplier).toBeGreaterThan(1);
    });

    it('should have stricter OTP config than login', () => {
      expect(RATE_LIMIT_CONFIG.otpVerification.maxAttempts).toBeLessThan(
        RATE_LIMIT_CONFIG.login.maxAttempts
      );
    });

    it('should have longer password reset window', () => {
      expect(RATE_LIMIT_CONFIG.passwordReset.windowMs).toBeGreaterThan(
        RATE_LIMIT_CONFIG.login.windowMs
      );
    });

    it('should have lenient API endpoint limits', () => {
      expect(RATE_LIMIT_CONFIG.apiEndpoint.maxAttempts).toBeGreaterThan(
        RATE_LIMIT_CONFIG.login.maxAttempts
      );
    });
  });
});
