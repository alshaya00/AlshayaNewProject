import {
  hashPassword,
  verifyPassword,
  validatePasswordStrength,
  generateToken,
  generateSessionToken,
  generateInviteCode,
  generatePasswordResetToken,
  generateVerificationToken,
  generateApiKey,
} from '@/lib/auth/password';

describe('Password Functions', () => {
  describe('hashPassword', () => {
    it('should hash a valid password', async () => {
      const password = 'SecurePassword123!';
      const hash = await hashPassword(password);
      expect(hash).toBeTruthy();
      expect(hash).not.toBe(password);
      expect(hash.length).toBeGreaterThan(20); // bcrypt hashes are longer
    });

    it('should create different hashes for the same password', async () => {
      const password = 'SecurePassword123!';
      const hash1 = await hashPassword(password);
      const hash2 = await hashPassword(password);
      expect(hash1).not.toBe(hash2); // Different hashes due to salt
    });

    it('should throw error for empty password', async () => {
      await expect(hashPassword('')).rejects.toThrow('Password cannot be empty');
    });

    it('should throw error for password shorter than 8 characters', async () => {
      await expect(hashPassword('Short1!')).rejects.toThrow('at least 8 characters');
    });

    it('should handle very long passwords', async () => {
      const longPassword = 'A'.repeat(100) + '1!';
      const hash = await hashPassword(longPassword);
      expect(hash).toBeTruthy();
    });

    it('should work with special characters', async () => {
      const password = 'Special!@#$%^&*()_+1234';
      const hash = await hashPassword(password);
      expect(hash).toBeTruthy();
    });

    it('should work with unicode characters', async () => {
      const password = 'SecurePass123!إسم';
      const hash = await hashPassword(password);
      expect(hash).toBeTruthy();
    });

    it('should be deterministic when verifying', async () => {
      const password = 'TestPass123!';
      const hash = await hashPassword(password);
      const isValid = await verifyPassword(password, hash);
      expect(isValid).toBe(true);
    });

    it('should handle whitespace in password', async () => {
      const password = 'Secure Pass 123!';
      const hash = await hashPassword(password);
      expect(hash).toBeTruthy();
    });

    it('should reject invalid hashes during verification', async () => {
      const password = 'SecurePassword123!';
      const hash = await hashPassword(password);
      const invalidPassword = 'WrongPassword123!';
      const isValid = await verifyPassword(invalidPassword, hash);
      expect(isValid).toBe(false);
    });
  });

  describe('verifyPassword', () => {
    it('should verify correct password', async () => {
      const password = 'SecurePassword123!';
      const hash = await hashPassword(password);
      const isValid = await verifyPassword(password, hash);
      expect(isValid).toBe(true);
    });

    it('should reject incorrect password', async () => {
      const password = 'SecurePassword123!';
      const hash = await hashPassword(password);
      const isValid = await verifyPassword('WrongPassword123!', hash);
      expect(isValid).toBe(false);
    });

    it('should handle empty password', async () => {
      const hash = await hashPassword('ValidPassword123!');
      const isValid = await verifyPassword('', hash);
      expect(isValid).toBe(false);
    });

    it('should handle empty hash', async () => {
      const isValid = await verifyPassword('SomePassword123!', '');
      expect(isValid).toBe(false);
    });

    it('should handle both empty', async () => {
      const isValid = await verifyPassword('', '');
      expect(isValid).toBe(false);
    });

    it('should be case-sensitive', async () => {
      const password = 'SecurePassword123!';
      const hash = await hashPassword(password);
      const isValid = await verifyPassword('securepassword123!', hash);
      expect(isValid).toBe(false);
    });

    it('should handle invalid bcrypt hash gracefully', async () => {
      const isValid = await verifyPassword('SomePassword123!', 'invalid-hash');
      expect(isValid).toBe(false);
    });

    it('should verify with special characters', async () => {
      const password = 'Pass!@#$%^&*()1';
      const hash = await hashPassword(password);
      const isValid = await verifyPassword(password, hash);
      expect(isValid).toBe(true);
    });

    it('should verify with unicode characters', async () => {
      const password = 'Pass123!إسم';
      const hash = await hashPassword(password);
      const isValid = await verifyPassword(password, hash);
      expect(isValid).toBe(true);
    });

    it('should reject password with extra space', async () => {
      const password = 'SecurePassword123!';
      const hash = await hashPassword(password);
      const isValid = await verifyPassword(password + ' ', hash);
      expect(isValid).toBe(false);
    });
  });

  describe('validatePasswordStrength', () => {
    it('should validate strong password', () => {
      const result = validatePasswordStrength('StrongPass123!@#');
      expect(result.valid).toBe(true);
      expect(result.score).toBeGreaterThan(70);
      expect(result.errors).toHaveLength(0);
    });

    it('should reject empty password', () => {
      const result = validatePasswordStrength('');
      expect(result.valid).toBe(false);
      expect(result.score).toBe(0);
      expect(result.errors.length).toBeGreaterThan(0);
    });

    it('should reject short password', () => {
      const result = validatePasswordStrength('Short1!');
      expect(result.valid).toBe(false);
      expect(result.errors[0].en).toContain('at least 8');
    });

    it('should detect missing uppercase', () => {
      const result = validatePasswordStrength('lowercase123!');
      expect(result.valid).toBe(false);
      expect(result.errors.some(e => e.en.includes('uppercase'))).toBe(true);
    });

    it('should detect missing lowercase', () => {
      const result = validatePasswordStrength('UPPERCASE123!');
      expect(result.valid).toBe(false);
      expect(result.errors.some(e => e.en.includes('lowercase'))).toBe(true);
    });

    it('should detect missing numbers', () => {
      const result = validatePasswordStrength('NoNumbers!@#');
      expect(result.valid).toBe(false);
      expect(result.errors.some(e => e.en.includes('number'))).toBe(true);
    });

    it('should suggest special characters if missing', () => {
      const result = validatePasswordStrength('ValidPass123');
      expect(result.valid).toBe(true);
      expect(result.suggestions.some(s => s.en.includes('special'))).toBe(true);
    });

    it('should detect repeating characters', () => {
      const result = validatePasswordStrength('PasssWord123!');
      expect(result.suggestions.some(s => s.en.includes('Avoid repeating'))).toBe(true);
    });

    it('should score longer passwords higher', () => {
      const short = validatePasswordStrength('ShortPass1!');
      const long = validatePasswordStrength('VeryLongPasswordWith123!@#');
      expect(long.score).toBeGreaterThan(short.score);
    });

    it('should have Arabic error messages', () => {
      const result = validatePasswordStrength('short');
      expect(result.errors[0].ar).toBeTruthy();
      expect(result.errors[0].ar).toContain('أحرف');
    });

    it('should have Arabic suggestions', () => {
      const result = validatePasswordStrength('ValidPass123');
      expect(result.suggestions[0].ar).toBeTruthy();
    });

    it('should score special characters', () => {
      const withSpecial = validatePasswordStrength('Pass123!@#');
      const withoutSpecial = validatePasswordStrength('PassWord123');
      expect(withSpecial.score).toBeGreaterThan(withoutSpecial.score);
    });

    it('should cap score at 100', () => {
      const result = validatePasswordStrength('VeryStrongPasswordWith123!@#$%^&*()');
      expect(result.score).toBeLessThanOrEqual(100);
    });

    it('should never have negative score', () => {
      const result = validatePasswordStrength('P1!');
      expect(result.score).toBeGreaterThanOrEqual(0);
    });

    it('should accept minimum valid password', () => {
      const result = validatePasswordStrength('ValidPass1!');
      expect(result.valid).toBe(true);
    });
  });

  describe('generateToken', () => {
    it('should generate token of default length', () => {
      const token = generateToken();
      expect(token).toHaveLength(32);
    });

    it('should generate token of specified length', () => {
      const token = generateToken(64);
      expect(token).toHaveLength(64);
    });

    it('should generate different tokens', () => {
      const token1 = generateToken();
      const token2 = generateToken();
      expect(token1).not.toBe(token2);
    });

    it('should only contain alphanumeric characters', () => {
      const token = generateToken(100);
      expect(/^[A-Za-z0-9]+$/.test(token)).toBe(true);
    });

    it('should generate cryptographically secure tokens', () => {
      const tokens = new Set();
      for (let i = 0; i < 100; i++) {
        tokens.add(generateToken());
      }
      expect(tokens.size).toBe(100); // All should be unique
    });

    it('should handle small length', () => {
      const token = generateToken(1);
      expect(token).toHaveLength(1);
    });

    it('should handle large length', () => {
      const token = generateToken(256);
      expect(token).toHaveLength(256);
    });
  });

  describe('generateSessionToken', () => {
    it('should generate 64-character token', () => {
      const token = generateSessionToken();
      expect(token).toHaveLength(64);
    });

    it('should generate unique tokens', () => {
      const token1 = generateSessionToken();
      const token2 = generateSessionToken();
      expect(token1).not.toBe(token2);
    });

    it('should only contain alphanumeric characters', () => {
      const token = generateSessionToken();
      expect(/^[A-Za-z0-9]+$/.test(token)).toBe(true);
    });
  });

  describe('generateInviteCode', () => {
    it('should generate valid invite code format', () => {
      const code = generateInviteCode();
      expect(/^ALSHAYA-[A-Z2-9]{4}-[A-Z2-9]{4}$/.test(code)).toBe(true);
    });

    it('should exclude confusing characters', () => {
      const code = generateInviteCode();
      expect(/[I0O1]/.test(code)).toBe(false);
    });

    it('should generate unique codes', () => {
      const code1 = generateInviteCode();
      const code2 = generateInviteCode();
      expect(code1).not.toBe(code2);
    });

    it('should have ALSHAYA prefix', () => {
      const code = generateInviteCode();
      expect(code.startsWith('ALSHAYA-')).toBe(true);
    });

    it('should be human readable', () => {
      const code = generateInviteCode();
      expect(code.length).toBe(17); // ALSHAYA- (8) + XXXX-XXXX (9)
    });
  });

  describe('generatePasswordResetToken', () => {
    it('should generate 48-character token', () => {
      const token = generatePasswordResetToken();
      expect(token).toHaveLength(48);
    });

    it('should be cryptographically secure', () => {
      const tokens = new Set();
      for (let i = 0; i < 50; i++) {
        tokens.add(generatePasswordResetToken());
      }
      expect(tokens.size).toBe(50);
    });
  });

  describe('generateVerificationToken', () => {
    it('should generate 32-character token', () => {
      const token = generateVerificationToken();
      expect(token).toHaveLength(32);
    });

    it('should be unique each time', () => {
      const token1 = generateVerificationToken();
      const token2 = generateVerificationToken();
      expect(token1).not.toBe(token2);
    });
  });

  describe('generateApiKey', () => {
    it('should generate API key with default prefix', () => {
      const key = generateApiKey();
      expect(key.startsWith('sk_')).toBe(true);
    });

    it('should generate API key with custom prefix', () => {
      const key = generateApiKey('test');
      expect(key.startsWith('test_')).toBe(true);
    });

    it('should contain base64url characters', () => {
      const key = generateApiKey();
      const withoutPrefix = key.replace('sk_', '');
      expect(/^[A-Za-z0-9_-]+$/.test(withoutPrefix)).toBe(true);
    });

    it('should generate unique keys', () => {
      const key1 = generateApiKey();
      const key2 = generateApiKey();
      expect(key1).not.toBe(key2);
    });

    it('should have reasonable length', () => {
      const key = generateApiKey();
      expect(key.length).toBeGreaterThan(30);
      expect(key.length).toBeLessThan(100);
    });
  });
});
