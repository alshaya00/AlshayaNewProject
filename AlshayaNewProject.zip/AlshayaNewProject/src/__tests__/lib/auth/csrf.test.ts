import {
  generateCsrfToken,
  createCsrfToken,
  validateCsrfToken,
  cleanupExpiredCsrfTokens,
  invalidateUserCsrfTokens,
  getCsrfCookieOptions,
  extractCsrfToken,
  validateApiCsrf,
  CSRF_CONFIG,
} from '@/lib/auth/csrf';
import { prisma } from '@/lib/db/prisma';

jest.mock('@/lib/db/prisma', () => ({
  prisma: {
    csrfToken: {
      create: jest.fn(),
      findFirst: jest.fn(),
      delete: jest.fn(),
      deleteMany: jest.fn(),
    },
  },
}));

describe('CSRF Token Functions', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('generateCsrfToken', () => {
    it('should generate a token with timestamp and random part', () => {
      const token = generateCsrfToken();
      expect(token).toMatch(/^[a-f0-9]+\.[a-f0-9]+$/);
    });

    it('should generate unique tokens', () => {
      const token1 = generateCsrfToken();
      const token2 = generateCsrfToken();
      expect(token1).not.toBe(token2);
    });

    it('should have correct format', () => {
      const token = generateCsrfToken();
      const parts = token.split('.');
      expect(parts).toHaveLength(2);
      expect(parts[0]).toMatch(/^[a-f0-9]+$/); // timestamp in hex
      expect(parts[1]).toMatch(/^[a-f0-9]+$/); // random part in hex
    });

    it('should not contain special characters', () => {
      const token = generateCsrfToken();
      expect(/^[a-f0-9.]+$/.test(token)).toBe(true);
    });

    it('should be reasonably long for security', () => {
      const token = generateCsrfToken();
      expect(token.length).toBeGreaterThan(40);
    });
  });

  describe('createCsrfToken', () => {
    it('should create token without user ID', async () => {
      const mockCreate = jest.fn().mockResolvedValue({});
      (prisma.csrfToken.create as jest.Mock) = mockCreate;

      const token = await createCsrfToken();

      expect(token).toBeTruthy();
      expect(mockCreate).toHaveBeenCalledWith({
        data: expect.objectContaining({
          token: expect.any(String),
          userId: null,
          expiresAt: expect.any(Date),
        }),
      });
    });

    it('should create token with user ID', async () => {
      const mockCreate = jest.fn().mockResolvedValue({});
      (prisma.csrfToken.create as jest.Mock) = mockCreate;

      const userId = 'user-123';
      await createCsrfToken(userId);

      expect(mockCreate).toHaveBeenCalledWith({
        data: expect.objectContaining({
          userId: userId,
        }),
      });
    });

    it('should set expiration to 24 hours', async () => {
      const mockCreate = jest.fn().mockResolvedValue({});
      (prisma.csrfToken.create as jest.Mock) = mockCreate;

      const now = Date.now();
      await createCsrfToken();

      const callArgs = mockCreate.mock.calls[0][0];
      const expiresAt = callArgs.data.expiresAt.getTime();
      const maxAgeMs = CSRF_CONFIG.maxAge * 1000;

      expect(expiresAt).toBeGreaterThan(now);
      expect(expiresAt - now).toBeCloseTo(maxAgeMs, -3); // Allow 1 second variance
    });

    it('should handle database errors gracefully', async () => {
      const mockCreate = jest.fn().mockRejectedValue(new Error('DB Error'));
      (prisma.csrfToken.create as jest.Mock) = mockCreate;

      const token = await createCsrfToken();

      expect(token).toBeTruthy();
      expect(mockCreate).toHaveBeenCalled();
    });

    it('should return valid token even on creation failure', async () => {
      const mockCreate = jest.fn().mockRejectedValue(new Error('DB Error'));
      (prisma.csrfToken.create as jest.Mock) = mockCreate;

      const token = await createCsrfToken();

      expect(token).toMatch(/^[a-f0-9]+\.[a-f0-9]+$/);
    });

    it('should store hashed token', async () => {
      const mockCreate = jest.fn().mockResolvedValue({});
      (prisma.csrfToken.create as jest.Mock) = mockCreate;

      const token = await createCsrfToken();

      const callArgs = mockCreate.mock.calls[0][0];
      const storedToken = callArgs.data.token;

      expect(storedToken).not.toBe(token);
      expect(storedToken).toMatch(/^[a-f0-9]{64}$/); // SHA256 hash
    });
  });

  describe('validateCsrfToken', () => {
    it('should validate existing token', async () => {
      const token = generateCsrfToken();
      const mockFindFirst = jest.fn().mockResolvedValue({ id: 'token-1' });
      const mockDelete = jest.fn().mockResolvedValue({});

      (prisma.csrfToken.findFirst as jest.Mock) = mockFindFirst;
      (prisma.csrfToken.delete as jest.Mock) = mockDelete;

      const result = await validateCsrfToken(token);

      expect(result).toBe(true);
      expect(mockFindFirst).toHaveBeenCalled();
      expect(mockDelete).toHaveBeenCalled();
    });

    it('should return false for empty token', async () => {
      const result = await validateCsrfToken('');

      expect(result).toBe(false);
    });

    it('should return false for missing token in database', async () => {
      const token = generateCsrfToken();
      const mockFindFirst = jest.fn().mockResolvedValue(null);

      (prisma.csrfToken.findFirst as jest.Mock) = mockFindFirst;

      const result = await validateCsrfToken(token);

      expect(result).toBe(false);
    });

    it('should include user ID in query when provided', async () => {
      const token = generateCsrfToken();
      const userId = 'user-123';
      const mockFindFirst = jest.fn().mockResolvedValue(null);

      (prisma.csrfToken.findFirst as jest.Mock) = mockFindFirst;

      await validateCsrfToken(token, userId);

      const callArgs = mockFindFirst.mock.calls[0][0];
      expect(callArgs.where.userId).toBe(userId);
    });

    it('should check token expiration', async () => {
      const token = generateCsrfToken();
      const mockFindFirst = jest.fn().mockResolvedValue(null);

      (prisma.csrfToken.findFirst as jest.Mock) = mockFindFirst;

      await validateCsrfToken(token);

      const callArgs = mockFindFirst.mock.calls[0][0];
      expect(callArgs.where.expiresAt.gt).toBeDefined();
    });

    it('should delete token after validation', async () => {
      const token = generateCsrfToken();
      const tokenId = 'token-123';
      const mockFindFirst = jest.fn().mockResolvedValue({ id: tokenId });
      const mockDelete = jest.fn().mockResolvedValue({});

      (prisma.csrfToken.findFirst as jest.Mock) = mockFindFirst;
      (prisma.csrfToken.delete as jest.Mock) = mockDelete;

      await validateCsrfToken(token);

      expect(mockDelete).toHaveBeenCalledWith({
        where: { id: tokenId },
      });
    });

    it('should handle database errors gracefully', async () => {
      const token = generateCsrfToken();
      const mockFindFirst = jest.fn().mockRejectedValue(new Error('DB Error'));

      (prisma.csrfToken.findFirst as jest.Mock) = mockFindFirst;

      const result = await validateCsrfToken(token);

      expect(result).toBe(false);
    });

    it('should hash token before lookup', async () => {
      const token = generateCsrfToken();
      const mockFindFirst = jest.fn().mockResolvedValue(null);

      (prisma.csrfToken.findFirst as jest.Mock) = mockFindFirst;

      await validateCsrfToken(token);

      const callArgs = mockFindFirst.mock.calls[0][0];
      expect(callArgs.where.token).toMatch(/^[a-f0-9]{64}$/);
      expect(callArgs.where.token).not.toBe(token);
    });
  });

  describe('cleanupExpiredCsrfTokens', () => {
    it('should delete expired tokens', async () => {
      const mockDeleteMany = jest.fn().mockResolvedValue({ count: 5 });
      (prisma.csrfToken.deleteMany as jest.Mock) = mockDeleteMany;

      const count = await cleanupExpiredCsrfTokens();

      expect(count).toBe(5);
      expect(mockDeleteMany).toHaveBeenCalled();
    });

    it('should check expiration date', async () => {
      const mockDeleteMany = jest.fn().mockResolvedValue({ count: 0 });
      (prisma.csrfToken.deleteMany as jest.Mock) = mockDeleteMany;

      await cleanupExpiredCsrfTokens();

      const callArgs = mockDeleteMany.mock.calls[0][0];
      expect(callArgs.where.expiresAt.lt).toBeDefined();
    });

    it('should handle database errors', async () => {
      const mockDeleteMany = jest.fn().mockRejectedValue(new Error('DB Error'));
      (prisma.csrfToken.deleteMany as jest.Mock) = mockDeleteMany;

      const count = await cleanupExpiredCsrfTokens();

      expect(count).toBe(0);
    });
  });

  describe('invalidateUserCsrfTokens', () => {
    it('should delete all user CSRF tokens', async () => {
      const mockDeleteMany = jest.fn().mockResolvedValue({ count: 3 });
      (prisma.csrfToken.deleteMany as jest.Mock) = mockDeleteMany;

      const userId = 'user-123';
      const count = await invalidateUserCsrfTokens(userId);

      expect(count).toBe(3);
      expect(mockDeleteMany).toHaveBeenCalledWith({
        where: { userId },
      });
    });

    it('should handle database errors', async () => {
      const mockDeleteMany = jest.fn().mockRejectedValue(new Error('DB Error'));
      (prisma.csrfToken.deleteMany as jest.Mock) = mockDeleteMany;

      const count = await invalidateUserCsrfTokens('user-123');

      expect(count).toBe(0);
    });
  });

  describe('getCsrfCookieOptions', () => {
    it('should return valid cookie options', () => {
      const options = getCsrfCookieOptions();

      expect(options.name).toBe(CSRF_CONFIG.cookieName);
      expect(options.maxAge).toBe(CSRF_CONFIG.maxAge);
      expect(options.secure).toBe(CSRF_CONFIG.secure);
      expect(options.httpOnly).toBe(CSRF_CONFIG.httpOnly);
      expect(options.sameSite).toBe('strict');
      expect(options.path).toBe('/');
    });

    it('should have secure flag in production', () => {
      const originalEnv = process.env.NODE_ENV;
      process.env.NODE_ENV = 'production';

      // Need to re-import to get updated value
      jest.resetModules();

      process.env.NODE_ENV = originalEnv;
    });
  });

  describe('extractCsrfToken', () => {
    it('should extract token from header', () => {
      const token = 'token-from-header';
      const request = {
        headers: { 'x-csrf-token': token },
      };

      const extracted = extractCsrfToken(request);

      expect(extracted).toBe(token);
    });

    it('should extract token from body', () => {
      const token = 'token-from-body';
      const request = {
        body: { _csrf: token },
      };

      const extracted = extractCsrfToken(request);

      expect(extracted).toBe(token);
    });

    it('should extract token from cookie', () => {
      const token = 'token-from-cookie';
      const request = {
        cookies: { alshaya_csrf: token },
      };

      const extracted = extractCsrfToken(request);

      expect(extracted).toBe(token);
    });

    it('should prefer header over body', () => {
      const request = {
        headers: { 'x-csrf-token': 'header-token' },
        body: { _csrf: 'body-token' },
      };

      const extracted = extractCsrfToken(request);

      expect(extracted).toBe('header-token');
    });

    it('should prefer header over cookie', () => {
      const request = {
        headers: { 'x-csrf-token': 'header-token' },
        cookies: { alshaya_csrf: 'cookie-token' },
      };

      const extracted = extractCsrfToken(request);

      expect(extracted).toBe('header-token');
    });

    it('should return null if no token found', () => {
      const request = {};

      const extracted = extractCsrfToken(request);

      expect(extracted).toBeNull();
    });

    it('should handle array of header values', () => {
      const request = {
        headers: { 'x-csrf-token': ['token1', 'token2'] },
      };

      const extracted = extractCsrfToken(request);

      expect(extracted).toBe('token1');
    });
  });

  describe('validateApiCsrf', () => {
    beforeEach(() => {
      jest.clearAllMocks();
    });

    it('should skip validation for GET requests', async () => {
      const result = await validateApiCsrf({ method: 'GET' });

      expect(result.valid).toBe(true);
    });

    it('should return error for missing token on POST', async () => {
      const result = await validateApiCsrf({ method: 'POST' });

      expect(result.valid).toBe(false);
      expect(result.error).toContain('Missing CSRF token');
    });

    it('should validate token for POST request', async () => {
      const token = generateCsrfToken();
      const mockFindFirst = jest.fn().mockResolvedValue({ id: 'token-1' });
      const mockDelete = jest.fn().mockResolvedValue({});

      (prisma.csrfToken.findFirst as jest.Mock) = mockFindFirst;
      (prisma.csrfToken.delete as jest.Mock) = mockDelete;

      const result = await validateApiCsrf({
        method: 'POST',
        headers: { 'x-csrf-token': token },
      });

      expect(result.valid).toBe(true);
    });

    it('should return error for invalid token', async () => {
      const token = generateCsrfToken();
      const mockFindFirst = jest.fn().mockResolvedValue(null);

      (prisma.csrfToken.findFirst as jest.Mock) = mockFindFirst;

      const result = await validateApiCsrf({
        method: 'POST',
        headers: { 'x-csrf-token': token },
      });

      expect(result.valid).toBe(false);
      expect(result.error).toContain('Invalid');
    });

    it('should pass userId to validation', async () => {
      const token = generateCsrfToken();
      const userId = 'user-123';
      const mockFindFirst = jest.fn().mockResolvedValue(null);

      (prisma.csrfToken.findFirst as jest.Mock) = mockFindFirst;

      await validateApiCsrf(
        {
          method: 'POST',
          headers: { 'x-csrf-token': token },
        },
        userId
      );

      const callArgs = mockFindFirst.mock.calls[0][0];
      expect(callArgs.where.userId).toBe(userId);
    });

    it('should work with PUT requests', async () => {
      const token = generateCsrfToken();
      const mockFindFirst = jest.fn().mockResolvedValue({ id: 'token-1' });
      const mockDelete = jest.fn().mockResolvedValue({});

      (prisma.csrfToken.findFirst as jest.Mock) = mockFindFirst;
      (prisma.csrfToken.delete as jest.Mock) = mockDelete;

      const result = await validateApiCsrf({
        method: 'PUT',
        headers: { 'x-csrf-token': token },
      });

      expect(result.valid).toBe(true);
    });

    it('should work with DELETE requests', async () => {
      const token = generateCsrfToken();
      const mockFindFirst = jest.fn().mockResolvedValue({ id: 'token-1' });
      const mockDelete = jest.fn().mockResolvedValue({});

      (prisma.csrfToken.findFirst as jest.Mock) = mockFindFirst;
      (prisma.csrfToken.delete as jest.Mock) = mockDelete;

      const result = await validateApiCsrf({
        method: 'DELETE',
        headers: { 'x-csrf-token': token },
      });

      expect(result.valid).toBe(true);
    });
  });
});
