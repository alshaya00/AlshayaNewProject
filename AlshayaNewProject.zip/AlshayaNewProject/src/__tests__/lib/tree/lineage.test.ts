import { getLineagePath, getGen2Ancestor } from '@/lib/tree/lineage';
import { FamilyMember } from '@/types';

describe('Lineage Functions', () => {
  const createMember = (
    id: string,
    generation: number,
    fatherId?: string
  ): FamilyMember => ({
    id,
    userId: 'user-1',
    generation,
    fatherId,
    firstName: `Member ${id}`,
    firstNameAr: `عضو ${id}`,
    birthDate: null,
    deathDate: null,
    gender: 'M',
    notes: null,
    createdAt: new Date(),
    updatedAt: new Date(),
  });

  describe('getLineagePath', () => {
    it('should return empty path for root member', () => {
      const members = [createMember('1', 1)];
      const path = getLineagePath('1', members);
      expect(path).toEqual([]);
    });

    it('should return single father for direct child', () => {
      const members = [
        createMember('1', 1),
        createMember('2', 2, '1'),
      ];
      const path = getLineagePath('2', members);
      expect(path).toEqual(['1']);
    });

    it('should return full ancestor path', () => {
      const members = [
        createMember('1', 1),
        createMember('2', 2, '1'),
        createMember('3', 3, '2'),
        createMember('4', 4, '3'),
      ];
      const path = getLineagePath('4', members);
      expect(path).toEqual(['3', '2', '1']);
    });

    it('should handle deep genealogy', () => {
      const members: FamilyMember[] = [];
      let parentId: string | undefined;

      for (let i = 1; i <= 10; i++) {
        members.push(createMember(i.toString(), i, parentId));
        parentId = i.toString();
      }

      const path = getLineagePath('10', members);
      expect(path).toHaveLength(9);
      expect(path[0]).toBe('9');
      expect(path[path.length - 1]).toBe('1');
    });

    it('should return empty path for unknown member', () => {
      const members = [createMember('1', 1)];
      const path = getLineagePath('unknown', members);
      expect(path).toEqual([]);
    });

    it('should use memoization for performance', () => {
      const members = [
        createMember('1', 1),
        createMember('2', 2, '1'),
        createMember('3', 3, '2'),
      ];

      const memo = new Map<string, string[]>();

      // First call
      const path1 = getLineagePath('3', members, memo);
      const memoSize1 = memo.size;

      // Second call should use memoization
      const path2 = getLineagePath('3', members, memo);
      const memoSize2 = memo.size;

      expect(path1).toEqual(path2);
      expect(memoSize1).toBe(memoSize2);
    });

    it('should build memoization correctly', () => {
      const members = [
        createMember('1', 1),
        createMember('2', 2, '1'),
        createMember('3', 3, '2'),
      ];

      const memo = new Map<string, string[]>();
      getLineagePath('3', members, memo);

      expect(memo.has('3')).toBe(true);
      expect(memo.get('3')).toEqual(['2', '1']);
    });

    it('should handle multiple sibling branches', () => {
      const members = [
        createMember('1', 1),
        createMember('2', 2, '1'),
        createMember('3', 2, '1'), // sibling
        createMember('4', 3, '2'),
        createMember('5', 3, '3'), // different branch
      ];

      const path2 = getLineagePath('4', members);
      const path3 = getLineagePath('5', members);

      expect(path2).toEqual(['2', '1']);
      expect(path3).toEqual(['3', '1']);
    });

    it('should handle cycles gracefully', () => {
      const members = [
        createMember('1', 1),
        createMember('2', 2, '1'),
        // Cycle: 3's father is 1, but 1 has father 3 in reality (shouldn't happen)
      ];

      const path = getLineagePath('2', members);
      expect(path).toEqual(['1']);
    });

    it('should maintain correct order (root to immediate parent)', () => {
      const members = [
        createMember('root', 1),
        createMember('a', 2, 'root'),
        createMember('b', 3, 'a'),
        createMember('c', 4, 'b'),
      ];

      const path = getLineagePath('c', members);
      expect(path[0]).toBe('b'); // immediate parent first
      expect(path[path.length - 1]).toBe('root'); // root last
    });
  });

  describe('getGen2Ancestor', () => {
    it('should return null for Gen 1 member', () => {
      const members = [createMember('1', 1)];
      const ancestor = getGen2Ancestor('1', members);
      expect(ancestor).toBeNull();
    });

    it('should return null for Gen 2 looking for their Gen 2 ancestor', () => {
      const members = [
        createMember('1', 1),
        createMember('2', 2, '1'),
      ];
      const ancestor = getGen2Ancestor('2', members);
      expect(ancestor).toBeNull();
    });

    it('should return the Gen 2 ancestor for Gen 3 member', () => {
      const members = [
        createMember('1', 1),
        createMember('2', 2, '1'),
        createMember('3', 3, '2'),
      ];
      const ancestor = getGen2Ancestor('3', members);
      expect(ancestor?.id).toBe('2');
    });

    it('should return Gen 2 ancestor for deeply nested member', () => {
      const members: FamilyMember[] = [];
      let parentId: string | undefined;

      for (let i = 1; i <= 6; i++) {
        members.push(createMember(i.toString(), i, parentId));
        parentId = i.toString();
      }

      const ancestor = getGen2Ancestor('6', members);
      expect(ancestor?.generation).toBe(2);
      expect(ancestor?.id).toBe('2');
    });

    it('should return null for unknown member', () => {
      const members = [createMember('1', 1)];
      const ancestor = getGen2Ancestor('unknown', members);
      expect(ancestor).toBeNull();
    });

    it('should use memoization correctly', () => {
      const members = [
        createMember('1', 1),
        createMember('2', 2, '1'),
        createMember('3', 3, '2'),
      ];

      const memo = new Map<string, FamilyMember | null>();

      // First call
      const ancestor1 = getGen2Ancestor('3', members, memo);
      const memoSize1 = memo.size;

      // Second call should use memoization
      const ancestor2 = getGen2Ancestor('3', members, memo);
      const memoSize2 = memo.size;

      expect(ancestor1?.id).toBe(ancestor2?.id);
      expect(memoSize1).toBe(memoSize2);
    });

    it('should handle multiple branches with same Gen 2 ancestor', () => {
      const members = [
        createMember('1', 1),
        createMember('2', 2, '1'),
        createMember('3', 3, '2'),
        createMember('4', 3, '2'), // sibling
        createMember('5', 4, '3'),
        createMember('6', 4, '4'), // different branch, same Gen 2 ancestor
      ];

      const ancestor5 = getGen2Ancestor('5', members);
      const ancestor6 = getGen2Ancestor('6', members);

      expect(ancestor5?.id).toBe('2');
      expect(ancestor6?.id).toBe('2');
    });

    it('should return the first Gen 2 ancestor in lineage', () => {
      const members = [
        createMember('1', 1),
        createMember('2', 2, '1'),
        createMember('3', 2, '1'), // another Gen 2, but different branch
        createMember('4', 3, '2'),
      ];

      const ancestor = getGen2Ancestor('4', members);
      expect(ancestor?.id).toBe('2');
    });

    it('should handle Gen 2 requesting its own Gen 2 ancestor correctly', () => {
      const members = [
        createMember('1', 1),
        createMember('2', 2, '1'),
      ];

      const ancestor = getGen2Ancestor('2', members);
      expect(ancestor).toBeNull();
    });

    it('should distinguish between Gen 2 and Gen 3+', () => {
      const members = [
        createMember('1', 1),
        createMember('2', 2, '1'),
        createMember('3', 3, '2'),
      ];

      const ancestor2 = getGen2Ancestor('2', members);
      const ancestor3 = getGen2Ancestor('3', members);

      expect(ancestor2).toBeNull();
      expect(ancestor3?.id).toBe('2');
    });

    it('should build memoization for multiple queries', () => {
      const members = [
        createMember('1', 1),
        createMember('2', 2, '1'),
        createMember('3', 3, '2'),
        createMember('4', 4, '3'),
      ];

      const memo = new Map<string, FamilyMember | null>();

      getGen2Ancestor('3', members, memo);
      getGen2Ancestor('4', members, memo);

      expect(memo.size).toBeGreaterThan(1);
    });

    it('should handle malformed data gracefully', () => {
      const members = [
        createMember('1', 1),
        createMember('2', 2, 'non-existent'),
      ];

      const ancestor = getGen2Ancestor('2', members);
      expect(ancestor).toBeNull();
    });

    it('should work with large family trees', () => {
      const members: FamilyMember[] = [];

      // Create Gen 1
      members.push(createMember('root', 1));

      // Create Gen 2 (10 members)
      for (let i = 1; i <= 10; i++) {
        members.push(createMember(`gen2-${i}`, 2, 'root'));
      }

      // Create Gen 3 (50 members)
      for (let i = 1; i <= 50; i++) {
        const gen2 = `gen2-${((i - 1) % 10) + 1}`;
        members.push(createMember(`gen3-${i}`, 3, gen2));
      }

      // Create Gen 4 (200 members)
      for (let i = 1; i <= 200; i++) {
        const gen3 = `gen3-${((i - 1) % 50) + 1}`;
        members.push(createMember(`gen4-${i}`, 4, gen3));
      }

      const ancestor = getGen2Ancestor('gen4-100', members);
      expect(ancestor?.generation).toBe(2);
      expect(ancestor).not.toBeNull();
    });
  });

  describe('Edge cases', () => {
    it('should handle empty member list', () => {
      const path = getLineagePath('1', []);
      expect(path).toEqual([]);

      const ancestor = getGen2Ancestor('1', []);
      expect(ancestor).toBeNull();
    });

    it('should handle member with null father ID', () => {
      const members = [createMember('1', 5, undefined)];
      const path = getLineagePath('1', members);
      expect(path).toEqual([]);
    });

    it('should handle generation 0', () => {
      const members = [
        createMember('1', 0),
        createMember('2', 1, '1'),
      ];

      const ancestor = getGen2Ancestor('2', members);
      expect(ancestor).toBeNull();
    });

    it('should handle very high generation numbers', () => {
      const members = [
        createMember('1', 1),
        createMember('2', 2, '1'),
        createMember('3', 100, '2'),
      ];

      const ancestor = getGen2Ancestor('3', members);
      expect(ancestor?.id).toBe('2');
    });
  });
});
