import { FamilyMember } from '@/types';

// Tests for data integrity functions
describe('Data Integrity Checks', () => {
  const createMember = (
    id: string,
    generation: number,
    fatherId?: string | null
  ): FamilyMember => ({
    id,
    userId: 'user-1',
    generation,
    fatherId: fatherId || null,
    firstName: `Member ${id}`,
    firstNameAr: `عضو ${id}`,
    birthDate: null,
    deathDate: null,
    gender: 'M',
    notes: null,
    createdAt: new Date(),
    updatedAt: new Date(),
  });

  describe('Cycle Detection', () => {
    it('should detect self-referencing cycle', () => {
      const member = createMember('1', 1, '1');
      const members = [member];

      // Check if member references itself
      const hasCycle = member.fatherId === member.id;
      expect(hasCycle).toBe(true);
    });

    it('should detect two-way cycle', () => {
      const members = [
        createMember('1', 1, '2'),
        createMember('2', 1, '1'),
      ];

      // Create a map for quick lookup
      const memberMap = new Map(members.map((m) => [m.id, m]));

      // Check for two-way cycle
      const hasCycle = members.some((member) => {
        if (!member.fatherId) return false;
        const father = memberMap.get(member.fatherId);
        return father?.fatherId === member.id;
      });

      expect(hasCycle).toBe(true);
    });

    it('should detect multi-node cycle', () => {
      const members = [
        createMember('1', 1, '2'),
        createMember('2', 1, '3'),
        createMember('3', 1, '1'),
      ];

      const memberMap = new Map(members.map((m) => [m.id, m]));

      // DFS-based cycle detection
      function hasCycleFromNode(nodeId: string, visited = new Set<string>()): boolean {
        if (visited.has(nodeId)) return true;
        visited.add(nodeId);

        const node = memberMap.get(nodeId);
        if (!node?.fatherId) return false;

        return hasCycleFromNode(node.fatherId, visited);
      }

      const hasCycle = members.some((m) => hasCycleFromNode(m.id));
      expect(hasCycle).toBe(true);
    });

    it('should not detect cycle in valid tree', () => {
      const members = [
        createMember('1', 1),
        createMember('2', 2, '1'),
        createMember('3', 3, '2'),
      ];

      const memberMap = new Map(members.map((m) => [m.id, m]));

      function hasCycleFromNode(nodeId: string, visited = new Set<string>()): boolean {
        if (visited.has(nodeId)) return true;
        visited.add(nodeId);

        const node = memberMap.get(nodeId);
        if (!node?.fatherId) return false;

        return hasCycleFromNode(node.fatherId, visited);
      }

      const hasCycle = members.some((m) => hasCycleFromNode(m.id));
      expect(hasCycle).toBe(false);
    });
  });

  describe('Parent Existence Validation', () => {
    it('should detect missing parent reference', () => {
      const members = [
        createMember('1', 1),
        createMember('2', 2, 'non-existent-parent'),
      ];

      const memberMap = new Map(members.map((m) => [m.id, m]));

      const hasInvalidParent = members.some((m) => {
        if (!m.fatherId) return false;
        return !memberMap.has(m.fatherId);
      });

      expect(hasInvalidParent).toBe(true);
    });

    it('should validate all parents exist', () => {
      const members = [
        createMember('1', 1),
        createMember('2', 2, '1'),
        createMember('3', 3, '2'),
      ];

      const memberMap = new Map(members.map((m) => [m.id, m]));

      const hasInvalidParent = members.some((m) => {
        if (!m.fatherId) return false;
        return !memberMap.has(m.fatherId);
      });

      expect(hasInvalidParent).toBe(false);
    });
  });

  describe('Generation Consistency', () => {
    it('should detect invalid child generation', () => {
      const members = [
        createMember('1', 1),
        createMember('2', 2, '1'),
        createMember('3', 2, '2'), // Invalid: child has same generation as parent
      ];

      const memberMap = new Map(members.map((m) => [m.id, m]));

      const hasInvalidGeneration = members.some((member) => {
        if (!member.fatherId) return false;
        const father = memberMap.get(member.fatherId);
        return father && member.generation <= father.generation;
      });

      expect(hasInvalidGeneration).toBe(true);
    });

    it('should accept valid generation progression', () => {
      const members = [
        createMember('1', 1),
        createMember('2', 2, '1'),
        createMember('3', 3, '2'),
      ];

      const memberMap = new Map(members.map((m) => [m.id, m]));

      const hasInvalidGeneration = members.some((member) => {
        if (!member.fatherId) return false;
        const father = memberMap.get(member.fatherId);
        return father && member.generation <= father.generation;
      });

      expect(hasInvalidGeneration).toBe(false);
    });

    it('should allow generation gaps', () => {
      const members = [
        createMember('1', 1),
        createMember('2', 3, '1'), // Gap from gen 1 to gen 3
      ];

      const memberMap = new Map(members.map((m) => [m.id, m]));

      const hasInvalidGeneration = members.some((member) => {
        if (!member.fatherId) return false;
        const father = memberMap.get(member.fatherId);
        return father && member.generation <= father.generation;
      });

      expect(hasInvalidGeneration).toBe(false);
    });
  });

  describe('Orphaned Member Detection', () => {
    it('should detect orphaned members', () => {
      const members = [
        createMember('1', 1),
        createMember('2', 2, '1'),
        createMember('3', 3, 'non-existent'),
      ];

      const memberMap = new Map(members.map((m) => [m.id, m]));

      const orphans = members.filter((m) => {
        if (!m.fatherId) return false;
        return !memberMap.has(m.fatherId);
      });

      expect(orphans).toHaveLength(1);
      expect(orphans[0].id).toBe('3');
    });

    it('should not flag root members as orphaned', () => {
      const members = [
        createMember('1', 1, null),
        createMember('2', 2, '1'),
      ];

      const memberMap = new Map(members.map((m) => [m.id, m]));

      const orphans = members.filter((m) => {
        if (!m.fatherId) return false;
        return !memberMap.has(m.fatherId);
      });

      expect(orphans).toHaveLength(0);
    });
  });

  describe('Duplicate Detection', () => {
    it('should detect duplicate IDs', () => {
      const members = [
        createMember('1', 1),
        createMember('1', 2), // Duplicate
      ];

      const ids = new Set<string>();
      const duplicates: string[] = [];

      members.forEach((m) => {
        if (ids.has(m.id)) {
          duplicates.push(m.id);
        }
        ids.add(m.id);
      });

      expect(duplicates).toHaveLength(1);
      expect(duplicates[0]).toBe('1');
    });

    it('should not flag unique IDs as duplicates', () => {
      const members = [
        createMember('1', 1),
        createMember('2', 2),
        createMember('3', 3),
      ];

      const ids = new Set<string>();
      const duplicates: string[] = [];

      members.forEach((m) => {
        if (ids.has(m.id)) {
          duplicates.push(m.id);
        }
        ids.add(m.id);
      });

      expect(duplicates).toHaveLength(0);
    });
  });

  describe('Date Validity', () => {
    it('should validate birth date before death date', () => {
      const birthDate = new Date('1950-01-01');
      const deathDate = new Date('2020-01-01');

      const isValid = birthDate < deathDate;
      expect(isValid).toBe(true);
    });

    it('should detect invalid date order', () => {
      const birthDate = new Date('2020-01-01');
      const deathDate = new Date('1950-01-01');

      const isValid = birthDate < deathDate;
      expect(isValid).toBe(false);
    });

    it('should allow null dates', () => {
      const member = createMember('1', 1);
      expect(member.birthDate).toBeNull();
      expect(member.deathDate).toBeNull();
    });
  });

  describe('Gender Consistency', () => {
    it('should validate gender values', () => {
      const validGenders = ['M', 'F', 'Unknown'];
      const member = createMember('1', 1);

      expect(validGenders).toContain(member.gender);
    });

    it('should reject invalid gender', () => {
      const validGenders = ['M', 'F', 'Unknown'];
      const invalidGender = 'X';

      expect(validGenders).not.toContain(invalidGender);
    });
  });

  describe('Name Validation', () => {
    it('should require non-empty names', () => {
      const member = createMember('1', 1);

      expect(member.firstName).toBeTruthy();
      expect(member.firstName.length).toBeGreaterThan(0);
    });

    it('should accept Arabic names', () => {
      const member = {
        ...createMember('1', 1),
        firstNameAr: 'محمد',
      };

      expect(member.firstNameAr).toBeTruthy();
      expect(/[\u0600-\u06FF]/.test(member.firstNameAr)).toBe(true);
    });
  });

  describe('User Association', () => {
    it('should require userId for all members', () => {
      const members = [
        createMember('1', 1),
        createMember('2', 2, '1'),
      ];

      const allHaveUserId = members.every((m) => m.userId);
      expect(allHaveUserId).toBe(true);
    });

    it('should detect members without userId', () => {
      const member = createMember('1', 1);
      const memberWithoutUserId = { ...member, userId: '' };

      expect(memberWithoutUserId.userId).toBeFalsy();
    });
  });

  describe('Batch Integrity Check', () => {
    it('should perform comprehensive integrity check', () => {
      const members = [
        createMember('1', 1),
        createMember('2', 2, '1'),
        createMember('3', 3, '2'),
      ];

      const memberMap = new Map(members.map((m) => [m.id, m]));

      interface IntegrityReport {
        valid: boolean;
        errors: string[];
      }

      const report: IntegrityReport = {
        valid: true,
        errors: [],
      };

      // Check for duplicates
      const ids = new Set<string>();
      members.forEach((m) => {
        if (ids.has(m.id)) {
          report.errors.push(`Duplicate ID: ${m.id}`);
          report.valid = false;
        }
        ids.add(m.id);
      });

      // Check for missing parents
      members.forEach((m) => {
        if (m.fatherId && !memberMap.has(m.fatherId)) {
          report.errors.push(`Missing parent ${m.fatherId} for ${m.id}`);
          report.valid = false;
        }
      });

      // Check generation consistency
      members.forEach((m) => {
        if (m.fatherId) {
          const father = memberMap.get(m.fatherId);
          if (father && m.generation <= father.generation) {
            report.errors.push(`Invalid generation for ${m.id}`);
            report.valid = false;
          }
        }
      });

      expect(report.valid).toBe(true);
      expect(report.errors).toHaveLength(0);
    });

    it('should report all errors in integrity check', () => {
      const members = [
        createMember('1', 1, 'non-existent'),
        createMember('2', 2, '1'),
        createMember('2', 3, '1'), // Duplicate ID
      ];

      const memberMap = new Map(members.map((m) => [m.id, m]));

      interface IntegrityReport {
        valid: boolean;
        errors: string[];
      }

      const report: IntegrityReport = {
        valid: true,
        errors: [],
      };

      // Check for duplicates
      const ids = new Set<string>();
      const seenIds = new Map<string, number>();
      members.forEach((m) => {
        seenIds.set(m.id, (seenIds.get(m.id) || 0) + 1);
      });

      seenIds.forEach((count, id) => {
        if (count > 1) {
          report.errors.push(`Duplicate ID: ${id}`);
          report.valid = false;
        }
      });

      // Check for missing parents
      members.forEach((m) => {
        if (m.fatherId && !memberMap.has(m.fatherId)) {
          report.errors.push(`Missing parent ${m.fatherId} for ${m.id}`);
          report.valid = false;
        }
      });

      expect(report.valid).toBe(false);
      expect(report.errors.length).toBeGreaterThan(0);
    });
  });
});
