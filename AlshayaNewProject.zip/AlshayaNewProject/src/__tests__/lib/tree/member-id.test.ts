import { nanoid } from 'nanoid';

// Mock nanoid
jest.mock('nanoid');

describe('Member ID Generation', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('should generate unique IDs using nanoid', () => {
    const mockNanoid = nanoid as jest.MockedFunction<typeof nanoid>;
    mockNanoid.mockReturnValueOnce('id-1').mockReturnValueOnce('id-2');

    const id1 = nanoid();
    const id2 = nanoid();

    expect(id1).not.toBe(id2);
    expect(mockNanoid).toHaveBeenCalledTimes(2);
  });

  it('should generate non-empty IDs', () => {
    const mockNanoid = nanoid as jest.MockedFunction<typeof nanoid>;
    mockNanoid.mockReturnValue('test-id');

    const id = nanoid();
    expect(id).toBeTruthy();
    expect(id.length).toBeGreaterThan(0);
  });

  it('should generate URL-safe IDs', () => {
    const mockNanoid = nanoid as jest.MockedFunction<typeof nanoid>;
    mockNanoid.mockReturnValue('V1StGXR_Z5j3eK_V8c');

    const id = nanoid();
    // nanoid by default generates URL-safe strings
    expect(/^[A-Za-z0-9_-]+$/.test(id)).toBe(true);
  });

  it('should generate IDs of consistent length by default', () => {
    const mockNanoid = nanoid as jest.MockedFunction<typeof nanoid>;
    mockNanoid.mockReturnValue('V1StGXR_Z5j3eK');

    const id1 = nanoid();
    const id2 = nanoid();

    expect(id1.length).toBe(id2.length);
  });

  it('should support custom length parameter', () => {
    const mockNanoid = nanoid as jest.MockedFunction<typeof nanoid>;
    mockNanoid.mockReturnValue('short');

    const id = nanoid(5);

    expect(mockNanoid).toHaveBeenCalledWith(5);
  });

  it('should generate IDs suitable for database primary keys', () => {
    const mockNanoid = nanoid as jest.MockedFunction<typeof nanoid>;
    mockNanoid.mockReturnValue('abc123XyZ_-');

    const id = nanoid();

    // Should be suitable for URLs and databases
    expect(id).toMatch(/^[A-Za-z0-9_-]+$/);
  });

  it('should be suitable for MongoDB ObjectId replacement', () => {
    const mockNanoid = nanoid as jest.MockedFunction<typeof nanoid>;
    mockNanoid.mockReturnValue('V1StGXR_Z5j3eK_V8');

    const id = nanoid();

    // Typical nanoid length is 21 characters
    expect(id.length).toBeGreaterThan(10);
    expect(id.length).toBeLessThan(50);
  });

  it('should maintain performance with many generation calls', () => {
    const mockNanoid = nanoid as jest.MockedFunction<typeof nanoid>;
    let counter = 0;
    mockNanoid.mockImplementation(() => `id-${++counter}`);

    const startTime = Date.now();
    const ids: string[] = [];

    for (let i = 0; i < 10000; i++) {
      ids.push(nanoid());
    }

    const endTime = Date.now();
    const duration = endTime - startTime;

    expect(ids.length).toBe(10000);
    expect(duration).toBeLessThan(1000); // Should be fast
  });

  it('should handle collision avoidance', () => {
    const mockNanoid = nanoid as jest.MockedFunction<typeof nanoid>;

    const ids = new Set<string>();
    let callCount = 0;

    mockNanoid.mockImplementation(() => {
      callCount++;
      return `id-${callCount}`;
    });

    for (let i = 0; i < 1000; i++) {
      ids.add(nanoid());
    }

    expect(ids.size).toBe(1000); // All unique
  });

  it('should work with thread-safe operations', () => {
    const mockNanoid = nanoid as jest.MockedFunction<typeof nanoid>;
    let counter = 0;
    mockNanoid.mockImplementation(() => `id-${++counter}`);

    const id1 = nanoid();
    const id2 = nanoid();
    const id3 = nanoid();

    expect(id1).not.toBe(id2);
    expect(id2).not.toBe(id3);
    expect(id1).not.toBe(id3);
  });

  it('should not contain confusing characters', () => {
    const mockNanoid = nanoid as jest.MockedFunction<typeof nanoid>;
    mockNanoid.mockReturnValue('V1StGXR_Z5j3eK');

    const id = nanoid();

    // Should not contain: I, O, l (lowercase L), 0, 1 (confusing in URLs)
    expect(id).not.toMatch(/[IOl01]/);
  });

  it('should be case-sensitive', () => {
    const mockNanoid = nanoid as jest.MockedFunction<typeof nanoid>;
    mockNanoid
      .mockReturnValueOnce('abc')
      .mockReturnValueOnce('ABC');

    const id1 = nanoid();
    const id2 = nanoid();

    expect(id1.toLowerCase()).toBe(id2.toLowerCase());
    expect(id1).not.toBe(id2);
  });

  it('should include both letters and numbers', () => {
    const mockNanoid = nanoid as jest.MockedFunction<typeof nanoid>;
    mockNanoid.mockReturnValue('V1StGXR_Z5j3eK_V8');

    const id = nanoid();

    const hasLetters = /[A-Za-z]/.test(id);
    const hasNumbers = /[0-9]/.test(id);

    expect(hasLetters).toBe(true);
    expect(hasNumbers).toBe(true);
  });

  it('should generate IDs without special characters except _ and -', () => {
    const mockNanoid = nanoid as jest.MockedFunction<typeof nanoid>;
    mockNanoid.mockReturnValue('V1St_GXR-Z5j3eK');

    const id = nanoid();

    expect(/^[A-Za-z0-9_-]+$/.test(id)).toBe(true);
  });

  it('should work with truncation for custom lengths', () => {
    const mockNanoid = nanoid as jest.MockedFunction<typeof nanoid>;
    mockNanoid.mockReturnValue('V1StGXR_Z5');

    const shortId = nanoid(10);

    expect(mockNanoid).toHaveBeenCalledWith(10);
  });

  it('should be suitable for cache keys', () => {
    const mockNanoid = nanoid as jest.MockedFunction<typeof nanoid>;
    mockNanoid.mockReturnValue('cache_key_123_ABC');

    const cacheKey = nanoid();

    expect(cacheKey).toBeTruthy();
    expect(/^[A-Za-z0-9_-]+$/.test(cacheKey)).toBe(true);
  });

  it('should be suitable for API endpoints', () => {
    const mockNanoid = nanoid as jest.MockedFunction<typeof nanoid>;
    mockNanoid.mockReturnValue('V1StGXR_Z5j3eK_V8');

    const id = nanoid();
    const endpoint = `/api/members/${id}`;

    expect(endpoint).toBeTruthy();
    expect(endpoint).toMatch(/\/api\/members\/[A-Za-z0-9_-]+/);
  });

  it('should support batch ID generation', () => {
    const mockNanoid = nanoid as jest.MockedFunction<typeof nanoid>;
    let counter = 0;
    mockNanoid.mockImplementation(() => `batch-${++counter}`);

    const ids = Array.from({ length: 100 }, () => nanoid());

    expect(ids.length).toBe(100);
    expect(new Set(ids).size).toBe(100); // All unique
  });
});
