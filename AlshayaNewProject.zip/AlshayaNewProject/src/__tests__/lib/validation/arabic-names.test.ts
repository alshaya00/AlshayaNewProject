import {
  removeDiacritics,
  normalizeAlef,
  normalizeTaaMarbuta,
  normalizeAlefMaksura,
  normalizeHamza,
  normalizeArabicName,
  fuzzyMatchArabicNames,
  calculateNameSimilarity,
  extractNamesFromLineage,
  findMemberByFuzzyName,
  findMembersByNameSimilarity,
  isValidArabicName,
  formatArabicName,
} from '@/lib/validation/arabic-names';

describe('Arabic Name Normalization', () => {
  describe('removeDiacritics', () => {
    it('should remove fatha', () => {
      expect(removeDiacritics('مَحمد')).toBe('محمد');
    });

    it('should remove damma', () => {
      expect(removeDiacritics('مُحمد')).toBe('محمد');
    });

    it('should remove kasra', () => {
      expect(removeDiacritics('مِحمد')).toBe('محمد');
    });

    it('should remove shadda', () => {
      expect(removeDiacritics('محمّد')).toBe('محمد');
    });

    it('should remove all diacritics', () => {
      expect(removeDiacritics('مُحَمَّد')).toBe('محمد');
    });

    it('should return empty string for empty input', () => {
      expect(removeDiacritics('')).toBe('');
    });

    it('should handle text with multiple diacritics', () => {
      expect(removeDiacritics('سُلَيْمَان')).toBe('سليمان');
    });

    it('should preserve text without diacritics', () => {
      expect(removeDiacritics('محمد')).toBe('محمد');
    });
  });

  describe('normalizeAlef', () => {
    it('should normalize alef with hamza above', () => {
      expect(normalizeAlef('أحمد')).toBe('احمد');
    });

    it('should normalize alef with hamza below', () => {
      expect(normalizeAlef('إبراهيم')).toBe('ابراهيم');
    });

    it('should normalize alef with madda', () => {
      expect(normalizeAlef('آدم')).toBe('ادم');
    });

    it('should normalize all alef variants', () => {
      expect(normalizeAlef('أإآ')).toBe('اا ا');
    });

    it('should return empty for empty input', () => {
      expect(normalizeAlef('')).toBe('');
    });

    it('should preserve plain alef', () => {
      expect(normalizeAlef('احمد')).toBe('احمد');
    });

    it('should handle mixed alef variants', () => {
      expect(normalizeAlef('أحمد إبراهيم آدم')).toBe('احمد ابراهيم ادم');
    });
  });

  describe('normalizeTaaMarbuta', () => {
    it('should normalize ta marbuta to ha', () => {
      expect(normalizeTaaMarbuta('فاطمة')).toBe('فاطمه');
    });

    it('should handle multiple ta marbutas', () => {
      expect(normalizeTaaMarbuta('زينة عائشة')).toBe('زينه عائشه');
    });

    it('should return empty for empty input', () => {
      expect(normalizeTaaMarbuta('')).toBe('');
    });

    it('should preserve other letters', () => {
      expect(normalizeTaaMarbuta('فاطمة علي')).toBe('فاطمه علي');
    });
  });

  describe('normalizeAlefMaksura', () => {
    it('should normalize alef maksura to ya', () => {
      expect(normalizeAlefMaksura('مصطفى')).toBe('مصطفي');
    });

    it('should handle multiple alef maksuras', () => {
      expect(normalizeAlefMaksura('موسى علي')).toContain('موسي');
    });

    it('should return empty for empty input', () => {
      expect(normalizeAlefMaksura('')).toBe('');
    });

    it('should preserve other ya letters', () => {
      expect(normalizeAlefMaksura('يوسف')).toBe('يوسف');
    });
  });

  describe('normalizeHamza', () => {
    it('should remove hamza', () => {
      expect(normalizeHamza('سؤال')).toBe('سوال');
    });

    it('should handle multiple hamzas', () => {
      expect(normalizeHamza('سؤال قرآن')).toBe('سوال قران');
    });

    it('should return empty for empty input', () => {
      expect(normalizeHamza('')).toBe('');
    });
  });

  describe('normalizeArabicName', () => {
    it('should normalize complete name with diacritics', () => {
      expect(normalizeArabicName('مُحَمَّد')).toBe('محمد');
    });

    it('should normalize name with alef variants', () => {
      expect(normalizeArabicName('إبراهيم')).toBe('ابراهيم');
    });

    it('should normalize with multiple rules', () => {
      expect(normalizeArabicName('مُحَمَّد أحْمَد')).toBe('محمد احمد');
    });

    it('should remove family prefix آل', () => {
      expect(normalizeArabicName('آل شايع')).toBe('شايع');
    });

    it('should remove family prefix ال', () => {
      expect(normalizeArabicName('ال شايع')).toBe('شايع');
    });

    it('should normalize extra spaces', () => {
      expect(normalizeArabicName('محمد  علي')).toBe('محمد علي');
    });

    it('should trim whitespace', () => {
      expect(normalizeArabicName('  محمد  ')).toBe('محمد');
    });

    it('should return empty for empty input', () => {
      expect(normalizeArabicName('')).toBe('');
    });

    it('should handle complex names', () => {
      expect(normalizeArabicName('عَبْدُ الرَّحْمَٰن مُحَمَّد')).toBe('عبد الرحمن محمد');
    });

    it('should handle Al- prefix with space', () => {
      expect(normalizeArabicName('ال محمد')).toBe('محمد');
    });
  });

  describe('fuzzyMatchArabicNames', () => {
    it('should match identical names', () => {
      expect(fuzzyMatchArabicNames('محمد', 'محمد')).toBe(true);
    });

    it('should match names with diacritics removed', () => {
      expect(fuzzyMatchArabicNames('مُحَمَّد', 'محمد')).toBe(true);
    });

    it('should match name variations', () => {
      expect(fuzzyMatchArabicNames('عبدالله', 'عبد الله')).toBe(true);
    });

    it('should match عبدالرحمن variations', () => {
      expect(fuzzyMatchArabicNames('عبدالرحمن', 'عبد الرحمن')).toBe(true);
    });

    it('should match without spaces', () => {
      expect(fuzzyMatchArabicNames('محمد علي', 'محمدعلي')).toBe(true);
    });

    it('should not match different names', () => {
      expect(fuzzyMatchArabicNames('محمد', 'أحمد')).toBe(false);
    });

    it('should return false for empty strings', () => {
      expect(fuzzyMatchArabicNames('', 'محمد')).toBe(false);
      expect(fuzzyMatchArabicNames('محمد', '')).toBe(false);
      expect(fuzzyMatchArabicNames('', '')).toBe(false);
    });

    it('should match with family prefix removed', () => {
      expect(fuzzyMatchArabicNames('آل شايع', 'شايع')).toBe(true);
    });

    it('should match with alef normalization', () => {
      expect(fuzzyMatchArabicNames('إبراهيم', 'ابراهيم')).toBe(true);
    });

    it('should match عبدالكريم variations', () => {
      expect(fuzzyMatchArabicNames('عبدالكريم', 'عبد الكريم')).toBe(true);
    });
  });

  describe('calculateNameSimilarity', () => {
    it('should return 100 for identical names', () => {
      expect(calculateNameSimilarity('محمد', 'محمد')).toBe(100);
    });

    it('should return 100 for names with diacritics', () => {
      expect(calculateNameSimilarity('مُحَمَّد', 'محمد')).toBe(100);
    });

    it('should return high score for very similar names', () => {
      const score = calculateNameSimilarity('محمد', 'محمود');
      expect(score).toBeGreaterThan(70);
    });

    it('should return low score for different names', () => {
      const score = calculateNameSimilarity('محمد', 'علي');
      expect(score).toBeLessThan(30);
    });

    it('should return 0 for empty strings', () => {
      expect(calculateNameSimilarity('', 'محمد')).toBe(0);
      expect(calculateNameSimilarity('محمد', '')).toBe(0);
    });

    it('should be symmetric', () => {
      const score1 = calculateNameSimilarity('محمد', 'احمد');
      const score2 = calculateNameSimilarity('احمد', 'محمد');
      expect(score1).toBe(score2);
    });

    it('should never exceed 100', () => {
      const score = calculateNameSimilarity('محمد محمد محمد', 'محمد');
      expect(score).toBeLessThanOrEqual(100);
    });

    it('should never be negative', () => {
      const score = calculateNameSimilarity('محمد', '的确是的');
      expect(score).toBeGreaterThanOrEqual(0);
    });

    it('should handle long names', () => {
      const name1 = 'عبدالرحمن محمد علي سعد خالد';
      const name2 = 'عبدالرحمن محمد علي سعد';
      const score = calculateNameSimilarity(name1, name2);
      expect(score).toBeGreaterThan(70);
    });
  });

  describe('extractNamesFromLineage', () => {
    it('should extract single name', () => {
      expect(extractNamesFromLineage('محمد')).toEqual(['محمد']);
    });

    it('should extract names separated by بن', () => {
      expect(extractNamesFromLineage('محمد بن علي')).toEqual(['محمد', 'علي']);
    });

    it('should extract multiple ancestors', () => {
      expect(extractNamesFromLineage('سعد بن ناصر بن إبراهيم')).toEqual([
        'سعد',
        'ناصر',
        'إبراهيم',
      ]);
    });

    it('should remove family name', () => {
      expect(extractNamesFromLineage('محمد علي آل شايع')).toContain('محمد');
      expect(extractNamesFromLineage('محمد علي آل شايع')).not.toContain('شايع');
    });

    it('should handle بنت for females', () => {
      const result = extractNamesFromLineage('فاطمة بنت محمد');
      expect(result).toContain('فاطمة');
      expect(result).toContain('محمد');
    });

    it('should return empty array for empty input', () => {
      expect(extractNamesFromLineage('')).toEqual([]);
    });

    it('should handle multiple spaces around بن', () => {
      expect(extractNamesFromLineage('محمد   بن   علي')).toEqual(['محمد', 'علي']);
    });

    it('should trim whitespace from names', () => {
      expect(extractNamesFromLineage(' محمد بن علي ')).toEqual(['محمد', 'علي']);
    });

    it('should handle mixed بن and بنت', () => {
      const result = extractNamesFromLineage('فاطمة بنت محمد بن علي');
      expect(result.length).toBe(3);
    });

    it('should handle no spaces around بن', () => {
      expect(extractNamesFromLineage('محمدبنعلي')).toEqual(['محمد', 'علي']);
    });
  });

  describe('findMemberByFuzzyName', () => {
    const members = [
      { firstName: 'محمد', id: '1' },
      { firstName: 'علي', id: '2' },
      { firstName: 'سارة', id: '3' },
    ];

    it('should find exact match', () => {
      const result = findMemberByFuzzyName('محمد', members);
      expect(result?.id).toBe('1');
    });

    it('should find fuzzy match with diacritics', () => {
      const result = findMemberByFuzzyName('مُحَمَّد', members);
      expect(result?.id).toBe('1');
    });

    it('should return null for not found', () => {
      const result = findMemberByFuzzyName('خالد', members);
      expect(result).toBeNull();
    });

    it('should return null for empty name', () => {
      const result = findMemberByFuzzyName('', members);
      expect(result).toBeNull();
    });

    it('should handle case sensitivity', () => {
      const result = findMemberByFuzzyName('محمد', members);
      expect(result).not.toBeNull();
    });

    it('should find first match among variations', () => {
      const result = findMemberByFuzzyName('علي', members);
      expect(result?.id).toBe('2');
    });
  });

  describe('findMembersByNameSimilarity', () => {
    const members = [
      { firstName: 'محمد', id: '1' },
      { firstName: 'احمد', id: '2' },
      { firstName: 'محمود', id: '3' },
      { firstName: 'علي', id: '4' },
    ];

    it('should find members above threshold', () => {
      const results = findMembersByNameSimilarity('محمد', members, 70);
      expect(results.length).toBeGreaterThan(0);
    });

    it('should include exact match', () => {
      const results = findMembersByNameSimilarity('محمد', members, 70);
      const exactMatch = results.find((r) => r.member.id === '1');
      expect(exactMatch).toBeDefined();
    });

    it('should sort by similarity descending', () => {
      const results = findMembersByNameSimilarity('محمد', members, 50);
      for (let i = 0; i < results.length - 1; i++) {
        expect(results[i].similarity).toBeGreaterThanOrEqual(results[i + 1].similarity);
      }
    });

    it('should respect threshold', () => {
      const results = findMembersByNameSimilarity('محمد', members, 95);
      results.forEach((r) => {
        expect(r.similarity).toBeGreaterThanOrEqual(95);
      });
    });

    it('should return empty for high threshold', () => {
      const results = findMembersByNameSimilarity('محمد', members, 99.9);
      expect(results.length).toBeLessThanOrEqual(1);
    });

    it('should handle default threshold', () => {
      const results = findMembersByNameSimilarity('محمد', members);
      expect(Array.isArray(results)).toBe(true);
    });

    it('should include similarity score', () => {
      const results = findMembersByNameSimilarity('محمد', members, 50);
      results.forEach((r) => {
        expect(typeof r.similarity).toBe('number');
        expect(r.similarity).toBeGreaterThanOrEqual(0);
        expect(r.similarity).toBeLessThanOrEqual(100);
      });
    });

    it('should return empty for empty input', () => {
      const results = findMembersByNameSimilarity('', members);
      expect(results).toEqual([]);
    });
  });

  describe('isValidArabicName', () => {
    it('should accept valid Arabic name', () => {
      expect(isValidArabicName('محمد')).toBe(true);
    });

    it('should accept name with spaces', () => {
      expect(isValidArabicName('محمد علي')).toBe(true);
    });

    it('should accept name with dash', () => {
      expect(isValidArabicName('عبد-الرحمن')).toBe(true);
    });

    it('should reject English name', () => {
      expect(isValidArabicName('Muhammad')).toBe(false);
    });

    it('should reject single character', () => {
      expect(isValidArabicName('م')).toBe(false);
    });

    it('should reject empty string', () => {
      expect(isValidArabicName('')).toBe(false);
    });

    it('should reject name with numbers', () => {
      expect(isValidArabicName('محمد 123')).toBe(false);
    });

    it('should accept name with apostrophe', () => {
      expect(isValidArabicName("أم'أحمد")).toBe(true);
    });

    it('should accept minimum 2 characters', () => {
      expect(isValidArabicName('محمد')).toBe(true);
    });

    it('should reject mixed scripts', () => {
      expect(isValidArabicName('محمد John')).toBe(false);
    });

    it('should accept long names', () => {
      expect(isValidArabicName('عبدالرحمن محمد علي سعد خالد')).toBe(true);
    });
  });

  describe('formatArabicName', () => {
    it('should trim whitespace', () => {
      expect(formatArabicName('  محمد  ')).toBe('محمد');
    });

    it('should normalize extra spaces', () => {
      expect(formatArabicName('محمد   علي')).toBe('محمد علي');
    });

    it('should return empty string for empty input', () => {
      expect(formatArabicName('')).toBe('');
    });

    it('should preserve original formatting', () => {
      expect(formatArabicName('محمد علي')).toBe('محمد علي');
    });

    it('should handle multiple names', () => {
      expect(formatArabicName('عبدالرحمن محمد علي')).toBe('عبدالرحمن محمد علي');
    });

    it('should normalize multiple consecutive spaces', () => {
      expect(formatArabicName('محمد    علي    سعد')).toBe('محمد علي سعد');
    });
  });

  describe('Integration tests', () => {
    it('should handle complete workflow', () => {
      const name = 'مُحَمَّد بن إبراهيم آل شايع';
      const normalized = normalizeArabicName(name);
      expect(normalized).toBe('محمد بن ابراهيم');
    });

    it('should match variations in lineage', () => {
      const lineage1 = 'سعد بن ناصر بن إبراهيم';
      const lineage2 = 'سعد بن ناصر بن ابراهيم';
      const names1 = extractNamesFromLineage(lineage1);
      const names2 = extractNamesFromLineage(lineage2);

      for (let i = 0; i < names1.length; i++) {
        expect(fuzzyMatchArabicNames(names1[i], names2[i])).toBe(true);
      }
    });

    it('should find members with various name formats', () => {
      const members = [
        { firstName: 'محمد علي', id: '1' },
        { firstName: 'احمد سعد', id: '2' },
      ];

      const result1 = findMemberByFuzzyName('مُحَمَّد عَلي', members);
      expect(result1?.id).toBe('1');

      const results2 = findMembersByNameSimilarity('احمد', members, 70);
      const found = results2.find((r) => r.member.id === '2');
      expect(found).toBeDefined();
    });
  });
});
