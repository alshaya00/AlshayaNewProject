import {
  idSchema,
  emailSchema,
  phoneSchema,
  passwordSchema,
  arabicNameSchema,
  englishNameSchema,
  loginSchema,
  registerSchema,
  passwordResetSchema,
  twoFactorVerifySchema,
} from '@/lib/validation/schemas';

describe('Validation Schemas', () => {
  describe('idSchema', () => {
    it('should validate non-empty string', () => {
      const result = idSchema.safeParse('valid-id-123');
      expect(result.success).toBe(true);
    });

    it('should reject empty string', () => {
      const result = idSchema.safeParse('');
      expect(result.success).toBe(false);
    });

    it('should reject string exceeding max length', () => {
      const result = idSchema.safeParse('a'.repeat(256));
      expect(result.success).toBe(false);
    });

    it('should accept UUID', () => {
      const uuid = '550e8400-e29b-41d4-a716-446655440000';
      const result = idSchema.safeParse(uuid);
      expect(result.success).toBe(true);
    });

    it('should accept numeric string', () => {
      const result = idSchema.safeParse('12345');
      expect(result.success).toBe(true);
    });
  });

  describe('emailSchema', () => {
    it('should validate correct email', () => {
      const result = emailSchema.safeParse('user@example.com');
      expect(result.success).toBe(true);
      expect(result.data).toBe('user@example.com');
    });

    it('should lowercase email', () => {
      const result = emailSchema.safeParse('User@Example.COM');
      expect(result.success).toBe(true);
      expect(result.data).toBe('user@example.com');
    });

    it('should reject invalid email', () => {
      const result = emailSchema.safeParse('not-an-email');
      expect(result.success).toBe(false);
    });

    it('should reject email without domain', () => {
      const result = emailSchema.safeParse('user@');
      expect(result.success).toBe(false);
    });

    it('should accept subdomain', () => {
      const result = emailSchema.safeParse('user@mail.example.co.uk');
      expect(result.success).toBe(true);
    });

    it('should handle international domain', () => {
      const result = emailSchema.safeParse('user@example.إس');
      expect(result.success).toBe(true);
    });

    it('should reject empty string', () => {
      const result = emailSchema.safeParse('');
      expect(result.success).toBe(false);
    });

    it('should accept plus addressing', () => {
      const result = emailSchema.safeParse('user+test@example.com');
      expect(result.success).toBe(true);
    });

    it('should accept domain-only TLD', () => {
      const result = emailSchema.safeParse('user@localhost.local');
      expect(result.success).toBe(true);
    });
  });

  describe('phoneSchema', () => {
    it('should accept valid Saudi phone starting with 05', () => {
      const result = phoneSchema.safeParse('0512345678');
      expect(result.success).toBe(true);
    });

    it('should accept phone with spaces', () => {
      const result = phoneSchema.safeParse('05 1234 5678');
      expect(result.success).toBe(true);
    });

    it('should accept phone with dashes', () => {
      const result = phoneSchema.safeParse('05-1234-5678');
      expect(result.success).toBe(true);
    });

    it('should accept international format +966', () => {
      const result = phoneSchema.safeParse('+966512345678');
      expect(result.success).toBe(true);
    });

    it('should accept 00966 format', () => {
      const result = phoneSchema.safeParse('00966512345678');
      expect(result.success).toBe(true);
    });

    it('should accept 966 format', () => {
      const result = phoneSchema.safeParse('966512345678');
      expect(result.success).toBe(true);
    });

    it('should accept short format 5XXXXXXXX', () => {
      const result = phoneSchema.safeParse('512345678');
      expect(result.success).toBe(true);
    });

    it('should be optional', () => {
      const result = phoneSchema.safeParse('');
      expect(result.success).toBe(true);
    });

    it('should accept undefined', () => {
      const result = phoneSchema.safeParse(undefined);
      expect(result.success).toBe(true);
    });

    it('should reject non-5xxx mobile', () => {
      const result = phoneSchema.safeParse('0541234567'); // 4 instead of 5
      expect(result.success).toBe(false);
    });

    it('should reject wrong length', () => {
      const result = phoneSchema.safeParse('05123456'); // Too short
      expect(result.success).toBe(false);
    });

    it('should handle parentheses in phone', () => {
      const result = phoneSchema.safeParse('(05) 123-4567');
      expect(result.success).toBe(true);
    });
  });

  describe('passwordSchema', () => {
    it('should validate strong password', () => {
      const result = passwordSchema.safeParse('StrongPass123');
      expect(result.success).toBe(true);
    });

    it('should reject short password', () => {
      const result = passwordSchema.safeParse('Pass1');
      expect(result.success).toBe(false);
    });

    it('should require uppercase', () => {
      const result = passwordSchema.safeParse('password123');
      expect(result.success).toBe(false);
    });

    it('should require lowercase', () => {
      const result = passwordSchema.safeParse('PASSWORD123');
      expect(result.success).toBe(false);
    });

    it('should require number', () => {
      const result = passwordSchema.safeParse('PasswordAbcd');
      expect(result.success).toBe(false);
    });

    it('should accept special characters', () => {
      const result = passwordSchema.safeParse('Pass123!@#');
      expect(result.success).toBe(true);
    });

    it('should accept minimum valid password', () => {
      const result = passwordSchema.safeParse('Passw0rd');
      expect(result.success).toBe(true);
    });

    it('should accept long password', () => {
      const result = passwordSchema.safeParse('VeryLongPassword123WithManyCharacters');
      expect(result.success).toBe(true);
    });

    it('should accept unicode characters', () => {
      const result = passwordSchema.safeParse('Pass123إسم');
      expect(result.success).toBe(true);
    });
  });

  describe('arabicNameSchema', () => {
    it('should validate Arabic name', () => {
      const result = arabicNameSchema.safeParse('محمد');
      expect(result.success).toBe(true);
    });

    it('should validate Arabic name with spaces', () => {
      const result = arabicNameSchema.safeParse('محمد علي');
      expect(result.success).toBe(true);
    });

    it('should reject English name', () => {
      const result = arabicNameSchema.safeParse('John');
      expect(result.success).toBe(false);
    });

    it('should reject short name', () => {
      const result = arabicNameSchema.safeParse('م');
      expect(result.success).toBe(false);
    });

    it('should accept minimum length 2', () => {
      const result = arabicNameSchema.safeParse('مح');
      expect(result.success).toBe(true);
    });

    it('should reject numbers', () => {
      const result = arabicNameSchema.safeParse('محمد123');
      expect(result.success).toBe(false);
    });

    it('should reject special characters', () => {
      const result = arabicNameSchema.safeParse('محمد!');
      expect(result.success).toBe(false);
    });

    it('should accept long Arabic name', () => {
      const result = arabicNameSchema.safeParse('عبدالرحمن محمد علي');
      expect(result.success).toBe(true);
    });

    it('should handle common Arabic names', () => {
      const names = ['فاطمة', 'عائشة', 'زينب', 'خديجة', 'سارة'];
      names.forEach((name) => {
        const result = arabicNameSchema.safeParse(name);
        expect(result.success).toBe(true);
      });
    });
  });

  describe('englishNameSchema', () => {
    it('should validate English name', () => {
      const result = englishNameSchema.safeParse('John');
      expect(result.success).toBe(true);
    });

    it('should validate English name with spaces', () => {
      const result = englishNameSchema.safeParse('John Smith');
      expect(result.success).toBe(true);
    });

    it('should be optional', () => {
      const result = englishNameSchema.safeParse('');
      expect(result.success).toBe(true);
    });

    it('should accept undefined', () => {
      const result = englishNameSchema.safeParse(undefined);
      expect(result.success).toBe(true);
    });

    it('should reject Arabic name', () => {
      const result = englishNameSchema.safeParse('محمد');
      expect(result.success).toBe(false);
    });

    it('should reject numbers', () => {
      const result = englishNameSchema.safeParse('John123');
      expect(result.success).toBe(false);
    });

    it('should accept mixed case', () => {
      const result = englishNameSchema.safeParse('JoHn');
      expect(result.success).toBe(true);
    });

    it('should accept names with hyphen is invalid', () => {
      const result = englishNameSchema.safeParse('Mary-Jane');
      expect(result.success).toBe(false); // Regex only allows a-zA-Z and spaces
    });

    it('should accept minimum length 2', () => {
      const result = englishNameSchema.safeParse('Jo');
      expect(result.success).toBe(true);
    });
  });

  describe('loginSchema', () => {
    it('should validate correct login', () => {
      const result = loginSchema.safeParse({
        email: 'user@example.com',
        password: 'Password123',
      });
      expect(result.success).toBe(true);
    });

    it('should lowercase email in login', () => {
      const result = loginSchema.safeParse({
        email: 'User@Example.COM',
        password: 'Password123',
      });
      expect(result.success).toBe(true);
      expect(result.data?.email).toBe('user@example.com');
    });

    it('should accept remember me flag', () => {
      const result = loginSchema.safeParse({
        email: 'user@example.com',
        password: 'Password123',
        rememberMe: true,
      });
      expect(result.success).toBe(true);
      expect(result.data?.rememberMe).toBe(true);
    });

    it('should default remember me to false', () => {
      const result = loginSchema.safeParse({
        email: 'user@example.com',
        password: 'Password123',
      });
      expect(result.success).toBe(true);
      expect(result.data?.rememberMe).toBe(false);
    });

    it('should reject invalid email', () => {
      const result = loginSchema.safeParse({
        email: 'not-an-email',
        password: 'Password123',
      });
      expect(result.success).toBe(false);
    });

    it('should reject missing password', () => {
      const result = loginSchema.safeParse({
        email: 'user@example.com',
      });
      expect(result.success).toBe(false);
    });

    it('should reject missing email', () => {
      const result = loginSchema.safeParse({
        password: 'Password123',
      });
      expect(result.success).toBe(false);
    });
  });

  describe('registerSchema', () => {
    it('should validate complete registration', () => {
      const result = registerSchema.safeParse({
        email: 'user@example.com',
        password: 'Password123',
        nameArabic: 'محمد',
        nameEnglish: 'Muhammad',
        phone: '0512345678',
      });
      expect(result.success).toBe(true);
    });

    it('should accept optional nameEnglish', () => {
      const result = registerSchema.safeParse({
        email: 'user@example.com',
        password: 'Password123',
        nameArabic: 'محمد',
        nameEnglish: '',
      });
      expect(result.success).toBe(true);
    });

    it('should accept optional phone', () => {
      const result = registerSchema.safeParse({
        email: 'user@example.com',
        password: 'Password123',
        nameArabic: 'محمد',
        nameEnglish: 'Muhammad',
      });
      expect(result.success).toBe(true);
    });

    it('should reject weak password', () => {
      const result = registerSchema.safeParse({
        email: 'user@example.com',
        password: 'weak',
        nameArabic: 'محمد',
        nameEnglish: 'Muhammad',
      });
      expect(result.success).toBe(false);
    });

    it('should reject invalid Arabic name', () => {
      const result = registerSchema.safeParse({
        email: 'user@example.com',
        password: 'Password123',
        nameArabic: 'Muhammad',
        nameEnglish: 'Muhammad',
      });
      expect(result.success).toBe(false);
    });

    it('should reject invalid email', () => {
      const result = registerSchema.safeParse({
        email: 'not-an-email',
        password: 'Password123',
        nameArabic: 'محمد',
        nameEnglish: 'Muhammad',
      });
      expect(result.success).toBe(false);
    });

    it('should reject invalid phone', () => {
      const result = registerSchema.safeParse({
        email: 'user@example.com',
        password: 'Password123',
        nameArabic: 'محمد',
        nameEnglish: 'Muhammad',
        phone: 'invalid-phone',
      });
      expect(result.success).toBe(false);
    });
  });

  describe('passwordResetSchema', () => {
    it('should validate reset with matching passwords', () => {
      const result = passwordResetSchema.safeParse({
        token: 'reset-token-123',
        password: 'NewPassword123',
        confirmPassword: 'NewPassword123',
      });
      expect(result.success).toBe(true);
    });

    it('should reject non-matching passwords', () => {
      const result = passwordResetSchema.safeParse({
        token: 'reset-token-123',
        password: 'NewPassword123',
        confirmPassword: 'DifferentPassword123',
      });
      expect(result.success).toBe(false);
    });

    it('should reject weak password', () => {
      const result = passwordResetSchema.safeParse({
        token: 'reset-token-123',
        password: 'weak',
        confirmPassword: 'weak',
      });
      expect(result.success).toBe(false);
    });

    it('should require token', () => {
      const result = passwordResetSchema.safeParse({
        token: '',
        password: 'NewPassword123',
        confirmPassword: 'NewPassword123',
      });
      expect(result.success).toBe(false);
    });

    it('should provide helpful error message for mismatch', () => {
      const result = passwordResetSchema.safeParse({
        token: 'token',
        password: 'Password123',
        confirmPassword: 'Different123',
      });
      expect(result.success).toBe(false);
      if (!result.success) {
        const passwordError = result.error.issues.find((i) => i.path.includes('confirmPassword'));
        expect(passwordError?.message).toContain("don't match");
      }
    });
  });

  describe('twoFactorVerifySchema', () => {
    it('should validate 6-digit code', () => {
      const result = twoFactorVerifySchema.safeParse({
        code: '123456',
      });
      expect(result.success).toBe(true);
    });

    it('should accept optional backup code', () => {
      const result = twoFactorVerifySchema.safeParse({
        code: '123456',
        backupCode: 'backup-code-123',
      });
      expect(result.success).toBe(true);
    });

    it('should reject non-numeric code', () => {
      const result = twoFactorVerifySchema.safeParse({
        code: '12345a',
      });
      expect(result.success).toBe(false);
    });

    it('should reject code with less than 6 digits', () => {
      const result = twoFactorVerifySchema.safeParse({
        code: '12345',
      });
      expect(result.success).toBe(false);
    });

    it('should reject code with more than 6 digits', () => {
      const result = twoFactorVerifySchema.safeParse({
        code: '1234567',
      });
      expect(result.success).toBe(false);
    });

    it('should reject empty code', () => {
      const result = twoFactorVerifySchema.safeParse({
        code: '',
      });
      expect(result.success).toBe(false);
    });

    it('should require code field', () => {
      const result = twoFactorVerifySchema.safeParse({});
      expect(result.success).toBe(false);
    });

    it('should accept 000000 as valid code', () => {
      const result = twoFactorVerifySchema.safeParse({
        code: '000000',
      });
      expect(result.success).toBe(true);
    });

    it('should accept 999999 as valid code', () => {
      const result = twoFactorVerifySchema.safeParse({
        code: '999999',
      });
      expect(result.success).toBe(true);
    });
  });

  describe('Schema edge cases', () => {
    it('should handle null values', () => {
      const result = idSchema.safeParse(null);
      expect(result.success).toBe(false);
    });

    it('should handle undefined values', () => {
      const result = emailSchema.safeParse(undefined);
      expect(result.success).toBe(false);
    });

    it('should trim whitespace appropriately', () => {
      const result = emailSchema.safeParse('  user@example.com  ');
      // Zod doesn't trim by default, but most modern versions do
      expect(result.success).toBe(false);
    });

    it('should handle very long strings', () => {
      const longString = 'a'.repeat(10000);
      const result = idSchema.safeParse(longString);
      expect(result.success).toBe(false);
    });

    it('should validate complex Arabic name combinations', () => {
      const result = arabicNameSchema.safeParse('عبد الرحمن محمد علي الشايع');
      expect(result.success).toBe(true);
    });
  });
});
