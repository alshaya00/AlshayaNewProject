/**
 * Authentication-Specific Types
 */

import { prisma } from '@/lib/db/prisma';
import { PermissionKey, SessionUser, UserRole } from './index';

/**
 * Get session user from database
 * Fetches user with all permissions populated
 */
export async function getSessionUser(userId: string): Promise<SessionUser | null> {
  try {
    const user = await prisma.user.findUnique({
      where: { id: userId },
    });

    if (!user) return null;

    // Get permissions based on role
    const permissions = getPermissionsForRole(user.role as UserRole);

    return {
      id: user.id,
      email: user.email,
      nameArabic: user.nameArabic,
      nameEnglish: user.nameEnglish || undefined,
      role: user.role as UserRole,
      status: user.status as 'ACTIVE' | 'PENDING' | 'DISABLED',
      linkedMemberId: user.linkedMemberId || undefined,
      assignedBranch: user.assignedBranch || undefined,
      permissions,
      twoFactorEnabled: user.twoFactorEnabled,
      lastLoginAt: user.lastLoginAt || undefined,
      createdAt: user.createdAt,
    };
  } catch (error) {
    console.error('[Auth] Error getting session user:', error);
    return null;
  }
}

/**
 * Get permissions for a specific role
 */
export function getPermissionsForRole(role: UserRole): Record<PermissionKey, boolean> {
  const basePermissions: Record<PermissionKey, boolean> = {
    view_members: false,
    add_member: false,
    edit_member: false,
    delete_member: false,
    change_parent: false,
    export_data: false,
    import_data: false,
    manage_duplicates: false,
    view_history: false,
    rollback_changes: false,
    create_snapshots: false,
    manage_admins: false,
    approve_pending_members: false,
    manage_branch_links: false,
    invite_users: false,
  };

  const rolePermissions: Record<UserRole, Record<PermissionKey, boolean>> = {
    SUPER_ADMIN: {
      ...basePermissions,
      view_members: true,
      add_member: true,
      edit_member: true,
      delete_member: true,
      change_parent: true,
      export_data: true,
      import_data: true,
      manage_duplicates: true,
      view_history: true,
      rollback_changes: true,
      create_snapshots: true,
      manage_admins: true,
      approve_pending_members: true,
      manage_branch_links: true,
      invite_users: true,
    },
    ADMIN: {
      ...basePermissions,
      view_members: true,
      add_member: true,
      edit_member: true,
      delete_member: true,
      change_parent: true,
      export_data: true,
      import_data: true,
      manage_duplicates: true,
      view_history: true,
      rollback_changes: true,
      create_snapshots: true,
      approve_pending_members: true,
      manage_branch_links: true,
      invite_users: true,
    },
    BRANCH_LEADER: {
      ...basePermissions,
      view_members: true,
      add_member: true,
      edit_member: true,
      export_data: true,
      view_history: true,
      create_snapshots: true,
      approve_pending_members: true,
      manage_branch_links: true,
    },
    MEMBER: {
      ...basePermissions,
      view_members: true,
      export_data: true,
    },
    GUEST: {
      ...basePermissions,
      view_members: true,
    },
  };

  return rolePermissions[role] || basePermissions;
}

/**
 * Login credentials
 */
export interface LoginCredentials {
  email: string;
  password: string;
  rememberMe?: boolean;
}

/**
 * Registration credentials
 */
export interface RegisterCredentials {
  email: string;
  password: string;
  nameArabic: string;
  nameEnglish?: string;
  phone?: string;
}

/**
 * Password reset request
 */
export interface PasswordResetRequest {
  token: string;
  password: string;
  confirmPassword: string;
}

/**
 * Two-factor authentication setup
 */
export interface TwoFactorSetup {
  method: 'TOTP' | 'SMS';
  secret?: string;
  qrCode?: string;
  backupCodes?: string[];
}

/**
 * Two-factor authentication verification
 */
export interface TwoFactorVerification {
  code: string;
  backupCode?: string;
}

/**
 * Session token payload
 */
export interface SessionTokenPayload {
  userId: string;
  email: string;
  role: UserRole;
  iat?: number;
  exp?: number;
}

/**
 * OAuth provider info
 */
export interface OAuthProvider {
  name: string;
  clientId: string;
  clientSecret: string;
  redirectUri: string;
}

/**
 * OAuth user info
 */
export interface OAuthUserInfo {
  id: string;
  email: string;
  name?: string;
  avatar?: string;
  provider: string;
}

/**
 * Permission group
 */
export interface PermissionGroup {
  name: string;
  permissions: PermissionKey[];
}

/**
 * Role-based permission groups
 */
export const PERMISSION_GROUPS: Record<UserRole, PermissionGroup[]> = {
  SUPER_ADMIN: [
    {
      name: 'Members',
      permissions: [
        'view_members',
        'add_member',
        'edit_member',
        'delete_member',
        'change_parent',
      ],
    },
    {
      name: 'Data',
      permissions: ['export_data', 'import_data'],
    },
    {
      name: 'Quality',
      permissions: [
        'manage_duplicates',
        'view_history',
        'rollback_changes',
        'create_snapshots',
      ],
    },
    {
      name: 'Administration',
      permissions: [
        'manage_admins',
        'approve_pending_members',
        'manage_branch_links',
        'invite_users',
      ],
    },
  ],
  ADMIN: [
    {
      name: 'Members',
      permissions: [
        'view_members',
        'add_member',
        'edit_member',
        'delete_member',
        'change_parent',
      ],
    },
    {
      name: 'Data',
      permissions: ['export_data', 'import_data'],
    },
    {
      name: 'Quality',
      permissions: [
        'manage_duplicates',
        'view_history',
        'rollback_changes',
        'create_snapshots',
      ],
    },
    {
      name: 'Users',
      permissions: [
        'approve_pending_members',
        'manage_branch_links',
        'invite_users',
      ],
    },
  ],
  BRANCH_LEADER: [
    {
      name: 'Members',
      permissions: ['view_members', 'add_member', 'edit_member'],
    },
    {
      name: 'Data',
      permissions: ['export_data'],
    },
    {
      name: 'Branch',
      permissions: [
        'view_history',
        'create_snapshots',
        'approve_pending_members',
        'manage_branch_links',
      ],
    },
  ],
  MEMBER: [
    {
      name: 'Data',
      permissions: ['view_members', 'export_data'],
    },
  ],
  GUEST: [
    {
      name: 'View',
      permissions: ['view_members'],
    },
  ],
};
