/**
 * Core TypeScript Types and Interfaces
 * Comprehensive type definitions for the application
 */

// ============================================
// FAMILY MEMBER TYPES
// ============================================

export interface FamilyMember {
  id: string;
  firstName: string;
  fatherName?: string | null;
  grandfatherName?: string | null;
  greatGrandfatherName?: string | null;
  familyName: string;
  fatherId?: string | null;
  gender: 'Male' | 'Female';
  birthYear?: number | null;
  birthCalendar?: 'HIJRI' | 'GREGORIAN';
  deathYear?: number | null;
  deathCalendar?: 'HIJRI' | 'GREGORIAN';
  sonsCount: number;
  daughtersCount: number;
  generation: number;
  branch?: string | null;
  fullNameAr?: string | null;
  fullNameEn?: string | null;
  phone?: string | null;
  city?: string | null;
  status: 'Living' | 'Deceased';
  photoUrl?: string | null;
  biography?: string | null;
  occupation?: string | null;
  email?: string | null;
  createdAt?: Date;
  updatedAt?: Date;
  createdBy?: string | null;
  lastModifiedBy?: string | null;
  version?: number;
  lineageBranchId?: string | null;
  lineageBranchName?: string | null;
  subBranchId?: string | null;
  subBranchName?: string | null;
  lineagePath?: string[];
}

export interface TreeNode extends FamilyMember {
  children: TreeNode[];
  expanded?: boolean;
  level?: number;
}

// ============================================
// USER & AUTHENTICATION TYPES
// ============================================

export type UserRole = 'SUPER_ADMIN' | 'ADMIN' | 'BRANCH_LEADER' | 'MEMBER' | 'GUEST';

export type UserStatus = 'PENDING' | 'ACTIVE' | 'DISABLED';

export type PermissionKey =
  | 'view_members'
  | 'add_member'
  | 'edit_member'
  | 'delete_member'
  | 'change_parent'
  | 'export_data'
  | 'import_data'
  | 'manage_duplicates'
  | 'view_history'
  | 'rollback_changes'
  | 'create_snapshots'
  | 'manage_admins'
  | 'approve_pending_members'
  | 'manage_branch_links'
  | 'invite_users';

export interface SessionUser {
  id: string;
  email: string;
  nameArabic: string;
  nameEnglish?: string;
  role: UserRole;
  status: UserStatus;
  linkedMemberId?: string | null;
  assignedBranch?: string | null;
  permissions: Record<PermissionKey, boolean>;
  twoFactorEnabled: boolean;
  lastLoginAt?: Date;
  createdAt: Date;
}

export interface AuthSession {
  user: SessionUser;
  token: string;
  expiresAt: Date;
}

// ============================================
// AUDIT & HISTORY TYPES
// ============================================

export type ChangeType = 'CREATE' | 'UPDATE' | 'DELETE' | 'PARENT_CHANGE' | 'RESTORE';

export interface ChangeHistory {
  id: string;
  memberId: string;
  fieldName: string;
  oldValue?: string | null;
  newValue?: string | null;
  changeType: ChangeType;
  changedBy: string;
  changedByName: string;
  changedAt: Date;
  batchId?: string | null;
  fullSnapshot?: string | null;
  reason?: string | null;
  ipAddress?: string | null;
}

export type SnapshotType = 'MANUAL' | 'AUTO_BACKUP' | 'PRE_IMPORT';

export interface Snapshot {
  id: string;
  name: string;
  description?: string | null;
  treeData: string;
  memberCount: number;
  createdBy: string;
  createdByName: string;
  createdAt: Date;
  snapshotType: SnapshotType;
}

// ============================================
// IMPORT/EXPORT TYPES
// ============================================

export type ExportFormat = 'JSON' | 'CSV' | 'EXCEL' | 'PDF';

export interface ExportFilters {
  generations?: number[];
  branches?: string[];
  genders?: ('Male' | 'Female')[];
  status?: ('Living' | 'Deceased')[];
  searchQuery?: string;
}

export interface ExportJob {
  id: string;
  format: ExportFormat;
  fileName: string;
  memberCount: number;
  fieldsIncluded: string[];
  filters?: ExportFilters;
  exportedBy: string;
  exportedByName: string;
  exportedAt: Date;
  fileSize?: number | null;
  downloadUrl?: string | null;
}

// ============================================
// DUPLICATE DETECTION TYPES
// ============================================

export type DuplicateStatus = 'PENDING' | 'CONFIRMED_DUPLICATE' | 'NOT_DUPLICATE' | 'MERGED';

export interface DuplicateFlag {
  id: string;
  sourceMemberId: string;
  sourceMember?: FamilyMember;
  targetMemberId: string;
  targetMember?: FamilyMember;
  matchScore: number;
  matchReasons: string[];
  status: DuplicateStatus;
  resolvedBy?: string | null;
  resolvedAt?: Date | null;
  resolution?: string | null;
  detectedAt: Date;
  detectedBy: string;
}

// ============================================
// MILK KINSHIP TYPES
// ============================================

export interface BreastfeedingRelationship {
  id: string;
  childId: string;
  nurseId?: string | null;
  externalNurseName?: string | null;
  milkFatherId?: string | null;
  externalMilkFatherName?: string | null;
  notes?: string | null;
  breastfeedingYear?: number | null;
  createdAt: Date;
  updatedAt: Date;
  createdBy?: string | null;
}

// ============================================
// SETTINGS TYPES
// ============================================

export interface SiteSettings {
  familyNameArabic: string;
  familyNameEnglish: string;
  taglineArabic?: string;
  taglineEnglish?: string;
  logoUrl?: string | null;
  defaultLanguage: 'ar' | 'en';
  sessionDurationDays: number;
  rememberMeDurationDays: number;
  allowSelfRegistration: boolean;
  requireEmailVerification: boolean;
  require2FAForAdmins: boolean;
  maxLoginAttempts: number;
  lockoutDurationMinutes: number;
}

// ============================================
// VALIDATION TYPES
// ============================================

export interface ValidationError {
  field: string;
  message: string;
  code: string;
}

export interface ValidationWarning {
  field: string;
  message: string;
  suggestion?: string;
}

export interface ValidationResult {
  valid: boolean;
  errors: ValidationError[];
  warnings: ValidationWarning[];
}

// ============================================
// API TYPES
// ============================================

export interface PaginationParams {
  page?: number;
  limit?: number;
}

export interface PaginatedResponse<T> {
  data: T[];
  pagination: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
    hasMore: boolean;
  };
}

export interface SortParams {
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
}

// ============================================
// LOCALIZATION TYPES
// ============================================

export interface LocalizedString {
  ar: string;
  en: string;
}

export type Locale = 'ar' | 'en';

// ============================================
// ERROR TYPES
// ============================================

export interface ApiError {
  code: string;
  message: string;
  statusCode: number;
  details?: Record<string, unknown>;
}

// ============================================
// TREE OPERATION TYPES
// ============================================

export interface DragDropOperation {
  nodeId: string;
  oldParentId?: string | null;
  newParentId?: string | null;
  position?: number;
}

export interface TreeValidation {
  valid: boolean;
  wouldCreateCycle: boolean;
  generationChange: number;
  affectedMembers: string[];
  errors: string[];
}

export interface EditOperation {
  memberId: string;
  changes: Partial<FamilyMember>;
  reason?: string;
}

export interface ParentChangeOperation {
  memberId: string;
  oldParentId?: string | null;
  newParentId?: string | null;
  reason?: string;
}
