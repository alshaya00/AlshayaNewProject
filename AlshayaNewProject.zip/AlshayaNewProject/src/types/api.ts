/**
 * API Request/Response Types
 */

import { FamilyMember, LocalizedString, PaginatedResponse } from './index';

/**
 * API Request wrapper
 */
export interface ApiRequest<T = unknown> {
  body?: T;
  query?: Record<string, string | string[]>;
  params?: Record<string, string>;
  headers?: Record<string, string>;
  method?: string;
  url?: string;
}

/**
 * API Response wrapper
 */
export interface ApiResponseWrapper<T = unknown> {
  success: boolean;
  statusCode: number;
  data?: T;
  error?: {
    code: string;
    message: string;
    details?: Record<string, unknown>;
  };
  meta?: {
    timestamp: string;
    version: string;
    requestId?: string;
  };
}

/**
 * Member list response
 */
export type MembersListResponse = PaginatedResponse<FamilyMember>;

/**
 * Member detail response
 */
export interface MemberDetailResponse {
  member: FamilyMember;
  relatives?: FamilyMember[];
  statistics?: {
    totalDescendants: number;
    sons: number;
    daughters: number;
  };
}

/**
 * Create member request
 */
export interface CreateMemberRequest {
  firstName: string;
  fatherName?: string;
  grandfatherName?: string;
  greatGrandfatherName?: string;
  familyName?: string;
  fatherId?: string;
  gender: 'Male' | 'Female';
  birthYear?: number;
  birthCalendar?: 'HIJRI' | 'GREGORIAN';
  deathYear?: number;
  deathCalendar?: 'HIJRI' | 'GREGORIAN';
  generation?: number;
  branch?: string;
  fullNameAr?: string;
  fullNameEn?: string;
  phone?: string;
  city?: string;
  status?: 'Living' | 'Deceased';
  photoUrl?: string;
  biography?: string;
  occupation?: string;
  email?: string;
}

/**
 * Update member request
 */
export type UpdateMemberRequest = Partial<CreateMemberRequest> & { id: string };

/**
 * Delete member request
 */
export interface DeleteMemberRequest {
  id: string;
  reason?: string;
}

/**
 * Change parent request
 */
export interface ChangeParentRequest {
  memberId: string;
  newFatherId?: string | null;
  reason?: string;
}

/**
 * Bulk update request
 */
export interface BulkUpdateRequest {
  memberIds: string[];
  updates: Partial<CreateMemberRequest>;
  reason?: string;
}

/**
 * Search request
 */
export interface SearchRequest {
  query: string;
  type?: 'members' | 'users' | 'all';
  page?: number;
  limit?: number;
}

/**
 * Search response
 */
export interface SearchResponse {
  members?: FamilyMember[];
  users?: any[]; // User type from auth
  query: string;
  resultCount: number;
}

/**
 * Export request
 */
export interface ExportRequest {
  format: 'JSON' | 'CSV' | 'EXCEL' | 'PDF';
  fields?: string[];
  includeTree?: boolean;
  groupByGeneration?: boolean;
  filters?: {
    generations?: number[];
    branches?: string[];
    genders?: ('Male' | 'Female')[];
    status?: ('Living' | 'Deceased')[];
  };
}

/**
 * Export response
 */
export interface ExportResponse {
  downloadUrl: string;
  fileName: string;
  format: string;
  memberCount: number;
  fileSize?: number;
}

/**
 * Import request
 */
export interface ImportRequest {
  file: File | Buffer;
  fileType: 'JSON' | 'CSV' | 'EXCEL';
  conflictStrategy?: 'SKIP' | 'OVERWRITE' | 'MERGE' | 'ASK';
  validateOnly?: boolean;
}

/**
 * Import response
 */
export interface ImportResponse {
  jobId: string;
  status: 'PENDING' | 'PROCESSING' | 'COMPLETED' | 'FAILED';
  totalRecords: number;
  processedCount: number;
  successCount: number;
  errorCount: number;
  conflicts?: Array<{
    rowNumber: number;
    existingMemberId: string;
    conflictType: string;
  }>;
  errors?: Array<{
    rowNumber: number;
    field?: string;
    error: string;
  }>;
}

/**
 * Statistics response
 */
export interface StatisticsResponse {
  totalMembers: number;
  generationCount: Record<number, number>;
  genderCount: { Male: number; Female: number };
  statusCount: { Living: number; Deceased: number };
  branchCount: Record<string, number>;
  avgChildrenPerMember: number;
}

/**
 * Batch operation response
 */
export interface BatchOperationResponse {
  operationId: string;
  status: 'PENDING' | 'IN_PROGRESS' | 'COMPLETED' | 'FAILED';
  totalOperations: number;
  completedOperations: number;
  failedOperations: number;
  errors?: Array<{
    operationIndex: number;
    error: string;
  }>;
}

/**
 * Integrity check response
 */
export interface IntegrityCheckResponse {
  valid: boolean;
  issueCount: number;
  errorCount: number;
  warningCount: number;
  issues?: Array<{
    type: string;
    memberId: string;
    message: string;
    severity: 'error' | 'warning';
    suggestion?: string;
  }>;
}

/**
 * Health check response
 */
export interface HealthCheckResponse {
  status: 'healthy' | 'degraded' | 'unhealthy';
  timestamp: string;
  components?: {
    database?: { status: string; latency: number };
    cache?: { status: string; latency: number };
    externalServices?: { [key: string]: { status: string; latency: number } };
  };
}

/**
 * Pagination query
 */
export interface PaginationQuery {
  page?: number;
  limit?: number;
}

/**
 * Sort query
 */
export interface SortQuery {
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
}

/**
 * Filter query
 */
export interface FilterQuery {
  gender?: 'Male' | 'Female';
  generation?: number;
  branch?: string;
  status?: 'Living' | 'Deceased';
  startYear?: number;
  endYear?: number;
}

/**
 * Combined query params
 */
export interface QueryParams extends PaginationQuery, SortQuery, FilterQuery {
  search?: string;
}
