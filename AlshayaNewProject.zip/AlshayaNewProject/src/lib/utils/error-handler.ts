/**
 * Global Error Handler with Proper Logging
 * No stack traces in production, detailed logging for debugging
 */

/**
 * Application error types
 */
export enum ErrorCategory {
  AUTHENTICATION = 'AUTHENTICATION',
  AUTHORIZATION = 'AUTHORIZATION',
  VALIDATION = 'VALIDATION',
  NOT_FOUND = 'NOT_FOUND',
  CONFLICT = 'CONFLICT',
  RATE_LIMIT = 'RATE_LIMIT',
  DATABASE = 'DATABASE',
  EXTERNAL_SERVICE = 'EXTERNAL_SERVICE',
  INTERNAL = 'INTERNAL',
}

/**
 * Application error class
 */
export class AppError extends Error {
  constructor(
    public statusCode: number,
    public code: string,
    message: string,
    public category: ErrorCategory = ErrorCategory.INTERNAL,
    public details?: Record<string, unknown>
  ) {
    super(message);
    this.name = 'AppError';

    // Maintain proper stack trace for where our error was thrown
    if (Error.captureStackTrace) {
      Error.captureStackTrace(this, this.constructor);
    }
  }

  /**
   * Serialize to API response format
   */
  toJSON() {
    return {
      success: false,
      statusCode: this.statusCode,
      error: {
        code: this.code,
        message: this.message,
        ...(process.env.NODE_ENV !== 'production' && { details: this.details }),
      },
    };
  }

  /**
   * Log error with context
   */
  log(context?: Record<string, unknown>): void {
    const logLevel = this.statusCode >= 500 ? 'error' : 'warn';
    const logger = console[logLevel as keyof typeof console] || console.log;

    const logData = {
      timestamp: new Date().toISOString(),
      level: logLevel,
      code: this.code,
      message: this.message,
      category: this.category,
      statusCode: this.statusCode,
      ...(process.env.NODE_ENV !== 'production' && {
        details: this.details,
        stack: this.stack,
      }),
      ...context,
    };

    logger('[AppError]', JSON.stringify(logData));
  }
}

/**
 * Validation error
 */
export class ValidationError extends AppError {
  constructor(
    message: string,
    public fieldErrors?: Record<string, string[]>
  ) {
    super(
      400,
      'VALIDATION_ERROR',
      message,
      ErrorCategory.VALIDATION,
      { fieldErrors }
    );
    this.name = 'ValidationError';
  }
}

/**
 * Authentication error
 */
export class AuthenticationError extends AppError {
  constructor(message: string = 'Authentication failed') {
    super(
      401,
      'AUTHENTICATION_ERROR',
      message,
      ErrorCategory.AUTHENTICATION
    );
    this.name = 'AuthenticationError';
  }
}

/**
 * Authorization error
 */
export class AuthorizationError extends AppError {
  constructor(message: string = 'Access denied') {
    super(
      403,
      'AUTHORIZATION_ERROR',
      message,
      ErrorCategory.AUTHORIZATION
    );
    this.name = 'AuthorizationError';
  }
}

/**
 * Not found error
 */
export class NotFoundError extends AppError {
  constructor(resource: string = 'Resource') {
    super(
      404,
      'NOT_FOUND',
      `${resource} not found`,
      ErrorCategory.NOT_FOUND
    );
    this.name = 'NotFoundError';
  }
}

/**
 * Conflict error
 */
export class ConflictError extends AppError {
  constructor(message: string = 'Conflict') {
    super(
      409,
      'CONFLICT',
      message,
      ErrorCategory.CONFLICT
    );
    this.name = 'ConflictError';
  }
}

/**
 * Rate limit error
 */
export class RateLimitError extends AppError {
  constructor(public retryAfter?: number) {
    super(
      429,
      'RATE_LIMIT_EXCEEDED',
      'Too many requests. Please try again later.',
      ErrorCategory.RATE_LIMIT,
      { retryAfter }
    );
    this.name = 'RateLimitError';
  }
}

/**
 * Database error
 */
export class DatabaseError extends AppError {
  constructor(message: string, public originalError?: unknown) {
    super(
      500,
      'DATABASE_ERROR',
      message,
      ErrorCategory.DATABASE,
      {
        originalCode: (originalError as any)?.code,
      }
    );
    this.name = 'DatabaseError';

    // Log the original error in development
    if (process.env.NODE_ENV !== 'production') {
      console.error('[DatabaseError] Original:', originalError);
    }
  }
}

/**
 * External service error
 */
export class ExternalServiceError extends AppError {
  constructor(
    service: string,
    message: string,
    public retryable: boolean = true
  ) {
    super(
      502,
      'EXTERNAL_SERVICE_ERROR',
      `${service}: ${message}`,
      ErrorCategory.EXTERNAL_SERVICE,
      { service, retryable }
    );
    this.name = 'ExternalServiceError';
  }
}

/**
 * Global error handler middleware response
 */
export interface ErrorHandlerResponse {
  statusCode: number;
  body: {
    success: boolean;
    error: {
      code: string;
      message: string;
      details?: Record<string, unknown>;
    };
  };
}

/**
 * Handle any error and convert to standardized format
 */
export function handleError(error: unknown): ErrorHandlerResponse {
  console.error('[ErrorHandler]', error);

  // Known AppError
  if (error instanceof AppError) {
    error.log();
    return {
      statusCode: error.statusCode,
      body: error.toJSON() as any,
    };
  }

  // Zod validation error
  if (error instanceof Error && error.name === 'ZodError') {
    return {
      statusCode: 400,
      body: {
        success: false,
        error: {
          code: 'VALIDATION_ERROR',
          message: 'Validation failed',
          details: (error as any).errors,
        },
      },
    };
  }

  // Prisma errors
  if (error instanceof Error && error.constructor.name === 'PrismaClientError') {
    const dbError = new DatabaseError('Database operation failed', error);
    dbError.log();
    return {
      statusCode: dbError.statusCode,
      body: dbError.toJSON() as any,
    };
  }

  // Standard JavaScript Error
  if (error instanceof Error) {
    const appError = new AppError(
      500,
      'INTERNAL_ERROR',
      process.env.NODE_ENV === 'production'
        ? 'An internal error occurred'
        : error.message,
      ErrorCategory.INTERNAL
    );
    appError.log({ originalMessage: error.message, originalStack: error.stack });
    return {
      statusCode: appError.statusCode,
      body: appError.toJSON() as any,
    };
  }

  // Unknown error
  const unknownError = new AppError(
    500,
    'UNKNOWN_ERROR',
    'An unknown error occurred',
    ErrorCategory.INTERNAL
  );
  unknownError.log({ error });
  return {
    statusCode: unknownError.statusCode,
    body: unknownError.toJSON() as any,
  };
}

/**
 * Safely execute async function with error handling
 */
export async function tryCatch<T>(
  fn: () => Promise<T>,
  context?: Record<string, unknown>
): Promise<{ success: true; data: T } | { success: false; error: AppError }> {
  try {
    const data = await fn();
    return { success: true, data };
  } catch (error) {
    let appError: AppError;

    if (error instanceof AppError) {
      appError = error;
    } else if (error instanceof Error) {
      appError = new AppError(500, 'UNKNOWN_ERROR', error.message);
    } else {
      appError = new AppError(500, 'UNKNOWN_ERROR', 'An unknown error occurred');
    }

    appError.log(context);
    return { success: false, error: appError };
  }
}

/**
 * Assert condition, throw if false
 */
export function assert(
  condition: unknown,
  message: string,
  errorCode: string = 'ASSERTION_ERROR'
): asserts condition {
  if (!condition) {
    throw new AppError(
      500,
      errorCode,
      message,
      ErrorCategory.INTERNAL
    );
  }
}

/**
 * Safe JSON stringify for logging
 */
export function safeStringify(
  obj: unknown,
  replacer?: (key: string, value: unknown) => unknown
): string {
  try {
    return JSON.stringify(obj, replacer);
  } catch {
    return '[Circular]';
  }
}
