/**
 * Tailwind Class Merging Utility
 * Combines clsx with tailwind-merge for proper class conflict resolution
 */

import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

/**
 * Merge Tailwind CSS classes and resolve conflicts
 * Uses twMerge to handle Tailwind-specific class conflicts
 * Uses clsx for conditional classes
 *
 * Examples:
 * cn('px-2', 'px-4') // 'px-4' (last one wins)
 * cn('px-2', condition && 'px-4')
 * cn('text-sm', { 'text-lg': isLarge })
 */
export function cn(...inputs: ClassValue[]): string {
  return twMerge(clsx(inputs));
}

/**
 * Create a safe class string with validation
 */
export function createClassName(...inputs: ClassValue[]): string {
  const merged = cn(...inputs);

  // Basic validation - ensure no suspicious patterns
  if (merged.includes('javascript:') || merged.includes('<') || merged.includes('>')) {
    console.warn('[ClassName] Suspicious class value detected:', merged);
    return '';
  }

  return merged;
}

/**
 * Conditional class helper
 */
export function conditionalClass(
  baseClass: string,
  condition: boolean,
  conditionClass: string
): string {
  return cn(baseClass, condition && conditionClass);
}

/**
 * Chain multiple class conditions
 */
export function chainClasses(
  baseClass: string,
  conditions: Record<string, boolean>
): string {
  const classes = [baseClass];

  for (const [className, condition] of Object.entries(conditions)) {
    if (condition) {
      classes.push(className);
    }
  }

  return cn(...classes);
}

/**
 * Responsive class builder
 * Helps create responsive Tailwind classes
 */
export function responsiveClass(
  baseClass: string,
  variants?: {
    sm?: string;
    md?: string;
    lg?: string;
    xl?: string;
    '2xl'?: string;
  }
): string {
  const classes = [baseClass];

  if (variants) {
    if (variants.sm) classes.push(`sm:${variants.sm}`);
    if (variants.md) classes.push(`md:${variants.md}`);
    if (variants.lg) classes.push(`lg:${variants.lg}`);
    if (variants.xl) classes.push(`xl:${variants.xl}`);
    if (variants['2xl']) classes.push(`2xl:${variants['2xl']}`);
  }

  return cn(...classes);
}

/**
 * Variant class builder (like CVA pattern)
 */
export interface VariantConfig {
  base?: string;
  variants?: Record<string, Record<string, string>>;
  defaultVariants?: Record<string, string>;
}

export function createVariants(config: VariantConfig) {
  return function classNameFn(
    props?: Record<string, string | number | boolean | undefined>
  ): string {
    const classes: string[] = [];

    if (config.base) {
      classes.push(config.base);
    }

    if (config.variants && props) {
      for (const [key, value] of Object.entries(props)) {
        if (config.variants[key]) {
          const variantClass = config.variants[key][String(value)];
          if (variantClass) {
            classes.push(variantClass);
          }
        }
      }
    }

    if (config.defaultVariants && props) {
      for (const [key, defaultValue] of Object.entries(config.defaultVariants)) {
        if (!(key in props) && config.variants?.[key]) {
          const variantClass = config.variants[key][defaultValue];
          if (variantClass) {
            classes.push(variantClass);
          }
        }
      }
    }

    return cn(...classes);
  };
}

/**
 * Common Tailwind breakpoints
 */
export const BREAKPOINTS = {
  sm: '640px',
  md: '768px',
  lg: '1024px',
  xl: '1280px',
  '2xl': '1536px',
} as const;

/**
 * Common color utilities
 */
export const COLOR_VARIANTS = {
  primary: {
    bg: 'bg-blue-500',
    text: 'text-blue-600',
    border: 'border-blue-300',
    hover: 'hover:bg-blue-600',
  },
  danger: {
    bg: 'bg-red-500',
    text: 'text-red-600',
    border: 'border-red-300',
    hover: 'hover:bg-red-600',
  },
  success: {
    bg: 'bg-green-500',
    text: 'text-green-600',
    border: 'border-green-300',
    hover: 'hover:bg-green-600',
  },
  warning: {
    bg: 'bg-yellow-500',
    text: 'text-yellow-600',
    border: 'border-yellow-300',
    hover: 'hover:bg-yellow-600',
  },
} as const;

/**
 * Common spacing utilities
 */
export const SPACING = {
  xs: 'px-2 py-1',
  sm: 'px-3 py-2',
  md: 'px-4 py-2',
  lg: 'px-6 py-3',
  xl: 'px-8 py-4',
} as const;
