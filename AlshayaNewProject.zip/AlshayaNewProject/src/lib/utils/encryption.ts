/**
 * AES-256-GCM Encryption Utilities for PII Fields
 * Provides authenticated encryption for sensitive data storage
 */

import { createCipheriv, createDecipheriv, randomBytes, scryptSync } from 'crypto';

// Encryption configuration
const ALGORITHM = 'aes-256-gcm';
const KEY_LENGTH = 32; // 256 bits
const IV_LENGTH = 16; // 128 bits
const AUTH_TAG_LENGTH = 16; // 128 bits
const SALT_LENGTH = 32;

/**
 * Get encryption key from environment
 */
function getEncryptionKey(): Buffer {
  const secret = process.env.ENCRYPTION_SECRET || process.env.JWT_SECRET;

  if (!secret) {
    if (process.env.NODE_ENV === 'production') {
      throw new Error(
        'CRITICAL: ENCRYPTION_SECRET or JWT_SECRET must be set in production. ' +
          'Generate with: openssl rand -base64 32'
      );
    }
    console.warn('[Encryption] Using default key. Set ENCRYPTION_SECRET for production!');
  }

  const effectiveSecret = secret || 'dev-only-secret-not-for-production';
  const salt = process.env.ENCRYPTION_SALT || 'alshaya-family-tree-salt';
  return scryptSync(effectiveSecret, salt, KEY_LENGTH);
}

/**
 * Encrypt plaintext using AES-256-GCM
 * Returns base64 encoded string: salt:iv:authTag:encryptedData
 */
export function encrypt(plaintext: string): string {
  if (!plaintext) return '';

  try {
    const key = getEncryptionKey();
    const iv = randomBytes(IV_LENGTH);
    const salt = randomBytes(SALT_LENGTH);

    // Derive a unique key for this encryption
    const derivedKey = scryptSync(key, salt, KEY_LENGTH);
    const cipher = createCipheriv(ALGORITHM, derivedKey, iv);

    let encrypted = cipher.update(plaintext, 'utf8', 'base64');
    encrypted += cipher.final('base64');

    const authTag = cipher.getAuthTag();

    // Combine salt, iv, authTag, and encrypted data
    const combined = Buffer.concat([
      salt,
      iv,
      authTag,
      Buffer.from(encrypted, 'base64'),
    ]);

    return combined.toString('base64');
  } catch (error) {
    console.error('[Encryption] Error encrypting data:', error);
    throw new Error('Failed to encrypt data');
  }
}

/**
 * Decrypt data encrypted with the encrypt function
 */
export function decrypt(encryptedData: string): string {
  if (!encryptedData) return '';

  try {
    const key = getEncryptionKey();
    const combined = Buffer.from(encryptedData, 'base64');

    // Extract components
    const salt = combined.subarray(0, SALT_LENGTH);
    const iv = combined.subarray(SALT_LENGTH, SALT_LENGTH + IV_LENGTH);
    const authTag = combined.subarray(
      SALT_LENGTH + IV_LENGTH,
      SALT_LENGTH + IV_LENGTH + AUTH_TAG_LENGTH
    );
    const encrypted = combined.subarray(
      SALT_LENGTH + IV_LENGTH + AUTH_TAG_LENGTH
    );

    // Derive the key using the same salt
    const derivedKey = scryptSync(key, salt, KEY_LENGTH);
    const decipher = createDecipheriv(ALGORITHM, derivedKey, iv);
    decipher.setAuthTag(authTag);

    let decrypted = decipher.update(encrypted);
    decrypted = Buffer.concat([decrypted, decipher.final()]);

    return decrypted.toString('utf8');
  } catch (error) {
    console.error('[Encryption] Error decrypting data:', error);
    throw new Error('Failed to decrypt data');
  }
}

/**
 * Check if a string looks encrypted
 */
export function isEncrypted(value: string): boolean {
  if (!value) return false;

  try {
    const decoded = Buffer.from(value, 'base64');
    // Minimum length: salt + iv + authTag + at least 1 byte of data
    return decoded.length > SALT_LENGTH + IV_LENGTH + AUTH_TAG_LENGTH;
  } catch {
    return false;
  }
}

/**
 * Encrypt multiple fields in an object
 */
export function encryptFields<T extends Record<string, unknown>>(
  data: T,
  fieldsToEncrypt: string[]
): T {
  const result = { ...data };

  for (const field of fieldsToEncrypt) {
    const value = result[field];
    if (typeof value === 'string' && value) {
      (result as Record<string, unknown>)[field] = encrypt(value);
    }
  }

  return result;
}

/**
 * Decrypt multiple fields in an object
 */
export function decryptFields<T extends Record<string, unknown>>(
  data: T,
  fieldsToDecrypt: string[]
): T {
  const result = { ...data };

  for (const field of fieldsToDecrypt) {
    const value = result[field];
    if (typeof value === 'string' && value && isEncrypted(value)) {
      try {
        (result as Record<string, unknown>)[field] = decrypt(value);
      } catch {
        console.warn(`[Encryption] Failed to decrypt field: ${field}`);
      }
    }
  }

  return result;
}

/**
 * Encrypt an API key with masked version for display
 */
export function encryptApiKey(apiKey: string): {
  encrypted: string;
  masked: string;
} {
  if (!apiKey) {
    return { encrypted: '', masked: '' };
  }

  const encrypted = encrypt(apiKey);

  // Create masked version (show first 4 and last 4 characters)
  let masked: string;
  if (apiKey.length <= 8) {
    masked = '*'.repeat(apiKey.length);
  } else {
    masked =
      apiKey.substring(0, 4) +
      '*'.repeat(apiKey.length - 8) +
      apiKey.substring(apiKey.length - 4);
  }

  return { encrypted, masked };
}

/**
 * Decrypt an encrypted API key
 */
export function decryptApiKey(encryptedKey: string): string {
  if (!encryptedKey) return '';
  return decrypt(encryptedKey);
}

/**
 * Hash a value for one-way encryption (for API key verification)
 */
export function hashValue(value: string): string {
  const salt = process.env.ENCRYPTION_SALT || 'alshaya-family-tree-salt';
  return scryptSync(value, salt, 32).toString('hex');
}

/**
 * Verify a value against its hash
 */
export function verifyHash(value: string, hash: string): boolean {
  const newHash = hashValue(value);
  return newHash === hash;
}
