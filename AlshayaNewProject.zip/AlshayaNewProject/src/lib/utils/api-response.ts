/**
 * Standardized API Response Helpers
 * Provides consistent response format across all API endpoints
 */

/**
 * API response metadata
 */
export interface ResponseMeta {
  timestamp: string;
  version: string;
  requestId?: string;
}

/**
 * Pagination information
 */
export interface PaginationMeta {
  page: number;
  limit: number;
  total: number;
  totalPages: number;
  hasMore: boolean;
}

/**
 * Standard API response structure
 */
export interface ApiResponse<T> {
  success: boolean;
  statusCode: number;
  data?: T;
  error?: {
    code: string;
    message: string;
    details?: Record<string, unknown>;
  };
  meta?: ResponseMeta & {
    pagination?: PaginationMeta;
  };
}

/**
 * Success response helper
 */
export function successResponse<T>(
  data: T,
  statusCode: number = 200,
  pagination?: PaginationMeta
): ApiResponse<T> {
  return {
    success: true,
    statusCode,
    data,
    meta: {
      timestamp: new Date().toISOString(),
      version: process.env.API_VERSION || '1.0.0',
      ...(pagination && { pagination }),
    },
  };
}

/**
 * Error response helper
 */
export function errorResponse(
  code: string,
  message: string,
  statusCode: number = 400,
  details?: Record<string, unknown>
): ApiResponse<never> {
  return {
    success: false,
    statusCode,
    error: {
      code,
      message,
      ...(details && { details }),
    },
    meta: {
      timestamp: new Date().toISOString(),
      version: process.env.API_VERSION || '1.0.0',
    },
  };
}

/**
 * Pagination helper
 */
export function createPaginationMeta(
  page: number,
  limit: number,
  total: number
): PaginationMeta {
  const totalPages = Math.ceil(total / limit);

  return {
    page,
    limit,
    total,
    totalPages,
    hasMore: page < totalPages,
  };
}

/**
 * Response wrapper for consistent error handling
 */
export class ApiResponseBuilder<T> {
  private response: ApiResponse<T>;

  constructor() {
    this.response = {
      success: true,
      statusCode: 200,
      meta: {
        timestamp: new Date().toISOString(),
        version: process.env.API_VERSION || '1.0.0',
      },
    };
  }

  /**
   * Set response data
   */
  setData(data: T): this {
    this.response.data = data;
    return this;
  }

  /**
   * Set status code
   */
  setStatusCode(statusCode: number): this {
    this.response.statusCode = statusCode;
    return this;
  }

  /**
   * Set error
   */
  setError(
    code: string,
    message: string,
    details?: Record<string, unknown>
  ): this {
    this.response.success = false;
    this.response.error = { code, message, ...(details && { details }) };
    return this;
  }

  /**
   * Set pagination
   */
  setPagination(pagination: PaginationMeta): this {
    if (!this.response.meta) {
      this.response.meta = {
        timestamp: new Date().toISOString(),
        version: process.env.API_VERSION || '1.0.0',
      };
    }
    this.response.meta.pagination = pagination;
    return this;
  }

  /**
   * Add request ID
   */
  setRequestId(requestId: string): this {
    if (!this.response.meta) {
      this.response.meta = {
        timestamp: new Date().toISOString(),
        version: process.env.API_VERSION || '1.0.0',
      };
    }
    this.response.meta.requestId = requestId;
    return this;
  }

  /**
   * Build response
   */
  build(): ApiResponse<T> {
    return this.response;
  }
}

/**
 * Common error codes and messages
 */
export const ERROR_CODES = {
  // Authentication errors
  UNAUTHORIZED: { code: 'UNAUTHORIZED', statusCode: 401, message: 'Unauthorized' },
  INVALID_TOKEN: { code: 'INVALID_TOKEN', statusCode: 401, message: 'Invalid token' },
  EXPIRED_TOKEN: { code: 'EXPIRED_TOKEN', statusCode: 401, message: 'Token expired' },
  MISSING_CREDENTIALS: { code: 'MISSING_CREDENTIALS', statusCode: 401, message: 'Missing credentials' },

  // Authorization errors
  FORBIDDEN: { code: 'FORBIDDEN', statusCode: 403, message: 'Forbidden' },
  PERMISSION_DENIED: { code: 'PERMISSION_DENIED', statusCode: 403, message: 'Permission denied' },
  INSUFFICIENT_ROLE: { code: 'INSUFFICIENT_ROLE', statusCode: 403, message: 'Insufficient role' },

  // Resource errors
  NOT_FOUND: { code: 'NOT_FOUND', statusCode: 404, message: 'Resource not found' },
  ALREADY_EXISTS: { code: 'ALREADY_EXISTS', statusCode: 409, message: 'Resource already exists' },

  // Validation errors
  VALIDATION_ERROR: { code: 'VALIDATION_ERROR', statusCode: 400, message: 'Validation error' },
  INVALID_INPUT: { code: 'INVALID_INPUT', statusCode: 400, message: 'Invalid input' },
  MISSING_FIELD: { code: 'MISSING_FIELD', statusCode: 400, message: 'Missing required field' },

  // Rate limiting
  RATE_LIMITED: { code: 'RATE_LIMITED', statusCode: 429, message: 'Rate limit exceeded' },
  TOO_MANY_REQUESTS: { code: 'TOO_MANY_REQUESTS', statusCode: 429, message: 'Too many requests' },

  // Server errors
  INTERNAL_ERROR: { code: 'INTERNAL_ERROR', statusCode: 500, message: 'Internal server error' },
  SERVICE_UNAVAILABLE: { code: 'SERVICE_UNAVAILABLE', statusCode: 503, message: 'Service unavailable' },
} as const;

/**
 * Create error response with predefined codes
 */
export function createErrorResponse<T>(
  errorCode: keyof typeof ERROR_CODES,
  customMessage?: string,
  details?: Record<string, unknown>
): ApiResponse<T> {
  const error = ERROR_CODES[errorCode];

  return errorResponse(
    error.code,
    customMessage || error.message,
    error.statusCode,
    details
  );
}
