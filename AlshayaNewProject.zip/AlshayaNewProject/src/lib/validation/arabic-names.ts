/**
 * Arabic Name Normalization and Validation
 * Handles diacritics, alef variants, taa marbuta normalization
 * Enables fuzzy matching for Arabic names with variations
 */

/**
 * Common Arabic name variations
 */
const nameVariations: Record<string, string[]> = {
  عبدالله: ['عبد الله', 'عبدلله'],
  عبدالعزيز: ['عبد العزيز', 'عبدلعزيز'],
  عبدالرحمن: ['عبد الرحمن', 'عبدلرحمن'],
  عبدالكريم: ['عبد الكريم', 'عبدلكريم'],
  إبراهيم: ['ابراهيم', 'ابراهم'],
  محمد: ['محمّد', 'مُحمد', 'محمود'],
  ناصر: ['ناصِر'],
  سليمان: ['سلمان', 'سليمن'],
  أحمد: ['احمد', 'أحمَد'],
  حمد: ['حمَد'],
  خالد: ['خالِد'],
  صالح: ['صالِح'],
  سعد: ['سعَد'],
  فهد: ['فهَد'],
  شايع: ['الشايع', 'آل شايع'],
};

/**
 * Remove diacritical marks (tashkeel) from Arabic text
 * Removes: Fatha, Damma, Kasra, Shadda, Sukun, Tanwin, etc.
 */
export function removeDiacritics(text: string): string {
  if (!text) return '';
  // Unicode range for Arabic diacritics: U+064B to U+065F
  return text.replace(/[\u064B-\u065F\u0670]/g, '');
}

/**
 * Normalize alef variations to plain alef (ا)
 * Converts: أ (alef with hamza above) → ا
 *          إ (alef with hamza below) → ا
 *          آ (alef with madda) → ا
 */
export function normalizeAlef(text: string): string {
  if (!text) return '';
  return text.replace(/[أإآ]/g, 'ا');
}

/**
 * Normalize taa marbuta (ة) to haa (ه)
 * Helps match endings like: كاتبة → كاتبه
 */
export function normalizeTaaMarbuta(text: string): string {
  if (!text) return '';
  return text.replace(/ة/g, 'ه');
}

/**
 * Normalize alef maksura (ى) to yaa (ي)
 * Helps match: مصطفى → مصطفي
 */
export function normalizeAlefMaksura(text: string): string {
  if (!text) return '';
  return text.replace(/ى/g, 'ي');
}

/**
 * Normalize hamza variations (remove hamza)
 */
export function normalizeHamza(text: string): string {
  if (!text) return '';
  return text.replace(/[ء]/g, '');
}

/**
 * Complete Arabic name normalization
 * Applies all normalization rules
 */
export function normalizeArabicName(name: string): string {
  if (!name) return '';

  let normalized = name;

  // Remove diacritics
  normalized = removeDiacritics(normalized);

  // Normalize alef variations
  normalized = normalizeAlef(normalized);

  // Normalize taa marbuta
  normalized = normalizeTaaMarbuta(normalized);

  // Normalize alef maksura
  normalized = normalizeAlefMaksura(normalized);

  // Normalize hamza
  normalized = normalizeHamza(normalized);

  // Remove extra spaces and trim
  normalized = normalized.replace(/\s+/g, ' ').trim();

  // Remove "آل" or "ال" prefix (family prefix)
  normalized = normalized.replace(/^(آل|ال)\s*/g, '');

  return normalized;
}

/**
 * Check if two Arabic names are fuzzy matches
 */
export function fuzzyMatchArabicNames(name1: string, name2: string): boolean {
  if (!name1 || !name2) return false;

  const norm1 = normalizeArabicName(name1);
  const norm2 = normalizeArabicName(name2);

  // Direct match after normalization
  if (norm1 === norm2) return true;

  // Check against known variations
  for (const [canonical, variations] of Object.entries(nameVariations)) {
    const allForms = [canonical, ...variations].map(normalizeArabicName);
    const norm1Match = allForms.includes(norm1);
    const norm2Match = allForms.includes(norm2);
    if (norm1Match && norm2Match) return true;
  }

  // Check if one contains the other (for partial matches)
  const norm1NoSpaces = norm1.replace(/\s/g, '');
  const norm2NoSpaces = norm2.replace(/\s/g, '');
  if (norm1NoSpaces === norm2NoSpaces) return true;

  return false;
}

/**
 * Calculate similarity score between two Arabic names (0-100)
 * Uses weighted Levenshtein distance
 */
export function calculateNameSimilarity(name1: string, name2: string): number {
  const norm1 = normalizeArabicName(name1);
  const norm2 = normalizeArabicName(name2);

  if (norm1 === norm2) return 100;
  if (!norm1 || !norm2) return 0;

  // Levenshtein distance
  const distance = levenshteinDistance(norm1, norm2);
  const maxLength = Math.max(norm1.length, norm2.length);

  if (maxLength === 0) return 100;

  const similarity = ((maxLength - distance) / maxLength) * 100;
  return Math.max(0, Math.min(100, similarity));
}

/**
 * Calculate Levenshtein distance between two strings
 */
function levenshteinDistance(str1: string, str2: string): number {
  const matrix: number[][] = [];

  for (let i = 0; i <= str2.length; i++) {
    matrix[i] = [i];
  }

  for (let j = 0; j <= str1.length; j++) {
    matrix[0][j] = j;
  }

  for (let i = 1; i <= str2.length; i++) {
    for (let j = 1; j <= str1.length; j++) {
      if (str2.charAt(i - 1) === str1.charAt(j - 1)) {
        matrix[i][j] = matrix[i - 1][j - 1];
      } else {
        matrix[i][j] = Math.min(
          matrix[i - 1][j - 1] + 1,
          matrix[i][j - 1] + 1,
          matrix[i - 1][j] + 1
        );
      }
    }
  }

  return matrix[str2.length][str1.length];
}

/**
 * Extract individual names from a lineage string
 * Parses strings like "سعد بن ناصر بن ابراهيم آل شايع"
 */
export function extractNamesFromLineage(lineageString: string): string[] {
  if (!lineageString) return [];

  // Remove family name
  let cleaned = lineageString.replace(/آل\s*شايع/g, '').trim();

  // Split by "بن" (bin/son) or "بنت" (bint/daughter)
  const parts = cleaned.split(/\s*(?:بن|بنت)\s*/);

  // Filter out empty strings and trim
  return parts.map((p) => p.trim()).filter((p) => p.length > 0);
}

/**
 * Find a member by fuzzy name matching
 */
export function findMemberByFuzzyName<T extends { firstName: string }>(
  name: string,
  members: T[]
): T | null {
  if (!name) return null;

  const normalizedName = normalizeArabicName(name);

  // First try exact match
  for (const member of members) {
    if (normalizeArabicName(member.firstName) === normalizedName) {
      return member;
    }
  }

  // Then try fuzzy match
  for (const member of members) {
    if (fuzzyMatchArabicNames(member.firstName, name)) {
      return member;
    }
  }

  return null;
}

/**
 * Find all members matching a name with similarity threshold
 */
export function findMembersByNameSimilarity<
  T extends { firstName: string }
>(
  name: string,
  members: T[],
  threshold: number = 70
): Array<{ member: T; similarity: number }> {
  if (!name) return [];

  const results: Array<{ member: T; similarity: number }> = [];

  for (const member of members) {
    const similarity = calculateNameSimilarity(name, member.firstName);
    if (similarity >= threshold) {
      results.push({ member, similarity });
    }
  }

  // Sort by similarity descending
  return results.sort((a, b) => b.similarity - a.similarity);
}

/**
 * Validate Arabic name format
 */
export function isValidArabicName(name: string): boolean {
  if (!name || name.length < 2) return false;

  // Check if contains Arabic characters
  const arabicRegex = /[\u0600-\u06FF]/;
  if (!arabicRegex.test(name)) return false;

  // Allow letters, numbers, spaces, and common punctuation
  const validRegex = /^[\u0600-\u06FF\s\-']*$/;
  return validRegex.test(name);
}

/**
 * Format Arabic name for display
 */
export function formatArabicName(name: string): string {
  if (!name) return '';

  // Trim and normalize spaces
  let formatted = name.trim().replace(/\s+/g, ' ');

  // Capitalize first letter of each word (doesn't really apply to Arabic but for consistency)
  return formatted;
}
