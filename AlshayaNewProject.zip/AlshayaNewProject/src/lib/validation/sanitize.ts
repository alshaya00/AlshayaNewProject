/**
 * Input Sanitization to Prevent XSS and Injection Attacks
 * Provides safe sanitization while preserving legitimate content
 */

/**
 * Escape HTML special characters to prevent XSS
 */
export function escapeHtml(text: string | null | undefined): string {
  if (!text) return '';

  return String(text)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;')
    .replace(/\//g, '&#x2F;');
}

/**
 * Unescape HTML entities (use with caution - only for trusted content)
 */
export function unescapeHtml(text: string): string {
  const map: Record<string, string> = {
    '&amp;': '&',
    '&lt;': '<',
    '&gt;': '>',
    '&quot;': '"',
    '&#39;': "'",
    '&#x2F;': '/',
  };

  let unescaped = text;
  for (const [escaped, unesc] of Object.entries(map)) {
    unescaped = unescaped.replace(new RegExp(escaped, 'g'), unesc);
  }
  return unescaped;
}

/**
 * Remove potentially dangerous characters from user input
 */
export function sanitizeText(
  text: string | null | undefined,
  options?: {
    allowNewlines?: boolean;
    maxLength?: number;
  }
): string {
  if (!text) return '';

  let sanitized = String(text);

  // Remove null bytes
  sanitized = sanitized.replace(/\0/g, '');

  // Remove control characters except newline/tab
  sanitized = sanitized.replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/g, '');

  // Handle newlines
  if (!options?.allowNewlines) {
    sanitized = sanitized.replace(/[\r\n]/g, ' ');
  }

  // Trim whitespace
  sanitized = sanitized.trim();

  // Enforce max length
  if (options?.maxLength) {
    sanitized = sanitized.substring(0, options.maxLength);
  }

  return sanitized;
}

/**
 * Sanitize a filename to prevent directory traversal attacks
 */
export function sanitizeFilename(filename: string): string {
  if (!filename) return 'file';

  // Remove path separators
  let sanitized = filename
    .replace(/\//g, '_')
    .replace(/\\/g, '_')
    .replace(/\./g, '_');

  // Remove special characters
  sanitized = sanitized.replace(/[^a-zA-Z0-9_\-\.]/g, '_');

  // Remove multiple underscores
  sanitized = sanitized.replace(/_+/g, '_');

  // Ensure it doesn't start with a dot
  sanitized = sanitized.replace(/^\.+/, '');

  // Maximum length
  sanitized = sanitized.substring(0, 255);

  return sanitized || 'file';
}

/**
 * Sanitize SQL input to prevent SQL injection (use parameterized queries instead!)
 * This is a fallback - always use parameterized queries with Prisma
 */
export function escapeSqlLiteral(value: string): string {
  if (!value) return "''";

  return (
    "'" +
    value
      .replace(/'/g, "''")
      .replace(/\\/g, '\\\\')
      .replace(/\x00/g, '\\0') +
    "'"
  );
}

/**
 * Sanitize URL to prevent javascript: and data: attacks
 */
export function sanitizeUrl(url: string | null | undefined): string {
  if (!url) return '';

  const trimmed = String(url).trim();

  // Block dangerous protocols
  const dangerousProtocols = [
    'javascript:',
    'data:',
    'vbscript:',
    'file:',
    'about:',
  ];

  const lowerUrl = trimmed.toLowerCase();
  for (const protocol of dangerousProtocols) {
    if (lowerUrl.startsWith(protocol)) {
      return '';
    }
  }

  // Allow only http, https, and relative URLs
  if (!lowerUrl.startsWith('http://') && !lowerUrl.startsWith('https://') && !lowerUrl.startsWith('/')) {
    return '';
  }

  try {
    // Validate as URL
    new URL(trimmed, 'http://localhost');
    return trimmed;
  } catch {
    // If not a valid absolute URL, check if it's a valid relative URL
    if (trimmed.startsWith('/') || trimmed.startsWith('.')) {
      return trimmed;
    }
    return '';
  }
}

/**
 * Sanitize JSON input to prevent injection
 */
export function sanitizeJson(jsonString: string): Record<string, unknown> {
  if (!jsonString) return {};

  try {
    const parsed = JSON.parse(jsonString);

    // Recursively sanitize all string values
    return sanitizeJsonObject(parsed);
  } catch (error) {
    console.error('[Sanitize] Invalid JSON:', error);
    return {};
  }
}

/**
 * Recursively sanitize all strings in an object
 */
function sanitizeJsonObject(
  obj: unknown
): unknown {
  if (obj === null || obj === undefined) {
    return obj;
  }

  if (typeof obj === 'string') {
    return sanitizeText(obj);
  }

  if (typeof obj === 'number' || typeof obj === 'boolean') {
    return obj;
  }

  if (Array.isArray(obj)) {
    return obj.map(sanitizeJsonObject);
  }

  if (typeof obj === 'object') {
    const sanitized: Record<string, unknown> = {};
    for (const [key, value] of Object.entries(obj as Record<string, unknown>)) {
      sanitized[sanitizeText(key)] = sanitizeJsonObject(value);
    }
    return sanitized;
  }

  return obj;
}

/**
 * Sanitize email address
 */
export function sanitizeEmail(email: string): string {
  if (!email) return '';

  const sanitized = sanitizeText(email).toLowerCase();

  // Basic email validation
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(sanitized)) {
    return '';
  }

  return sanitized;
}

/**
 * Sanitize phone number
 */
export function sanitizePhone(phone: string): string {
  if (!phone) return '';

  // Keep only digits, +, and dashes
  const sanitized = sanitizeText(phone).replace(/[^\d+\-]/g, '');

  return sanitized;
}

/**
 * Sanitize and validate an object based on schema
 */
export function sanitizeObject<T extends Record<string, unknown>>(
  obj: T,
  schema: Record<keyof T, { type: string; maxLength?: number }>
): Partial<T> {
  const sanitized: Partial<T> = {};

  for (const [key, value] of Object.entries(obj)) {
    const fieldSchema = schema[key as keyof T];

    if (!fieldSchema) {
      continue; // Skip unknown fields
    }

    if (value === null || value === undefined) {
      sanitized[key as keyof T] = value as any;
      continue;
    }

    if (fieldSchema.type === 'string') {
      sanitized[key as keyof T] = sanitizeText(String(value), {
        maxLength: fieldSchema.maxLength,
      }) as any;
    } else if (fieldSchema.type === 'email') {
      sanitized[key as keyof T] = sanitizeEmail(String(value)) as any;
    } else if (fieldSchema.type === 'url') {
      sanitized[key as keyof T] = sanitizeUrl(String(value)) as any;
    } else if (fieldSchema.type === 'phone') {
      sanitized[key as keyof T] = sanitizePhone(String(value)) as any;
    } else {
      sanitized[key as keyof T] = value;
    }
  }

  return sanitized;
}
