/**
 * Zod Validation Schemas for All Data Types
 * Comprehensive validation for members, users, auth, and settings
 */

import { z } from 'zod';

// ============================================
// COMMON SCHEMAS
// ============================================

export const idSchema = z.string().min(1, 'ID is required').max(255);

export const emailSchema = z.string().email('Invalid email address').toLowerCase();

// Saudi phone validation: accepts various formats
export const phoneSchema = z
  .string()
  .transform((val) => val?.replace(/[\s\-()]/g, '') || '')
  .refine(
    (val) => {
      if (!val || val === '') return true; // Optional field
      const cleaned = val.replace(/^\+/, '');
      if (cleaned.startsWith('00966') && cleaned.length === 14)
        return cleaned.substring(5).startsWith('5');
      if (cleaned.startsWith('966') && cleaned.length === 12)
        return cleaned.substring(3).startsWith('5');
      if (cleaned.startsWith('05') && cleaned.length === 10) return true;
      if (cleaned.startsWith('5') && cleaned.length === 9) return true;
      return false;
    },
    'Invalid Saudi phone number'
  )
  .optional()
  .or(z.literal(''));

export const passwordSchema = z
  .string()
  .min(8, 'Password must be at least 8 characters')
  .regex(/[A-Z]/, 'Password must contain at least one uppercase letter')
  .regex(/[a-z]/, 'Password must contain at least one lowercase letter')
  .regex(/[0-9]/, 'Password must contain at least one number');

export const arabicNameSchema = z
  .string()
  .min(2, 'Name must be at least 2 characters')
  .regex(/^[\u0600-\u06FF\s]+$/, 'Name must be in Arabic');

export const englishNameSchema = z
  .string()
  .min(2, 'Name must be at least 2 characters')
  .regex(/^[a-zA-Z\s]+$/, 'Name must be in English')
  .optional()
  .or(z.literal(''));

// ============================================
// AUTHENTICATION SCHEMAS
// ============================================

export const loginSchema = z.object({
  email: emailSchema,
  password: z.string().min(1, 'Password is required'),
  rememberMe: z.boolean().optional().default(false),
});

export const registerSchema = z.object({
  email: emailSchema,
  password: passwordSchema,
  nameArabic: arabicNameSchema,
  nameEnglish: englishNameSchema,
  phone: phoneSchema,
});

export const passwordResetRequestSchema = z.object({
  email: emailSchema,
});

export const passwordResetSchema = z
  .object({
    token: z.string().min(1, 'Token is required'),
    password: passwordSchema,
    confirmPassword: z.string(),
  })
  .refine((data) => data.password === data.confirmPassword, {
    message: "Passwords don't match",
    path: ['confirmPassword'],
  });

export const twoFactorSetupSchema = z.object({
  method: z.enum(['TOTP', 'SMS']),
  phoneNumber: phoneSchema.optional(),
});

export const twoFactorVerifySchema = z.object({
  code: z.string().regex(/^\d{6}$/, 'Code must be 6 digits'),
  backupCode: z.string().optional(),
});

// ============================================
// FAMILY MEMBER SCHEMAS
// ============================================

export const genderSchema = z.enum(['Male', 'Female']);

export const memberStatusSchema = z.enum(['Living', 'Deceased']);

export const createMemberSchema = z.object({
  firstName: z.string().min(1, 'First name is required').max(100),
  fatherName: z.string().max(100).optional().nullable(),
  grandfatherName: z.string().max(100).optional().nullable(),
  greatGrandfatherName: z.string().max(100).optional().nullable(),
  familyName: z.string().default('آل شايع'),
  fatherId: z.string().optional().nullable(),
  gender: genderSchema,
  birthYear: z
    .number()
    .int()
    .min(1800)
    .max(new Date().getFullYear())
    .optional()
    .nullable(),
  birthCalendar: z.enum(['HIJRI', 'GREGORIAN']).optional(),
  deathYear: z
    .number()
    .int()
    .min(1800)
    .max(new Date().getFullYear())
    .optional()
    .nullable(),
  deathCalendar: z.enum(['HIJRI', 'GREGORIAN']).optional(),
  generation: z.number().int().min(1).max(20).optional(),
  branch: z.string().max(100).optional().nullable(),
  fullNameAr: z.string().max(200).optional().nullable(),
  fullNameEn: z.string().max(200).optional().nullable(),
  phone: phoneSchema,
  city: z.string().max(100).optional().nullable(),
  status: memberStatusSchema.default('Living'),
  photoUrl: z.string().url().optional().nullable(),
  biography: z.string().max(2000).optional().nullable(),
  occupation: z.string().max(100).optional().nullable(),
  email: emailSchema.optional().nullable().or(z.literal('')),
});

export const updateMemberSchema = createMemberSchema
  .partial()
  .extend({
    id: idSchema,
  });

export const memberQuerySchema = z.object({
  page: z.coerce.number().int().min(1).default(1),
  limit: z.coerce.number().int().min(1).max(100).default(10),
  gender: genderSchema.optional(),
  generation: z.coerce.number().int().min(1).max(20).optional(),
  branch: z.string().optional(),
  status: memberStatusSchema.optional(),
  search: z.string().optional(),
  sortBy: z
    .enum(['firstName', 'generation', 'birthYear', 'createdAt'])
    .default('firstName'),
  sortOrder: z.enum(['asc', 'desc']).default('asc'),
});

// ============================================
// USER MANAGEMENT SCHEMAS
// ============================================

export const userRoleSchema = z.enum(['SUPER_ADMIN', 'ADMIN', 'BRANCH_LEADER', 'MEMBER', 'GUEST']);

export const userStatusSchema = z.enum(['PENDING', 'ACTIVE', 'DISABLED']);

export const createUserSchema = z.object({
  email: emailSchema,
  password: passwordSchema,
  nameArabic: arabicNameSchema,
  nameEnglish: englishNameSchema,
  phone: phoneSchema,
  role: userRoleSchema.default('MEMBER'),
  linkedMemberId: z.string().optional().nullable(),
  assignedBranch: z.string().optional().nullable(),
});

export const updateUserSchema = z.object({
  id: idSchema,
  nameArabic: arabicNameSchema.optional(),
  nameEnglish: englishNameSchema.optional(),
  phone: phoneSchema,
  role: userRoleSchema.optional(),
  status: userStatusSchema.optional(),
  linkedMemberId: z.string().optional().nullable(),
  assignedBranch: z.string().optional().nullable(),
});

// ============================================
// EXPORT SCHEMAS
// ============================================

export const exportOptionsSchema = z.object({
  format: z.enum(['JSON', 'CSV', 'EXCEL', 'PDF']),
  fields: z.array(z.string()).min(1, 'Select at least one field'),
  includeTree: z.boolean().default(false),
  groupByGeneration: z.boolean().default(false),
  filters: z
    .object({
      generations: z.array(z.number()).optional(),
      branches: z.array(z.string()).optional(),
      genders: z.array(genderSchema).optional(),
      status: z.array(memberStatusSchema).optional(),
      searchQuery: z.string().optional(),
    })
    .optional(),
});

export const importOptionsSchema = z.object({
  fileType: z.enum(['JSON', 'CSV', 'EXCEL']),
  conflictStrategy: z
    .enum(['SKIP', 'OVERWRITE', 'MERGE', 'ASK'])
    .default('ASK'),
  validateOnly: z.boolean().default(false),
});

// ============================================
// SETTINGS SCHEMAS
// ============================================

export const siteSettingsSchema = z.object({
  familyNameArabic: z.string().min(1),
  familyNameEnglish: z.string().min(1),
  taglineArabic: z.string().optional(),
  taglineEnglish: z.string().optional(),
  logoUrl: z.string().url().optional().nullable(),
  defaultLanguage: z.enum(['ar', 'en']).default('ar'),
  sessionDurationDays: z.number().int().min(1).max(365).default(7),
  rememberMeDurationDays: z.number().int().min(1).max(365).default(30),
  allowSelfRegistration: z.boolean().default(true),
  requireEmailVerification: z.boolean().default(false),
  require2FAForAdmins: z.boolean().default(false),
  maxLoginAttempts: z.number().int().min(3).max(10).default(5),
  lockoutDurationMinutes: z.number().int().min(5).max(60).default(15),
});

// ============================================
// TYPE EXPORTS
// ============================================

export type LoginInput = z.infer<typeof loginSchema>;
export type RegisterInput = z.infer<typeof registerSchema>;
export type PasswordResetInput = z.infer<typeof passwordResetSchema>;
export type CreateMemberInput = z.infer<typeof createMemberSchema>;
export type UpdateMemberInput = z.infer<typeof updateMemberSchema>;
export type MemberQueryInput = z.infer<typeof memberQuerySchema>;
export type CreateUserInput = z.infer<typeof createUserSchema>;
export type UpdateUserInput = z.infer<typeof updateUserSchema>;
export type ExportOptionsInput = z.infer<typeof exportOptionsSchema>;
export type ImportOptionsInput = z.infer<typeof importOptionsSchema>;
export type SiteSettingsInput = z.infer<typeof siteSettingsSchema>;

/**
 * Validate input with schema
 */
export function validateInput<T>(
  schema: z.ZodSchema<T>,
  data: unknown
): { success: true; data: T } | { success: false; errors: z.ZodError } {
  const result = schema.safeParse(data);
  if (result.success) {
    return { success: true, data: result.data };
  }
  return { success: false, errors: result.error };
}

/**
 * Format Zod errors for API response
 */
export function formatZodErrors(errors: z.ZodError): Record<string, string> {
  const formatted: Record<string, string> = {};
  for (const error of errors.issues) {
    const path = error.path.join('.');
    formatted[path] = error.message;
  }
  return formatted;
}
