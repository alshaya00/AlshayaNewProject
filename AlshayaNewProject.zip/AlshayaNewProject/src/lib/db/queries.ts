/**
 * Reusable Query Builders for Common Database Operations
 * Provides safe, typed query patterns for the application
 */

import { prisma } from './prisma';
import { Prisma } from '@prisma/client';

/**
 * Query builder for finding a member with all relations
 */
export const memberQueries = {
  /**
   * Get a member with full relations
   */
  getWithRelations: async (memberId: string) => {
    return prisma.familyMember.findUnique({
      where: { id: memberId },
      include: {
        father: true,
        children: true,
        changeHistory: true,
      },
    });
  },

  /**
   * Get members by generation
   */
  getByGeneration: async (generation: number, limit?: number) => {
    return prisma.familyMember.findMany({
      where: { generation },
      take: limit,
      orderBy: { firstName: 'asc' },
    });
  },

  /**
   * Get members by branch with pagination
   */
  getByBranch: async (branch: string, skip: number = 0, take: number = 10) => {
    return prisma.familyMember.findMany({
      where: { branch },
      skip,
      take,
      orderBy: { firstName: 'asc' },
    });
  },

  /**
   * Search members by name (fuzzy)
   */
  search: async (searchTerm: string, limit: number = 20) => {
    return prisma.familyMember.findMany({
      where: {
        OR: [
          { firstName: { contains: searchTerm, mode: 'insensitive' } },
          { fullNameAr: { contains: searchTerm, mode: 'insensitive' } },
          { fullNameEn: { contains: searchTerm, mode: 'insensitive' } },
        ],
      },
      take: limit,
    });
  },

  /**
   * Get count of members
   */
  count: async (where?: Prisma.FamilyMemberWhereInput) => {
    return prisma.familyMember.count({ where });
  },

  /**
   * Get all members for tree building
   */
  getAll: async () => {
    return prisma.familyMember.findMany({
      orderBy: [{ generation: 'asc' }, { firstName: 'asc' }],
    });
  },
};

/**
 * Query builder for user operations
 */
export const userQueries = {
  /**
   * Get user by email
   */
  getByEmail: async (email: string) => {
    return prisma.user.findUnique({
      where: { email },
      include: { sessions: true },
    });
  },

  /**
   * Get user with all relations
   */
  getWithRelations: async (userId: string) => {
    return prisma.user.findUnique({
      where: { id: userId },
      include: {
        sessions: true,
        linkedMember: true,
      },
    });
  },

  /**
   * Get active users
   */
  getActive: async (limit?: number) => {
    return prisma.user.findMany({
      where: { status: 'ACTIVE' },
      take: limit,
      orderBy: { createdAt: 'desc' },
    });
  },

  /**
   * Get users by role
   */
  getByRole: async (role: string) => {
    return prisma.user.findMany({
      where: { role },
      orderBy: { createdAt: 'desc' },
    });
  },

  /**
   * Get count of users
   */
  count: async (where?: Prisma.UserWhereInput) => {
    return prisma.user.count({ where });
  },
};

/**
 * Query builder for session operations
 */
export const sessionQueries = {
  /**
   * Get session by token
   */
  getByToken: async (token: string) => {
    return prisma.session.findUnique({
      where: { token },
      include: { user: true },
    });
  },

  /**
   * Get active sessions for a user
   */
  getActiveForUser: async (userId: string) => {
    return prisma.session.findMany({
      where: {
        userId,
        expiresAt: { gt: new Date() },
      },
      orderBy: { createdAt: 'desc' },
    });
  },

  /**
   * Delete expired sessions
   */
  deleteExpired: async () => {
    return prisma.session.deleteMany({
      where: { expiresAt: { lt: new Date() } },
    });
  },

  /**
   * Count active sessions
   */
  countActive: async (userId: string) => {
    return prisma.session.count({
      where: {
        userId,
        expiresAt: { gt: new Date() },
      },
    });
  },
};

/**
 * Query builder for audit log operations
 */
export const auditQueries = {
  /**
   * Get recent changes for a member
   */
  getMemberHistory: async (memberId: string, limit: number = 50) => {
    return prisma.changeHistory.findMany({
      where: { memberId },
      take: limit,
      orderBy: { changedAt: 'desc' },
    });
  },

  /**
   * Get changes by user
   */
  getByUser: async (userId: string, limit: number = 50) => {
    return prisma.changeHistory.findMany({
      where: { changedBy: userId },
      take: limit,
      orderBy: { changedAt: 'desc' },
    });
  },

  /**
   * Get all changes in a time range
   */
  getByDateRange: async (startDate: Date, endDate: Date, limit?: number) => {
    return prisma.changeHistory.findMany({
      where: {
        changedAt: { gte: startDate, lte: endDate },
      },
      take: limit,
      orderBy: { changedAt: 'desc' },
    });
  },

  /**
   * Count total changes
   */
  count: async () => {
    return prisma.changeHistory.count();
  },
};

/**
 * Query builder for snapshot operations
 */
export const snapshotQueries = {
  /**
   * Get recent snapshots
   */
  getRecent: async (limit: number = 10) => {
    return prisma.snapshot.findMany({
      orderBy: { createdAt: 'desc' },
      take: limit,
    });
  },

  /**
   * Get snapshots by type
   */
  getByType: async (snapshotType: string) => {
    return prisma.snapshot.findMany({
      where: { snapshotType },
      orderBy: { createdAt: 'desc' },
    });
  },

  /**
   * Get snapshot by ID
   */
  getById: async (snapshotId: string) => {
    return prisma.snapshot.findUnique({
      where: { id: snapshotId },
    });
  },
};

/**
 * Batch operations helper
 */
export const batchQueries = {
  /**
   * Get multiple members by IDs
   */
  getMembersByIds: async (memberIds: string[]) => {
    return prisma.familyMember.findMany({
      where: { id: { in: memberIds } },
    });
  },

  /**
   * Get multiple users by IDs
   */
  getUsersByIds: async (userIds: string[]) => {
    return prisma.user.findMany({
      where: { id: { in: userIds } },
    });
  },

  /**
   * Update multiple members
   */
  updateMembers: async (
    memberIds: string[],
    data: Prisma.FamilyMemberUpdateInput
  ) => {
    return prisma.familyMember.updateMany({
      where: { id: { in: memberIds } },
      data,
    });
  },
};

/**
 * Transaction helper for complex operations
 */
export const transactionQueries = {
  /**
   * Run a transaction with multiple operations
   */
  execute: async <T>(
    callback: (tx: typeof prisma) => Promise<T>
  ): Promise<T> => {
    return prisma.$transaction(callback);
  },

  /**
   * Run raw transaction queries
   */
  raw: async <T>(
    queries: Prisma.PrismaPromise<T>[]
  ): Promise<T[]> => {
    return prisma.$transaction(queries);
  },
};
