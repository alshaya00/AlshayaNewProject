/**
 * Singleton Prisma Client with Connection Pooling
 * Handles database connection management for Next.js 14
 * Prevents connection pool exhaustion in development/production
 */

import { PrismaClient, Prisma } from '@prisma/client';

export { Prisma };

// Type for the Prisma client
type PrismaClientType = PrismaClient;

/**
 * Create a mock Prisma client for build time when Prisma isn't fully initialized
 */
function createMockPrismaClient(): PrismaClientType {
  const mockModel = {
    findMany: () => Promise.resolve([]),
    findFirst: () => Promise.resolve(null),
    findUnique: () => Promise.resolve(null),
    create: () => Promise.resolve({}),
    update: () => Promise.resolve({}),
    delete: () => Promise.resolve({}),
    deleteMany: () => Promise.resolve({ count: 0 }),
    count: () => Promise.resolve(0),
    upsert: () => Promise.resolve({}),
    updateMany: () => Promise.resolve({ count: 0 }),
    createMany: () => Promise.resolve({ count: 0 }),
    aggregate: () => Promise.resolve({}),
    groupBy: () => Promise.resolve([]),
  };

  const mockHandler = {
    get(_target: unknown, prop: string) {
      if (prop === '$connect' || prop === '$disconnect') {
        return () => Promise.resolve();
      }
      if (prop === '$transaction') {
        return (fn: (tx: unknown) => Promise<unknown>) => fn(createMockPrismaClient());
      }
      if (prop === '$queryRaw' || prop === '$executeRaw') {
        return () => Promise.resolve([]);
      }
      return mockModel;
    },
  };
  return new Proxy({}, mockHandler) as PrismaClientType;
}

// Global type for Prisma client singleton
declare global {
  // eslint-disable-next-line no-var
  var prisma: PrismaClientType | undefined;
}

let prisma: PrismaClientType;

try {
  // Check if DATABASE_URL is set
  if (!process.env.DATABASE_URL) {
    console.warn('[Prisma] DATABASE_URL not set, using mock client');
    prisma = createMockPrismaClient();
  } else {
    // Initialize Prisma with optimized connection pooling
    prisma =
      global.prisma ??
      new PrismaClient({
        log:
          process.env.NODE_ENV === 'development'
            ? ['query', 'error', 'warn']
            : ['error'],
        datasourceUrl: process.env.DATABASE_URL,
      });

    // Cache the client globally to reuse connections
    if (process.env.NODE_ENV !== 'production') {
      global.prisma = prisma;
    }
  }
} catch (error) {
  console.warn('[Prisma] Failed to initialize. Using mock client for build.', error);
  prisma = createMockPrismaClient();
}

// Graceful shutdown on process exit
if (typeof global.prisma === 'undefined') {
  process.on('exit', async () => {
    if (prisma && prisma !== createMockPrismaClient()) {
      await prisma.$disconnect();
    }
  });
}

export { prisma };
export default prisma;
