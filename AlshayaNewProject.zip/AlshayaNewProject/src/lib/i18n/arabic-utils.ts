import type { Locale } from '@/i18n/config';

// ============================================
// Text Direction
// ============================================

export function getDirection(locale: Locale): 'rtl' | 'ltr' {
  return locale === 'ar' ? 'rtl' : 'ltr';
}

export function isRTL(locale: Locale): boolean {
  return locale === 'ar';
}

export function isLTR(locale: Locale): boolean {
  return locale === 'en';
}

// ============================================
// Arabic Number/Numeral Conversion
// ============================================

// Arabic-Indic numerals
const ARABIC_NUMERALS = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
const ENGLISH_NUMERALS = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];

// Extended Arabic-Indic numerals (used in some regions)
const EASTERN_ARABIC_NUMERALS = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];

export function convertToArabicNumerals(text: string): string {
  let result = text;

  // Replace English numerals with Arabic numerals
  ENGLISH_NUMERALS.forEach((english, index) => {
    const regex = new RegExp(english, 'g');
    result = result.replace(regex, ARABIC_NUMERALS[index]);
  });

  // Also replace Eastern Arabic numerals to standard Arabic numerals
  EASTERN_ARABIC_NUMERALS.forEach((eastern, index) => {
    const regex = new RegExp(eastern, 'g');
    result = result.replace(regex, ARABIC_NUMERALS[index]);
  });

  return result;
}

export function convertToEnglishNumerals(text: string): string {
  let result = text;

  // Replace Arabic numerals with English numerals
  ARABIC_NUMERALS.forEach((arabic, index) => {
    const regex = new RegExp(arabic, 'g');
    result = result.replace(regex, ENGLISH_NUMERALS[index]);
  });

  // Also replace Eastern Arabic numerals
  EASTERN_ARABIC_NUMERALS.forEach((eastern, index) => {
    const regex = new RegExp(eastern, 'g');
    result = result.replace(regex, ENGLISH_NUMERALS[index]);
  });

  return result;
}

// ============================================
// Arabic Text Detection
// ============================================

// Unicode ranges for Arabic
const ARABIC_UNICODE_RANGE = /[\u0600-\u06FF\u0750-\u077F]/g;

export function isArabicText(text: string): boolean {
  return ARABIC_UNICODE_RANGE.test(text);
}

export function hasArabicText(text: string): boolean {
  return isArabicText(text);
}

export function getTextLanguage(text: string): 'ar' | 'en' | 'mixed' {
  const arabicMatch = text.match(ARABIC_UNICODE_RANGE);
  const arabicRatio = arabicMatch ? arabicMatch.length / text.length : 0;

  if (arabicRatio > 0.7) return 'ar';
  if (arabicRatio < 0.3) return 'en';
  return 'mixed';
}

// ============================================
// Arabic Diacritics (Tashkeel) Handling
// ============================================

const DIACRITICS = [
  '\u064B', // FATHATAN
  '\u064C', // DAMMATAN
  '\u064D', // KASRATAN
  '\u064E', // FATHA
  '\u064F', // DAMMA
  '\u0650', // KASRA
  '\u0651', // SHADDA
  '\u0652', // SUKUN
  '\u0653', // MADDAH
  '\u0654', // HAMZA ABOVE
  '\u0655', // HAMZA BELOW
  '\u0656', // SUBSCRIPT ALEF
  '\u0657', // INVERTED DAMMA
  '\u0658', // MARK NOON GHUNNA
  '\u0670', // SUPERSCRIPT ALEF
];

export function removeDiacritics(text: string): string {
  return text.split('').filter((char) => !DIACRITICS.includes(char)).join('');
}

export function hasDiacritics(text: string): boolean {
  return DIACRITICS.some((diacritic) => text.includes(diacritic));
}

// ============================================
// Islamic/Arabic Calendar (Hijri) Conversion
// ============================================

interface HijriDate {
  year: number;
  month: number;
  day: number;
}

// Gregorian to Hijri conversion
export function gregorianToHijri(gregorianDate: Date): HijriDate {
  const day = gregorianDate.getDate();
  const month = gregorianDate.getMonth() + 1;
  const year = gregorianDate.getFullYear();

  let julianDay = Math.floor((11 * year + 3) / 30) + 365 * year + 30 * month - Math.floor((month - 1) / 11) + day + 1948440 - 385;

  let hijriYear = Math.floor((30 * julianDay + 10646) / 10631);
  let hijriMonth = Math.floor(((julianDay - Math.floor((11 * hijriYear + 3) / 30) - 1) % 354) / 30) + 1;
  let hijriDay = julianDay - Math.floor((11 * hijriYear + 3) / 30) - Math.floor((hijriMonth - 1) / 12) * 30 - Math.floor((hijriMonth - 1) % 11 / 11) + 1;

  return {
    year: hijriYear,
    month: hijriMonth,
    day: hijriDay,
  };
}

// Hijri to Gregorian conversion
export function hijriToGregorian(hijriDate: HijriDate): Date {
  const { year: hijriYear, month: hijriMonth, day: hijriDay } = hijriDate;

  let julianDay = Math.floor((11 * hijriYear + 3) / 30) + 365 * hijriYear + 30 * hijriMonth - Math.floor((hijriMonth - 1) / 11) + hijriDay + 1948440 - 385;

  let gregorianYear = Math.floor((julianDay - 1867216.25) / 36524.25);
  gregorianYear = Math.floor((julianDay - Math.floor(gregorianYear / 4) + gregorianYear - 2) / 365.25);

  let gregorianMonth = Math.floor(((julianDay - Math.floor(365.25 * gregorianYear) - Math.floor((gregorianYear % 4) / 4)) * 12) / 367.25);
  gregorianMonth = Math.floor((julianDay - Math.floor(365.25 * gregorianYear) - Math.floor((gregorianYear % 4) / 4) - Math.floor((30.6 * gregorianMonth) / 1)) / 30.6);

  if (gregorianMonth > 12) {
    gregorianMonth = 12;
  }

  let gregorianDay = julianDay - Math.floor(365.25 * gregorianYear) - Math.floor((gregorianYear % 4) / 4) - Math.floor((30.6 * gregorianMonth) / 1);

  return new Date(gregorianYear, gregorianMonth - 1, gregorianDay);
}

export function formatHijriDate(hijriDate: HijriDate, locale: Locale): string {
  const months = [
    'محرم',
    'صفر',
    'ربيع الأول',
    'ربيع الثاني',
    'جمادى الأولى',
    'جمادى الثانية',
    'رجب',
    'شعبان',
    'رمضان',
    'شوال',
    'ذو القعدة',
    'ذو الحجة',
  ];

  const monthName = months[hijriDate.month - 1];
  return `${hijriDate.day} ${monthName} ${hijriDate.year} هـ`;
}

// ============================================
// Arabic Family Terminology
// ============================================

export const FAMILY_TERMS_AR = {
  // Direct family
  father: 'والد',
  mother: 'والدة',
  son: 'ابن',
  daughter: 'ابنة',
  brother: 'أخ',
  sister: 'أخت',
  grandfather: 'جد',
  grandmother: 'جدة',
  grandson: 'حفيد',
  granddaughter: 'حفيدة',

  // Extended family
  uncle_paternal: 'عم',
  aunt_paternal: 'عمة',
  uncle_maternal: 'خال',
  aunt_maternal: 'خالة',
  nephew: 'ابن الأخ/الأخت',
  niece: 'ابنة الأخ/الأخت',
  cousin: 'ابن العم/العمة/الخال/الخالة',

  // In-laws
  husband: 'زوج',
  wife: 'زوجة',
  father_in_law: 'حم',
  mother_in_law: 'حماة',
  son_in_law: 'صهر',
  daughter_in_law: 'كنة',
  brother_in_law: 'أخ بالمصاهرة',
  sister_in_law: 'أخت بالمصاهرة',

  // Step and foster relations
  stepfather: 'زوج الأم',
  stepmother: 'زوج الأب',
  stepbrother: 'أخ غير شقيق',
  stepsister: 'أخت غير شقيقة',
  foster_father: 'والد بالتبني',
  foster_mother: 'والدة بالتبني',
  foster_brother: 'أخ بالتبني',
  foster_sister: 'أخت بالتبني',

  // Milk relations (Islamic)
  milk_brother: 'أخ من الرضاعة',
  milk_sister: 'أخت من الرضاعة',
  milk_father: 'والد من الرضاعة',
  milk_mother: 'والدة من الرضاعة',
};

export function getArabicFamilyTerm(relationship: string): string {
  const key = relationship.toLowerCase().replace(/\s+/g, '_') as keyof typeof FAMILY_TERMS_AR;
  return FAMILY_TERMS_AR[key] || relationship;
}

// ============================================
// Arabic Text Shaping (Basic)
// ============================================

export function shouldRenderAsArabic(text: string): boolean {
  return getTextLanguage(text) !== 'en';
}

export function normalizeArabicText(text: string): string {
  let normalized = text;

  // Normalize hamza variations
  normalized = normalized.replace(/أ|إ|ٱ/g, 'ا'); // Alef with hamza variations
  normalized = normalized.replace(/ى/g, 'ي'); // Alef maqsura to ya
  normalized = normalized.replace(/ة/g, 'ه'); // Teh marbuta to heh

  // Remove diacritics
  normalized = removeDiacritics(normalized);

  // Normalize whitespace
  normalized = normalized.replace(/\s+/g, ' ').trim();

  return normalized;
}

// ============================================
// Arabic Name Parsing
// ============================================

export function parseArabicName(fullName: string): {
  first: string;
  middle: string[];
  last: string;
} {
  const parts = fullName.trim().split(/\s+/);

  if (parts.length === 0) {
    return { first: '', middle: [], last: '' };
  }

  if (parts.length === 1) {
    return { first: parts[0], middle: [], last: '' };
  }

  if (parts.length === 2) {
    return { first: parts[0], middle: [], last: parts[1] };
  }

  return {
    first: parts[0],
    middle: parts.slice(1, -1),
    last: parts[parts.length - 1],
  };
}

export function formatArabicName(first: string, last: string, middle?: string): string {
  if (!first && !last) return '';
  if (!last) return first;
  if (!first) return last;

  return middle ? `${first} ${middle} ${last}` : `${first} ${last}`;
}
