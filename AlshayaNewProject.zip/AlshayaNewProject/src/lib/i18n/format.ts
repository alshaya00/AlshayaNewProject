import type { Locale } from '@/i18n/config';

// ============================================
// Number Formatting
// ============================================

export function formatNumber(
  value: number,
  locale: Locale,
  options?: Intl.NumberFormatOptions
): string {
  try {
    const formatter = new Intl.NumberFormat(
      locale === 'ar' ? 'ar-SA' : 'en-US',
      options
    );
    return formatter.format(value);
  } catch (error) {
    console.error('Error formatting number:', error);
    return String(value);
  }
}

export function formatCurrency(
  value: number,
  locale: Locale,
  currency: string = 'SAR',
  options?: Intl.NumberFormatOptions
): string {
  return formatNumber(locale, locale, {
    style: 'currency',
    currency,
    ...options,
  });
}

export function formatPercent(
  value: number,
  locale: Locale,
  fractionDigits: number = 2
): string {
  return formatNumber(value, locale, {
    style: 'percent',
    minimumFractionDigits: fractionDigits,
    maximumFractionDigits: fractionDigits,
  });
}

// ============================================
// Date Formatting
// ============================================

export function formatDate(
  date: Date | string | number,
  locale: Locale,
  options?: Intl.DateTimeFormatOptions
): string {
  try {
    const dateObj = typeof date === 'string' || typeof date === 'number'
      ? new Date(date)
      : date;

    if (isNaN(dateObj.getTime())) {
      console.warn('Invalid date:', date);
      return '';
    }

    const formatter = new Intl.DateTimeFormat(
      locale === 'ar' ? 'ar-SA' : 'en-US',
      options
    );
    return formatter.format(dateObj);
  } catch (error) {
    console.error('Error formatting date:', error);
    return '';
  }
}

export function formatShortDate(date: Date | string | number, locale: Locale): string {
  return formatDate(date, locale, {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });
}

export function formatLongDate(date: Date | string | number, locale: Locale): string {
  return formatDate(date, locale, {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
}

export function formatDateTime(
  date: Date | string | number,
  locale: Locale,
  options?: Intl.DateTimeFormatOptions
): string {
  return formatDate(date, locale, {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    ...options,
  });
}

export function formatTime(
  date: Date | string | number,
  locale: Locale,
  options?: Intl.DateTimeFormatOptions
): string {
  return formatDate(date, locale, {
    hour: '2-digit',
    minute: '2-digit',
    ...options,
  });
}

// ============================================
// Relative Time Formatting
// ============================================

export function formatRelativeTime(
  date: Date | string | number,
  locale: Locale,
  now: Date = new Date()
): string {
  try {
    const dateObj = typeof date === 'string' || typeof date === 'number'
      ? new Date(date)
      : date;

    const milliseconds = now.getTime() - dateObj.getTime();
    const seconds = Math.floor(milliseconds / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);

    const rtf = new Intl.RelativeTimeFormat(
      locale === 'ar' ? 'ar-SA' : 'en-US',
      { numeric: 'auto' }
    );

    if (days > 0) {
      return rtf.format(-days, 'day');
    }
    if (hours > 0) {
      return rtf.format(-hours, 'hour');
    }
    if (minutes > 0) {
      return rtf.format(-minutes, 'minute');
    }
    return rtf.format(-seconds, 'second');
  } catch (error) {
    console.error('Error formatting relative time:', error);
    return '';
  }
}

// ============================================
// File Size Formatting
// ============================================

export function formatFileSize(bytes: number, locale: Locale): string {
  if (bytes === 0) return '0 B';

  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));

  const size = bytes / Math.pow(k, i);
  const formatted = formatNumber(size, locale, {
    minimumFractionDigits: i === 0 ? 0 : 2,
    maximumFractionDigits: i === 0 ? 0 : 2,
  });

  return `${formatted} ${sizes[i]}`;
}

// ============================================
// List Formatting
// ============================================

export function formatList(
  items: string[],
  locale: Locale,
  type: 'conjunction' | 'disjunction' = 'conjunction'
): string {
  try {
    if (items.length === 0) return '';
    if (items.length === 1) return items[0];

    const formatter = new Intl.ListFormat(
      locale === 'ar' ? 'ar-SA' : 'en-US',
      { style: 'long', type }
    );
    return formatter.format(items);
  } catch (error) {
    console.error('Error formatting list:', error);
    return items.join(', ');
  }
}

// ============================================
// Name/Text Formatting
// ============================================

export function toTitleCase(str: string): string {
  return str
    .toLowerCase()
    .split(' ')
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(' ');
}

export function toCamelCase(str: string): string {
  return str
    .toLowerCase()
    .replace(/[^a-z0-9]+(.)/g, (_, chr) => chr.toUpperCase());
}

export function toKebabCase(str: string): string {
  return str
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '');
}

// ============================================
// Phone Number Formatting
// ============================================

export function formatPhoneNumber(phone: string, locale: Locale): string {
  // Remove non-digits
  const cleaned = phone.replace(/\D/g, '');

  if (locale === 'ar') {
    // Saudi format: +966 50 1234 5678 or 050 1234 5678
    if (cleaned.startsWith('966')) {
      const number = cleaned.slice(3);
      return `+966 ${number.slice(0, 2)} ${number.slice(2, 6)} ${number.slice(6)}`;
    }
    if (cleaned.length === 9 || cleaned.length === 10) {
      return `0${cleaned.slice(-9).slice(0, 2)} ${cleaned.slice(-7, -3)} ${cleaned.slice(-3)}`;
    }
  } else {
    // US format: (xxx) xxx-xxxx
    if (cleaned.length === 10) {
      return `(${cleaned.slice(0, 3)}) ${cleaned.slice(3, 6)}-${cleaned.slice(6)}`;
    }
  }

  return phone;
}
