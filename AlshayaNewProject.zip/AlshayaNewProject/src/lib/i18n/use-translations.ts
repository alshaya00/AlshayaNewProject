'use client';

import { useCallback, useMemo } from 'react';
import type { Locale } from '@/i18n/config';
import ar from '@/messages/ar.json';
import en from '@/messages/en.json';

type TranslationKeys = keyof typeof ar;
type Translations = Record<TranslationKeys, string>;

const messages: Record<Locale, Translations> = {
  ar: ar as Translations,
  en: en as Translations,
};

interface UseTranslationsOptions {
  locale: Locale;
}

interface FormatParams {
  [key: string]: string | number | boolean;
}

export function useTranslations(options: UseTranslationsOptions) {
  const { locale } = options;

  const getTranslation = useCallback(
    (key: TranslationKeys, params?: FormatParams): string => {
      const translation = messages[locale][key];

      if (!translation) {
        console.warn(`Missing translation for key: ${key}`);
        return key;
      }

      if (!params) {
        return translation;
      }

      // Replace placeholders with provided values
      return Object.entries(params).reduce((result, [paramKey, paramValue]) => {
        const placeholder = new RegExp(`\\{${paramKey}\\}`, 'g');
        return result.replace(placeholder, String(paramValue));
      }, translation);
    },
    [locale]
  );

  const t = useCallback(
    (key: TranslationKeys, params?: FormatParams): string => {
      return getTranslation(key, params);
    },
    [getTranslation]
  );

  const tKey = useCallback(
    (key: TranslationKeys): TranslationKeys => {
      return key;
    },
    []
  );

  // Get all translations for a namespace (e.g., "common.*")
  const getNamespace = useCallback(
    (namespace: string): Record<string, string> => {
      const translations = messages[locale];
      const prefix = `${namespace}.`;
      const result: Record<string, string> = {};

      Object.entries(translations).forEach(([key, value]) => {
        if (key.startsWith(prefix)) {
          const nameKey = key.substring(prefix.length);
          result[nameKey] = value;
        }
      });

      return result;
    },
    [locale]
  );

  // Format a message with pluralization support
  const formatMessage = useCallback(
    (
      key: TranslationKeys,
      count?: number,
      params?: FormatParams
    ): string => {
      let message = getTranslation(key, params);

      if (count !== undefined) {
        // Handle plural forms (could be extended with more sophisticated plural rules)
        const pluralKey = count === 1 ? `${key}_one` : `${key}_other`;
        const pluralMessage = messages[locale][pluralKey as TranslationKeys];

        if (pluralMessage) {
          message = pluralMessage;
        }
      }

      return message;
    },
    [getTranslation, locale]
  );

  return useMemo(
    () => ({
      t,
      tKey,
      getTranslation,
      getNamespace,
      formatMessage,
      locale,
    }),
    [t, tKey, getTranslation, getNamespace, formatMessage, locale]
  );
}

// Export a simple function for server-side translations
export function getServerTranslations(locale: Locale) {
  const translations = messages[locale];

  return {
    t: (key: TranslationKeys, params?: FormatParams): string => {
      const translation = translations[key];

      if (!translation) {
        console.warn(`Missing translation for key: ${key}`);
        return key;
      }

      if (!params) {
        return translation;
      }

      return Object.entries(params).reduce((result, [paramKey, paramValue]) => {
        const placeholder = new RegExp(`\\{${paramKey}\\}`, 'g');
        return result.replace(placeholder, String(paramValue));
      }, translation);
    },

    locale,
  };
}
