/**
 * Thread-Safe Member ID Generation
 * Prevents race conditions in ID generation
 */

import { randomBytes } from 'crypto';

/**
 * Member ID configuration
 */
export const MEMBER_ID_CONFIG = {
  prefix: 'MEM',
  length: 12, // Total length: 3 (prefix) + 9 (random)
  charset: 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789',
};

/**
 * Simple counter-based ID generator with mutex-like behavior
 */
class MemberIdGenerator {
  private counter: number = 0;
  private lastTimestamp: number = 0;
  private readonly lock = { isLocked: false };

  /**
   * Acquire mutex lock
   */
  private acquireLock(): void {
    // In single-threaded Node.js, this is simplified
    // In a distributed system, use Redis or similar
    this.lock.isLocked = true;
  }

  /**
   * Release mutex lock
   */
  private releaseLock(): void {
    this.lock.isLocked = false;
  }

  /**
   * Generate a unique member ID
   * Format: MEM-TIMESTAMP-COUNTER-RANDOM
   */
  generateId(): string {
    this.acquireLock();

    try {
      const now = Date.now();
      const timestamp = now.toString(36).toUpperCase(); // Base36 timestamp
      const randomPart = this.generateRandomString(8);

      // Use counter to ensure uniqueness within same millisecond
      if (now === this.lastTimestamp) {
        this.counter++;
      } else {
        this.counter = 0;
        this.lastTimestamp = now;
      }

      const counterStr = this.counter.toString(36).toUpperCase().padStart(4, '0');

      return `${MEMBER_ID_CONFIG.prefix}-${timestamp}-${counterStr}-${randomPart}`;
    } finally {
      this.releaseLock();
    }
  }

  /**
   * Generate a random string
   */
  private generateRandomString(length: number): string {
    const bytes = randomBytes(length);
    let result = '';

    for (let i = 0; i < length; i++) {
      result += MEMBER_ID_CONFIG.charset[bytes[i] % MEMBER_ID_CONFIG.charset.length];
    }

    return result;
  }

  /**
   * Reset counter (for testing)
   */
  reset(): void {
    this.counter = 0;
    this.lastTimestamp = 0;
  }
}

// Global generator instance
const generator = new MemberIdGenerator();

/**
 * Generate a unique member ID
 */
export function generateMemberId(): string {
  return generator.generateId();
}

/**
 * Validate member ID format
 */
export function isValidMemberId(id: string): boolean {
  if (!id) return false;

  // Basic format check
  const format = /^MEM-[A-Z0-9]+-[A-Z0-9]+-[A-Z0-9]+$/;
  if (!format.test(id)) return false;

  // Check length constraints
  if (id.length < 15) return false;
  if (id.length > 50) return false;

  return true;
}

/**
 * Extract timestamp from member ID
 */
export function getTimestampFromMemberId(memberId: string): Date | null {
  if (!isValidMemberId(memberId)) return null;

  const parts = memberId.split('-');
  if (parts.length < 2) return null;

  try {
    const timestamp = parseInt(parts[1], 36);
    return new Date(timestamp);
  } catch {
    return null;
  }
}

/**
 * Generate multiple member IDs efficiently
 */
export function generateMemberIds(count: number): string[] {
  const ids: string[] = [];

  for (let i = 0; i < count; i++) {
    ids.push(generateMemberId());
  }

  return ids;
}

/**
 * Alternative: UUID-based ID generation
 * More portable but longer IDs
 */
export function generateUuidMemberId(): string {
  const uuid = crypto.randomUUID?.();
  if (!uuid) {
    // Fallback for Node.js < 15.7
    return generateMemberId();
  }
  return `MEM-${uuid.toUpperCase()}`;
}

/**
 * Validate UUID-based member ID
 */
export function isValidUuidMemberId(id: string): boolean {
  if (!id.startsWith('MEM-')) return false;

  const uuid = id.slice(4);
  const uuidRegex =
    /^[0-9A-F]{8}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{12}$/i;

  return uuidRegex.test(uuid);
}

/**
 * Batch ID generation with collision detection
 */
export function generateUniqueMemberIds(
  count: number,
  existingIds: Set<string>
): { ids: string[]; generated: number; collisions: number } {
  const ids: string[] = [];
  let collisions = 0;
  let attempts = 0;
  const maxAttempts = count * 10; // Prevent infinite loops

  while (ids.length < count && attempts < maxAttempts) {
    const newId = generateMemberId();

    if (!existingIds.has(newId)) {
      ids.push(newId);
      existingIds.add(newId);
    } else {
      collisions++;
    }

    attempts++;
  }

  return {
    ids,
    generated: ids.length,
    collisions,
  };
}
