/**
 * Tree Data Integrity Validation
 * Detects cycles, orphans, and other structural issues
 */

import { FamilyMember } from '@/types';

/**
 * Validation issue types
 */
export enum ValidationIssueType {
  CYCLE_DETECTED = 'cycle_detected',
  ORPHAN_MEMBER = 'orphan_member',
  PARENT_NOT_FOUND = 'parent_not_found',
  INVALID_GENERATION = 'invalid_generation',
  MISSING_REQUIRED_FIELD = 'missing_required_field',
  DUPLICATE_ID = 'duplicate_id',
  INVALID_PARENT_CHILD_ORDER = 'invalid_parent_child_order',
}

/**
 * Validation issue
 */
export interface ValidationIssue {
  type: ValidationIssueType;
  memberId: string;
  message: string;
  severity: 'error' | 'warning';
  suggestion?: string;
}

/**
 * Validation result
 */
export interface IntegrityValidationResult {
  valid: boolean;
  issues: ValidationIssue[];
  memberCount: number;
  errorCount: number;
  warningCount: number;
}

/**
 * Check for cycles in the family tree
 * Uses DFS to detect if a member is their own ancestor
 */
export function hasCycle(
  startMemberId: string,
  allMembers: FamilyMember[]
): boolean {
  const visited = new Set<string>();
  const recursionStack = new Set<string>();

  function dfs(memberId: string): boolean {
    visited.add(memberId);
    recursionStack.add(memberId);

    const member = allMembers.find((m) => m.id === memberId);
    if (member && member.fatherId) {
      if (!visited.has(member.fatherId)) {
        if (dfs(member.fatherId)) {
          return true;
        }
      } else if (recursionStack.has(member.fatherId)) {
        return true;
      }
    }

    recursionStack.delete(memberId);
    return false;
  }

  return dfs(startMemberId);
}

/**
 * Check if a member would create a cycle if assigned as a parent
 */
export function wouldCreateCycle(
  memberId: string,
  newFatherId: string,
  allMembers: FamilyMember[]
): boolean {
  // Can't be your own parent
  if (memberId === newFatherId) return true;

  // Check if memberId is an ancestor of newFatherId
  const memberMap = new Map(allMembers.map((m) => [m.id, m]));
  let currentMember = memberMap.get(newFatherId);

  while (currentMember?.fatherId) {
    if (currentMember.fatherId === memberId) {
      return true; // Would create cycle
    }
    currentMember = memberMap.get(currentMember.fatherId);
  }

  return false;
}

/**
 * Get all orphaned members (members with missing parents)
 */
export function getOrphanedMembers(allMembers: FamilyMember[]): FamilyMember[] {
  const memberIds = new Set(allMembers.map((m) => m.id));

  return allMembers.filter((m) => {
    if (!m.fatherId) return false;
    if (memberIds.has(m.fatherId)) return false;
    // Parent doesn't exist but member expects one
    return true;
  });
}

/**
 * Validate generation consistency
 * A member's generation should be parent's generation + 1
 */
export function validateGenerationConsistency(
  member: FamilyMember,
  allMembers: FamilyMember[]
): ValidationIssue | null {
  if (!member.fatherId || !member.generation) {
    return null;
  }

  const father = allMembers.find((m) => m.id === member.fatherId);
  if (!father || !father.generation) {
    return null;
  }

  if (father.generation + 1 !== member.generation) {
    return {
      type: ValidationIssueType.INVALID_GENERATION,
      memberId: member.id,
      message: `Generation mismatch: ${member.firstName} is generation ${member.generation} but father is generation ${father.generation}`,
      severity: 'error',
      suggestion: `Update generation to ${father.generation + 1}`,
    };
  }

  return null;
}

/**
 * Check for duplicate IDs
 */
export function checkDuplicateIds(allMembers: FamilyMember[]): ValidationIssue[] {
  const issues: ValidationIssue[] = [];
  const idCount = new Map<string, number>();

  for (const member of allMembers) {
    idCount.set(member.id, (idCount.get(member.id) || 0) + 1);
  }

  for (const [id, count] of idCount.entries()) {
    if (count > 1) {
      issues.push({
        type: ValidationIssueType.DUPLICATE_ID,
        memberId: id,
        message: `Found ${count} members with ID: ${id}`,
        severity: 'error',
        suggestion: 'Ensure all member IDs are unique',
      });
    }
  }

  return issues;
}

/**
 * Validate required fields
 */
export function validateRequiredFields(
  member: FamilyMember
): ValidationIssue | null {
  if (!member.id) {
    return {
      type: ValidationIssueType.MISSING_REQUIRED_FIELD,
      memberId: member.id || 'unknown',
      message: 'Member is missing ID',
      severity: 'error',
    };
  }

  if (!member.firstName) {
    return {
      type: ValidationIssueType.MISSING_REQUIRED_FIELD,
      memberId: member.id,
      message: `${member.id} is missing first name`,
      severity: 'error',
    };
  }

  if (!member.gender) {
    return {
      type: ValidationIssueType.MISSING_REQUIRED_FIELD,
      memberId: member.id,
      message: `${member.firstName} is missing gender`,
      severity: 'warning',
    };
  }

  return null;
}

/**
 * Validate parent-child age consistency
 */
export function validateParentChildAges(
  parent: FamilyMember,
  child: FamilyMember
): ValidationIssue | null {
  if (!parent.birthYear || !child.birthYear) {
    return null;
  }

  const ageDifference = child.birthYear - parent.birthYear;

  // Minimum reasonable age difference (15 years)
  if (ageDifference < 15) {
    return {
      type: ValidationIssueType.INVALID_PARENT_CHILD_ORDER,
      memberId: child.id,
      message: `${parent.firstName} and ${child.firstName} have an unrealistic age difference (${ageDifference} years)`,
      severity: 'warning',
      suggestion: 'Check birth years for accuracy',
    };
  }

  return null;
}

/**
 * Complete integrity validation
 */
export function validateTreeIntegrity(
  allMembers: FamilyMember[]
): IntegrityValidationResult {
  const issues: ValidationIssue[] = [];

  // Check for duplicate IDs
  issues.push(...checkDuplicateIds(allMembers));

  // Validate each member
  for (const member of allMembers) {
    // Check required fields
    const requiredFieldIssue = validateRequiredFields(member);
    if (requiredFieldIssue) {
      issues.push(requiredFieldIssue);
    }

    // Check for cycles
    if (hasCycle(member.id, allMembers)) {
      issues.push({
        type: ValidationIssueType.CYCLE_DETECTED,
        memberId: member.id,
        message: `Cycle detected involving ${member.firstName}`,
        severity: 'error',
        suggestion: 'Review parent relationships',
      });
    }

    // Check generation consistency
    const genIssue = validateGenerationConsistency(member, allMembers);
    if (genIssue) {
      issues.push(genIssue);
    }

    // Check parent exists
    if (member.fatherId) {
      const parent = allMembers.find((m) => m.id === member.fatherId);
      if (!parent) {
        issues.push({
          type: ValidationIssueType.PARENT_NOT_FOUND,
          memberId: member.id,
          message: `Parent with ID ${member.fatherId} not found for ${member.firstName}`,
          severity: 'error',
          suggestion: `Link to existing parent or remove parent reference`,
        });
      } else {
        // Check age consistency
        const ageIssue = validateParentChildAges(parent, member);
        if (ageIssue) {
          issues.push(ageIssue);
        }
      }
    }
  }

  // Check for orphans
  const orphans = getOrphanedMembers(allMembers);
  for (const orphan of orphans) {
    issues.push({
      type: ValidationIssueType.ORPHAN_MEMBER,
      memberId: orphan.id,
      message: `${orphan.firstName} has missing parent (ID: ${orphan.fatherId})`,
      severity: 'warning',
      suggestion: 'Link to existing parent or remove parent reference',
    });
  }

  const errorCount = issues.filter((i) => i.severity === 'error').length;
  const warningCount = issues.filter((i) => i.severity === 'warning').length;

  return {
    valid: errorCount === 0,
    issues,
    memberCount: allMembers.length,
    errorCount,
    warningCount,
  };
}

/**
 * Get all ancestors of a member
 */
export function getAllAncestors(
  memberId: string,
  allMembers: FamilyMember[]
): FamilyMember[] {
  const ancestors: FamilyMember[] = [];
  const memberMap = new Map(allMembers.map((m) => [m.id, m]));
  let currentMember = memberMap.get(memberId);
  const visited = new Set<string>(); // Detect cycles

  while (currentMember?.fatherId && !visited.has(currentMember.fatherId)) {
    visited.add(currentMember.id);
    const parent = memberMap.get(currentMember.fatherId);
    if (parent) {
      ancestors.push(parent);
      currentMember = parent;
    } else {
      break;
    }
  }

  return ancestors;
}

/**
 * Get all descendants of a member
 */
export function getAllDescendants(
  memberId: string,
  allMembers: FamilyMember[]
): FamilyMember[] {
  const descendants: FamilyMember[] = [];
  const queue: string[] = [memberId];
  const visited = new Set<string>();

  while (queue.length > 0) {
    const currentId = queue.shift();
    if (!currentId || visited.has(currentId)) continue;

    visited.add(currentId);

    const children = allMembers.filter((m) => m.fatherId === currentId);
    descendants.push(...children);

    for (const child of children) {
      queue.push(child.id);
    }
  }

  return descendants;
}
