/**
 * Relationship Detection and Calculation
 * Detects sibling, cousin, uncle, aunt, and other relationships
 */

import { FamilyMember } from '@/types';

/**
 * Types of family relationships
 */
export enum RelationType {
  FATHER = 'father',
  MOTHER = 'mother',
  SON = 'son',
  DAUGHTER = 'daughter',
  BROTHER = 'brother',
  SISTER = 'sister',
  GRANDFATHER = 'grandfather',
  GRANDMOTHER = 'grandmother',
  GRANDSON = 'grandson',
  GRANDDAUGHTER = 'granddaughter',
  UNCLE = 'uncle',
  AUNT = 'aunt',
  NEPHEW = 'nephew',
  NIECE = 'niece',
  COUSIN = 'cousin',
  COUSIN_ONCE_REMOVED = 'cousin_once_removed',
  SPOUSE = 'spouse',
  UNKNOWN = 'unknown',
}

/**
 * Relationship information
 */
export interface Relationship {
  type: RelationType;
  relatedMemberId: string;
  relatedMember: FamilyMember | null;
  degree?: number; // Generation difference
}

/**
 * Get direct parent (father only in this system)
 */
export function getFather(
  member: FamilyMember,
  allMembers: FamilyMember[]
): FamilyMember | null {
  if (!member.fatherId) return null;
  return allMembers.find((m) => m.id === member.fatherId) || null;
}

/**
 * Get all children
 */
export function getChildren(
  member: FamilyMember,
  allMembers: FamilyMember[]
): FamilyMember[] {
  return allMembers.filter((m) => m.fatherId === member.id);
}

/**
 * Get all siblings
 */
export function getSiblings(
  member: FamilyMember,
  allMembers: FamilyMember[]
): FamilyMember[] {
  if (!member.fatherId) return [];

  return allMembers.filter(
    (m) => m.fatherId === member.fatherId && m.id !== member.id
  );
}

/**
 * Get all brothers
 */
export function getBrothers(
  member: FamilyMember,
  allMembers: FamilyMember[]
): FamilyMember[] {
  return getSiblings(member, allMembers).filter((m) => m.gender === 'Male');
}

/**
 * Get all sisters
 */
export function getSisters(
  member: FamilyMember,
  allMembers: FamilyMember[]
): FamilyMember[] {
  return getSiblings(member, allMembers).filter((m) => m.gender === 'Female');
}

/**
 * Get father's father (paternal grandfather)
 */
export function getPaternalGrandfather(
  member: FamilyMember,
  allMembers: FamilyMember[]
): FamilyMember | null {
  const father = getFather(member, allMembers);
  if (!father) return null;
  return getFather(father, allMembers);
}

/**
 * Get all paternal uncles
 */
export function getPaternalUncles(
  member: FamilyMember,
  allMembers: FamilyMember[]
): FamilyMember[] {
  const father = getFather(member, allMembers);
  if (!father) return [];
  return getBrothers(father, allMembers);
}

/**
 * Get all paternal aunts
 */
export function getPaternalAunts(
  member: FamilyMember,
  allMembers: FamilyMember[]
): FamilyMember[] {
  const father = getFather(member, allMembers);
  if (!father) return [];
  return getSisters(father, allMembers);
}

/**
 * Get all first cousins (paternal)
 */
export function getPaternalCousins(
  member: FamilyMember,
  allMembers: FamilyMember[]
): FamilyMember[] {
  const uncles = getPaternalUncles(member, allMembers);
  const cousins: FamilyMember[] = [];

  for (const uncle of uncles) {
    cousins.push(...getChildren(uncle, allMembers));
  }

  return cousins;
}

/**
 * Get all grandchildren
 */
export function getGrandchildren(
  member: FamilyMember,
  allMembers: FamilyMember[]
): FamilyMember[] {
  const children = getChildren(member, allMembers);
  const grandchildren: FamilyMember[] = [];

  for (const child of children) {
    grandchildren.push(...getChildren(child, allMembers));
  }

  return grandchildren;
}

/**
 * Get all nephews and nieces
 */
export function getNephewsAndNieces(
  member: FamilyMember,
  allMembers: FamilyMember[]
): FamilyMember[] {
  const siblings = getSiblings(member, allMembers);
  const nephewsAndNieces: FamilyMember[] = [];

  for (const sibling of siblings) {
    nephewsAndNieces.push(...getChildren(sibling, allMembers));
  }

  return nephewsAndNieces;
}

/**
 * Detect relationship between two members
 */
export function detectRelationship(
  member1: FamilyMember,
  member2: FamilyMember,
  allMembers: FamilyMember[]
): Relationship | null {
  // Same person
  if (member1.id === member2.id) {
    return null;
  }

  // Direct parent-child
  if (member2.fatherId === member1.id) {
    return {
      type: member2.gender === 'Male' ? RelationType.SON : RelationType.DAUGHTER,
      relatedMemberId: member2.id,
      relatedMember: member2,
    };
  }

  if (member1.fatherId === member2.id) {
    return {
      type: RelationType.FATHER,
      relatedMemberId: member2.id,
      relatedMember: member2,
      degree: 1,
    };
  }

  // Siblings
  if (member1.fatherId && member1.fatherId === member2.fatherId) {
    return {
      type: member2.gender === 'Male' ? RelationType.BROTHER : RelationType.SISTER,
      relatedMemberId: member2.id,
      relatedMember: member2,
    };
  }

  // Paternal grandfather
  const pgf = getPaternalGrandfather(member1, allMembers);
  if (pgf && pgf.id === member2.id) {
    return {
      type: RelationType.GRANDFATHER,
      relatedMemberId: member2.id,
      relatedMember: member2,
      degree: 2,
    };
  }

  // Paternal uncles
  const uncles = getPaternalUncles(member1, allMembers);
  if (uncles.some((u) => u.id === member2.id)) {
    return {
      type: RelationType.UNCLE,
      relatedMemberId: member2.id,
      relatedMember: member2,
      degree: 1,
    };
  }

  // Paternal aunts
  const aunts = getPaternalAunts(member1, allMembers);
  if (aunts.some((a) => a.id === member2.id)) {
    return {
      type: RelationType.AUNT,
      relatedMemberId: member2.id,
      relatedMember: member2,
      degree: 1,
    };
  }

  // First cousins
  const cousins = getPaternalCousins(member1, allMembers);
  if (cousins.some((c) => c.id === member2.id)) {
    return {
      type: RelationType.COUSIN,
      relatedMemberId: member2.id,
      relatedMember: member2,
      degree: 2,
    };
  }

  // Grandchildren
  const grandchildren = getGrandchildren(member1, allMembers);
  if (grandchildren.some((g) => g.id === member2.id)) {
    const children = getChildren(member1, allMembers);
    const isChild = children.some((c) => c.id === member2.id);
    return {
      type: isChild ? (member2.gender === 'Male' ? RelationType.SON : RelationType.DAUGHTER) :
        (member2.gender === 'Male' ? RelationType.GRANDSON : RelationType.GRANDDAUGHTER),
      relatedMemberId: member2.id,
      relatedMember: member2,
      degree: 2,
    };
  }

  // Nephews and nieces
  const nephewsAndNieces = getNephewsAndNieces(member1, allMembers);
  if (nephewsAndNieces.some((n) => n.id === member2.id)) {
    return {
      type: member2.gender === 'Male' ? RelationType.NEPHEW : RelationType.NIECE,
      relatedMemberId: member2.id,
      relatedMember: member2,
      degree: 1,
    };
  }

  return {
    type: RelationType.UNKNOWN,
    relatedMemberId: member2.id,
    relatedMember: member2,
  };
}

/**
 * Get all relatives of a member
 */
export function getAllRelatives(
  member: FamilyMember,
  allMembers: FamilyMember[]
): Relationship[] {
  const relatives: Relationship[] = [];

  // Father
  const father = getFather(member, allMembers);
  if (father) {
    relatives.push({
      type: RelationType.FATHER,
      relatedMemberId: father.id,
      relatedMember: father,
    });
  }

  // Children
  getChildren(member, allMembers).forEach((child) => {
    relatives.push({
      type: child.gender === 'Male' ? RelationType.SON : RelationType.DAUGHTER,
      relatedMemberId: child.id,
      relatedMember: child,
    });
  });

  // Siblings
  getSiblings(member, allMembers).forEach((sibling) => {
    relatives.push({
      type: sibling.gender === 'Male' ? RelationType.BROTHER : RelationType.SISTER,
      relatedMemberId: sibling.id,
      relatedMember: sibling,
    });
  });

  // Grandchildren
  getGrandchildren(member, allMembers).forEach((gc) => {
    relatives.push({
      type: gc.gender === 'Male' ? RelationType.GRANDSON : RelationType.GRANDDAUGHTER,
      relatedMemberId: gc.id,
      relatedMember: gc,
    });
  });

  // Paternal uncles
  getPaternalUncles(member, allMembers).forEach((uncle) => {
    relatives.push({
      type: RelationType.UNCLE,
      relatedMemberId: uncle.id,
      relatedMember: uncle,
    });
  });

  // Paternal aunts
  getPaternalAunts(member, allMembers).forEach((aunt) => {
    relatives.push({
      type: RelationType.AUNT,
      relatedMemberId: aunt.id,
      relatedMember: aunt,
    });
  });

  // Cousins
  getPaternalCousins(member, allMembers).forEach((cousin) => {
    relatives.push({
      type: RelationType.COUSIN,
      relatedMemberId: cousin.id,
      relatedMember: cousin,
    });
  });

  return relatives;
}

/**
 * Format relationship for display
 */
export function formatRelationship(
  relationship: Relationship,
  locale: 'ar' | 'en' = 'ar'
): string {
  const relationshipNames: Record<RelationType, { ar: string; en: string }> = {
    [RelationType.FATHER]: { ar: 'الأب', en: 'Father' },
    [RelationType.MOTHER]: { ar: 'الأم', en: 'Mother' },
    [RelationType.SON]: { ar: 'الابن', en: 'Son' },
    [RelationType.DAUGHTER]: { ar: 'الابنة', en: 'Daughter' },
    [RelationType.BROTHER]: { ar: 'الأخ', en: 'Brother' },
    [RelationType.SISTER]: { ar: 'الأخت', en: 'Sister' },
    [RelationType.GRANDFATHER]: { ar: 'الجد', en: 'Grandfather' },
    [RelationType.GRANDMOTHER]: { ar: 'الجدة', en: 'Grandmother' },
    [RelationType.GRANDSON]: { ar: 'الحفيد', en: 'Grandson' },
    [RelationType.GRANDDAUGHTER]: { ar: 'الحفيدة', en: 'Granddaughter' },
    [RelationType.UNCLE]: { ar: 'العم', en: 'Uncle' },
    [RelationType.AUNT]: { ar: 'العمة', en: 'Aunt' },
    [RelationType.NEPHEW]: { ar: 'ابن الأخ', en: 'Nephew' },
    [RelationType.NIECE]: { ar: 'بنت الأخ', en: 'Niece' },
    [RelationType.COUSIN]: { ar: 'ابن العم', en: 'Cousin' },
    [RelationType.COUSIN_ONCE_REMOVED]: { ar: 'ابن العم من الدرجة الثانية', en: 'Cousin once removed' },
    [RelationType.SPOUSE]: { ar: 'الزوج/الزوجة', en: 'Spouse' },
    [RelationType.UNKNOWN]: { ar: 'غير معروف', en: 'Unknown' },
  };

  return relationshipNames[relationship.type][locale];
}
