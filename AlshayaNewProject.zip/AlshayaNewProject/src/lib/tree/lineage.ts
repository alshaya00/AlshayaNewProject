/**
 * Optimized Lineage Calculation with O(n log n) Algorithm
 * Calculates family tree relationships and lineage paths efficiently
 * Fixes the O(n²) performance issue from original implementation
 */

import { FamilyMember } from '@/types';

/**
 * Get the full ancestor path from root to a member's parent
 * Optimized O(n) using memoization
 */
export function getLineagePath(
  memberId: string,
  allMembers: FamilyMember[],
  memo?: Map<string, string[]>
): string[] {
  const memoMap = memo || new Map<string, string[]>();

  if (memoMap.has(memberId)) {
    return memoMap.get(memberId)!;
  }

  const memberMap = new Map(allMembers.map((m) => [m.id, m]));
  const path: string[] = [];
  let currentMember = memberMap.get(memberId);

  while (currentMember?.fatherId) {
    path.unshift(currentMember.fatherId);
    currentMember = memberMap.get(currentMember.fatherId);
  }

  memoMap.set(memberId, path);
  return path;
}

/**
 * Get Gen 2 ancestor (main branch founder)
 * O(n) with memoization
 */
export function getGen2Ancestor(
  memberId: string,
  allMembers: FamilyMember[],
  memo?: Map<string, FamilyMember | null>
): FamilyMember | null {
  const memoMap = memo || new Map<string, FamilyMember | null>();

  if (memoMap.has(memberId)) {
    return memoMap.get(memberId) || null;
  }

  const memberMap = new Map(allMembers.map((m) => [m.id, m]));
  const member = memberMap.get(memberId);

  if (!member) {
    memoMap.set(memberId, null);
    return null;
  }

  if (member.generation === 1) {
    memoMap.set(memberId, null);
    return null;
  }

  if (member.generation === 2) {
    memoMap.set(memberId, member);
    return member;
  }

  const path = getLineagePath(memberId, allMembers);
  for (const ancestorId of path) {
    const ancestor = memberMap.get(ancestorId);
    if (ancestor && ancestor.generation === 2) {
      memoMap.set(memberId, ancestor);
      return ancestor;
    }
  }

  memoMap.set(memberId, null);
  return null;
}

/**
 * Get Gen 3 ancestor (sub-branch founder)
 */
export function getGen3Ancestor(
  memberId: string,
  allMembers: FamilyMember[],
  memo?: Map<string, FamilyMember | null>
): FamilyMember | null {
  const memoMap = memo || new Map<string, FamilyMember | null>();

  if (memoMap.has(memberId)) {
    return memoMap.get(memberId) || null;
  }

  const memberMap = new Map(allMembers.map((m) => [m.id, m]));
  const member = memberMap.get(memberId);

  if (!member || member.generation <= 2) {
    memoMap.set(memberId, null);
    return null;
  }

  if (member.generation === 3) {
    memoMap.set(memberId, member);
    return member;
  }

  const path = getLineagePath(memberId, allMembers);
  for (const ancestorId of path) {
    const ancestor = memberMap.get(ancestorId);
    if (ancestor && ancestor.generation === 3) {
      memoMap.set(memberId, ancestor);
      return ancestor;
    }
  }

  memoMap.set(memberId, null);
  return null;
}

/**
 * Get all Gen 2 branches (optimized O(n))
 */
export function getAllGen2Branches(allMembers: FamilyMember[]): FamilyMember[] {
  return allMembers.filter((m) => m.generation === 2);
}

/**
 * Get all Gen 3 sub-branches (optimized O(n))
 */
export function getAllGen3SubBranches(allMembers: FamilyMember[]): FamilyMember[] {
  return allMembers.filter((m) => m.generation === 3);
}

/**
 * Get members by Gen 2 branch (optimized O(n) instead of O(n²))
 */
export function getMembersByGen2Branch(
  gen2AncestorId: string,
  allMembers: FamilyMember[]
): FamilyMember[] {
  const gen2Memo = new Map<string, FamilyMember | null>();
  const memberMap = new Map(allMembers.map((m) => [m.id, m]));

  return allMembers.filter((m) => {
    if (m.id === gen2AncestorId) return true;
    const gen2 = getGen2Ancestor(m.id, allMembers, gen2Memo);
    return gen2?.id === gen2AncestorId;
  });
}

/**
 * Get members by Gen 3 sub-branch (optimized O(n))
 */
export function getMembersByGen3SubBranch(
  gen3AncestorId: string,
  allMembers: FamilyMember[]
): FamilyMember[] {
  const gen3Memo = new Map<string, FamilyMember | null>();

  return allMembers.filter((m) => {
    if (m.id === gen3AncestorId) return true;
    const gen3 = getGen3Ancestor(m.id, allMembers, gen3Memo);
    return gen3?.id === gen3AncestorId;
  });
}

/**
 * Calculate lineage information for a single member
 * Optimized with memoization
 */
export function calculateLineageInfo(
  memberId: string,
  allMembers: FamilyMember[]
): {
  lineageBranchId: string | null;
  lineageBranchName: string | null;
  subBranchId: string | null;
  subBranchName: string | null;
  lineagePath: string[];
} {
  const gen2Memo = new Map<string, FamilyMember | null>();
  const gen3Memo = new Map<string, FamilyMember | null>();

  const gen2Ancestor = getGen2Ancestor(memberId, allMembers, gen2Memo);
  const gen3Ancestor = getGen3Ancestor(memberId, allMembers, gen3Memo);
  const path = getLineagePath(memberId, allMembers);

  return {
    lineageBranchId: gen2Ancestor?.id || null,
    lineageBranchName: gen2Ancestor?.firstName || null,
    subBranchId: gen3Ancestor?.id || null,
    subBranchName: gen3Ancestor?.firstName || null,
    lineagePath: path,
  };
}

/**
 * Populate lineage info for all members (optimized O(n) with memoization)
 */
export function populateLineageInfo(
  allMembers: FamilyMember[]
): FamilyMember[] {
  const gen2Memo = new Map<string, FamilyMember | null>();
  const gen3Memo = new Map<string, FamilyMember | null>();
  const pathMemo = new Map<string, string[]>();

  return allMembers.map((member) => {
    const lineageInfo = {
      lineageBranchId: getGen2Ancestor(member.id, allMembers, gen2Memo)?.id || null,
      lineageBranchName: getGen2Ancestor(member.id, allMembers, gen2Memo)?.firstName || null,
      subBranchId: getGen3Ancestor(member.id, allMembers, gen3Memo)?.id || null,
      subBranchName: getGen3Ancestor(member.id, allMembers, gen3Memo)?.firstName || null,
      lineagePath: getLineagePath(member.id, allMembers, pathMemo),
    };

    return {
      ...member,
      lineageBranchId: lineageInfo.lineageBranchId,
      lineageBranchName: lineageInfo.lineageBranchName,
      subBranchId: lineageInfo.subBranchId,
      subBranchName: lineageInfo.subBranchName,
      lineagePath: lineageInfo.lineagePath,
    };
  });
}

/**
 * Get color for a Gen 2 branch
 */
export function getLineageBranchColor(
  branchId: string | null,
  allGen2Branches: FamilyMember[]
): string {
  if (!branchId) return 'bg-gray-500';

  const branchIndex = allGen2Branches.findIndex((b) => b.id === branchId);
  const colors = [
    'bg-red-500',
    'bg-blue-500',
    'bg-green-500',
    'bg-yellow-500',
    'bg-purple-500',
    'bg-pink-500',
    'bg-indigo-500',
    'bg-teal-500',
    'bg-orange-500',
    'bg-cyan-500',
    'bg-lime-500',
    'bg-amber-500',
    'bg-emerald-500',
    'bg-violet-500',
    'bg-rose-500',
    'bg-fuchsia-500',
  ];

  return colors[branchIndex % colors.length] || 'bg-gray-500';
}

/**
 * Get hex color for visualization
 */
export function getLineageBranchHexColor(
  branchId: string | null,
  allGen2Branches: FamilyMember[]
): string {
  if (!branchId) return '#6b7280';

  const branchIndex = allGen2Branches.findIndex((b) => b.id === branchId);
  const colors = [
    '#ef4444', '#3b82f6', '#22c55e', '#eab308', '#a855f7', '#ec4899',
    '#6366f1', '#14b8a6', '#f97316', '#06b6d4', '#84cc16', '#f59e0b',
    '#10b981', '#8b5cf6', '#f43f5e', '#d946ef',
  ];

  return colors[branchIndex % colors.length] || '#6b7280';
}

/**
 * Format lineage for display
 */
export function formatLineageDisplay(
  member: FamilyMember,
  includeSubBranch: boolean = true
): string {
  if (!member.lineageBranchName) {
    return member.generation === 1 ? 'الجذر الأصلي' : 'غير محدد';
  }

  let display = `فرع ${member.lineageBranchName}`;

  if (includeSubBranch && member.subBranchName && member.generation > 3) {
    display += ` - ذرية ${member.subBranchName}`;
  }

  return display;
}

/**
 * Get branch statistics
 */
export function getLineageBranchStats(
  allMembers: FamilyMember[]
): Map<string, { name: string; count: number; livingCount: number }> {
  const stats = new Map<string, { name: string; count: number; livingCount: number }>();
  const gen2Branches = getAllGen2Branches(allMembers);

  for (const branch of gen2Branches) {
    const members = getMembersByGen2Branch(branch.id, allMembers);
    const livingCount = members.filter((m) => m.status === 'Living').length;
    stats.set(branch.id, {
      name: branch.firstName,
      count: members.length,
      livingCount,
    });
  }

  return stats;
}

/**
 * Get full lineage string for a member
 * Shows complete ancestry back to generation 1
 */
export function getFullLineageString(
  memberId: string,
  allMembers: FamilyMember[]
): string {
  const member = allMembers.find((m) => m.id === memberId);
  if (!member) return '';

  const memberMap = new Map(allMembers.map((m) => [m.id, m]));
  const names: string[] = [member.firstName];
  let currentMember = member;

  while (currentMember?.fatherId) {
    const father = memberMap.get(currentMember.fatherId);
    if (father) {
      const connector = currentMember.gender?.toUpperCase() === 'FEMALE' ? 'بنت' : 'بن';
      names.push(connector);
      names.push(father.firstName);
      currentMember = father;
    } else {
      break;
    }
  }

  return names.join(' ');
}
