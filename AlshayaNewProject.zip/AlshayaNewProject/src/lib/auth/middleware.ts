/**
 * Authentication Middleware for API Routes
 * Verifies session, validates CSRF, and checks permissions
 */

import { validateSession } from './session';
import { validateApiCsrf, extractCsrfToken } from './csrf';
import { SessionUser, PermissionKey } from '@/types/auth';

/**
 * Authenticated request context
 */
export interface AuthContext {
  user: SessionUser;
  sessionToken: string;
  isAuthenticated: boolean;
  userAgent?: string;
  ipAddress?: string;
}

/**
 * Middleware error response
 */
export interface MiddlewareError {
  code: string;
  message: string;
  statusCode: number;
  details?: Record<string, unknown>;
}

/**
 * Check if user has required permission
 */
export function userHasPermission(
  user: SessionUser | null,
  permission: PermissionKey
): boolean {
  if (!user) return false;

  // SUPER_ADMIN has all permissions
  if (user.role === 'SUPER_ADMIN') return true;

  // Check if user has the permission
  return user.permissions?.[permission] ?? false;
}

/**
 * Check if user can act on a specific branch
 */
export function userCanActOnBranch(
  user: SessionUser | null,
  targetBranch: string | null | undefined,
  permission: PermissionKey
): boolean {
  if (!user) return false;

  // First check base permission
  if (!userHasPermission(user, permission)) {
    return false;
  }

  // Super admin and admin can act on any branch
  if (user.role === 'SUPER_ADMIN' || user.role === 'ADMIN') {
    return true;
  }

  // Branch leader can only act on their assigned branch
  if (user.role === 'BRANCH_LEADER') {
    return targetBranch !== null && user.assignedBranch === targetBranch;
  }

  return true;
}

/**
 * Verify session from request
 */
export async function verifySessionFromRequest(request: {
  cookies?: Record<string, string>;
  headers?: Record<string, string | string[] | undefined>;
}): Promise<{ valid: boolean; user?: SessionUser; error?: MiddlewareError }> {
  // Get session token from cookie or header
  const token =
    request.cookies?.alshaya_session ||
    (request.headers?.authorization?.startsWith('Bearer ')
      ? request.headers.authorization.slice(7)
      : null);

  if (!token) {
    return {
      valid: false,
      error: {
        code: 'MISSING_SESSION',
        message: 'No session token found',
        statusCode: 401,
      },
    };
  }

  const session = await validateSession(token);
  if (!session) {
    return {
      valid: false,
      error: {
        code: 'INVALID_SESSION',
        message: 'Session is invalid or expired',
        statusCode: 401,
      },
    };
  }

  return { valid: true, user: session.user };
}

/**
 * Verify CSRF token from request
 */
export async function verifyCsrfFromRequest(request: {
  headers?: Record<string, string | string[] | undefined>;
  body?: Record<string, unknown>;
  cookies?: Record<string, string>;
  method?: string;
}): Promise<{ valid: boolean; error?: MiddlewareError }> {
  // Skip for GET requests
  if (request.method === 'GET') {
    return { valid: true };
  }

  const token = extractCsrfToken(request);
  if (!token) {
    return {
      valid: false,
      error: {
        code: 'MISSING_CSRF',
        message: 'CSRF token is missing',
        statusCode: 403,
      },
    };
  }

  const isValid = await validateApiCsrf(request);
  if (!isValid.valid) {
    return {
      valid: false,
      error: {
        code: 'INVALID_CSRF',
        message: isValid.error || 'CSRF token is invalid',
        statusCode: 403,
      },
    };
  }

  return { valid: true };
}

/**
 * Complete authentication middleware
 * Validates session, CSRF, and user status
 */
export async function authenticateRequest(
  request: {
    cookies?: Record<string, string>;
    headers?: Record<string, string | string[] | undefined>;
    body?: Record<string, unknown>;
    method?: string;
  },
  options?: {
    requireCsrf?: boolean;
    requireRole?: SessionUser['role'];
    requirePermission?: PermissionKey;
  }
): Promise<{ valid: boolean; context?: AuthContext; error?: MiddlewareError }> {
  // Step 1: Verify session
  const sessionResult = await verifySessionFromRequest(request);
  if (!sessionResult.valid || !sessionResult.user) {
    return { valid: false, error: sessionResult.error };
  }

  // Step 2: Verify CSRF (if required)
  if (options?.requireCsrf !== false && request.method !== 'GET') {
    const csrfResult = await verifyCsrfFromRequest(request);
    if (!csrfResult.valid) {
      return { valid: false, error: csrfResult.error };
    }
  }

  const user = sessionResult.user;

  // Step 3: Check role requirement
  if (options?.requireRole) {
    const roleHierarchy: Record<SessionUser['role'], number> = {
      SUPER_ADMIN: 4,
      ADMIN: 3,
      BRANCH_LEADER: 2,
      MEMBER: 1,
      GUEST: 0,
    };

    const userLevel = roleHierarchy[user.role] || 0;
    const requiredLevel = roleHierarchy[options.requireRole] || 0;

    if (userLevel < requiredLevel) {
      return {
        valid: false,
        error: {
          code: 'INSUFFICIENT_ROLE',
          message: `This action requires ${options.requireRole} role or higher`,
          statusCode: 403,
        },
      };
    }
  }

  // Step 4: Check permission requirement
  if (options?.requirePermission) {
    if (!userHasPermission(user, options.requirePermission)) {
      return {
        valid: false,
        error: {
          code: 'PERMISSION_DENIED',
          message: `Permission '${options.requirePermission}' is required`,
          statusCode: 403,
        },
      };
    }
  }

  // All checks passed
  return {
    valid: true,
    context: {
      user,
      sessionToken: request.cookies?.alshaya_session || '',
      isAuthenticated: true,
      userAgent: Array.isArray(request.headers?.['user-agent'])
        ? request.headers['user-agent'][0]
        : (request.headers?.['user-agent'] as string | undefined),
      ipAddress: Array.isArray(request.headers?.['x-forwarded-for'])
        ? request.headers['x-forwarded-for'][0]
        : (request.headers?.['x-forwarded-for'] as string | undefined),
    },
  };
}

/**
 * Format auth error for response
 */
export function formatAuthError(error: MiddlewareError): {
  status: number;
  body: Record<string, unknown>;
} {
  return {
    status: error.statusCode,
    body: {
      error: error.code,
      message: error.message,
      ...(error.details && { details: error.details }),
    },
  };
}

/**
 * Create auth response headers
 */
export function createAuthHeaders(context?: AuthContext): Record<string, string> {
  return {
    'X-User-ID': context?.user?.id || '',
    'X-User-Role': context?.user?.role || '',
    ...(context?.sessionToken && { 'X-Session-Token': context.sessionToken }),
  };
}
