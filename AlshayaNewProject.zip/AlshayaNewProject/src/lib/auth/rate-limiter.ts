/**
 * Rate Limiter with Exponential Backoff
 * Protects against brute force attacks on login, API endpoints, and OTP endpoints
 * Uses in-memory store with Redis option for distributed systems
 */

/**
 * Rate limit configuration per endpoint
 */
export const RATE_LIMIT_CONFIG = {
  login: {
    maxAttempts: 5,
    windowMs: 15 * 60 * 1000, // 15 minutes
    backoffMs: 60 * 1000, // 1 minute exponential backoff
    backoffMultiplier: 2,
  },
  otpVerification: {
    maxAttempts: 3,
    windowMs: 10 * 60 * 1000, // 10 minutes
    backoffMs: 30 * 1000, // 30 seconds
    backoffMultiplier: 2,
  },
  passwordReset: {
    maxAttempts: 3,
    windowMs: 60 * 60 * 1000, // 1 hour
    backoffMs: 5 * 60 * 1000, // 5 minutes
    backoffMultiplier: 2,
  },
  apiEndpoint: {
    maxAttempts: 100,
    windowMs: 60 * 1000, // 1 minute
    backoffMs: 10 * 1000, // 10 seconds
    backoffMultiplier: 1.5,
  },
  registration: {
    maxAttempts: 5,
    windowMs: 60 * 60 * 1000, // 1 hour
    backoffMs: 10 * 60 * 1000, // 10 minutes
    backoffMultiplier: 2,
  },
};

/**
 * Attempt record for tracking failed attempts
 */
interface AttemptRecord {
  count: number;
  firstAttemptTime: number;
  lastAttemptTime: number;
  blockedUntil?: number;
}

/**
 * In-memory store for rate limiting
 * In production, use Redis or similar distributed store
 */
class RateLimiter {
  private attempts: Map<string, AttemptRecord> = new Map();
  private cleanupInterval: NodeJS.Timer | null = null;

  constructor() {
    // Clean up old records every 5 minutes
    if (typeof global !== 'undefined') {
      this.cleanupInterval = setInterval(() => {
        this.cleanup();
      }, 5 * 60 * 1000);
    }
  }

  /**
   * Record an attempt for an identifier
   */
  recordAttempt(
    identifier: string,
    config: typeof RATE_LIMIT_CONFIG['login']
  ): {
    allowed: boolean;
    remaining: number;
    retryAfter?: number;
    blockedUntil?: number;
  } {
    const now = Date.now();
    const record = this.attempts.get(identifier) || {
      count: 0,
      firstAttemptTime: now,
      lastAttemptTime: now,
    };

    // Check if currently blocked
    if (record.blockedUntil && record.blockedUntil > now) {
      const retryAfter = Math.ceil((record.blockedUntil - now) / 1000);
      return {
        allowed: false,
        remaining: 0,
        retryAfter,
        blockedUntil: record.blockedUntil,
      };
    }

    // Clear if outside time window
    if (record.firstAttemptTime + config.windowMs < now) {
      record.count = 0;
      record.firstAttemptTime = now;
    }

    // Increment counter
    record.count++;
    record.lastAttemptTime = now;

    // Calculate exponential backoff
    if (record.count > config.maxAttempts) {
      const blockDuration =
        config.backoffMs *
        Math.pow(config.backoffMultiplier, record.count - config.maxAttempts - 1);
      record.blockedUntil = now + blockDuration;

      this.attempts.set(identifier, record);

      return {
        allowed: false,
        remaining: 0,
        retryAfter: Math.ceil(blockDuration / 1000),
        blockedUntil: record.blockedUntil,
      };
    }

    this.attempts.set(identifier, record);

    return {
      allowed: true,
      remaining: config.maxAttempts - record.count,
    };
  }

  /**
   * Reset attempts for an identifier (after successful authentication)
   */
  reset(identifier: string): void {
    this.attempts.delete(identifier);
  }

  /**
   * Get current attempt info
   */
  getInfo(identifier: string): Omit<AttemptRecord, 'firstAttemptTime'> | null {
    const record = this.attempts.get(identifier);
    if (!record) return null;

    return {
      count: record.count,
      lastAttemptTime: record.lastAttemptTime,
      blockedUntil: record.blockedUntil,
    };
  }

  /**
   * Clean up old records
   */
  private cleanup(): void {
    const now = Date.now();
    const maxAge = 24 * 60 * 60 * 1000; // 24 hours

    for (const [key, record] of this.attempts.entries()) {
      if (record.lastAttemptTime + maxAge < now) {
        this.attempts.delete(key);
      }
    }
  }

  /**
   * Clear all records
   */
  clear(): void {
    this.attempts.clear();
  }

  /**
   * Destroy and cleanup
   */
  destroy(): void {
    if (this.cleanupInterval) {
      clearInterval(this.cleanupInterval);
    }
    this.clear();
  }
}

// Global rate limiter instance
let rateLimiter: RateLimiter | null = null;

/**
 * Get or create global rate limiter
 */
function getRateLimiter(): RateLimiter {
  if (!rateLimiter) {
    rateLimiter = new RateLimiter();
  }
  return rateLimiter;
}

/**
 * Check if an identifier is allowed to make an attempt
 */
export function checkRateLimit(
  identifier: string,
  limitType: keyof typeof RATE_LIMIT_CONFIG
): ReturnType<RateLimiter['recordAttempt']> {
  const config = RATE_LIMIT_CONFIG[limitType];
  return getRateLimiter().recordAttempt(identifier, config);
}

/**
 * Reset rate limit for an identifier
 */
export function resetRateLimit(identifier: string): void {
  getRateLimiter().reset(identifier);
}

/**
 * Get rate limit info for debugging
 */
export function getRateLimitInfo(identifier: string): {
  count: number;
  lastAttemptTime: Date | null;
  blockedUntil: Date | null;
} | null {
  const info = getRateLimiter().getInfo(identifier);
  if (!info) return null;

  return {
    count: info.count,
    lastAttemptTime: info.lastAttemptTime ? new Date(info.lastAttemptTime) : null,
    blockedUntil: info.blockedUntil ? new Date(info.blockedUntil) : null,
  };
}

/**
 * Clear all rate limits
 */
export function clearAllRateLimits(): void {
  getRateLimiter().clear();
}

/**
 * Cleanup rate limiter on process exit
 */
if (typeof process !== 'undefined') {
  process.on('exit', () => {
    rateLimiter?.destroy();
  });
}

/**
 * Create a rate limit response for API
 */
export function createRateLimitResponse(result: ReturnType<typeof checkRateLimit>) {
  return {
    headers: {
      'X-RateLimit-Remaining': result.remaining.toString(),
      ...(result.retryAfter && { 'Retry-After': result.retryAfter.toString() }),
    },
    body: result.allowed ? null : {
      error: 'Too many attempts. Please try again later.',
      retryAfter: result.retryAfter,
      blockedUntil: result.blockedUntil ? new Date(result.blockedUntil) : null,
    },
  };
}

/**
 * Format rate limit error message
 */
export function formatRateLimitError(
  result: ReturnType<typeof checkRateLimit>,
  locale: 'ar' | 'en' = 'ar'
): string {
  if (!result.retryAfter) return '';

  const minutes = Math.ceil(result.retryAfter / 60);

  if (locale === 'ar') {
    return `تم تجاوز محاولات متعددة. يرجى المحاولة مرة أخرى بعد ${minutes} دقيقة.`;
  }

  return `Too many attempts. Please try again in ${minutes} minute${minutes > 1 ? 's' : ''}.`;
}
