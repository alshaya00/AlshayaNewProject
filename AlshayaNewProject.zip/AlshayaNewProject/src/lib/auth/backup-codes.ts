/**
 * Encrypted Backup Codes Generation and Verification
 * For account recovery when 2FA device is lost
 * Stores backup codes encrypted in database
 */

import { randomBytes, createHash } from 'crypto';
import { encrypt, decrypt } from '@/lib/utils/encryption';

/**
 * Backup code configuration
 */
export const BACKUP_CODE_CONFIG = {
  count: 10,
  length: 8,
  format: 'XXXX-XXXX', // Display format
  expiresAfterUse: false, // All codes can be used multiple times
};

/**
 * Generate a single backup code
 */
export function generateBackupCode(): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  const bytes = randomBytes(BACKUP_CODE_CONFIG.length);
  let code = '';

  for (let i = 0; i < BACKUP_CODE_CONFIG.length; i++) {
    code += chars[bytes[i] % chars.length];
  }

  return code;
}

/**
 * Generate a batch of backup codes
 */
export function generateBackupCodeBatch(
  count: number = BACKUP_CODE_CONFIG.count
): string[] {
  const codes: string[] = [];

  for (let i = 0; i < count; i++) {
    codes.push(generateBackupCode());
  }

  return codes;
}

/**
 * Format a backup code for display
 */
export function formatBackupCode(code: string): string {
  const cleaned = code.replace(/[-\s]/g, '').toUpperCase();
  return `${cleaned.substring(0, 4)}-${cleaned.substring(4, 8)}`;
}

/**
 * Normalize a backup code for comparison
 */
export function normalizeBackupCode(code: string): string {
  return code.replace(/[-\s]/g, '').toUpperCase();
}

/**
 * Hash a backup code for secure storage
 */
export function hashBackupCode(code: string): string {
  const normalized = normalizeBackupCode(code);
  return createHash('sha256').update(normalized).digest('hex');
}

/**
 * Validate backup code format
 */
export function isValidBackupCodeFormat(code: string): boolean {
  const normalized = normalizeBackupCode(code);
  return /^[A-Z0-9]{8}$/.test(normalized);
}

/**
 * Encrypt backup codes for storage
 */
export function encryptBackupCodes(codes: string[]): {
  encrypted: string;
  hashes: string[];
} {
  const codesJson = JSON.stringify(codes);
  const encrypted = encrypt(codesJson);

  // Also store hashes for faster lookup without decryption
  const hashes = codes.map(hashBackupCode);

  return { encrypted, hashes };
}

/**
 * Decrypt backup codes from storage
 */
export function decryptBackupCodes(encrypted: string): string[] {
  try {
    const codesJson = decrypt(encrypted);
    const codes = JSON.parse(codesJson);

    if (!Array.isArray(codes)) {
      throw new Error('Invalid backup codes format');
    }

    return codes;
  } catch (error) {
    console.error('[BackupCodes] Error decrypting codes:', error);
    throw new Error('Failed to decrypt backup codes');
  }
}

/**
 * Verify a backup code against encrypted storage
 */
export function verifyBackupCode(
  code: string,
  encrypted: string
): boolean {
  if (!isValidBackupCodeFormat(code)) {
    return false;
  }

  try {
    const codes = decryptBackupCodes(encrypted);
    const normalized = normalizeBackupCode(code);

    return codes.some((stored) => normalizeBackupCode(stored) === normalized);
  } catch (error) {
    console.error('[BackupCodes] Error verifying code:', error);
    return false;
  }
}

/**
 * Use a backup code (remove it from the list)
 */
export function useBackupCode(
  code: string,
  encrypted: string
): { success: boolean; remaining: number; newEncrypted?: string } {
  if (!isValidBackupCodeFormat(code)) {
    return { success: false, remaining: 0 };
  }

  try {
    const codes = decryptBackupCodes(encrypted);
    const normalized = normalizeBackupCode(code);

    const index = codes.findIndex((stored) => normalizeBackupCode(stored) === normalized);

    if (index === -1) {
      return { success: false, remaining: codes.length };
    }

    // Remove the used code
    codes.splice(index, 1);

    if (codes.length === 0) {
      return { success: true, remaining: 0 };
    }

    // Re-encrypt the remaining codes
    const { encrypted: newEncrypted } = encryptBackupCodes(codes);

    return { success: true, remaining: codes.length, newEncrypted };
  } catch (error) {
    console.error('[BackupCodes] Error using backup code:', error);
    return { success: false, remaining: 0 };
  }
}

/**
 * Count remaining backup codes
 */
export function countBackupCodes(encrypted: string): number {
  try {
    const codes = decryptBackupCodes(encrypted);
    return codes.length;
  } catch (error) {
    console.error('[BackupCodes] Error counting codes:', error);
    return 0;
  }
}

/**
 * Regenerate all backup codes
 */
export function regenerateBackupCodes(): {
  codes: string[];
  encrypted: string;
  hashes: string[];
} {
  const codes = generateBackupCodeBatch(BACKUP_CODE_CONFIG.count);
  const { encrypted, hashes } = encryptBackupCodes(codes);

  return { codes, encrypted, hashes };
}

/**
 * Export backup codes for user download
 * Returns formatted string for printing/saving
 */
export function exportBackupCodes(codes: string[]): string {
  const timestamp = new Date().toISOString().split('T')[0];
  const lines = [
    'AL-SHAYA FAMILY TREE - BACKUP CODES',
    `Generated: ${timestamp}`,
    'Keep these codes in a safe place. Each code can only be used once.',
    '',
    'HOW TO USE:',
    '1. If you lose access to your authenticator app',
    '2. Use one of the codes below to regain access to your account',
    '3. Each code can only be used once',
    '',
    'BACKUP CODES:',
    ...codes.map((code, i) => `${(i + 1).toString().padStart(2, '0')}. ${formatBackupCode(code)}`),
    '',
    'SECURITY NOTE:',
    'If any of these codes were exposed or you used them,',
    'regenerate new codes immediately from account settings.',
  ];

  return lines.join('\n');
}

/**
 * Backup codes response structure
 */
export interface BackupCodesResponse {
  codes: string[];
  encrypted: string;
  hashes: string[];
  remaining: number;
  exportText: string;
}

/**
 * Create backup codes for a user
 */
export async function createBackupCodes(): Promise<BackupCodesResponse> {
  const codes = generateBackupCodeBatch(BACKUP_CODE_CONFIG.count);
  const { encrypted, hashes } = encryptBackupCodes(codes);
  const exportText = exportBackupCodes(codes);

  return {
    codes,
    encrypted,
    hashes,
    remaining: codes.length,
    exportText,
  };
}
