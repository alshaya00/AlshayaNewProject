/**
 * Server-Side Session Management for Authentication
 * Uses HttpOnly cookies with secure flags (NOT localStorage)
 * Provides session validation, refresh, and cleanup utilities
 */

import { prisma } from '@/lib/db/prisma';
import { generateSessionToken } from './password';
import { getSessionUser, SessionUser } from '@/types/auth';

// Session cookie configuration
export const SESSION_CONFIG = {
  name: 'alshaya_session',
  maxAge: 7 * 24 * 60 * 60, // 7 days in seconds
  secure: process.env.NODE_ENV === 'production',
  httpOnly: true,
  sameSite: 'lax' as const,
  domain: process.env.COOKIE_DOMAIN || undefined,
  path: '/',
};

export const REMEMBER_ME_CONFIG = {
  name: 'alshaya_remember',
  maxAge: 30 * 24 * 60 * 60, // 30 days in seconds
  secure: process.env.NODE_ENV === 'production',
  httpOnly: true,
  sameSite: 'lax' as const,
  domain: process.env.COOKIE_DOMAIN || undefined,
  path: '/',
};

/**
 * Session data structure stored in database and cookie
 */
export interface StoredSession {
  token: string;
  userId: string;
  expiresAt: Date;
  createdAt: Date;
  userAgent?: string;
  ipAddress?: string;
  lastActivityAt: Date;
}

/**
 * Create a new session for a user
 */
export async function createSession(
  userId: string,
  options?: {
    userAgent?: string;
    ipAddress?: string;
    rememberMe?: boolean;
  }
): Promise<StoredSession> {
  const token = generateSessionToken();
  const now = new Date();

  // Use remember me duration if specified, otherwise use default
  const durationMs = options?.rememberMe
    ? REMEMBER_ME_CONFIG.maxAge * 1000
    : SESSION_CONFIG.maxAge * 1000;

  const expiresAt = new Date(now.getTime() + durationMs);

  const session = await prisma.session.create({
    data: {
      token,
      userId,
      expiresAt,
      userAgent: options?.userAgent,
      ipAddress: options?.ipAddress,
      lastActivityAt: now,
    },
  });

  return {
    token: session.token,
    userId: session.userId,
    expiresAt: session.expiresAt,
    createdAt: session.createdAt,
    userAgent: session.userAgent || undefined,
    ipAddress: session.ipAddress || undefined,
    lastActivityAt: session.lastActivityAt,
  };
}

/**
 * Retrieve a session by token
 */
export async function getSession(token: string): Promise<StoredSession | null> {
  if (!token) return null;

  try {
    const session = await prisma.session.findUnique({
      where: { token },
    });

    if (!session) return null;

    // Check if session is expired
    if (session.expiresAt < new Date()) {
      await prisma.session.delete({ where: { token } });
      return null;
    }

    // Update last activity
    await prisma.session.update({
      where: { token },
      data: { lastActivityAt: new Date() },
    });

    return {
      token: session.token,
      userId: session.userId,
      expiresAt: session.expiresAt,
      createdAt: session.createdAt,
      userAgent: session.userAgent || undefined,
      ipAddress: session.ipAddress || undefined,
      lastActivityAt: session.lastActivityAt,
    };
  } catch (error) {
    console.error('[Session] Error retrieving session:', error);
    return null;
  }
}

/**
 * Validate a session and get user information
 */
export async function validateSession(
  token: string
): Promise<{ user: SessionUser; session: StoredSession } | null> {
  if (!token) return null;

  try {
    const session = await getSession(token);
    if (!session) return null;

    const user = await getSessionUser(session.userId);
    if (!user) {
      // Session exists but user doesn't - clean up
      await prisma.session.delete({ where: { token } });
      return null;
    }

    // Check if user is active
    if (user.status !== 'ACTIVE') {
      return null;
    }

    return { user, session };
  } catch (error) {
    console.error('[Session] Error validating session:', error);
    return null;
  }
}

/**
 * Refresh a session (extend expiration)
 */
export async function refreshSession(token: string): Promise<StoredSession | null> {
  if (!token) return null;

  try {
    const session = await prisma.session.findUnique({
      where: { token },
    });

    if (!session) return null;

    const durationMs = SESSION_CONFIG.maxAge * 1000;
    const expiresAt = new Date(Date.now() + durationMs);

    const updated = await prisma.session.update({
      where: { token },
      data: {
        expiresAt,
        lastActivityAt: new Date(),
      },
    });

    return {
      token: updated.token,
      userId: updated.userId,
      expiresAt: updated.expiresAt,
      createdAt: updated.createdAt,
      userAgent: updated.userAgent || undefined,
      ipAddress: updated.ipAddress || undefined,
      lastActivityAt: updated.lastActivityAt,
    };
  } catch (error) {
    console.error('[Session] Error refreshing session:', error);
    return null;
  }
}

/**
 * Delete a session (logout)
 */
export async function deleteSession(token: string): Promise<boolean> {
  if (!token) return false;

  try {
    await prisma.session.delete({
      where: { token },
    });
    return true;
  } catch (error) {
    console.error('[Session] Error deleting session:', error);
    return false;
  }
}

/**
 * Delete all sessions for a user
 */
export async function deleteAllUserSessions(userId: string): Promise<number> {
  try {
    const result = await prisma.session.deleteMany({
      where: { userId },
    });
    return result.count;
  } catch (error) {
    console.error('[Session] Error deleting user sessions:', error);
    return 0;
  }
}

/**
 * Clean up expired sessions
 */
export async function cleanupExpiredSessions(): Promise<number> {
  try {
    const result = await prisma.session.deleteMany({
      where: {
        expiresAt: { lt: new Date() },
      },
    });
    return result.count;
  } catch (error) {
    console.error('[Session] Error cleaning up expired sessions:', error);
    return 0;
  }
}

/**
 * Get all active sessions for a user
 */
export async function getUserActiveSessions(userId: string): Promise<StoredSession[]> {
  try {
    const sessions = await prisma.session.findMany({
      where: {
        userId,
        expiresAt: { gt: new Date() },
      },
      orderBy: { createdAt: 'desc' },
    });

    return sessions.map((session) => ({
      token: session.token,
      userId: session.userId,
      expiresAt: session.expiresAt,
      createdAt: session.createdAt,
      userAgent: session.userAgent || undefined,
      ipAddress: session.ipAddress || undefined,
      lastActivityAt: session.lastActivityAt,
    }));
  } catch (error) {
    console.error('[Session] Error getting user sessions:', error);
    return [];
  }
}

/**
 * Check if a session is valid and not expired
 */
export function isSessionValid(expiresAt: Date): boolean {
  return expiresAt > new Date();
}

/**
 * Format session expiry for display
 */
export function formatSessionExpiry(expiresAt: Date, locale: 'ar' | 'en' = 'ar'): string {
  const now = new Date();
  const diff = expiresAt.getTime() - now.getTime();

  if (diff <= 0) {
    return locale === 'ar' ? 'منتهية الصلاحية' : 'Expired';
  }

  const days = Math.floor(diff / (1000 * 60 * 60 * 24));
  const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));

  if (locale === 'ar') {
    if (days > 0) {
      return `${days} يوم و ${hours} ساعة`;
    }
    if (hours > 0) {
      return `${hours} ساعة و ${minutes} دقيقة`;
    }
    return `${minutes} دقيقة`;
  }

  if (days > 0) {
    return `${days} day${days > 1 ? 's' : ''} and ${hours} hour${hours > 1 ? 's' : ''}`;
  }
  if (hours > 0) {
    return `${hours} hour${hours > 1 ? 's' : ''} and ${minutes} minute${minutes > 1 ? 's' : ''}`;
  }
  return `${minutes} minute${minutes > 1 ? 's' : ''}`;
}

/**
 * Get session duration percentage for progress indicators
 */
export function getSessionDurationPercent(
  createdAt: Date,
  expiresAt: Date
): number {
  const totalDuration = expiresAt.getTime() - createdAt.getTime();
  const elapsed = Date.now() - createdAt.getTime();
  return Math.min(100, Math.max(0, (elapsed / totalDuration) * 100));
}
