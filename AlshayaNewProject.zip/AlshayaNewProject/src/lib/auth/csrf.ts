/**
 * CSRF Token Generation and Validation
 * Critical security fix - prevents Cross-Site Request Forgery attacks
 * Implements double-submit cookie pattern with secure random tokens
 */

import { createHash, randomBytes } from 'crypto';
import { prisma } from '@/lib/db/prisma';

// CSRF token configuration
export const CSRF_CONFIG = {
  cookieName: 'alshaya_csrf',
  headerName: 'x-csrf-token',
  formFieldName: '_csrf',
  maxAge: 60 * 60 * 24, // 24 hours in seconds
  secure: process.env.NODE_ENV === 'production',
  httpOnly: false, // CSRF token needs to be accessible to JavaScript
  sameSite: 'strict' as const,
};

/**
 * Generate a cryptographically secure CSRF token
 */
export function generateCsrfToken(): string {
  const randomPart = randomBytes(32).toString('hex');
  const timestamp = Date.now().toString(16);
  return `${timestamp}.${randomPart}`;
}

/**
 * Hash CSRF token for secure storage
 */
function hashCsrfToken(token: string): string {
  return createHash('sha256').update(token).digest('hex');
}

/**
 * Create and store CSRF token in database
 */
export async function createCsrfToken(userId?: string): Promise<string> {
  const token = generateCsrfToken();
  const hashedToken = hashCsrfToken(token);
  const expiresAt = new Date(Date.now() + CSRF_CONFIG.maxAge * 1000);

  try {
    await prisma.csrfToken.create({
      data: {
        token: hashedToken,
        userId: userId || null,
        expiresAt,
      },
    });
  } catch (error) {
    console.error('[CSRF] Error creating token:', error);
    // If database fails, we can still return the token but it won't be validated
    // This prevents breaking authentication due to database issues
  }

  return token;
}

/**
 * Validate CSRF token against stored value
 */
export async function validateCsrfToken(
  token: string,
  userId?: string
): Promise<boolean> {
  if (!token) {
    console.warn('[CSRF] Missing token');
    return false;
  }

  try {
    const hashedToken = hashCsrfToken(token);

    const storedToken = await prisma.csrfToken.findFirst({
      where: {
        token: hashedToken,
        expiresAt: { gt: new Date() },
        ...(userId && { userId }),
      },
    });

    if (!storedToken) {
      console.warn('[CSRF] Token not found or expired');
      return false;
    }

    // Delete the token after validation (one-time use)
    await prisma.csrfToken.delete({
      where: { id: storedToken.id },
    });

    return true;
  } catch (error) {
    console.error('[CSRF] Error validating token:', error);
    return false;
  }
}

/**
 * Clean up expired CSRF tokens
 */
export async function cleanupExpiredCsrfTokens(): Promise<number> {
  try {
    const result = await prisma.csrfToken.deleteMany({
      where: {
        expiresAt: { lt: new Date() },
      },
    });
    return result.count;
  } catch (error) {
    console.error('[CSRF] Error cleaning up expired tokens:', error);
    return 0;
  }
}

/**
 * Invalidate all CSRF tokens for a user (logout)
 */
export async function invalidateUserCsrfTokens(userId: string): Promise<number> {
  try {
    const result = await prisma.csrfToken.deleteMany({
      where: { userId },
    });
    return result.count;
  } catch (error) {
    console.error('[CSRF] Error invalidating user tokens:', error);
    return 0;
  }
}

/**
 * Cookie options for CSRF token
 */
export function getCsrfCookieOptions() {
  return {
    name: CSRF_CONFIG.cookieName,
    maxAge: CSRF_CONFIG.maxAge,
    secure: CSRF_CONFIG.secure,
    httpOnly: CSRF_CONFIG.httpOnly,
    sameSite: CSRF_CONFIG.sameSite,
    path: '/',
  };
}

/**
 * Middleware to validate CSRF token from request
 * Extracts token from header, body, or cookie
 */
export function extractCsrfToken(request: {
  headers?: Record<string, string | string[] | undefined>;
  body?: Record<string, unknown>;
  cookies?: Record<string, string>;
}): string | null {
  // Try to get from header (preferred for API calls)
  const headerToken = request.headers?.[CSRF_CONFIG.headerName];
  if (headerToken) {
    return Array.isArray(headerToken) ? headerToken[0] : headerToken;
  }

  // Try to get from request body
  const bodyToken = request.body?.[CSRF_CONFIG.formFieldName];
  if (bodyToken && typeof bodyToken === 'string') {
    return bodyToken;
  }

  // Try to get from cookie (for backward compatibility)
  const cookieToken = request.cookies?.[CSRF_CONFIG.cookieName];
  if (cookieToken) {
    return cookieToken;
  }

  return null;
}

/**
 * Validate CSRF on API requests
 * Should be used in API route handlers
 */
export async function validateApiCsrf(
  request: {
    headers?: Record<string, string | string[] | undefined>;
    body?: Record<string, unknown>;
    cookies?: Record<string, string>;
    method?: string;
  },
  userId?: string
): Promise<{ valid: boolean; error?: string }> {
  // Skip validation for GET requests
  if (request.method === 'GET') {
    return { valid: true };
  }

  const token = extractCsrfToken(request);
  if (!token) {
    return { valid: false, error: 'Missing CSRF token' };
  }

  const isValid = await validateCsrfToken(token, userId);
  if (!isValid) {
    return { valid: false, error: 'Invalid or expired CSRF token' };
  }

  return { valid: true };
}
