/**
 * Password Hashing, Validation, and Token Generation
 * Uses bcrypt with 12 salt rounds for secure password storage
 * Includes password strength validation and secure token generation
 */

import bcrypt from 'bcryptjs';
import { randomBytes } from 'crypto';

const SALT_ROUNDS = 12; // NIST recommends 12+
const MIN_PASSWORD_LENGTH = 8;

/**
 * Hash a password using bcrypt
 * Uses 12 salt rounds for strong security (NIST recommendation)
 */
export async function hashPassword(password: string): Promise<string> {
  if (!password) {
    throw new Error('Password cannot be empty');
  }

  if (password.length < MIN_PASSWORD_LENGTH) {
    throw new Error(`Password must be at least ${MIN_PASSWORD_LENGTH} characters`);
  }

  try {
    return await bcrypt.hash(password, SALT_ROUNDS);
  } catch (error) {
    console.error('[Password] Error hashing password:', error);
    throw new Error('Failed to hash password');
  }
}

/**
 * Verify a password against a bcrypt hash
 */
export async function verifyPassword(
  password: string,
  hash: string
): Promise<boolean> {
  if (!password || !hash) {
    return false;
  }

  try {
    return await bcrypt.compare(password, hash);
  } catch (error) {
    console.error('[Password] Error verifying password:', error);
    return false;
  }
}

/**
 * Password strength validation result
 */
export interface PasswordValidationResult {
  valid: boolean;
  score: number; // 0-100
  errors: Array<{ en: string; ar: string }>;
  suggestions: Array<{ en: string; ar: string }>;
}

/**
 * Validate password strength
 * Checks for length, uppercase, lowercase, numbers, and special characters
 */
export function validatePasswordStrength(password: string): PasswordValidationResult {
  const errors: Array<{ en: string; ar: string }> = [];
  const suggestions: Array<{ en: string; ar: string }> = [];
  let score = 0;

  if (!password) {
    return {
      valid: false,
      score: 0,
      errors: [{ en: 'Password is required', ar: 'كلمة المرور مطلوبة' }],
      suggestions: [],
    };
  }

  // Length check (base: 20 points)
  if (password.length < MIN_PASSWORD_LENGTH) {
    errors.push({
      en: `Password must be at least ${MIN_PASSWORD_LENGTH} characters`,
      ar: `يجب أن تكون كلمة المرور ${MIN_PASSWORD_LENGTH} أحرف على الأقل`,
    });
  } else if (password.length < 12) {
    suggestions.push({
      en: 'Consider using a longer password (12+ characters)',
      ar: 'استخدم كلمة مرور أطول (12 حرف أو أكثر)',
    });
    score += 15;
  } else if (password.length >= 16) {
    score += 25; // Extra points for very long password
  } else {
    score += 20;
  }

  // Uppercase check (15 points)
  if (!/[A-Z]/.test(password)) {
    errors.push({
      en: 'Password must contain at least one uppercase letter',
      ar: 'يجب أن تحتوي على حرف كبير واحد على الأقل',
    });
  } else {
    score += 15;
  }

  // Lowercase check (15 points)
  if (!/[a-z]/.test(password)) {
    errors.push({
      en: 'Password must contain at least one lowercase letter',
      ar: 'يجب أن تحتوي على حرف صغير واحد على الأقل',
    });
  } else {
    score += 15;
  }

  // Number check (20 points)
  if (!/[0-9]/.test(password)) {
    errors.push({
      en: 'Password must contain at least one number',
      ar: 'يجب أن تحتوي على رقم واحد على الأقل',
    });
  } else {
    score += 20;
  }

  // Special character check (15 points)
  if (!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password)) {
    suggestions.push({
      en: 'Consider adding special characters (!@#$%^&*) for stronger security',
      ar: 'أضف أحرف خاصة (!@#$%^&*) لأمان أفضل',
    });
  } else {
    score += 15;
  }

  // Check for common patterns (subtract points)
  if (/(.)\1{2,}/.test(password)) {
    // Three or more repeating characters
    suggestions.push({
      en: 'Avoid repeating characters (aaa, 111, etc.)',
      ar: 'تجنب تكرار الأحرف (aaa، 111، إلخ)',
    });
    score -= 10;
  }

  if (/^[a-zA-Z]+|^[0-9]+/.test(password)) {
    // Only letters or only numbers at the start
    suggestions.push({
      en: 'Mix letters and numbers throughout the password',
      ar: 'امزج الأحرف والأرقام في كل مكان',
    });
    score -= 5;
  }

  return {
    valid: errors.length === 0,
    score: Math.max(0, Math.min(100, score)),
    errors,
    suggestions,
  };
}

/**
 * Generate a cryptographically secure random token
 * Uses Node.js crypto.randomBytes for secure random generation
 */
export function generateToken(length: number = 32): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  const bytes = randomBytes(length);
  let token = '';

  for (let i = 0; i < length; i++) {
    token += chars[bytes[i] % chars.length];
  }

  return token;
}

/**
 * Generate a session token (longer, more secure)
 */
export function generateSessionToken(): string {
  return generateToken(64);
}

/**
 * Generate a cryptographically secure invite code
 * Format: ALSHAYA-XXXX-XXXX (excludes confusing characters like I, O, 0, 1)
 */
export function generateInviteCode(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // Removed I, O, 0, 1
  const bytes = randomBytes(8);
  let code = 'ALSHAYA-';

  for (let i = 0; i < 4; i++) {
    code += chars[bytes[i] % chars.length];
  }
  code += '-';
  for (let i = 4; i < 8; i++) {
    code += chars[bytes[i] % chars.length];
  }

  return code;
}

/**
 * Generate a password reset token
 */
export function generatePasswordResetToken(): string {
  return generateToken(48);
}

/**
 * Generate a verification token for email/phone
 */
export function generateVerificationToken(): string {
  return generateToken(32);
}

/**
 * Generate an API key with prefix
 */
export function generateApiKey(prefix: string = 'sk'): string {
  const randomPart = randomBytes(24).toString('base64url');
  return `${prefix}_${randomPart}`;
}
