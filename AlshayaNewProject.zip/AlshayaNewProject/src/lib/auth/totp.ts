/**
 * Time-Based One-Time Password (TOTP) 2FA Implementation
 * Implements RFC 6238 with speakeasy
 * Includes QR code generation and backup code support
 */

import speakeasy from 'speakeasy';
import QRCode from 'qrcode';

/**
 * TOTP configuration
 */
export const TOTP_CONFIG = {
  issuer: 'Al-Shaya Family Tree',
  window: 1, // Allow 1 time window before/after (±30 seconds)
  digits: 6,
};

/**
 * Generate TOTP secret for a new user
 */
export function generateTotpSecret(userEmail: string): {
  secret: string;
  otpauth_url: string;
} {
  const secret = speakeasy.generateSecret({
    name: `${TOTP_CONFIG.issuer} (${userEmail})`,
    issuer: TOTP_CONFIG.issuer,
    length: 32,
  });

  if (!secret.otpauth_url) {
    throw new Error('Failed to generate TOTP secret');
  }

  return {
    secret: secret.base32 || '',
    otpauth_url: secret.otpauth_url,
  };
}

/**
 * Generate QR code image for TOTP setup
 */
export async function generateTotpQRCode(
  otpauth_url: string,
  options?: {
    size?: number;
    margin?: number;
    errorCorrectionLevel?: 'L' | 'M' | 'Q' | 'H';
  }
): Promise<string> {
  try {
    const qrCode = await QRCode.toDataURL(otpauth_url, {
      errorCorrectionLevel: options?.errorCorrectionLevel || 'M',
      type: 'image/png',
      quality: 0.95,
      margin: options?.margin || 1,
      width: options?.size || 300,
    });
    return qrCode;
  } catch (error) {
    console.error('[TOTP] Error generating QR code:', error);
    throw new Error('Failed to generate QR code');
  }
}

/**
 * Verify a TOTP code
 */
export function verifyTotp(
  secret: string,
  token: string
): boolean {
  if (!secret || !token) {
    return false;
  }

  // Remove any whitespace from token
  const cleanToken = token.replace(/\s/g, '');

  try {
    const verified = speakeasy.totp.verify({
      secret,
      encoding: 'base32',
      token: cleanToken,
      window: TOTP_CONFIG.window,
    });

    return verified;
  } catch (error) {
    console.error('[TOTP] Error verifying token:', error);
    return false;
  }
}

/**
 * Generate the current TOTP code (for testing/debugging)
 */
export function generateTotp(secret: string): string {
  try {
    const token = speakeasy.totp({
      secret,
      encoding: 'base32',
    });
    return token;
  } catch (error) {
    console.error('[TOTP] Error generating TOTP:', error);
    throw new Error('Failed to generate TOTP code');
  }
}

/**
 * Get time remaining until next TOTP window (in seconds)
 */
export function getTotpTimeRemaining(): number {
  const timeStep = 30; // Standard TOTP time step
  const now = Math.floor(Date.now() / 1000);
  const remaining = timeStep - (now % timeStep);
  return remaining;
}

/**
 * Format TOTP secret for display (in groups of 4)
 */
export function formatTotpSecret(secret: string): string {
  return secret.replace(/(.{4})/g, '$1 ').trim();
}

/**
 * Validate TOTP secret format
 */
export function isValidTotpSecret(secret: string): boolean {
  if (!secret) return false;
  // Base32 alphabet
  return /^[A-Z2-7]+=*$/.test(secret.replace(/\s/g, ''));
}

/**
 * Generate backup codes for TOTP (in case user loses access to authenticator)
 */
export function generateBackupCodes(count: number = 10): string[] {
  const codes: string[] = [];
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';

  for (let i = 0; i < count; i++) {
    let code = '';
    for (let j = 0; j < 8; j++) {
      code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    codes.push(code);
  }

  return codes;
}

/**
 * Format backup code for display
 */
export function formatBackupCode(code: string): string {
  // Format as XXXX-XXXX
  return `${code.substring(0, 4)}-${code.substring(4, 8)}`;
}

/**
 * Check if a string is a valid backup code format
 */
export function isValidBackupCodeFormat(code: string): boolean {
  const cleaned = code.replace(/[-\s]/g, '');
  return /^[A-Z0-9]{8}$/.test(cleaned);
}

/**
 * Normalize backup code for comparison
 */
export function normalizeBackupCode(code: string): string {
  return code.replace(/[-\s]/g, '').toUpperCase();
}

/**
 * TOTP setup response structure
 */
export interface TotpSetupResponse {
  secret: string;
  qrCode: string;
  manualEntryKey: string;
  backupCodes: string[];
}

/**
 * Create complete TOTP setup for a user
 */
export async function createTotpSetup(
  userEmail: string
): Promise<TotpSetupResponse> {
  try {
    const { secret, otpauth_url } = generateTotpSecret(userEmail);
    const qrCode = await generateTotpQRCode(otpauth_url);
    const backupCodes = generateBackupCodes(10);

    return {
      secret,
      qrCode,
      manualEntryKey: formatTotpSecret(secret),
      backupCodes,
    };
  } catch (error) {
    console.error('[TOTP] Error creating setup:', error);
    throw new Error('Failed to create TOTP setup');
  }
}
