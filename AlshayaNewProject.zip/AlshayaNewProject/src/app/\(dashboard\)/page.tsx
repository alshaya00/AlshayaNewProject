import type { Metadata } from 'next';
import Link from 'next/link';

export const metadata: Metadata = {
  title: 'Dashboard',
  description: 'Family tree management dashboard',
};

export default function DashboardPage() {
  return (
    <div className="w-full">
      {/* Header */}
      <header className="bg-gradient-to-r from-slate-800 to-slate-900 border-b border-slate-700 p-6">
        <div className="max-w-7xl">
          <h1 className="text-3xl font-bold text-white mb-2">لوحة التحكم</h1>
          <p className="text-slate-400">مرحباً بك في شجرة عائلة آل شايع</p>
        </div>
      </header>

      {/* Main Content */}
      <main className="p-6 max-w-7xl">
        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-slate-800 rounded-lg p-6 border border-slate-700">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-400 text-sm">إجمالي الأعضاء</p>
                <p className="text-3xl font-bold text-white mt-1">1,245</p>
              </div>
              <div className="w-12 h-12 rounded-full bg-blue-900 flex items-center justify-center">
                <svg className="w-6 h-6 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3.634a1 1 0 01-.952-1.405l2.697-7.894A6 6 0 0112 13a6 6 0 015.621 3.701l2.697 7.894a1 1 0 01-.952 1.405zm0 0h5.366a1 1 0 00.952-1.405l-2.697-7.894a6 6 0 10-5.621-3.701" />
                </svg>
              </div>
            </div>
            <p className="text-xs text-slate-500 mt-4">زيادة 12 هذا الشهر</p>
          </div>

          <div className="bg-slate-800 rounded-lg p-6 border border-slate-700">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-400 text-sm">الأحداث القادمة</p>
                <p className="text-3xl font-bold text-white mt-1">23</p>
              </div>
              <div className="w-12 h-12 rounded-full bg-green-900 flex items-center justify-center">
                <svg className="w-6 h-6 text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
              </div>
            </div>
            <p className="text-xs text-slate-500 mt-4">خلال 3 أشهر</p>
          </div>

          <div className="bg-slate-800 rounded-lg p-6 border border-slate-700">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-400 text-sm">الدفاتر</p>
                <p className="text-3xl font-bold text-white mt-1">58</p>
              </div>
              <div className="w-12 h-12 rounded-full bg-purple-900 flex items-center justify-center">
                <svg className="w-6 h-6 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C6.5 6.253 2 10.998 2 17s4.5 10.747 10 10.747m0-13c5.5 0 10 4.745 10 10.747S17.5 27.747 12 27.747" />
                </svg>
              </div>
            </div>
            <p className="text-xs text-slate-500 mt-4">دفاتر نشطة</p>
          </div>

          <div className="bg-slate-800 rounded-lg p-6 border border-slate-700">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-400 text-sm">الصور</p>
                <p className="text-3xl font-bold text-white mt-1">892</p>
              </div>
              <div className="w-12 h-12 rounded-full bg-orange-900 flex items-center justify-center">
                <svg className="w-6 h-6 text-orange-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
              </div>
            </div>
            <p className="text-xs text-slate-500 mt-4">وسائط مختلفة</p>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="bg-slate-800 rounded-lg p-6 border border-slate-700 mb-8">
          <h2 className="text-xl font-bold text-white mb-4">إجراءات سريعة</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Link
              href="/dashboard/members/new"
              className="flex items-center gap-4 p-4 rounded-lg bg-slate-700 hover:bg-slate-600 transition-colors group"
            >
              <div className="w-10 h-10 rounded-full bg-blue-900 flex items-center justify-center group-hover:bg-blue-800">
                <svg className="w-5 h-5 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                </svg>
              </div>
              <div>
                <p className="font-medium text-white">إضافة عضو جديد</p>
                <p className="text-xs text-slate-400">إضافة شخص جديد للعائلة</p>
              </div>
            </Link>

            <Link
              href="/dashboard/journals/new"
              className="flex items-center gap-4 p-4 rounded-lg bg-slate-700 hover:bg-slate-600 transition-colors group"
            >
              <div className="w-10 h-10 rounded-full bg-green-900 flex items-center justify-center group-hover:bg-green-800">
                <svg className="w-5 h-5 text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                </svg>
              </div>
              <div>
                <p className="font-medium text-white">كتابة دفتر جديد</p>
                <p className="text-xs text-slate-400">توثيق قصة عائلية</p>
              </div>
            </Link>

            <Link
              href="/dashboard/tree"
              className="flex items-center gap-4 p-4 rounded-lg bg-slate-700 hover:bg-slate-600 transition-colors group"
            >
              <div className="w-10 h-10 rounded-full bg-purple-900 flex items-center justify-center group-hover:bg-purple-800">
                <svg className="w-5 h-5 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5a2 2 0 012-2h.93a2 2 0 011.664.89l.812 1.22a2 2 0 001.664.89H17a2 2 0 012 2M9 5a9 9 0 019 9m0 0a9 9 0 01-9 9m9-9H6" />
                </svg>
              </div>
              <div>
                <p className="font-medium text-white">عرض الشجرة</p>
                <p className="text-xs text-slate-400">رؤية العلاقات العائلية</p>
              </div>
            </Link>
          </div>
        </div>

        {/* Recent Activity */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="bg-slate-800 rounded-lg p-6 border border-slate-700">
            <h2 className="text-xl font-bold text-white mb-4">النشاط الأخير</h2>
            <div className="space-y-4">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="flex items-start gap-4 pb-4 border-b border-slate-700 last:border-b-0">
                  <div className="w-10 h-10 rounded-full bg-slate-700 flex items-center justify-center flex-shrink-0">
                    <svg className="w-5 h-5 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-white">تم إضافة عضو جديد</p>
                    <p className="text-sm text-slate-400">محمد علي الشايع</p>
                    <p className="text-xs text-slate-500 mt-1">قبل ساعتين</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-slate-800 rounded-lg p-6 border border-slate-700">
            <h2 className="text-xl font-bold text-white mb-4">الأحداث القادمة</h2>
            <div className="space-y-4">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="flex items-start gap-4 pb-4 border-b border-slate-700 last:border-b-0">
                  <div className="w-10 h-10 rounded-full bg-orange-900 flex items-center justify-center flex-shrink-0">
                    <svg className="w-5 h-5 text-orange-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                    </svg>
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-white">حفل عائلي</p>
                    <p className="text-sm text-slate-400">لم الشمل السنوي</p>
                    <p className="text-xs text-slate-500 mt-1">2024-03-15</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
