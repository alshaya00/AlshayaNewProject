import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Notifications',
  description: 'Notification center',
};

export default function NotificationsPage() {
  return (
    <div className="w-full">
      <header className="bg-gradient-to-r from-slate-800 to-slate-900 border-b border-slate-700 p-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-white mb-2">الإشعارات</h1>
            <p className="text-slate-400">جميع إشعاراتك</p>
          </div>
          <button className="text-sm text-blue-400 hover:text-blue-300">
            مسح الكل
          </button>
        </div>
      </header>

      <main className="p-6 max-w-2xl">
        <div className="space-y-2">
          {[
            {
              title: 'عضو جديد انضم إلى العائلة',
              description: 'فاطمة الشايع انضمت للتو إلى الشجرة',
              time: 'قبل ساعة',
              type: 'member',
              read: false,
            },
            {
              title: 'تعليق جديد على دفترك',
              description: 'محمد علي: تعليق رائع جداً',
              time: 'قبل 3 ساعات',
              type: 'comment',
              read: false,
            },
            {
              title: 'حدث عائلي قريب',
              description: 'لم الشمل السنوي في 15 أبريل',
              time: 'قبل يوم',
              type: 'event',
              read: true,
            },
            {
              title: 'تم تحديث حسابك',
              description: 'تم تسجيل دخول جديد من جهاز مختلف',
              time: 'قبل يومين',
              type: 'security',
              read: true,
            },
            {
              title: 'صورة جديدة في المعرض',
              description: 'نور الشايع أضافت صور جديدة',
              time: 'قبل 3 أيام',
              type: 'photo',
              read: true,
            },
          ].map((notification, i) => (
            <div
              key={i}
              className={`p-4 rounded-lg border transition-colors ${
                notification.read
                  ? 'bg-slate-800 border-slate-700 hover:bg-slate-700'
                  : 'bg-slate-700 border-blue-600/50 hover:bg-slate-600'
              }`}
            >
              <div className="flex items-start gap-4">
                <div className={`w-3 h-3 rounded-full flex-shrink-0 mt-1.5 ${notification.read ? 'bg-slate-500' : 'bg-blue-500'}`} />

                <div className="flex-1 min-w-0">
                  <p className={`font-medium ${notification.read ? 'text-slate-300' : 'text-white'}`}>
                    {notification.title}
                  </p>
                  <p className="text-sm text-slate-400 mt-1">{notification.description}</p>
                  <p className="text-xs text-slate-500 mt-2">{notification.time}</p>
                </div>

                <button className="text-slate-500 hover:text-slate-300 flex-shrink-0">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Empty State */}
        <div className="mt-12 text-center py-12">
          <div className="w-16 h-16 rounded-full bg-slate-800 flex items-center justify-center mx-auto mb-4">
            <svg className="w-8 h-8 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0018 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
            </svg>
          </div>
          <p className="text-slate-400">لا توجد إشعارات جديدة</p>
        </div>
      </main>
    </div>
  );
}
