export default function DashboardLoading() {
  return (
    <div className="w-full">
      <header className="bg-gradient-to-r from-slate-800 to-slate-900 border-b border-slate-700 p-6">
        <div className="max-w-7xl">
          <div className="h-8 bg-slate-700 rounded animate-pulse w-1/4 mb-3" />
          <div className="h-4 bg-slate-700 rounded animate-pulse w-1/3" />
        </div>
      </header>

      <main className="p-6 max-w-7xl">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="bg-slate-800 rounded-lg p-6 border border-slate-700">
              <div className="h-4 bg-slate-700 rounded animate-pulse w-1/2 mb-3" />
              <div className="h-8 bg-slate-700 rounded animate-pulse w-2/3" />
              <div className="h-3 bg-slate-700 rounded animate-pulse w-1/3 mt-4" />
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {[1, 2].map((i) => (
            <div key={i} className="bg-slate-800 rounded-lg p-6 border border-slate-700">
              <div className="h-6 bg-slate-700 rounded animate-pulse w-1/3 mb-4" />
              <div className="space-y-4">
                {[1, 2, 3, 4].map((j) => (
                  <div key={j} className="pb-4 border-b border-slate-700 last:border-b-0">
                    <div className="h-4 bg-slate-700 rounded animate-pulse w-3/4 mb-2" />
                    <div className="h-3 bg-slate-700 rounded animate-pulse w-1/2" />
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}
