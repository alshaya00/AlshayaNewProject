import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Events',
  description: 'Family events timeline',
};

export default function EventsPage() {
  return (
    <div className="w-full">
      <header className="bg-gradient-to-r from-slate-800 to-slate-900 border-b border-slate-700 p-6">
        <h1 className="text-3xl font-bold text-white mb-2">الأحداث</h1>
        <p className="text-slate-400">الأحداث والتواريخ المهمة للعائلة</p>
      </header>

      <main className="p-6">
        <div className="max-w-4xl">
          <div className="mb-6">
            <input
              type="text"
              placeholder="ابحث عن حدث..."
              className="w-full px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white placeholder-slate-400 focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div className="relative space-y-6">
            {/* Timeline */}
            {[1, 2, 3, 4, 5].map((i) => (
              <div key={i} className="flex gap-6">
                <div className="flex flex-col items-center">
                  <div className="w-4 h-4 rounded-full bg-blue-600" />
                  {i < 5 && <div className="w-0.5 h-24 bg-slate-700 my-2" />}
                </div>
                <div className="bg-slate-800 rounded-lg border border-slate-700 p-6 flex-1">
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="font-semibold text-white">لم الشمل السنوي</h3>
                      <p className="text-slate-400 text-sm mt-1">اجتماع عائلي سنوي</p>
                    </div>
                    <span className="text-sm font-medium text-slate-300">2024-04-15</span>
                  </div>
                  <p className="text-slate-300 text-sm mt-3">
                    يجتمع أفراد العائلة من جميع أنحاء العالم للاحتفال معاً
                  </p>
                  <div className="mt-4 flex items-center gap-2">
                    <span className="inline-block px-3 py-1 bg-blue-900/30 text-blue-400 rounded-full text-xs">عائلي</span>
                    <span className="inline-block px-3 py-1 bg-green-900/30 text-green-400 rounded-full text-xs">قادم</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
}
