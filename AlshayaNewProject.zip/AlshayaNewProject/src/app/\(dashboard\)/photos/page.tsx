import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Photos',
  description: 'Family photo gallery',
};

export default function PhotosPage() {
  return (
    <div className="w-full">
      <header className="bg-gradient-to-r from-slate-800 to-slate-900 border-b border-slate-700 p-6">
        <h1 className="text-3xl font-bold text-white mb-2">الصور</h1>
        <p className="text-slate-400">معرض الصور العائلية</p>
      </header>

      <main className="p-6">
        <div className="mb-6 flex gap-4">
          <input
            type="text"
            placeholder="ابحث عن صور..."
            className="flex-1 px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white placeholder-slate-400 focus:ring-2 focus:ring-blue-500"
          />
          <select className="px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white focus:ring-2 focus:ring-blue-500">
            <option>ترتيب حسب الأحدث</option>
            <option>ترتيب حسب الأقدم</option>
            <option>ترتيب حسب المفضلة</option>
          </select>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {[1, 2, 3, 4, 5, 6, 7, 8].map((i) => (
            <div key={i} className="aspect-square rounded-lg overflow-hidden bg-slate-800 border border-slate-700 hover:border-blue-600 transition-colors group cursor-pointer">
              <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-slate-700 to-slate-800">
                <svg className="w-12 h-12 text-slate-500 group-hover:text-blue-400 transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-8 text-center">
          <button className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
            تحميل المزيد
          </button>
        </div>
      </main>
    </div>
  );
}
