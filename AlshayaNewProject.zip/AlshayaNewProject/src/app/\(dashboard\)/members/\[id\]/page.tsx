import type { Metadata } from 'next';
import Link from 'next/link';

export const metadata: Metadata = {
  title: 'Member Profile',
  description: 'Family member profile and details',
};

interface MemberDetailPageProps {
  params: {
    id: string;
  };
}

export default function MemberDetailPage({ params }: MemberDetailPageProps) {
  return (
    <div className="w-full">
      <header className="bg-gradient-to-r from-slate-800 to-slate-900 border-b border-slate-700 p-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-white mb-2">محمد علي الشايع</h1>
            <p className="text-slate-400">رقم المعرف: {params.id}</p>
          </div>
          <div className="flex gap-3">
            <Link
              href={`/dashboard/members/${params.id}/edit`}
              className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              تعديل
            </Link>
            <button className="px-6 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors">
              حذف
            </button>
          </div>
        </div>
      </header>

      <main className="p-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Info */}
          <div className="lg:col-span-2">
            <div className="bg-slate-800 rounded-lg border border-slate-700 p-6 mb-6">
              <h2 className="text-xl font-bold text-white mb-4">المعلومات الشخصية</h2>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-slate-400 text-sm">الاسم بالعربية</p>
                  <p className="text-white font-medium">محمد علي</p>
                </div>
                <div>
                  <p className="text-slate-400 text-sm">الاسم بالإنجليزية</p>
                  <p className="text-white font-medium">Mohammed Ali</p>
                </div>
                <div>
                  <p className="text-slate-400 text-sm">تاريخ الميلاد</p>
                  <p className="text-white font-medium">1985-05-15</p>
                </div>
                <div>
                  <p className="text-slate-400 text-sm">الجنس</p>
                  <p className="text-white font-medium">ذكر</p>
                </div>
                <div>
                  <p className="text-slate-400 text-sm">حالة الزواج</p>
                  <p className="text-white font-medium">متزوج</p>
                </div>
                <div>
                  <p className="text-slate-400 text-sm">مكان الإقامة</p>
                  <p className="text-white font-medium">الرياض، المملكة العربية السعودية</p>
                </div>
              </div>
            </div>

            <div className="bg-slate-800 rounded-lg border border-slate-700 p-6 mb-6">
              <h2 className="text-xl font-bold text-white mb-4">معلومات التواصل</h2>
              <div className="space-y-3">
                <div>
                  <p className="text-slate-400 text-sm">البريد الإلكتروني</p>
                  <p className="text-white font-medium">mohammed@example.com</p>
                </div>
                <div>
                  <p className="text-slate-400 text-sm">رقم الجوال</p>
                  <p className="text-white font-medium">+966501234567</p>
                </div>
                <div>
                  <p className="text-slate-400 text-sm">رقم الهاتف</p>
                  <p className="text-white font-medium">+96611234567</p>
                </div>
              </div>
            </div>

            <div className="bg-slate-800 rounded-lg border border-slate-700 p-6">
              <h2 className="text-xl font-bold text-white mb-4">السيرة الذاتية</h2>
              <p className="text-slate-300">
                محمد علي الشايع هو عضو نشط في العائلة منذ عام 2020. متخصص في تطوير الأعمال وله اهتمامات كبيرة في الحفاظ على تاريخ العائلة.
              </p>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <div className="bg-slate-800 rounded-lg border border-slate-700 p-6 text-center">
              <div className="w-24 h-24 rounded-full bg-slate-700 flex items-center justify-center mx-auto mb-4">
                <svg className="w-12 h-12 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                </svg>
              </div>
              <h3 className="font-semibold text-white">محمد علي الشايع</h3>
              <p className="text-slate-400 text-sm mt-1">عضو نشط</p>
            </div>

            <div className="bg-slate-800 rounded-lg border border-slate-700 p-6">
              <h3 className="font-semibold text-white mb-4">الأقارب</h3>
              <div className="space-y-2">
                <Link href="#" className="block text-blue-400 hover:text-blue-300 text-sm">
                  الأب: علي الشايع
                </Link>
                <Link href="#" className="block text-blue-400 hover:text-blue-300 text-sm">
                  الأم: فاطمة الشايع
                </Link>
                <Link href="#" className="block text-blue-400 hover:text-blue-300 text-sm">
                  الزوجة: نور الشايع
                </Link>
              </div>
            </div>

            <div className="bg-slate-800 rounded-lg border border-slate-700 p-6">
              <h3 className="font-semibold text-white mb-4">الإحصائيات</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-slate-400">تاريخ الانضمام</span>
                  <span className="text-white">2020-01-15</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">آخر تحديث</span>
                  <span className="text-white">2024-03-08</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">الصور</span>
                  <span className="text-white">15</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
