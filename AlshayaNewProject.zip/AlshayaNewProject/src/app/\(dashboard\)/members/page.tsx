import type { Metadata } from 'next';
import Link from 'next/link';

export const metadata: Metadata = {
  title: 'Members',
  description: 'Family members listing and management',
};

export default function MembersPage() {
  return (
    <div className="w-full">
      <header className="bg-gradient-to-r from-slate-800 to-slate-900 border-b border-slate-700 p-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-white mb-2">الأعضاء</h1>
            <p className="text-slate-400">قائمة أعضاء العائلة</p>
          </div>
          <Link
            href="/dashboard/members/new"
            className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            + إضافة عضو
          </Link>
        </div>
      </header>

      <main className="p-6">
        <div className="mb-6 space-y-4">
          <input
            type="text"
            placeholder="ابحث عن عضو..."
            className="w-full px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white placeholder-slate-400 focus:ring-2 focus:ring-blue-500"
          />

          <div className="flex gap-4">
            <select className="px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white focus:ring-2 focus:ring-blue-500">
              <option>جميع الفروع</option>
              <option>الفرع الأول</option>
              <option>الفرع الثاني</option>
            </select>

            <select className="px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white focus:ring-2 focus:ring-blue-500">
              <option>ترتيب حسب الاسم</option>
              <option>ترتيب حسب التاريخ</option>
              <option>ترتيب حسب الجنس</option>
            </select>
          </div>
        </div>

        <div className="bg-slate-800 rounded-lg border border-slate-700 overflow-hidden">
          <table className="w-full">
            <thead className="bg-slate-700">
              <tr>
                <th className="px-6 py-3 text-right text-sm font-semibold text-white">الاسم</th>
                <th className="px-6 py-3 text-right text-sm font-semibold text-white">تاريخ الميلاد</th>
                <th className="px-6 py-3 text-right text-sm font-semibold text-white">الحالة</th>
                <th className="px-6 py-3 text-right text-sm font-semibold text-white">الإجراءات</th>
              </tr>
            </thead>
            <tbody>
              {[1, 2, 3, 4, 5].map((i) => (
                <tr key={i} className="border-t border-slate-700 hover:bg-slate-700/50">
                  <td className="px-6 py-4 text-white">محمد علي الشايع</td>
                  <td className="px-6 py-4 text-slate-400">1985-05-15</td>
                  <td className="px-6 py-4">
                    <span className="px-3 py-1 bg-green-900/30 text-green-400 rounded-full text-sm">نشط</span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex gap-2">
                      <Link
                        href={`/dashboard/members/${i}`}
                        className="text-blue-400 hover:text-blue-300"
                      >
                        عرض
                      </Link>
                      <Link
                        href={`/dashboard/members/${i}/edit`}
                        className="text-slate-400 hover:text-white"
                      >
                        تعديل
                      </Link>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="mt-6 flex items-center justify-between">
          <p className="text-slate-400">عرض 1-5 من 47 عضو</p>
          <div className="flex gap-2">
            <button className="px-4 py-2 bg-slate-800 text-white rounded-lg hover:bg-slate-700 disabled:opacity-50">السابق</button>
            <button className="px-4 py-2 bg-blue-600 text-white rounded-lg">1</button>
            <button className="px-4 py-2 bg-slate-800 text-white rounded-lg hover:bg-slate-700">2</button>
            <button className="px-4 py-2 bg-slate-800 text-white rounded-lg hover:bg-slate-700">3</button>
            <button className="px-4 py-2 bg-slate-800 text-white rounded-lg hover:bg-slate-700">التالي</button>
          </div>
        </div>
      </main>
    </div>
  );
}
