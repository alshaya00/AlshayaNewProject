import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Security Settings',
  description: 'Manage security and password settings',
};

export default function SecurityPage() {
  return (
    <div className="w-full">
      <header className="bg-gradient-to-r from-slate-800 to-slate-900 border-b border-slate-700 p-6">
        <h1 className="text-3xl font-bold text-white mb-2">الأمان</h1>
        <p className="text-slate-400">إدارة كلمة المرور والمصادقة الثنائية</p>
      </header>

      <main className="p-6 max-w-4xl">
        {/* Change Password Section */}
        <div className="bg-slate-800 rounded-lg border border-slate-700 p-6 mb-6">
          <h2 className="text-xl font-semibold text-white mb-4">تغيير كلمة المرور</h2>
          <form className="space-y-4">
            <div>
              <label className="block text-sm text-slate-400 mb-2">كلمة المرور الحالية</label>
              <input
                type="password"
                placeholder="••••••••"
                className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:ring-2 focus:ring-blue-500"
                dir="ltr"
              />
            </div>

            <div>
              <label className="block text-sm text-slate-400 mb-2">كلمة المرور الجديدة</label>
              <input
                type="password"
                placeholder="••••••••"
                className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:ring-2 focus:ring-blue-500"
                dir="ltr"
              />
            </div>

            <div>
              <label className="block text-sm text-slate-400 mb-2">تأكيد كلمة المرور الجديدة</label>
              <input
                type="password"
                placeholder="••••••••"
                className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:ring-2 focus:ring-blue-500"
                dir="ltr"
              />
            </div>

            <button
              type="submit"
              className="w-full px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              تحديث كلمة المرور
            </button>
          </form>
        </div>

        {/* Two Factor Authentication Section */}
        <div className="bg-slate-800 rounded-lg border border-slate-700 p-6 mb-6">
          <div className="flex items-start justify-between mb-4">
            <div>
              <h2 className="text-xl font-semibold text-white">المصادقة الثنائية</h2>
              <p className="text-sm text-slate-400 mt-1">أضف طبقة حماية إضافية لحسابك</p>
            </div>
            <span className="px-3 py-1 bg-green-900/30 text-green-400 rounded-full text-sm font-medium">مفعلة</span>
          </div>

          <div className="space-y-4">
            <p className="text-slate-300">يتم استخدام تطبيق المصادقة على جهازك المحمول للتحقق من هويتك</p>
            <button className="px-4 py-2 bg-slate-700 text-white rounded-lg hover:bg-slate-600 transition-colors">
              إعادة تكوين المصادقة الثنائية
            </button>
          </div>
        </div>

        {/* Backup Codes Section */}
        <div className="bg-slate-800 rounded-lg border border-slate-700 p-6 mb-6">
          <h2 className="text-xl font-semibold text-white mb-4">أكواد الاسترداد</h2>
          <p className="text-slate-300 mb-4">
            احتفظ بنسخة احتياطية من أكواد الاسترداد في مكان آمن. يمكنك استخدام هذه الأكواد إذا فقدت الوصول إلى تطبيق المصادقة.
          </p>
          <button className="px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors">
            عرض أكواد الاسترداد
          </button>
        </div>

        {/* Login Sessions Section */}
        <div className="bg-slate-800 rounded-lg border border-slate-700 p-6">
          <h2 className="text-xl font-semibold text-white mb-4">جلسات تسجيل الدخول النشطة</h2>
          <div className="space-y-4">
            {[1, 2].map((i) => (
              <div key={i} className="flex items-start justify-between p-4 rounded-lg bg-slate-700">
                <div className="flex items-center gap-3">
                  <svg className="w-5 h-5 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z" />
                  </svg>
                  <div>
                    <p className="font-medium text-white">جهاز محمول - iOS</p>
                    <p className="text-xs text-slate-400">آخر تفاعل: قبل 2 ساعة</p>
                  </div>
                </div>
                <button className="text-red-400 hover:text-red-300 text-sm">
                  تسجيل خروج
                </button>
              </div>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
}
