import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Advanced Search',
  description: 'Search family members with advanced filters',
};

export default function SearchPage() {
  return (
    <div className="w-full">
      <header className="bg-gradient-to-r from-slate-800 to-slate-900 border-b border-slate-700 p-6">
        <h1 className="text-3xl font-bold text-white mb-2">البحث المتقدم</h1>
        <p className="text-slate-400">ابحث عن الأعضاء بمعايير متعددة</p>
      </header>

      <main className="p-6 max-w-4xl">
        <form className="space-y-6">
          <div className="bg-slate-800 rounded-lg border border-slate-700 p-6">
            <h2 className="text-lg font-semibold text-white mb-4">معايير البحث</h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">الاسم</label>
                <input
                  type="text"
                  placeholder="ابحث بالاسم"
                  className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:ring-2 focus:ring-blue-500"
                  dir="rtl"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">الفرع</label>
                <select className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:ring-2 focus:ring-blue-500">
                  <option>اختر الفرع</option>
                  <option>الفرع الأول</option>
                  <option>الفرع الثاني</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">الجنس</label>
                <select className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:ring-2 focus:ring-blue-500">
                  <option>كل الجنسين</option>
                  <option>ذكر</option>
                  <option>أنثى</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">حالة الزواج</label>
                <select className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:ring-2 focus:ring-blue-500">
                  <option>الجميع</option>
                  <option>متزوج</option>
                  <option>أعزب</option>
                  <option>مطلق</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">من تاريخ الميلاد</label>
                <input type="date" className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:ring-2 focus:ring-blue-500" />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">إلى تاريخ الميلاد</label>
                <input type="date" className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:ring-2 focus:ring-blue-500" />
              </div>
            </div>

            <div className="flex gap-4">
              <button
                type="submit"
                className="px-8 py-2 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 transition-colors"
              >
                بحث
              </button>
              <button
                type="reset"
                className="px-8 py-2 bg-slate-700 text-white font-medium rounded-lg hover:bg-slate-600 transition-colors"
              >
                مسح
              </button>
            </div>
          </div>
        </form>

        {/* Search Results */}
        <div className="mt-8 bg-slate-800 rounded-lg border border-slate-700 overflow-hidden">
          <div className="p-4 bg-slate-700">
            <p className="text-slate-300">نتائج البحث: <span className="font-semibold text-white">5</span> أعضاء</p>
          </div>
          <table className="w-full">
            <thead>
              <tr className="border-b border-slate-700">
                <th className="px-6 py-3 text-right text-sm font-semibold text-white">الاسم</th>
                <th className="px-6 py-3 text-right text-sm font-semibold text-white">تاريخ الميلاد</th>
                <th className="px-6 py-3 text-right text-sm font-semibold text-white">الفرع</th>
                <th className="px-6 py-3 text-right text-sm font-semibold text-white">الإجراءات</th>
              </tr>
            </thead>
            <tbody>
              {[1, 2, 3, 4, 5].map((i) => (
                <tr key={i} className="border-b border-slate-700 hover:bg-slate-700/50">
                  <td className="px-6 py-4 text-white">محمد علي الشايع</td>
                  <td className="px-6 py-4 text-slate-400">1985-05-15</td>
                  <td className="px-6 py-4 text-slate-400">الفرع الأول</td>
                  <td className="px-6 py-4">
                    <a href="#" className="text-blue-400 hover:text-blue-300">عرض</a>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </main>
    </div>
  );
}
