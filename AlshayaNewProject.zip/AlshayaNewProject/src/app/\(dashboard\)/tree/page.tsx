import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Family Tree',
  description: 'Interactive family tree visualization',
};

export default function TreePage() {
  return (
    <div className="w-full">
      <header className="bg-gradient-to-r from-slate-800 to-slate-900 border-b border-slate-700 p-6">
        <h1 className="text-3xl font-bold text-white mb-2">شجرة العائلة</h1>
        <p className="text-slate-400">تصور العلاقات والروابط العائلية</p>
      </header>

      <main className="p-6">
        <div className="bg-slate-800 rounded-lg border border-slate-700 h-[600px] flex items-center justify-center">
          <div className="text-center">
            <div className="w-16 h-16 rounded-full bg-slate-700 flex items-center justify-center mx-auto mb-4">
              <svg className="w-8 h-8 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5a2 2 0 012-2h.93a2 2 0 011.664.89l.812 1.22a2 2 0 001.664.89H17a2 2 0 012 2M9 5a9 9 0 019 9m0 0a9 9 0 01-9 9m9-9H6" />
              </svg>
            </div>
            <h2 className="text-xl font-semibold text-white mb-2">شجرة العائلة التفاعلية</h2>
            <p className="text-slate-400 mb-4">جاري تحميل المحتوى...</p>
            <p className="text-sm text-slate-500">سيتم عرض شجرة العائلة هنا مع إمكانية التفاعل والتنقل</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
          <div className="bg-slate-800 rounded-lg p-6 border border-slate-700">
            <h3 className="font-semibold text-white mb-2">البحث</h3>
            <p className="text-slate-400 text-sm">ابحث عن أعضاء محددين في الشجرة</p>
          </div>

          <div className="bg-slate-800 rounded-lg p-6 border border-slate-700">
            <h3 className="font-semibold text-white mb-2">الفلاتر</h3>
            <p className="text-slate-400 text-sm">صفي النتائج حسب المعايير المختلفة</p>
          </div>

          <div className="bg-slate-800 rounded-lg p-6 border border-slate-700">
            <h3 className="font-semibold text-white mb-2">التصدير</h3>
            <p className="text-slate-400 text-sm">صدر البيانات بصيغ مختلفة</p>
          </div>
        </div>
      </main>
    </div>
  );
}
