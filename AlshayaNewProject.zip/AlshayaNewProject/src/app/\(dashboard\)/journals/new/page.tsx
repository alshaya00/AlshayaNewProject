import type { Metadata } from 'next';
import Link from 'next/link';

export const metadata: Metadata = {
  title: 'New Journal',
  description: 'Create a new family journal',
};

export default function NewJournalPage() {
  return (
    <div className="w-full">
      <header className="bg-gradient-to-r from-slate-800 to-slate-900 border-b border-slate-700 p-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-white mb-2">دفتر جديد</h1>
            <p className="text-slate-400">شارك قصة أو ذكرى عائلية</p>
          </div>
          <Link
            href="/dashboard/journals"
            className="px-6 py-2 bg-slate-700 text-white rounded-lg hover:bg-slate-600 transition-colors"
          >
            إلغاء
          </Link>
        </div>
      </header>

      <main className="p-6 max-w-4xl">
        <form className="space-y-6">
          <div className="bg-slate-800 rounded-lg border border-slate-700 p-6">
            <div className="mb-6">
              <label className="block text-sm font-medium text-slate-300 mb-2">العنوان *</label>
              <input
                type="text"
                placeholder="أدخل عنوان الدفتر"
                className="w-full px-4 py-3 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:ring-2 focus:ring-blue-500"
                dir="rtl"
                required
              />
            </div>

            <div className="mb-6">
              <label className="block text-sm font-medium text-slate-300 mb-2">المحتوى *</label>
              <textarea
                placeholder="اكتب قصتك أو ذكرياتك هنا..."
                rows={12}
                className="w-full px-4 py-3 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:ring-2 focus:ring-blue-500"
                dir="rtl"
                required
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">الفئة</label>
                <select className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:ring-2 focus:ring-blue-500">
                  <option>ذكريات</option>
                  <option>قصص عائلية</option>
                  <option>تاريخ العائلة</option>
                  <option>تقاليد</option>
                  <option>أخرى</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">التاريخ</label>
                <input
                  type="date"
                  className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>

            <div className="mt-6">
              <label className="block text-sm font-medium text-slate-300 mb-2">الأشخاص المتعلقين (اختياري)</label>
              <input
                type="text"
                placeholder="أدخل أسماء الأشخاص المتعلقين مفصولة بفواصل"
                className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:ring-2 focus:ring-blue-500"
                dir="rtl"
              />
            </div>

            <div className="mt-6">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  className="w-4 h-4 bg-slate-700 border-slate-600 rounded text-blue-600 focus:ring-blue-500"
                />
                <span className="text-sm text-slate-300">جعل هذا الدفتر خاصاً (مرئي لك فقط)</span>
              </label>
            </div>

            <div className="mt-8 flex gap-4">
              <button
                type="submit"
                className="px-8 py-3 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 transition-colors"
              >
                نشر الدفتر
              </button>
              <Link
                href="/dashboard/journals"
                className="px-8 py-3 bg-slate-700 text-white font-medium rounded-lg hover:bg-slate-600 transition-colors"
              >
                إلغاء
              </Link>
            </div>
          </div>
        </form>
      </main>
    </div>
  );
}
