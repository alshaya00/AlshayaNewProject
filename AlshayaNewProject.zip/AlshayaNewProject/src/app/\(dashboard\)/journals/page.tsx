import type { Metadata } from 'next';
import Link from 'next/link';

export const metadata: Metadata = {
  title: 'Journals',
  description: 'Family journals and stories',
};

export default function JournalsPage() {
  return (
    <div className="w-full">
      <header className="bg-gradient-to-r from-slate-800 to-slate-900 border-b border-slate-700 p-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-white mb-2">الدفاتر</h1>
            <p className="text-slate-400">قصص وذكريات العائلة</p>
          </div>
          <Link
            href="/dashboard/journals/new"
            className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            + دفتر جديد
          </Link>
        </div>
      </header>

      <main className="p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <Link
              key={i}
              href={`/dashboard/journals/${i}`}
              className="bg-slate-800 rounded-lg border border-slate-700 p-6 hover:border-blue-600 transition-colors group"
            >
              <div className="h-40 bg-slate-700 rounded-lg mb-4 flex items-center justify-center group-hover:bg-slate-600">
                <svg className="w-12 h-12 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C6.5 6.253 2 10.998 2 17s4.5 10.747 10 10.747m0-13c5.5 0 10 4.745 10 10.747S17.5 27.747 12 27.747" />
                </svg>
              </div>
              <h3 className="font-semibold text-white mb-2 line-clamp-2">ذكريات من الطفولة</h3>
              <p className="text-sm text-slate-400 mb-4 line-clamp-3">
                هذا دفتر يحتوي على ذكريات جميلة من الطفولة والأوقات الجميلة مع العائلة...
              </p>
              <div className="flex items-center justify-between text-xs text-slate-500">
                <span>محمد علي</span>
                <span>2024-03-01</span>
              </div>
            </Link>
          ))}
        </div>
      </main>
    </div>
  );
}
