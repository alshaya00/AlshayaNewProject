import type { Metadata } from 'next';
import Link from 'next/link';

export const metadata: Metadata = {
  title: 'Journal',
  description: 'Family journal entry',
};

interface JournalPageProps {
  params: {
    id: string;
  };
}

export default function JournalPage({ params }: JournalPageProps) {
  return (
    <div className="w-full">
      <header className="bg-gradient-to-r from-slate-800 to-slate-900 border-b border-slate-700 p-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-white mb-2">ذكريات من الطفولة</h1>
            <p className="text-slate-400">كتبه محمد علي • 2024-03-01</p>
          </div>
          <div className="flex gap-3">
            <button className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
              تعديل
            </button>
            <button className="px-6 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors">
              حذف
            </button>
          </div>
        </div>
      </header>

      <main className="p-6 max-w-4xl">
        <div className="bg-slate-800 rounded-lg border border-slate-700 p-8">
          <article className="prose prose-invert max-w-none">
            <p className="text-slate-300 leading-relaxed mb-4">
              هذه مجموعة من الذكريات الجميلة من الطفولة، حيث كنت نقضي الأوقات الممتعة مع عائلتنا الكبيرة.
              كانت تلك الأيام من أجمل أيام حياتي، حيث كنا نجتمع جميعاً في منزل الجدة في الرياض.
            </p>

            <p className="text-slate-300 leading-relaxed mb-4">
              أتذكر كيف كنا نلعب مع إخوتي وأبناء العمومة في الفناء الخارجي، وكيف كانت جدتنا تجهز لنا الطعام اللذيذ
              في المطبخ. كانت تلك الأيام تملأ قلوبنا بالفرح والسعادة.
            </p>

            <p className="text-slate-300 leading-relaxed">
              أتمنى أن نستعيد تلك الأيام الجميلة مرة أخرى، حيث اجتماع العائلة الكبيرة يجعل الحياة أكثر جمالاً ومعنى.
              هذه الذكريات ستبقى محفوظة في قلبي وفي هذا الدفتر للأجيال القادمة.
            </p>
          </article>
        </div>

        {/* Comments Section */}
        <div className="mt-8">
          <h2 className="text-2xl font-bold text-white mb-6">التعليقات</h2>

          <div className="bg-slate-800 rounded-lg border border-slate-700 p-6 mb-6">
            <h3 className="font-semibold text-white mb-4">إضافة تعليق</h3>
            <textarea
              placeholder="شارك رأيك أو ذكرياتك..."
              rows={4}
              className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:ring-2 focus:ring-blue-500 mb-4"
              dir="rtl"
            />
            <button className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
              إضافة تعليق
            </button>
          </div>

          <div className="space-y-4">
            {[1, 2].map((i) => (
              <div key={i} className="bg-slate-800 rounded-lg border border-slate-700 p-6">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-full bg-slate-700 flex-shrink-0" />
                  <div className="flex-1">
                    <p className="font-semibold text-white">فاطمة الشايع</p>
                    <p className="text-xs text-slate-400">قبل يومين</p>
                    <p className="text-slate-300 mt-2">
                      ذكريات جميلة جداً! أتذكر تلك الأيام وكل ما تحتويه من فرح وسعادة.
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
}
