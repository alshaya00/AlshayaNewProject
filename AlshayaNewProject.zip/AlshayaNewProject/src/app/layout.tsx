import type { Metadata, Viewport } from 'next';
import { IBM_Plex_Sans_Arabic, Inter } from 'next/font/google';
import { dir } from 'i18next-resources-to-backend';
import './globals.css';
import { ThemeProvider } from '@/providers/theme-provider';
import { QueryProvider } from '@/providers/query-provider';

const arabicFont = IBM_Plex_Sans_Arabic({
  subsets: ['arabic', 'latin'],
  weight: ['300', '400', '500', '600', '700'],
  variable: '--font-arabic',
});

const englishFont = Inter({
  subsets: ['latin'],
  weight: ['300', '400', '500', '600', '700'],
  variable: '--font-english',
});

interface RootLayoutProps {
  children: React.ReactNode;
  params: {
    locale: 'ar' | 'en';
  };
}

export const metadata: Metadata = {
  title: {
    default: 'Alshaya Family Tree',
    template: '%s | Alshaya Family Tree',
  },
  description:
    'Comprehensive family tree application for آل شايع family with genealogical records, relationships, and historical data.',
  keywords: [
    'family tree',
    'genealogy',
    'آل شايع',
    'alshaya',
    'family records',
    'ancestry',
  ],
  authors: [{ name: 'Alshaya Development Team' }],
  creator: 'Alshaya Development Team',
  publisher: 'Alshaya Family',
  openGraph: {
    type: 'website',
    locale: 'ar_SA',
    url: 'https://alshaya.family',
    siteName: 'Alshaya Family Tree',
    title: 'Alshaya Family Tree',
    description: 'Comprehensive family tree application for آل شايع family',
    images: [
      {
        url: '/og-image.png',
        width: 1200,
        height: 630,
        alt: 'Alshaya Family Tree',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Alshaya Family Tree',
    description: 'Comprehensive family tree application for آل شايع family',
    images: ['/og-image.png'],
  },
  appleWebApp: {
    capable: true,
    statusBarStyle: 'black-translucent',
    title: 'Alshaya Family Tree',
  },
  formatDetection: {
    telephone: true,
    email: true,
    address: true,
  },
};

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  viewportFit: 'cover',
  colorScheme: 'dark light',
  themeColor: '#1A1F3A',
};

export async function generateStaticParams() {
  return [{ locale: 'ar' }, { locale: 'en' }];
}

export default function RootLayout({ children, params }: RootLayoutProps) {
  const isArabic = params.locale === 'ar';

  return (
    <html
      lang={params.locale}
      dir={isArabic ? 'rtl' : 'ltr'}
      suppressHydrationWarning
      className={`${arabicFont.variable} ${englishFont.variable}`}
    >
      <head>
        <meta charSet="utf-8" />
        <meta name="mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
        <meta
          name="apple-mobile-web-app-title"
          content="Alshaya Family Tree"
        />
        <link rel="icon" href="/favicon.ico" />
        <link rel="apple-touch-icon" href="/apple-touch-icon.png" />
        <link rel="manifest" href="/manifest.json" />
      </head>
      <body className="antialiased">
        <ThemeProvider attribute="class" defaultTheme="dark" enableSystem>
          <QueryProvider>
            <div className="relative flex flex-col min-h-screen bg-background">
              {children}
            </div>
          </QueryProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}
