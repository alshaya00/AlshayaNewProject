import { NextRequest } from 'next/server';
import { requireAuth } from '@/lib/auth/middleware';
import { validateCSRFToken } from '@/lib/auth/csrf';
import { standardResponse, errorResponse } from '@/lib/api/response';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10MB
const ALLOWED_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'application/pdf'];

async function saveFile(
  file: File,
  userId: string
): Promise<{ url: string; filename: string }> {
  try {
    // Validate file size
    if (file.size > MAX_FILE_SIZE) {
      throw new Error('File size exceeds limit');
    }

    // Validate file type
    if (!ALLOWED_TYPES.includes(file.type)) {
      throw new Error('File type not allowed');
    }

    // In production, upload to cloud storage (S3, GCS, etc.)
    // For now, return a mock URL
    const filename = `${userId}-${Date.now()}-${file.name}`;
    const url = `/uploads/${filename}`;

    console.log('File saved:', { filename, size: file.size, type: file.type });

    return { url, filename };
  } catch (error) {
    console.error('Error saving file:', error);
    throw error;
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await requireAuth(request);
    await validateCSRFToken(request);

    const formData = await request.formData();
    const file = formData.get('file') as File;

    if (!file) {
      return errorResponse('No file provided', 400);
    }

    const { url, filename } = await saveFile(file, user.id);

    return standardResponse(
      {
        url,
        filename,
        size: file.size,
        type: file.type,
        uploadedAt: new Date(),
      },
      201
    );
  } catch (error) {
    const message =
      error instanceof Error ? error.message : 'File upload failed';
    console.error('Error uploading file:', error);
    return errorResponse(message, 500);
  }
}
