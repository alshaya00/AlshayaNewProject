import { NextRequest } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/prisma';
import { requireAuth } from '@/lib/auth/middleware';
import { standardResponse, errorResponse } from '@/lib/api/response';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

const validateMemberSchema = z.object({
  firstName: z.string().min(1).max(100),
  gender: z.enum(['MALE', 'FEMALE', 'OTHER', 'UNSPECIFIED']),
  fatherId: z.string().optional(),
  motherId: z.string().optional(),
  birthYear: z.number().int().optional(),
  deathYear: z.number().int().optional(),
  email: z.string().email().optional(),
  phone: z.string().optional(),
});

interface ValidationResult {
  valid: boolean;
  errors: string[];
  warnings: string[];
  suggestions: string[];
}

async function validateMemberData(
  data: any
): Promise<ValidationResult> {
  const result: ValidationResult = {
    valid: true,
    errors: [],
    warnings: [],
    suggestions: [],
  };

  // Validate required fields
  if (!data.firstName || typeof data.firstName !== 'string') {
    result.errors.push('firstName is required and must be a string');
    result.valid = false;
  }

  if (!data.gender || !['MALE', 'FEMALE', 'OTHER', 'UNSPECIFIED'].includes(data.gender)) {
    result.errors.push('gender must be one of: MALE, FEMALE, OTHER, UNSPECIFIED');
    result.valid = false;
  }

  // Validate parent references
  if (data.fatherId) {
    const father = await prisma.familyMember.findUnique({
      where: { id: data.fatherId },
    });
    if (!father) {
      result.errors.push(`Father with ID ${data.fatherId} not found`);
      result.valid = false;
    }
    if (father && father.gender !== 'MALE') {
      result.warnings.push('Father is not marked as MALE');
    }
  }

  if (data.motherId) {
    const mother = await prisma.familyMember.findUnique({
      where: { id: data.motherId },
    });
    if (!mother) {
      result.errors.push(`Mother with ID ${data.motherId} not found`);
      result.valid = false;
    }
    if (mother && mother.gender !== 'FEMALE') {
      result.warnings.push('Mother is not marked as FEMALE');
    }
  }

  // Validate dates
  const currentYear = new Date().getFullYear();
  if (data.birthYear) {
    if (data.birthYear < 1800 || data.birthYear > currentYear) {
      result.warnings.push(`Birth year ${data.birthYear} seems unusual`);
    }
  }

  if (data.deathYear) {
    if (data.birthYear && data.deathYear < data.birthYear) {
      result.errors.push('Death year cannot be before birth year');
      result.valid = false;
    }
    if (data.deathYear > currentYear) {
      result.warnings.push('Death year is in the future');
    }
  }

  // Validate email
  if (data.email) {
    const existingEmail = await prisma.familyMember.findFirst({
      where: { email: data.email },
    });
    if (existingEmail) {
      result.suggestions.push(`Email ${data.email} is already registered to another member`);
    }
  }

  // Validate phone format (basic validation)
  if (data.phone && !/^\+?[0-9\s\-()]+$/.test(data.phone)) {
    result.warnings.push('Phone number format seems invalid');
  }

  // Suggestions
  if (data.firstName && data.firstName.length < 2) {
    result.suggestions.push('First name is very short, consider adding full name');
  }

  return result;
}

export async function POST(request: NextRequest) {
  try {
    const user = await requireAuth(request);
    const body = await request.json();

    // Validate schema first
    try {
      validateMemberSchema.parse(body);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return standardResponse({
          valid: false,
          schemaErrors: error.errors,
        });
      }
    }

    const validation = await validateMemberData(body);

    return standardResponse({
      ...validation,
      timestamp: new Date(),
    });
  } catch (error) {
    console.error('Error validating member:', error);
    return errorResponse('Failed to validate member data', 500);
  }
}
