import { NextRequest } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/prisma';
import { requireAuth } from '@/lib/auth/middleware';
import { standardResponse, errorResponse } from '@/lib/api/response';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

const querySchema = z.object({
  page: z.string().transform(Number).default('1'),
  limit: z.string().transform(Number).default('50'),
  type: z.string().optional(),
  startDate: z.string().optional(),
  endDate: z.string().optional(),
});

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = await requireAuth(request);
    const id = params.id;

    const query = querySchema.parse(
      Object.fromEntries(request.nextUrl.searchParams)
    );

    const page = Math.max(1, query.page);
    const limit = Math.min(500, Math.max(1, query.limit));
    const skip = (page - 1) * limit;

    const member = await prisma.familyMember.findUnique({
      where: { id },
      select: { id: true, deletedAt: true },
    });

    if (!member) {
      return errorResponse('Member not found', 404);
    }

    if (member.deletedAt) {
      return errorResponse('Member has been deleted', 410);
    }

    const where: any = { memberId: id };

    if (query.type) {
      where.changeType = query.type;
    }

    if (query.startDate || query.endDate) {
      where.changedAt = {};
      if (query.startDate) {
        where.changedAt.gte = new Date(query.startDate);
      }
      if (query.endDate) {
        where.changedAt.lte = new Date(query.endDate);
      }
    }

    const [changes, total] = await Promise.all([
      prisma.changeHistory.findMany({
        where,
        skip,
        take: limit,
        select: {
          id: true,
          fieldName: true,
          oldValue: true,
          newValue: true,
          changeType: true,
          changedBy: true,
          changedByName: true,
          changedAt: true,
          reason: true,
          hasMaskedData: true,
        },
        orderBy: { changedAt: 'desc' },
      }),
      prisma.changeHistory.count({ where }),
    ]);

    return standardResponse({
      memberId: id,
      changes,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Error fetching change history:', error);
    return errorResponse('Failed to fetch change history', 500);
  }
}
