import { NextRequest } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireAuth } from '@/lib/auth/middleware';
import { standardResponse, errorResponse } from '@/lib/api/response';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

async function getAncestors(memberId: string): Promise<any[]> {
  const ancestors: any[] = [];
  let currentId: string | null = memberId;

  while (currentId) {
    const member = await prisma.familyMember.findUnique({
      where: { id: currentId },
      select: {
        id: true,
        firstName: true,
        fullNameAr: true,
        generation: true,
        fatherId: true,
        motherId: true,
        birthYear: true,
        status: true,
      },
    });

    if (!member) break;
    ancestors.unshift(member);
    currentId = member.fatherId;
  }

  return ancestors;
}

async function getDescendants(memberId: string, depth: number = 10): Promise<any[]> {
  const descendants: any[] = [];

  async function traverse(id: string, currentDepth: number) {
    if (currentDepth > depth) return;

    const children = await prisma.familyMember.findMany({
      where: {
        fatherId: id,
        deletedAt: null,
      },
      select: {
        id: true,
        firstName: true,
        fullNameAr: true,
        gender: true,
        generation: true,
        birthYear: true,
        status: true,
      },
    });

    for (const child of children) {
      descendants.push({
        ...child,
        depth: currentDepth,
      });
      await traverse(child.id, currentDepth + 1);
    }
  }

  await traverse(memberId, 1);
  return descendants;
}

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = await requireAuth(request);
    const id = params.id;
    const typeParam = request.nextUrl.searchParams.get('type') || 'all';
    const depthParam = request.nextUrl.searchParams.get('depth');
    const depth = depthParam ? Math.min(20, parseInt(depthParam)) : 10;

    const member = await prisma.familyMember.findUnique({
      where: { id },
      select: {
        id: true,
        firstName: true,
        fullNameAr: true,
        generation: true,
        lineageBranchId: true,
        lineageBranchName: true,
        subBranchId: true,
        subBranchName: true,
        deletedAt: true,
      },
    });

    if (!member) {
      return errorResponse('Member not found', 404);
    }

    if (member.deletedAt) {
      return errorResponse('Member has been deleted', 410);
    }

    const result: any = {
      member: {
        id: member.id,
        firstName: member.firstName,
        fullNameAr: member.fullNameAr,
        generation: member.generation,
        lineageBranchId: member.lineageBranchId,
        lineageBranchName: member.lineageBranchName,
        subBranchId: member.subBranchId,
        subBranchName: member.subBranchName,
      },
    };

    if (typeParam === 'all' || typeParam === 'ancestors') {
      result.ancestors = await getAncestors(id);
    }

    if (typeParam === 'all' || typeParam === 'descendants') {
      result.descendants = await getDescendants(id, depth);
    }

    if (typeParam === 'all') {
      result.statistics = {
        ancestorCount: result.ancestors.length,
        descendantCount: result.descendants.length,
        depth,
      };
    }

    return standardResponse(result);
  } catch (error) {
    console.error('Error fetching lineage:', error);
    return errorResponse('Failed to fetch lineage', 500);
  }
}
