import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/prisma';
import { requireAuth } from '@/lib/auth/middleware';
import { validateCSRFToken } from '@/lib/auth/csrf';
import { standardResponse, errorResponse } from '@/lib/api/response';
import { createAuditLog } from '@/lib/audit';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

const updateMemberSchema = z.object({
  firstName: z.string().min(1).max(100).optional(),
  fullNameEn: z.string().optional(),
  fullNameAr: z.string().optional(),
  gender: z.enum(['MALE', 'FEMALE', 'OTHER', 'UNSPECIFIED']).optional(),
  birthYear: z.number().int().optional(),
  birthCalendar: z.enum(['GREGORIAN', 'HIJRI', 'BOTH']).optional(),
  deathYear: z.number().int().optional(),
  status: z.enum(['LIVING', 'DECEASED', 'UNKNOWN', 'ARCHIVED']).optional(),
  fatherId: z.string().optional().nullable(),
  motherId: z.string().optional().nullable(),
  phone: z.string().optional(),
  email: z.string().email().optional(),
  city: z.string().optional(),
  occupation: z.string().optional(),
  biography: z.string().optional(),
  branch: z.string().optional(),
  photoUrl: z.string().optional(),
});

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = await requireAuth(request);
    const id = params.id;

    const member = await prisma.familyMember.findUnique({
      where: { id },
      include: {
        father: {
          select: {
            id: true,
            firstName: true,
            fullNameAr: true,
          },
        },
        mother: {
          select: {
            id: true,
            firstName: true,
            fullNameAr: true,
          },
        },
        children: {
          select: {
            id: true,
            firstName: true,
            gender: true,
            birthYear: true,
          },
        },
        photos: {
          select: {
            id: true,
            url: true,
            caption: true,
          },
        },
      },
    });

    if (!member) {
      return errorResponse('Member not found', 404);
    }

    if (member.deletedAt) {
      return errorResponse('Member has been deleted', 410);
    }

    return standardResponse(member);
  } catch (error) {
    console.error('Error fetching member:', error);
    return errorResponse('Failed to fetch member', 500);
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = await requireAuth(request);
    await validateCSRFToken(request);

    const id = params.id;
    const body = updateMemberSchema.parse(await request.json());

    const existing = await prisma.familyMember.findUnique({
      where: { id },
    });

    if (!existing) {
      return errorResponse('Member not found', 404);
    }

    if (existing.deletedAt) {
      return errorResponse('Cannot update deleted member', 410);
    }

    // Validate parent references
    if (body.fatherId !== undefined && body.fatherId !== null) {
      const father = await prisma.familyMember.findUnique({
        where: { id: body.fatherId },
      });
      if (!father) {
        return errorResponse('Father not found', 400);
      }
    }

    if (body.motherId !== undefined && body.motherId !== null) {
      const mother = await prisma.familyMember.findUnique({
        where: { id: body.motherId },
      });
      if (!mother) {
        return errorResponse('Mother not found', 400);
      }
    }

    // Track changes for audit log
    const changes: Record<string, any> = {};
    for (const [key, value] of Object.entries(body)) {
      if (value !== undefined && (existing as any)[key] !== value) {
        changes[key] = {
          old: (existing as any)[key],
          new: value,
        };
      }
    }

    const updated = await prisma.familyMember.update({
      where: { id },
      data: {
        ...body,
        lastModifiedBy: user.id,
        updatedAt: new Date(),
      },
    });

    // Log changes
    for (const [field, change] of Object.entries(changes)) {
      await createAuditLog({
        memberId: id,
        fieldName: field,
        changeType: 'UPDATE',
        changedBy: user.id,
        changedByName: user.email,
        oldValue: String(change.old),
        newValue: String(change.new),
      });
    }

    return standardResponse(updated);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return errorResponse('Validation error', 400, error.errors);
    }
    console.error('Error updating member:', error);
    return errorResponse('Failed to update member', 500);
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = await requireAuth(request);
    await validateCSRFToken(request);

    const id = params.id;
    const body = await request.json().catch(() => ({}));
    const reason = body.reason || 'No reason provided';

    const existing = await prisma.familyMember.findUnique({
      where: { id },
    });

    if (!existing) {
      return errorResponse('Member not found', 404);
    }

    if (existing.deletedAt) {
      return errorResponse('Member already deleted', 410);
    }

    // Soft delete
    const deleted = await prisma.familyMember.update({
      where: { id },
      data: {
        deletedAt: new Date(),
        deletedBy: user.id,
        deletedReason: reason,
      },
    });

    await createAuditLog({
      memberId: id,
      fieldName: 'member_deleted',
      changeType: 'DELETE',
      changedBy: user.id,
      changedByName: user.email,
      reason,
    });

    return standardResponse(
      { message: 'Member deleted successfully', deleted },
      200
    );
  } catch (error) {
    console.error('Error deleting member:', error);
    return errorResponse('Failed to delete member', 500);
  }
}
