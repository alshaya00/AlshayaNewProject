import { NextRequest } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/prisma';
import { requireAuth } from '@/lib/auth/middleware';
import { validateCSRFToken } from '@/lib/auth/csrf';
import { standardResponse, errorResponse } from '@/lib/api/response';
import { createAuditLog } from '@/lib/audit';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

const createPhotoSchema = z.object({
  url: z.string().url(),
  caption: z.string().optional(),
  uploadedBy: z.string().optional(),
  moderationStatus: z.enum(['PENDING', 'APPROVED', 'REJECTED', 'FLAGGED']).default('PENDING'),
});

interface MemberPhoto {
  id: string;
  url: string;
  caption?: string;
  uploadedAt: Date;
  moderationStatus: string;
  uploadedBy?: string;
}

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = await requireAuth(request);
    const id = params.id;

    const member = await prisma.familyMember.findUnique({
      where: { id },
      select: { deletedAt: true },
    });

    if (!member) {
      return errorResponse('Member not found', 404);
    }

    if (member.deletedAt) {
      return errorResponse('Member has been deleted', 410);
    }

    // Get photos from database (schema dependent)
    // This assumes a MemberPhoto model exists in Prisma schema
    const photos = await prisma.memberPhoto.findMany({
      where: {
        memberId: id,
        deletedAt: null,
      },
      select: {
        id: true,
        url: true,
        caption: true,
        createdAt: true,
        moderationStatus: true,
      },
      orderBy: { createdAt: 'desc' },
    });

    return standardResponse({
      memberId: id,
      photos,
      totalPhotos: photos.length,
    });
  } catch (error) {
    console.error('Error fetching photos:', error);
    return errorResponse('Failed to fetch photos', 500);
  }
}

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = await requireAuth(request);
    await validateCSRFToken(request);

    const id = params.id;
    const body = createPhotoSchema.parse(await request.json());

    const member = await prisma.familyMember.findUnique({
      where: { id },
      select: { id: true, deletedAt: true },
    });

    if (!member) {
      return errorResponse('Member not found', 404);
    }

    if (member.deletedAt) {
      return errorResponse('Cannot add photos to deleted member', 410);
    }

    const photo = await prisma.memberPhoto.create({
      data: {
        memberId: id,
        url: body.url,
        caption: body.caption,
        moderationStatus: body.moderationStatus,
        uploadedBy: user.id,
      },
    });

    await createAuditLog({
      memberId: id,
      fieldName: 'photo_added',
      changeType: 'CREATE',
      changedBy: user.id,
      changedByName: user.email,
      newValue: photo.url,
    });

    return standardResponse(photo, 201);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return errorResponse('Validation error', 400, error.errors);
    }
    console.error('Error uploading photo:', error);
    return errorResponse('Failed to upload photo', 500);
  }
}
