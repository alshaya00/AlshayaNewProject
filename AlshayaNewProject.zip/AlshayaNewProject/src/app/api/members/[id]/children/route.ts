import { NextRequest } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireAuth } from '@/lib/auth/middleware';
import { standardResponse, errorResponse } from '@/lib/api/response';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = await requireAuth(request);
    const id = params.id;

    const member = await prisma.familyMember.findUnique({
      where: { id },
      include: {
        children: {
          where: { deletedAt: null },
          select: {
            id: true,
            firstName: true,
            fullNameAr: true,
            fullNameEn: true,
            gender: true,
            birthYear: true,
            status: true,
            generation: true,
            photoUrl: true,
          },
          orderBy: { birthYear: 'desc' },
        },
        childrenByMother: {
          where: { deletedAt: null },
          select: {
            id: true,
            firstName: true,
            fullNameAr: true,
            fullNameEn: true,
            gender: true,
            birthYear: true,
            status: true,
            generation: true,
            photoUrl: true,
          },
          orderBy: { birthYear: 'desc' },
        },
      },
    });

    if (!member) {
      return errorResponse('Member not found', 404);
    }

    if (member.deletedAt) {
      return errorResponse('Member has been deleted', 410);
    }

    return standardResponse({
      memberId: id,
      childrenByFather: member.children,
      childrenByMother: member.childrenByMother,
      totalChildren: member.children.length + member.childrenByMother.length,
      sons: member.children.filter(c => c.gender === 'MALE').length,
      daughters: member.children.filter(c => c.gender === 'FEMALE').length,
    });
  } catch (error) {
    console.error('Error fetching children:', error);
    return errorResponse('Failed to fetch children', 500);
  }
}
