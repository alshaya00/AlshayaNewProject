import { NextRequest } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireAuth } from '@/lib/auth/middleware';
import { standardResponse, errorResponse } from '@/lib/api/response';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

async function getRelationships(memberId: string) {
  const member = await prisma.familyMember.findUnique({
    where: { id: memberId },
    select: {
      id: true,
      firstName: true,
      gender: true,
      fatherId: true,
      motherId: true,
    },
  });

  if (!member) return null;

  const relationships: any = {
    direct: {},
    extended: {},
  };

  // Father
  if (member.fatherId) {
    const father = await prisma.familyMember.findUnique({
      where: { id: member.fatherId },
      select: { id: true, firstName: true, fullNameAr: true },
    });
    if (father) {
      relationships.direct.father = { type: 'FATHER', member: father };
    }
  }

  // Mother
  if (member.motherId) {
    const mother = await prisma.familyMember.findUnique({
      where: { id: member.motherId },
      select: { id: true, firstName: true, fullNameAr: true },
    });
    if (mother) {
      relationships.direct.mother = { type: 'MOTHER', member: mother };
    }
  }

  // Children
  const children = await prisma.familyMember.findMany({
    where: { fatherId: memberId, deletedAt: null },
    select: { id: true, firstName: true, gender: true, fullNameAr: true },
  });
  relationships.direct.children = children.map(c => ({
    type: c.gender === 'MALE' ? 'SON' : 'DAUGHTER',
    member: c,
  }));

  // Siblings
  if (member.fatherId) {
    const siblings = await prisma.familyMember.findMany({
      where: {
        fatherId: member.fatherId,
        id: { not: memberId },
        deletedAt: null,
      },
      select: { id: true, firstName: true, gender: true, fullNameAr: true },
    });
    relationships.direct.siblings = siblings.map(s => ({
      type: s.gender === 'MALE' ? 'BROTHER' : 'SISTER',
      member: s,
    }));
  }

  // Extended: Grandchildren
  const grandchildren = await prisma.familyMember.findMany({
    where: {
      father: {
        fatherId: memberId,
      },
      deletedAt: null,
    },
    select: { id: true, firstName: true, gender: true, fullNameAr: true },
  });
  relationships.extended.grandchildren = grandchildren.map(gc => ({
    type: gc.gender === 'MALE' ? 'GRANDSON' : 'GRANDDAUGHTER',
    member: gc,
  }));

  // Extended: Paternal uncles/aunts
  if (member.fatherId) {
    const paternal = await prisma.familyMember.findMany({
      where: {
        fatherId: (await prisma.familyMember.findUnique({
          where: { id: member.fatherId },
          select: { fatherId: true },
        }))?.fatherId,
        id: { not: member.fatherId },
        deletedAt: null,
      },
      select: { id: true, firstName: true, gender: true, fullNameAr: true },
    });
    relationships.extended.paternalFamily = paternal.map(p => ({
      type: p.gender === 'MALE' ? 'UNCLE' : 'AUNT',
      member: p,
    }));
  }

  // Extended: Cousins
  if (member.fatherId) {
    const fathersFather = await prisma.familyMember.findUnique({
      where: { id: member.fatherId },
      select: { fatherId: true },
    });

    if (fathersFather?.fatherId) {
      const uncles = await prisma.familyMember.findMany({
        where: {
          fatherId: fathersFather.fatherId,
          id: { not: member.fatherId },
          deletedAt: null,
        },
        select: { id: true },
      });

      const cousins = await prisma.familyMember.findMany({
        where: {
          fatherId: { in: uncles.map(u => u.id) },
          deletedAt: null,
        },
        select: { id: true, firstName: true, fullNameAr: true },
      });
      relationships.extended.cousins = cousins.map(c => ({
        type: 'COUSIN',
        member: c,
      }));
    }
  }

  return relationships;
}

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = await requireAuth(request);
    const id = params.id;

    const member = await prisma.familyMember.findUnique({
      where: { id },
      select: { deletedAt: true },
    });

    if (!member) {
      return errorResponse('Member not found', 404);
    }

    if (member.deletedAt) {
      return errorResponse('Member has been deleted', 410);
    }

    const relationships = await getRelationships(id);
    if (!relationships) {
      return errorResponse('Member not found', 404);
    }

    return standardResponse(relationships);
  } catch (error) {
    console.error('Error fetching relationships:', error);
    return errorResponse('Failed to fetch relationships', 500);
  }
}
