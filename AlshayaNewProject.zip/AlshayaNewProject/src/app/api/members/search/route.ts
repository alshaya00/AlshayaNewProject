import { NextRequest } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/prisma';
import { requireAuth } from '@/lib/auth/middleware';
import { standardResponse, errorResponse } from '@/lib/api/response';
import { normalizeArabicName } from '@/lib/utils/arabic';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

const searchSchema = z.object({
  query: z.string().min(1),
  page: z.string().transform(Number).default('1'),
  limit: z.string().transform(Number).default('50'),
  fuzzy: z.string().transform(v => v === 'true').default('false'),
  fields: z.string().default('firstName,fullNameAr,fullNameEn'),
});

function normalizeForSearch(text: string): string {
  return normalizeArabicName(text).toLowerCase();
}

function calculateLevenshteinDistance(a: string, b: string): number {
  const matrix: number[][] = [];

  for (let i = 0; i <= b.length; i++) {
    matrix[i] = [i];
  }

  for (let j = 0; j <= a.length; j++) {
    matrix[0][j] = j;
  }

  for (let i = 1; i <= b.length; i++) {
    for (let j = 1; j <= a.length; j++) {
      if (b.charAt(i - 1) === a.charAt(j - 1)) {
        matrix[i][j] = matrix[i - 1][j - 1];
      } else {
        matrix[i][j] = Math.min(
          matrix[i - 1][j - 1] + 1,
          matrix[i][j - 1] + 1,
          matrix[i - 1][j] + 1
        );
      }
    }
  }

  return matrix[b.length][a.length];
}

function fuzzyMatch(query: string, text: string, maxDistance: number = 2): boolean {
  const normalized = normalizeForSearch(text);
  const normalizedQuery = normalizeForSearch(query);

  if (normalized.includes(normalizedQuery)) {
    return true;
  }

  const distance = calculateLevenshteinDistance(normalizedQuery, normalized);
  return distance <= maxDistance;
}

export async function GET(request: NextRequest) {
  try {
    const user = await requireAuth(request);

    const params = searchSchema.parse(
      Object.fromEntries(request.nextUrl.searchParams)
    );

    const page = Math.max(1, params.page);
    const limit = Math.min(500, Math.max(1, params.limit));
    const skip = (page - 1) * limit;

    const members = await prisma.familyMember.findMany({
      where: { deletedAt: null },
      select: {
        id: true,
        firstName: true,
        fullNameEn: true,
        fullNameAr: true,
        gender: true,
        birthYear: true,
        generation: true,
        branch: true,
        photoUrl: true,
        city: true,
      },
      take: limit * 3, // Get more results to filter with fuzzy matching
    });

    let results = members;

    if (params.fuzzy) {
      // Fuzzy matching with Levenshtein distance
      results = members.filter(member => {
        const fieldsToSearch = params.fields.split(',');
        return fieldsToSearch.some(field => {
          const value = (member as any)[field];
          if (!value) return false;
          return fuzzyMatch(params.query, value);
        });
      });
    } else {
      // Exact substring matching (case-insensitive)
      const normalized = normalizeForSearch(params.query);
      results = members.filter(member => {
        const fieldsToSearch = params.fields.split(',');
        return fieldsToSearch.some(field => {
          const value = (member as any)[field];
          if (!value) return false;
          return normalizeForSearch(value).includes(normalized);
        });
      });
    }

    const total = results.length;
    const paginatedResults = results.slice(skip, skip + limit);

    return standardResponse({
      query: params.query,
      results: paginatedResults,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit),
      },
      fuzzyMatching: params.fuzzy,
    });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return errorResponse('Validation error', 400, error.errors);
    }
    console.error('Error searching members:', error);
    return errorResponse('Failed to search members', 500);
  }
}
