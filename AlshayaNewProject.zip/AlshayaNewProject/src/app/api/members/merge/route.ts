import { NextRequest } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/prisma';
import { requireAuth } from '@/lib/auth/middleware';
import { validateCSRFToken } from '@/lib/auth/csrf';
import { standardResponse, errorResponse } from '@/lib/api/response';
import { createAuditLog } from '@/lib/audit';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

const mergeMembersSchema = z.object({
  sourceId: z.string(),
  targetId: z.string(),
  keepFields: z.record(z.string()).optional(),
  reason: z.string().optional(),
});

export async function POST(request: NextRequest) {
  try {
    const user = await requireAuth(request);
    await validateCSRFToken(request);

    const body = mergeMembersSchema.parse(await request.json());

    if (body.sourceId === body.targetId) {
      return errorResponse('Cannot merge member with itself', 400);
    }

    const [source, target] = await Promise.all([
      prisma.familyMember.findUnique({ where: { id: body.sourceId } }),
      prisma.familyMember.findUnique({ where: { id: body.targetId } }),
    ]);

    if (!source || !target) {
      return errorResponse('One or both members not found', 404);
    }

    if (source.deletedAt || target.deletedAt) {
      return errorResponse('Cannot merge deleted members', 410);
    }

    // Start transaction for atomic merge
    const result = await prisma.$transaction(async (tx) => {
      // Update children to point to target
      await tx.familyMember.updateMany({
        where: { fatherId: body.sourceId },
        data: { fatherId: body.targetId },
      });

      await tx.familyMember.updateMany({
        where: { motherId: body.sourceId },
        data: { motherId: body.targetId },
      });

      // Update duplicate flags
      const duplicateFlags = await tx.duplicateFlag.findMany({
        where: {
          OR: [
            { sourceId: body.sourceId },
            { targetId: body.sourceId },
          ],
        },
      });

      for (const flag of duplicateFlags) {
        await tx.duplicateFlag.update({
          where: { id: flag.id },
          data: {
            sourceId: flag.sourceId === body.sourceId ? body.targetId : flag.sourceId,
            targetId: flag.targetId === body.sourceId ? body.targetId : flag.targetId,
            resolutionStatus: 'MERGED',
            resolvedAt: new Date(),
            resolvedBy: user.id,
          },
        });
      }

      // Create a snapshot before merge
      const snapshot = await tx.treeSnapshot.create({
        data: {
          name: `Pre-merge snapshot: ${source.firstName} -> ${target.firstName}`,
          snapshotType: 'PRE_MERGE',
          createdBy: user.id,
          metadata: JSON.stringify({
            sourceMemberId: body.sourceId,
            targetMemberId: body.targetId,
            reason: body.reason,
          }),
        },
      });

      // Soft delete source
      const deleted = await tx.familyMember.update({
        where: { id: body.sourceId },
        data: {
          deletedAt: new Date(),
          deletedBy: user.id,
          deletedReason: `Merged with ${body.targetId}`,
        },
      });

      // Log merge
      await tx.changeHistory.create({
        data: {
          memberId: body.sourceId,
          fieldName: 'member_merged',
          changeType: 'MERGE',
          changedBy: user.id,
          changedByName: user.email,
          newValue: body.targetId,
          reason: body.reason || 'Duplicate member merge',
        },
      });

      return {
        snapshot,
        deleted,
      };
    });

    await createAuditLog({
      memberId: body.sourceId,
      fieldName: 'member_merged',
      changeType: 'MERGE',
      changedBy: user.id,
      changedByName: user.email,
      oldValue: body.sourceId,
      newValue: body.targetId,
      reason: body.reason || 'Member merged',
    });

    return standardResponse({
      message: 'Members merged successfully',
      sourceId: body.sourceId,
      targetId: body.targetId,
      snapshotId: result.snapshot.id,
    });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return errorResponse('Validation error', 400, error.errors);
    }
    console.error('Error merging members:', error);
    return errorResponse('Failed to merge members', 500);
  }
}
