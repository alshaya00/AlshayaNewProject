import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/prisma';
import { requireAuth } from '@/lib/auth/middleware';
import { validateCSRFToken } from '@/lib/auth/csrf';
import { standardResponse, errorResponse } from '@/lib/api/response';
import { createAuditLog } from '@/lib/audit';
import { normalizeArabicName } from '@/lib/utils/arabic';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

const createMemberSchema = z.object({
  firstName: z.string().min(1).max(100),
  fullNameEn: z.string().optional(),
  fullNameAr: z.string().optional(),
  gender: z.enum(['MALE', 'FEMALE', 'OTHER', 'UNSPECIFIED']),
  birthYear: z.number().int().optional(),
  birthCalendar: z.enum(['GREGORIAN', 'HIJRI', 'BOTH']).default('GREGORIAN'),
  deathYear: z.number().int().optional(),
  status: z.enum(['LIVING', 'DECEASED', 'UNKNOWN', 'ARCHIVED']).default('LIVING'),
  fatherId: z.string().optional(),
  motherId: z.string().optional(),
  generation: z.number().int().min(1).max(20).optional(),
  phone: z.string().optional(),
  email: z.string().email().optional(),
  city: z.string().optional(),
  occupation: z.string().optional(),
  biography: z.string().optional(),
  branch: z.string().optional(),
  photoUrl: z.string().optional(),
});

const listMembersSchema = z.object({
  page: z.string().transform(Number).default('1'),
  limit: z.string().transform(Number).default('50'),
  gender: z.string().optional(),
  generation: z.string().transform(Number).optional(),
  branch: z.string().optional(),
  status: z.string().optional(),
  search: z.string().optional(),
});

export async function GET(request: NextRequest) {
  try {
    const user = await requireAuth(request);

    const params = listMembersSchema.parse(
      Object.fromEntries(request.nextUrl.searchParams)
    );

    const page = Math.max(1, params.page);
    const limit = Math.min(500, Math.max(1, params.limit));
    const skip = (page - 1) * limit;

    const where: any = { deletedAt: null };

    if (params.gender) where.gender = params.gender;
    if (params.generation) where.generation = params.generation;
    if (params.branch) where.branch = params.branch;
    if (params.status) where.status = params.status;

    if (params.search) {
      const searchTerm = params.search.toLowerCase();
      where.OR = [
        { firstName: { contains: searchTerm, mode: 'insensitive' } },
        { fullNameEn: { contains: searchTerm, mode: 'insensitive' } },
        { fullNameAr: { contains: searchTerm, mode: 'insensitive' } },
        { id: { contains: searchTerm, mode: 'insensitive' } },
        { city: { contains: searchTerm, mode: 'insensitive' } },
      ];
    }

    const [members, total] = await Promise.all([
      prisma.familyMember.findMany({
        where,
        skip,
        take: limit,
        select: {
          id: true,
          firstName: true,
          fullNameEn: true,
          fullNameAr: true,
          gender: true,
          birthYear: true,
          status: true,
          generation: true,
          branch: true,
          photoUrl: true,
          createdAt: true,
        },
        orderBy: { createdAt: 'desc' },
      }),
      prisma.familyMember.count({ where }),
    ]);

    return standardResponse(
      {
        data: members,
        pagination: {
          page,
          limit,
          total,
          pages: Math.ceil(total / limit),
        },
      },
      200
    );
  } catch (error) {
    console.error('Error fetching members:', error);
    return errorResponse('Failed to fetch members', 500);
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await requireAuth(request);
    await validateCSRFToken(request);

    const body = createMemberSchema.parse(await request.json());

    // Validate parent references
    if (body.fatherId) {
      const father = await prisma.familyMember.findUnique({
        where: { id: body.fatherId },
      });
      if (!father) {
        return errorResponse('Father not found', 400);
      }
    }

    if (body.motherId) {
      const mother = await prisma.familyMember.findUnique({
        where: { id: body.motherId },
      });
      if (!mother) {
        return errorResponse('Mother not found', 400);
      }
    }

    const member = await prisma.familyMember.create({
      data: {
        firstName: body.firstName.trim(),
        fullNameEn: body.fullNameEn?.trim(),
        fullNameAr: body.fullNameAr?.trim(),
        gender: body.gender,
        birthYear: body.birthYear,
        birthCalendar: body.birthCalendar,
        deathYear: body.deathYear,
        status: body.status,
        fatherId: body.fatherId,
        motherId: body.motherId,
        generation: body.generation || 1,
        phone: body.phone,
        email: body.email,
        city: body.city,
        occupation: body.occupation,
        biography: body.biography,
        branch: body.branch,
        photoUrl: body.photoUrl,
        createdBy: user.id,
      },
    });

    await createAuditLog({
      memberId: member.id,
      fieldName: 'member_created',
      changeType: 'CREATE',
      changedBy: user.id,
      changedByName: user.email,
      newValue: JSON.stringify(member),
    });

    return standardResponse(member, 201);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return errorResponse('Validation error', 400, error.errors);
    }
    console.error('Error creating member:', error);
    return errorResponse('Failed to create member', 500);
  }
}
