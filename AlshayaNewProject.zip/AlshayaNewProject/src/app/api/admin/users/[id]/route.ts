/**
 * GET /api/admin/users/[id] - Get user details
 * PUT /api/admin/users/[id] - Update user
 * DELETE /api/admin/users/[id] - Delete user
 * Admin user management for specific user
 */

import { NextRequest, NextResponse } from 'next/server';
import { authenticateRequest, formatAuthError } from '@/lib/auth/middleware';
import { validateInput, updateUserSchema, formatZodErrors } from '@/lib/validation/schemas';

export const dynamic = 'force-dynamic';

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    // Verify authentication and admin role
    const auth = await authenticateRequest({
      cookies: {
        alshaya_session:
          request.cookies.get('alshaya_session')?.value || '',
      },
      headers: Object.fromEntries(request.headers.entries()),
      method: 'GET',
    }, {
      requireRole: 'ADMIN',
    });

    if (!auth.valid || !auth.context) {
      const error = auth.error || {
        code: 'UNAUTHORIZED',
        message: 'Admin access required',
        statusCode: 403,
      };
      return NextResponse.json(
        formatAuthError(error).body,
        { status: formatAuthError(error).status }
      );
    }

    const userId = params.id;

    // TODO: Implement user retrieval
    // In production, you would:
    // 1. Query database for user by ID
    // 2. Return user details excluding password hash
    // 3. Include user activity info if applicable

    const mockUser = {
      id: userId,
      email: `user@example.com`,
      nameArabic: 'مستخدم',
      nameEnglish: 'User',
      phone: '+966501234567',
      role: 'MEMBER',
      status: 'ACTIVE',
      linkedMemberId: null,
      assignedBranch: null,
      _2faEnabled: false,
      createdAt: new Date(Date.now() - 90 * 24 * 60 * 60 * 1000).toISOString(),
      updatedAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
      lastLogin: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
    };

    return NextResponse.json(
      {
        success: true,
        data: mockUser,
      },
      { status: 200 }
    );
  } catch (error) {
    console.error('Get user error:', error);
    return NextResponse.json(
      {
        success: false,
        error: 'INTERNAL_ERROR',
        message: 'An error occurred while retrieving the user',
      },
      { status: 500 }
    );
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    // Verify authentication and admin role
    const auth = await authenticateRequest({
      cookies: {
        alshaya_session:
          request.cookies.get('alshaya_session')?.value || '',
      },
      headers: Object.fromEntries(request.headers.entries()),
      method: 'PUT',
      body: {},
    }, {
      requireRole: 'ADMIN',
      requireCsrf: true,
    });

    if (!auth.valid || !auth.context) {
      const error = auth.error || {
        code: 'UNAUTHORIZED',
        message: 'Admin access required',
        statusCode: 403,
      };
      return NextResponse.json(
        formatAuthError(error).body,
        { status: formatAuthError(error).status }
      );
    }

    const userId = params.id;

    // Parse and validate request body
    const body = await request.json();
    const validation = validateInput(updateUserSchema, {
      ...body,
      id: userId,
    });

    if (!validation.success) {
      return NextResponse.json(
        {
          success: false,
          error: 'VALIDATION_ERROR',
          message: 'Invalid input data',
          details: formatZodErrors(validation.errors),
        },
        { status: 400 }
      );
    }

    const { nameArabic, nameEnglish, phone, role, status, linkedMemberId, assignedBranch } =
      validation.data;

    // TODO: Implement user update
    // In production, you would:
    // 1. Get user from database
    // 2. Validate updates (especially role changes)
    // 3. Update user in database
    // 4. Log update by admin
    // 5. Handle permission changes if role changed

    const updatedUser = {
      id: userId,
      email: 'user@example.com',
      nameArabic: nameArabic || 'مستخدم',
      nameEnglish: nameEnglish || 'User',
      phone,
      role: role || 'MEMBER',
      status: status || 'ACTIVE',
      linkedMemberId: linkedMemberId || null,
      assignedBranch: assignedBranch || null,
      updatedAt: new Date().toISOString(),
      updatedBy: auth.context.user.id,
    };

    return NextResponse.json(
      {
        success: true,
        message: 'User updated successfully',
        data: updatedUser,
      },
      { status: 200 }
    );
  } catch (error) {
    console.error('Update user error:', error);
    return NextResponse.json(
      {
        success: false,
        error: 'INTERNAL_ERROR',
        message: 'An error occurred while updating the user',
      },
      { status: 500 }
    );
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    // Verify authentication and super admin role (only super admins can delete)
    const auth = await authenticateRequest({
      cookies: {
        alshaya_session:
          request.cookies.get('alshaya_session')?.value || '',
      },
      headers: Object.fromEntries(request.headers.entries()),
      method: 'DELETE',
      body: {},
    }, {
      requireRole: 'SUPER_ADMIN',
      requireCsrf: true,
    });

    if (!auth.valid || !auth.context) {
      const error = auth.error || {
        code: 'UNAUTHORIZED',
        message: 'Super admin access required',
        statusCode: 403,
      };
      return NextResponse.json(
        formatAuthError(error).body,
        { status: formatAuthError(error).status }
      );
    }

    const userId = params.id;

    // Prevent deleting own account
    if (userId === auth.context.user.id) {
      return NextResponse.json(
        {
          success: false,
          error: 'INVALID_OPERATION',
          message: 'You cannot delete your own account',
        },
        { status: 400 }
      );
    }

    // TODO: Implement user deletion
    // In production, you would:
    // 1. Get user from database
    // 2. Check if user has any critical roles
    // 3. Optionally soft-delete instead of hard delete
    // 4. Invalidate all sessions for the user
    // 5. Log deletion by super admin

    return NextResponse.json(
      {
        success: true,
        message: 'User deleted successfully',
        data: {
          deletedUserId: userId,
          deletedAt: new Date().toISOString(),
        },
      },
      { status: 200 }
    );
  } catch (error) {
    console.error('Delete user error:', error);
    return NextResponse.json(
      {
        success: false,
        error: 'INTERNAL_ERROR',
        message: 'An error occurred while deleting the user',
      },
      { status: 500 }
    );
  }
}
