/**
 * GET /api/admin/users - List all users with pagination
 * POST /api/admin/users - Create a new user
 * Admin user management
 */

import { NextRequest, NextResponse } from 'next/server';
import { authenticateRequest, formatAuthError } from '@/lib/auth/middleware';
import { validateInput, createUserSchema, formatZodErrors } from '@/lib/validation/schemas';
import { z } from 'zod';

export const dynamic = 'force-dynamic';

const userListQuerySchema = z.object({
  page: z.coerce.number().int().min(1).default(1),
  limit: z.coerce.number().int().min(1).max(100).default(20),
  role: z.string().optional(),
  status: z.enum(['PENDING', 'ACTIVE', 'DISABLED']).optional(),
  search: z.string().optional(),
  sortBy: z.enum(['email', 'createdAt', 'nameArabic', 'role']).default('createdAt'),
  sortOrder: z.enum(['asc', 'desc']).default('desc'),
});

export async function GET(request: NextRequest) {
  try {
    // Verify authentication and admin role
    const auth = await authenticateRequest({
      cookies: {
        alshaya_session:
          request.cookies.get('alshaya_session')?.value || '',
      },
      headers: Object.fromEntries(request.headers.entries()),
      method: 'GET',
    }, {
      requireRole: 'ADMIN',
    });

    if (!auth.valid || !auth.context) {
      const error = auth.error || {
        code: 'UNAUTHORIZED',
        message: 'Admin access required',
        statusCode: 403,
      };
      return NextResponse.json(
        formatAuthError(error).body,
        { status: formatAuthError(error).status }
      );
    }

    // Parse and validate query parameters
    const searchParams = request.nextUrl.searchParams;
    const queryData = {
      page: searchParams.get('page') || '1',
      limit: searchParams.get('limit') || '20',
      role: searchParams.get('role'),
      status: searchParams.get('status'),
      search: searchParams.get('search'),
      sortBy: searchParams.get('sortBy') || 'createdAt',
      sortOrder: searchParams.get('sortOrder') || 'desc',
    };

    const validation = userListQuerySchema.safeParse(queryData);
    if (!validation.success) {
      return NextResponse.json(
        {
          success: false,
          error: 'VALIDATION_ERROR',
          message: 'Invalid query parameters',
          details: validation.error.flatten().fieldErrors,
        },
        { status: 400 }
      );
    }

    const { page, limit, role, status, search, sortBy, sortOrder } = validation.data;
    const skip = (page - 1) * limit;

    // TODO: Implement user listing from database
    // In production, you would:
    // 1. Query database with filters and pagination
    // 2. Apply search filter to email, nameArabic, nameEnglish
    // 3. Filter by role and status if provided
    // 4. Sort results
    // 5. Get total count for pagination
    // 6. Log admin access

    const mockUsers = Array.from({ length: limit }, (_, i) => ({
      id: `user_${skip + i + 1}`,
      email: `user${skip + i + 1}@example.com`,
      nameArabic: `مستخدم ${skip + i + 1}`,
      nameEnglish: `User ${skip + i + 1}`,
      role: ['SUPER_ADMIN', 'ADMIN', 'BRANCH_LEADER', 'MEMBER'][
        Math.floor(Math.random() * 4)
      ],
      status: ['PENDING', 'ACTIVE', 'DISABLED'][Math.floor(Math.random() * 3)],
      createdAt: new Date(
        Date.now() - Math.random() * 365 * 24 * 60 * 60 * 1000
      ).toISOString(),
      lastLogin: new Date(
        Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000
      ).toISOString(),
      _2faEnabled: Math.random() > 0.5,
    }));

    return NextResponse.json(
      {
        success: true,
        data: {
          users: mockUsers,
          pagination: {
            page,
            limit,
            total: 150, // Mock total
            pages: Math.ceil(150 / limit),
          },
          filters: {
            role,
            status,
            search,
          },
        },
      },
      { status: 200 }
    );
  } catch (error) {
    console.error('List users error:', error);
    return NextResponse.json(
      {
        success: false,
        error: 'INTERNAL_ERROR',
        message: 'An error occurred while listing users',
      },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    // Verify authentication and admin role
    const auth = await authenticateRequest({
      cookies: {
        alshaya_session:
          request.cookies.get('alshaya_session')?.value || '',
      },
      headers: Object.fromEntries(request.headers.entries()),
      method: 'POST',
      body: {},
    }, {
      requireRole: 'ADMIN',
      requireCsrf: true,
    });

    if (!auth.valid || !auth.context) {
      const error = auth.error || {
        code: 'UNAUTHORIZED',
        message: 'Admin access required',
        statusCode: 403,
      };
      return NextResponse.json(
        formatAuthError(error).body,
        { status: formatAuthError(error).status }
      );
    }

    // Parse and validate request body
    const body = await request.json();
    const validation = validateInput(createUserSchema, body);

    if (!validation.success) {
      return NextResponse.json(
        {
          success: false,
          error: 'VALIDATION_ERROR',
          message: 'Invalid input data',
          details: formatZodErrors(validation.errors),
        },
        { status: 400 }
      );
    }

    const { email, password, nameArabic, nameEnglish, phone, role, linkedMemberId, assignedBranch } =
      validation.data;

    // TODO: Implement user creation
    // In production, you would:
    // 1. Check if email already exists
    // 2. Hash password with bcrypt
    // 3. Create user in database
    // 4. Log user creation by admin
    // 5. Send welcome email if applicable

    const newUser = {
      id: `user_${Date.now()}`,
      email,
      nameArabic,
      nameEnglish: nameEnglish || '',
      phone,
      role,
      status: 'ACTIVE',
      linkedMemberId: linkedMemberId || null,
      assignedBranch: assignedBranch || null,
      _2faEnabled: false,
      createdAt: new Date().toISOString(),
      createdBy: auth.context.user.id,
    };

    return NextResponse.json(
      {
        success: true,
        message: 'User created successfully',
        data: newUser,
      },
      { status: 201 }
    );
  } catch (error) {
    console.error('Create user error:', error);
    return NextResponse.json(
      {
        success: false,
        error: 'INTERNAL_ERROR',
        message: 'An error occurred while creating the user',
      },
      { status: 500 }
    );
  }
}
