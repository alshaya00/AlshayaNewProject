import { NextRequest } from 'next/server';
import { z } from 'zod';
import { validateCSRFToken } from '@/lib/auth/csrf';
import { standardResponse, errorResponse } from '@/lib/api/response';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

const contactSchema = z.object({
  name: z.string().min(1).max(100),
  email: z.string().email(),
  subject: z.string().min(1).max(200),
  message: z.string().min(10).max(5000),
  category: z.enum(['FEEDBACK', 'BUG_REPORT', 'FEATURE_REQUEST', 'OTHER']).default('OTHER'),
});

async function sendContactEmail(
  name: string,
  email: string,
  subject: string,
  message: string,
  category: string
): Promise<boolean> {
  try {
    // This would integrate with your email service
    // For now, we'll log it and return success
    console.log('Contact form submission:', {
      name,
      email,
      subject,
      message,
      category,
      timestamp: new Date(),
    });

    // In production, send email using service like SendGrid, AWS SES, etc.
    return true;
  } catch (error) {
    console.error('Error sending contact email:', error);
    return false;
  }
}

export async function POST(request: NextRequest) {
  try {
    await validateCSRFToken(request);
    const body = contactSchema.parse(await request.json());

    const sent = await sendContactEmail(
      body.name,
      body.email,
      body.subject,
      body.message,
      body.category
    );

    if (!sent) {
      return errorResponse('Failed to send message', 500);
    }

    return standardResponse(
      {
        message: 'Your message has been received. We will get back to you soon.',
        email: body.email,
        timestamp: new Date(),
      },
      201
    );
  } catch (error) {
    if (error instanceof z.ZodError) {
      return errorResponse('Validation error', 400, error.errors);
    }
    console.error('Error processing contact form:', error);
    return errorResponse('Failed to process contact form', 500);
  }
}
