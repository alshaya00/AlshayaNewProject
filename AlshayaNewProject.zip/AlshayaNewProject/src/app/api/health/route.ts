import { NextRequest } from 'next/server';
import { prisma } from '@/lib/prisma';
import { standardResponse, errorResponse } from '@/lib/api/response';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

interface HealthStatus {
  status: 'healthy' | 'degraded' | 'unhealthy';
  timestamp: Date;
  database: {
    connected: boolean;
    responseTime: number;
  };
  uptime: number;
  version: string;
  environment: string;
}

let startTime = Date.now();

export async function GET(request: NextRequest) {
  try {
    const dbStart = Date.now();

    // Check database connectivity
    const dbConnected = await prisma.familyMember.count();
    const dbResponseTime = Date.now() - dbStart;

    const uptime = Date.now() - startTime;

    const health: HealthStatus = {
      status: dbConnected !== null ? 'healthy' : 'degraded',
      timestamp: new Date(),
      database: {
        connected: dbConnected !== null,
        responseTime: dbResponseTime,
      },
      uptime,
      version: process.env.APP_VERSION || '1.0.0',
      environment: process.env.NODE_ENV || 'development',
    };

    return standardResponse(health);
  } catch (error) {
    console.error('Health check failed:', error);
    return errorResponse('Database connection failed', 503);
  }
}
