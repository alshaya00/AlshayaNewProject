import { NextRequest } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/prisma';
import { requireAuth } from '@/lib/auth/middleware';
import { standardResponse, errorResponse } from '@/lib/api/response';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

const checkSchema = z.object({
  memberId1: z.string(),
  memberId2: z.string(),
});

export async function POST(request: NextRequest) {
  try {
    const user = await requireAuth(request);
    const body = checkSchema.parse(await request.json());

    if (body.memberId1 === body.memberId2) {
      return errorResponse('Cannot check milk kinship with same member', 400);
    }

    // Check if either is a milk sibling of the other
    const relationships = await prisma.breastfeedingRelationship.findMany({
      where: {
        OR: [
          {
            childId: body.memberId1,
            nurseId: body.memberId2,
          },
          {
            childId: body.memberId2,
            nurseId: body.memberId1,
          },
          {
            childId: body.memberId1,
            milkFatherId: body.memberId2,
          },
          {
            childId: body.memberId2,
            milkFatherId: body.memberId1,
          },
        ],
      },
    });

    // Check if they share the same nurse
    const member1Relationships = await prisma.breastfeedingRelationship.findMany({
      where: { childId: body.memberId1 },
      select: { nurseId: true },
    });

    const member2Relationships = await prisma.breastfeedingRelationship.findMany({
      where: { childId: body.memberId2 },
      select: { nurseId: true },
    });

    const sharedNurses = member1Relationships.filter(r =>
      member2Relationships.some(r2 => r2.nurseId === r.nurseId)
    );

    const relatedByMilk = relationships.length > 0;
    const relatedBySameMilk = sharedNurses.length > 0;

    return standardResponse({
      member1: body.memberId1,
      member2: body.memberId2,
      milkKinship: {
        related: relatedByMilk || relatedBySameMilk,
        directRelationship: relatedByMilk,
        sharedMilkMother: relatedBySameMilk,
        relationshipCount: relationships.length,
        sharedNurseCount: sharedNurses.length,
      },
      relationships,
      sharedNurses: sharedNurses.map(r => r.nurseId),
    });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return errorResponse('Validation error', 400, error.errors);
    }
    console.error('Error checking milk kinship:', error);
    return errorResponse('Failed to check milk kinship', 500);
  }
}
