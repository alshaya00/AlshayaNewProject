import { NextRequest } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/prisma';
import { requireAuth } from '@/lib/auth/middleware';
import { validateCSRFToken } from '@/lib/auth/csrf';
import { standardResponse, errorResponse } from '@/lib/api/response';
import { createAuditLog } from '@/lib/audit';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

const createRelationshipSchema = z.object({
  childId: z.string(),
  milkFatherId: z.string().optional(),
  nurseId: z.string().optional(),
  date: z.string().optional(),
  notes: z.string().optional(),
  verified: z.boolean().default(false),
});

const listSchema = z.object({
  page: z.string().transform(Number).default('1'),
  limit: z.string().transform(Number).default('50'),
  childId: z.string().optional(),
  nurserId: z.string().optional(),
});

export async function GET(request: NextRequest) {
  try {
    const user = await requireAuth(request);
    const params = listSchema.parse(
      Object.fromEntries(request.nextUrl.searchParams)
    );

    const page = Math.max(1, params.page);
    const limit = Math.min(500, Math.max(1, params.limit));
    const skip = (page - 1) * limit;

    const where: any = {};
    if (params.childId) where.childId = params.childId;
    if (params.nurserId) where.nurseId = params.nurserId;

    const [relationships, total] = await Promise.all([
      prisma.breastfeedingRelationship.findMany({
        where,
        skip,
        take: limit,
        include: {
          child: {
            select: {
              id: true,
              firstName: true,
              fullNameAr: true,
            },
          },
          milkFather: {
            select: {
              id: true,
              firstName: true,
              fullNameAr: true,
            },
          },
          nurse: {
            select: {
              id: true,
              firstName: true,
              fullNameAr: true,
            },
          },
        },
        orderBy: { createdAt: 'desc' },
      }),
      prisma.breastfeedingRelationship.count({ where }),
    ]);

    return standardResponse({
      data: relationships,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Error fetching breastfeeding relationships:', error);
    return errorResponse('Failed to fetch relationships', 500);
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await requireAuth(request);
    await validateCSRFToken(request);

    const body = createRelationshipSchema.parse(await request.json());

    // Validate child exists
    const child = await prisma.familyMember.findUnique({
      where: { id: body.childId },
    });
    if (!child) {
      return errorResponse('Child not found', 404);
    }

    // Validate milk father if provided
    if (body.milkFatherId) {
      const milkFather = await prisma.familyMember.findUnique({
        where: { id: body.milkFatherId },
      });
      if (!milkFather) {
        return errorResponse('Milk father not found', 404);
      }
    }

    // Validate nurse if provided
    if (body.nurseId) {
      const nurse = await prisma.familyMember.findUnique({
        where: { id: body.nurseId },
      });
      if (!nurse) {
        return errorResponse('Nurse not found', 404);
      }
    }

    const relationship = await prisma.breastfeedingRelationship.create({
      data: {
        childId: body.childId,
        milkFatherId: body.milkFatherId,
        nurseId: body.nurseId,
        date: body.date ? new Date(body.date) : null,
        notes: body.notes,
        verified: body.verified,
        verifiedBy: body.verified ? user.id : null,
      },
      include: {
        child: true,
        milkFather: true,
        nurse: true,
      },
    });

    await createAuditLog({
      memberId: body.childId,
      fieldName: 'breastfeeding_relationship_created',
      changeType: 'CREATE',
      changedBy: user.id,
      changedByName: user.email,
      newValue: JSON.stringify({
        childId: body.childId,
        milkFatherId: body.milkFatherId,
        nurseId: body.nurseId,
      }),
    });

    return standardResponse(relationship, 201);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return errorResponse('Validation error', 400, error.errors);
    }
    console.error('Error creating breastfeeding relationship:', error);
    return errorResponse('Failed to create relationship', 500);
  }
}
