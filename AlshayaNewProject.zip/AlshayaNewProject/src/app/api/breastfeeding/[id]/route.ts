import { NextRequest } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/prisma';
import { requireAuth } from '@/lib/auth/middleware';
import { validateCSRFToken } from '@/lib/auth/csrf';
import { standardResponse, errorResponse } from '@/lib/api/response';
import { createAuditLog } from '@/lib/audit';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

const updateSchema = z.object({
  notes: z.string().optional(),
  verified: z.boolean().optional(),
  date: z.string().optional(),
});

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = await requireAuth(request);

    const relationship = await prisma.breastfeedingRelationship.findUnique({
      where: { id: params.id },
      include: {
        child: {
          select: {
            id: true,
            firstName: true,
            fullNameAr: true,
            gender: true,
          },
        },
        milkFather: {
          select: {
            id: true,
            firstName: true,
            fullNameAr: true,
            gender: true,
          },
        },
        nurse: {
          select: {
            id: true,
            firstName: true,
            fullNameAr: true,
            gender: true,
          },
        },
      },
    });

    if (!relationship) {
      return errorResponse('Relationship not found', 404);
    }

    return standardResponse(relationship);
  } catch (error) {
    console.error('Error fetching relationship:', error);
    return errorResponse('Failed to fetch relationship', 500);
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = await requireAuth(request);
    await validateCSRFToken(request);

    const body = updateSchema.parse(await request.json());

    const existing = await prisma.breastfeedingRelationship.findUnique({
      where: { id: params.id },
    });

    if (!existing) {
      return errorResponse('Relationship not found', 404);
    }

    const updated = await prisma.breastfeedingRelationship.update({
      where: { id: params.id },
      data: {
        notes: body.notes,
        verified: body.verified,
        verifiedBy: body.verified ? user.id : undefined,
        date: body.date ? new Date(body.date) : undefined,
      },
      include: {
        child: true,
        milkFather: true,
        nurse: true,
      },
    });

    await createAuditLog({
      memberId: existing.childId,
      fieldName: 'breastfeeding_relationship_updated',
      changeType: 'UPDATE',
      changedBy: user.id,
      changedByName: user.email,
      oldValue: JSON.stringify(existing),
      newValue: JSON.stringify(updated),
    });

    return standardResponse(updated);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return errorResponse('Validation error', 400, error.errors);
    }
    console.error('Error updating relationship:', error);
    return errorResponse('Failed to update relationship', 500);
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = await requireAuth(request);
    await validateCSRFToken(request);

    const existing = await prisma.breastfeedingRelationship.findUnique({
      where: { id: params.id },
    });

    if (!existing) {
      return errorResponse('Relationship not found', 404);
    }

    const deleted = await prisma.breastfeedingRelationship.delete({
      where: { id: params.id },
    });

    await createAuditLog({
      memberId: existing.childId,
      fieldName: 'breastfeeding_relationship_deleted',
      changeType: 'DELETE',
      changedBy: user.id,
      changedByName: user.email,
      oldValue: JSON.stringify(existing),
    });

    return standardResponse({ message: 'Relationship deleted', deleted });
  } catch (error) {
    console.error('Error deleting relationship:', error);
    return errorResponse('Failed to delete relationship', 500);
  }
}
