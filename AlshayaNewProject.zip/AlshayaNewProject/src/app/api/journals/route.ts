import { NextRequest } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/prisma';
import { requireAuth } from '@/lib/auth/middleware';
import { validateCSRFToken } from '@/lib/auth/csrf';
import { standardResponse, errorResponse } from '@/lib/api/response';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

const createJournalSchema = z.object({
  title: z.string().min(1).max(255),
  content: z.string().min(1),
  status: z.enum(['DRAFT', 'PENDING_REVIEW', 'PUBLISHED', 'ARCHIVED']).default('DRAFT'),
  tags: z.array(z.string()).optional(),
  mentionedMembers: z.array(z.string()).optional(),
});

const listSchema = z.object({
  page: z.string().transform(Number).default('1'),
  limit: z.string().transform(Number).default('50'),
  status: z.string().optional(),
  search: z.string().optional(),
});

export async function GET(request: NextRequest) {
  try {
    const user = await requireAuth(request);
    const params = listSchema.parse(
      Object.fromEntries(request.nextUrl.searchParams)
    );

    const page = Math.max(1, params.page);
    const limit = Math.min(500, Math.max(1, params.limit));
    const skip = (page - 1) * limit;

    const where: any = {};
    if (params.status) where.status = params.status;

    if (params.search) {
      where.OR = [
        { title: { contains: params.search, mode: 'insensitive' } },
        { content: { contains: params.search, mode: 'insensitive' } },
      ];
    }

    const [journals, total] = await Promise.all([
      prisma.familyJournal.findMany({
        where,
        skip,
        take: limit,
        select: {
          id: true,
          title: true,
          content: true,
          status: true,
          createdAt: true,
          updatedAt: true,
          authorId: true,
        },
        orderBy: { createdAt: 'desc' },
      }),
      prisma.familyJournal.count({ where }),
    ]);

    return standardResponse({
      data: journals,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Error fetching journals:', error);
    return errorResponse('Failed to fetch journals', 500);
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await requireAuth(request);
    await validateCSRFToken(request);

    const body = createJournalSchema.parse(await request.json());

    const journal = await prisma.familyJournal.create({
      data: {
        title: body.title,
        content: body.content,
        status: body.status,
        authorId: user.id,
        tags: body.tags || [],
      },
    });

    // Link mentioned members if provided
    if (body.mentionedMembers && body.mentionedMembers.length > 0) {
      await Promise.all(
        body.mentionedMembers.map(memberId =>
          prisma.familyJournal.update({
            where: { id: journal.id },
            data: {
              members: {
                connect: { id: memberId },
              },
            },
          })
        )
      );
    }

    return standardResponse(journal, 201);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return errorResponse('Validation error', 400, error.errors);
    }
    console.error('Error creating journal:', error);
    return errorResponse('Failed to create journal', 500);
  }
}
