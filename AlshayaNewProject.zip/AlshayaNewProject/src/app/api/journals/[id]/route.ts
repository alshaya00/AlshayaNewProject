import { NextRequest } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/prisma';
import { requireAuth } from '@/lib/auth/middleware';
import { validateCSRFToken } from '@/lib/auth/csrf';
import { standardResponse, errorResponse } from '@/lib/api/response';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

const updateJournalSchema = z.object({
  title: z.string().min(1).max(255).optional(),
  content: z.string().min(1).optional(),
  status: z.enum(['DRAFT', 'PENDING_REVIEW', 'PUBLISHED', 'ARCHIVED']).optional(),
  tags: z.array(z.string()).optional(),
});

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = await requireAuth(request);

    const journal = await prisma.familyJournal.findUnique({
      where: { id: params.id },
      include: {
        members: {
          select: {
            id: true,
            firstName: true,
            fullNameAr: true,
          },
        },
      },
    });

    if (!journal) {
      return errorResponse('Journal not found', 404);
    }

    return standardResponse(journal);
  } catch (error) {
    console.error('Error fetching journal:', error);
    return errorResponse('Failed to fetch journal', 500);
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = await requireAuth(request);
    await validateCSRFToken(request);

    const body = updateJournalSchema.parse(await request.json());

    const journal = await prisma.familyJournal.findUnique({
      where: { id: params.id },
    });

    if (!journal) {
      return errorResponse('Journal not found', 404);
    }

    const updated = await prisma.familyJournal.update({
      where: { id: params.id },
      data: {
        title: body.title,
        content: body.content,
        status: body.status,
        tags: body.tags,
      },
    });

    return standardResponse(updated);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return errorResponse('Validation error', 400, error.errors);
    }
    console.error('Error updating journal:', error);
    return errorResponse('Failed to update journal', 500);
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = await requireAuth(request);
    await validateCSRFToken(request);

    const journal = await prisma.familyJournal.findUnique({
      where: { id: params.id },
    });

    if (!journal) {
      return errorResponse('Journal not found', 404);
    }

    await prisma.familyJournal.update({
      where: { id: params.id },
      data: { status: 'DELETED' },
    });

    return standardResponse({ message: 'Journal deleted' });
  } catch (error) {
    console.error('Error deleting journal:', error);
    return errorResponse('Failed to delete journal', 500);
  }
}
