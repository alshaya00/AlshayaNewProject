/**
 * GET /api/auth/backup-codes - Get remaining backup codes
 * POST /api/auth/backup-codes - Regenerate backup codes
 * Two-factor authentication backup code management
 */

import { NextRequest, NextResponse } from 'next/server';
import { authenticateRequest, formatAuthError } from '@/lib/auth/middleware';

export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest) {
  try {
    // Verify authentication
    const auth = await authenticateRequest({
      cookies: {
        alshaya_session:
          request.cookies.get('alshaya_session')?.value || '',
      },
      headers: Object.fromEntries(request.headers.entries()),
      method: 'GET',
    });

    if (!auth.valid || !auth.context) {
      const error = auth.error || {
        code: 'UNAUTHORIZED',
        message: 'Authentication required',
        statusCode: 401,
      };
      return NextResponse.json(
        formatAuthError(error).body,
        { status: formatAuthError(error).status }
      );
    }

    const userId = auth.context.user.id;

    // TODO: Implement backup codes retrieval
    // In production, you would:
    // 1. Get user from database
    // 2. Get backup codes count
    // 3. Return count and generation date

    return NextResponse.json(
      {
        success: true,
        data: {
          userId,
          backupCodesRemaining: 10,
          lastGeneratedAt: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
          _2faEnabled: true,
        },
      },
      { status: 200 }
    );
  } catch (error) {
    console.error('Get backup codes error:', error);
    return NextResponse.json(
      {
        success: false,
        error: 'INTERNAL_ERROR',
        message: 'An error occurred while retrieving backup codes',
      },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    // Verify authentication
    const auth = await authenticateRequest({
      cookies: {
        alshaya_session:
          request.cookies.get('alshaya_session')?.value || '',
      },
      headers: Object.fromEntries(request.headers.entries()),
      method: 'POST',
      body: {},
    });

    if (!auth.valid || !auth.context) {
      const error = auth.error || {
        code: 'UNAUTHORIZED',
        message: 'Authentication required',
        statusCode: 401,
      };
      return NextResponse.json(
        formatAuthError(error).body,
        { status: formatAuthError(error).status }
      );
    }

    const userId = auth.context.user.id;

    // TODO: Implement backup codes regeneration
    // In production, you would:
    // 1. Verify user is authenticated
    // 2. Generate new set of backup codes
    // 3. Invalidate old codes
    // 4. Store new codes in database
    // 5. Log backup code regeneration

    const newBackupCodes = Array.from({ length: 10 }, () =>
      Math.random().toString(36).substring(2, 10)
    );

    return NextResponse.json(
      {
        success: true,
        message: 'New backup codes have been generated. Store them in a safe place.',
        data: {
          backupCodes: newBackupCodes,
          generatedAt: new Date().toISOString(),
          important:
            'Save these codes in a secure location. Each code can be used once to access your account if you lose your authenticator.',
        },
      },
      { status: 200 }
    );
  } catch (error) {
    console.error('Regenerate backup codes error:', error);
    return NextResponse.json(
      {
        success: false,
        error: 'INTERNAL_ERROR',
        message: 'An error occurred while regenerating backup codes',
      },
      { status: 500 }
    );
  }
}
