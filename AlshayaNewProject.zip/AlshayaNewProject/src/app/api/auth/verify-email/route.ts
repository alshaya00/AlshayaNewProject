/**
 * POST /api/auth/verify-email
 * Email verification token validation
 */

import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';

export const dynamic = 'force-dynamic';

const verifyEmailSchema = z.object({
  token: z.string().min(1, 'Token is required'),
  email: z.string().email('Invalid email address'),
});

export async function POST(request: NextRequest) {
  try {
    // Parse and validate request body
    const body = await request.json();
    const validation = verifyEmailSchema.safeParse(body);

    if (!validation.success) {
      return NextResponse.json(
        {
          success: false,
          error: 'VALIDATION_ERROR',
          message: 'Invalid input data',
          details: validation.error.flatten().fieldErrors,
        },
        { status: 400 }
      );
    }

    const { token, email } = validation.data;

    // TODO: Implement email verification logic
    // In production, you would:
    // 1. Find verification token in database
    // 2. Check if token is expired
    // 3. Check if token matches email
    // 4. Update user status to ACTIVE
    // 5. Delete verification token
    // 6. Log verification event

    return NextResponse.json(
      {
        success: true,
        message: 'Email verified successfully. Your account is now active.',
        data: {
          email,
          status: 'ACTIVE',
        },
      },
      { status: 200 }
    );
  } catch (error) {
    console.error('Email verification error:', error);
    return NextResponse.json(
      {
        success: false,
        error: 'INTERNAL_ERROR',
        message: 'An error occurred during email verification',
      },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  try {
    // Support verification via URL query parameters for email links
    const searchParams = request.nextUrl.searchParams;
    const token = searchParams.get('token');
    const email = searchParams.get('email');

    if (!token || !email) {
      return NextResponse.json(
        {
          success: false,
          error: 'MISSING_PARAMS',
          message: 'Token and email are required',
        },
        { status: 400 }
      );
    }

    // TODO: Implement email verification logic
    // (Same as POST implementation)

    return NextResponse.json(
      {
        success: true,
        message: 'Email verified successfully. Your account is now active.',
        data: {
          email,
          status: 'ACTIVE',
        },
      },
      { status: 200 }
    );
  } catch (error) {
    console.error('Email verification error:', error);
    return NextResponse.json(
      {
        success: false,
        error: 'INTERNAL_ERROR',
        message: 'An error occurred during email verification',
      },
      { status: 500 }
    );
  }
}
