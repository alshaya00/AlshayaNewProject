/**
 * POST /api/auth/login
 * Email/password login with rate limiting and brute force protection
 */

import { NextRequest, NextResponse } from 'next/server';
import { validateInput, loginSchema, formatZodErrors } from '@/lib/validation/schemas';
import { authenticateRequest, formatAuthError } from '@/lib/auth/middleware';
import { v4 as uuidv4 } from 'uuid';

export const dynamic = 'force-dynamic';

// In-memory rate limiting (in production, use Redis)
const loginAttempts = new Map<string, { count: number; resetTime: number }>();
const MAX_ATTEMPTS = 5;
const LOCKOUT_DURATION = 15 * 60 * 1000; // 15 minutes

function checkRateLimit(identifier: string): { allowed: boolean; message?: string } {
  const now = Date.now();
  const record = loginAttempts.get(identifier);

  if (!record || now > record.resetTime) {
    loginAttempts.set(identifier, { count: 0, resetTime: now + LOCKOUT_DURATION });
    return { allowed: true };
  }

  if (record.count >= MAX_ATTEMPTS) {
    const remainingTime = Math.ceil((record.resetTime - now) / 1000 / 60);
    return {
      allowed: false,
      message: `Too many login attempts. Try again in ${remainingTime} minutes.`,
    };
  }

  return { allowed: true };
}

function incrementLoginAttempt(identifier: string): void {
  const record = loginAttempts.get(identifier);
  if (record) {
    record.count++;
  }
}

function resetLoginAttempts(identifier: string): void {
  loginAttempts.delete(identifier);
}

export async function POST(request: NextRequest) {
  try {
    const ipAddress =
      request.headers.get('x-forwarded-for') ||
      request.headers.get('x-real-ip') ||
      'unknown';

    // Check rate limit
    const rateLimit = checkRateLimit(ipAddress);
    if (!rateLimit.allowed) {
      return NextResponse.json(
        {
          success: false,
          error: 'RATE_LIMITED',
          message: rateLimit.message || 'Too many login attempts',
        },
        { status: 429 }
      );
    }

    // Parse and validate request body
    const body = await request.json();
    const validation = validateInput(loginSchema, body);

    if (!validation.success) {
      incrementLoginAttempt(ipAddress);
      return NextResponse.json(
        {
          success: false,
          error: 'VALIDATION_ERROR',
          message: 'Invalid input data',
          details: formatZodErrors(validation.errors),
        },
        { status: 400 }
      );
    }

    const { email, password, rememberMe } = validation.data;

    // TODO: Implement actual authentication logic
    // This is a placeholder implementation
    // In production, you would:
    // 1. Query database for user by email
    // 2. Verify password hash
    // 3. Create session token
    // 4. Set secure cookies
    // 5. Log authentication event

    // Placeholder response
    const sessionToken = uuidv4();
    const expiresAt = new Date(
      Date.now() + (rememberMe ? 30 * 24 * 60 * 60 * 1000 : 7 * 24 * 60 * 60 * 1000)
    );

    resetLoginAttempts(ipAddress);

    const response = NextResponse.json(
      {
        success: true,
        message: 'Login successful',
        sessionToken,
        expiresAt: expiresAt.toISOString(),
      },
      { status: 200 }
    );

    // Set secure session cookie
    response.cookies.set('alshaya_session', sessionToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict',
      maxAge: rememberMe ? 30 * 24 * 60 * 60 : 7 * 24 * 60 * 60,
      path: '/',
    });

    return response;
  } catch (error) {
    console.error('Login error:', error);
    return NextResponse.json(
      {
        success: false,
        error: 'INTERNAL_ERROR',
        message: 'An error occurred during login',
      },
      { status: 500 }
    );
  }
}
