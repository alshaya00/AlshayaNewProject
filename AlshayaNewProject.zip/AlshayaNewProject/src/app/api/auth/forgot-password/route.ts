/**
 * POST /api/auth/forgot-password
 * Password reset request
 */

import { NextRequest, NextResponse } from 'next/server';
import { validateInput, passwordResetRequestSchema, formatZodErrors } from '@/lib/validation/schemas';
import { v4 as uuidv4 } from 'uuid';

export const dynamic = 'force-dynamic';

// Rate limiting for password reset
const resetAttempts = new Map<string, { count: number; resetTime: number }>();
const MAX_ATTEMPTS = 3;
const LOCKOUT_DURATION = 60 * 60 * 1000; // 1 hour

function checkPasswordResetLimit(email: string): { allowed: boolean; message?: string } {
  const now = Date.now();
  const record = resetAttempts.get(email);

  if (!record || now > record.resetTime) {
    resetAttempts.set(email, { count: 0, resetTime: now + LOCKOUT_DURATION });
    return { allowed: true };
  }

  if (record.count >= MAX_ATTEMPTS) {
    const remainingTime = Math.ceil((record.resetTime - now) / 1000 / 60);
    return {
      allowed: false,
      message: `Too many reset attempts. Try again in ${remainingTime} minutes.`,
    };
  }

  return { allowed: true };
}

function incrementResetAttempt(email: string): void {
  const record = resetAttempts.get(email);
  if (record) {
    record.count++;
  }
}

export async function POST(request: NextRequest) {
  try {
    // Parse and validate request body
    const body = await request.json();
    const validation = validateInput(passwordResetRequestSchema, body);

    if (!validation.success) {
      return NextResponse.json(
        {
          success: false,
          error: 'VALIDATION_ERROR',
          message: 'Invalid input data',
          details: formatZodErrors(validation.errors),
        },
        { status: 400 }
      );
    }

    const { email } = validation.data;

    // Check rate limit
    const rateLimit = checkPasswordResetLimit(email);
    if (!rateLimit.allowed) {
      return NextResponse.json(
        {
          success: false,
          error: 'RATE_LIMITED',
          message: rateLimit.message || 'Too many reset attempts',
        },
        { status: 429 }
      );
    }

    // TODO: Implement password reset request logic
    // In production, you would:
    // 1. Find user by email
    // 2. Check if user exists (don't reveal if account doesn't exist)
    // 3. Generate reset token
    // 4. Store token in database with expiration
    // 5. Send reset email with token link
    // 6. Log password reset request

    const resetToken = uuidv4();
    const expiresAt = new Date(Date.now() + 60 * 60 * 1000); // 1 hour

    incrementResetAttempt(email);

    // Always return success to avoid user enumeration
    return NextResponse.json(
      {
        success: true,
        message: 'If an account exists with this email, you will receive a password reset link shortly.',
        data: {
          email: email.replace(/(.{2})(.*)(@.*)/, '$1***$3'), // Partially masked
          resetTokenExpiry: expiresAt.toISOString(),
        },
      },
      { status: 200 }
    );
  } catch (error) {
    console.error('Forgot password error:', error);
    return NextResponse.json(
      {
        success: false,
        error: 'INTERNAL_ERROR',
        message: 'An error occurred while processing your request',
      },
      { status: 500 }
    );
  }
}
