/**
 * POST /api/auth/change-password
 * Authenticated password change for logged-in users
 */

import { NextRequest, NextResponse } from 'next/server';
import { authenticateRequest, formatAuthError } from '@/lib/auth/middleware';
import { z } from 'zod';

export const dynamic = 'force-dynamic';

const changePasswordSchema = z
  .object({
    currentPassword: z.string().min(1, 'Current password is required'),
    newPassword: z
      .string()
      .min(8, 'Password must be at least 8 characters')
      .regex(/[A-Z]/, 'Password must contain at least one uppercase letter')
      .regex(/[a-z]/, 'Password must contain at least one lowercase letter')
      .regex(/[0-9]/, 'Password must contain at least one number'),
    confirmPassword: z.string(),
  })
  .refine((data) => data.newPassword === data.confirmPassword, {
    message: "Passwords don't match",
    path: ['confirmPassword'],
  });

export async function POST(request: NextRequest) {
  try {
    // Verify authentication
    const auth = await authenticateRequest({
      cookies: {
        alshaya_session:
          request.cookies.get('alshaya_session')?.value || '',
      },
      headers: Object.fromEntries(request.headers.entries()),
      method: 'POST',
    });

    if (!auth.valid || !auth.context) {
      const error = auth.error || {
        code: 'UNAUTHORIZED',
        message: 'Authentication required',
        statusCode: 401,
      };
      return NextResponse.json(
        formatAuthError(error).body,
        { status: formatAuthError(error).status }
      );
    }

    // Parse and validate request body
    const body = await request.json();
    const validation = changePasswordSchema.safeParse(body);

    if (!validation.success) {
      return NextResponse.json(
        {
          success: false,
          error: 'VALIDATION_ERROR',
          message: 'Invalid input data',
          details: validation.error.flatten().fieldErrors,
        },
        { status: 400 }
      );
    }

    const { currentPassword, newPassword } = validation.data;
    const userId = auth.context.user.id;

    // TODO: Implement password change logic
    // In production, you would:
    // 1. Get user from database
    // 2. Verify current password matches
    // 3. Hash new password
    // 4. Update password in database
    // 5. Optionally invalidate other sessions
    // 6. Log password change event

    const ipAddress =
      request.headers.get('x-forwarded-for') ||
      request.headers.get('x-real-ip') ||
      'unknown';

    return NextResponse.json(
      {
        success: true,
        message: 'Password changed successfully',
        data: {
          userId,
          changedAt: new Date().toISOString(),
        },
      },
      { status: 200 }
    );
  } catch (error) {
    console.error('Change password error:', error);
    return NextResponse.json(
      {
        success: false,
        error: 'INTERNAL_ERROR',
        message: 'An error occurred while changing your password',
      },
      { status: 500 }
    );
  }
}
