/**
 * POST /api/auth/register
 * User registration with email verification
 */

import { NextRequest, NextResponse } from 'next/server';
import { validateInput, registerSchema, formatZodErrors } from '@/lib/validation/schemas';
import { v4 as uuidv4 } from 'uuid';

export const dynamic = 'force-dynamic';

export async function POST(request: NextRequest) {
  try {
    // Parse and validate request body
    const body = await request.json();
    const validation = validateInput(registerSchema, body);

    if (!validation.success) {
      return NextResponse.json(
        {
          success: false,
          error: 'VALIDATION_ERROR',
          message: 'Invalid input data',
          details: formatZodErrors(validation.errors),
        },
        { status: 400 }
      );
    }

    const { email, password, nameArabic, nameEnglish, phone } = validation.data;

    // TODO: Implement registration logic
    // In production, you would:
    // 1. Check if user already exists
    // 2. Hash password with bcrypt
    // 3. Create user in database with PENDING status
    // 4. Generate email verification token
    // 5. Send verification email
    // 6. Log registration event

    const verificationToken = uuidv4();
    const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24 hours

    return NextResponse.json(
      {
        success: true,
        message: 'Registration successful. Check your email to verify your account.',
        data: {
          email,
          status: 'PENDING',
          verificationRequired: true,
          expiresAt: expiresAt.toISOString(),
        },
      },
      { status: 201 }
    );
  } catch (error) {
    console.error('Registration error:', error);
    return NextResponse.json(
      {
        success: false,
        error: 'INTERNAL_ERROR',
        message: 'An error occurred during registration',
      },
      { status: 500 }
    );
  }
}
