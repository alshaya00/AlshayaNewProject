/**
 * POST /api/auth/verify-2fa
 * Two-factor authentication code verification
 */

import { NextRequest, NextResponse } from 'next/server';
import { validateInput, twoFactorVerifySchema, formatZodErrors } from '@/lib/validation/schemas';

export const dynamic = 'force-dynamic';

export async function POST(request: NextRequest) {
  try {
    // Parse and validate request body
    const body = await request.json();
    const validation = validateInput(twoFactorVerifySchema, body);

    if (!validation.success) {
      return NextResponse.json(
        {
          success: false,
          error: 'VALIDATION_ERROR',
          message: 'Invalid input data',
          details: formatZodErrors(validation.errors),
        },
        { status: 400 }
      );
    }

    const { code, backupCode } = validation.data;

    // Get temporary 2FA setup from session or request
    const setupToken = request.headers.get('x-2fa-setup-token');
    if (!setupToken) {
      return NextResponse.json(
        {
          success: false,
          error: 'MISSING_SETUP',
          message: '2FA setup not initiated',
        },
        { status: 400 }
      );
    }

    // TODO: Implement 2FA verification logic
    // In production, you would:
    // 1. Get temporary 2FA setup from database
    // 2. Check if setup is expired
    // 3. If TOTP:
    //    - Verify TOTP code using library like 'speakeasy'
    //    - Allow ±30 second window
    // 4. If backup code:
    //    - Check against list of backup codes
    //    - Mark as used
    // 5. Confirm 2FA setup in database
    // 6. Generate new backup codes
    // 7. Log 2FA activation

    const ipAddress =
      request.headers.get('x-forwarded-for') ||
      request.headers.get('x-real-ip') ||
      'unknown';

    return NextResponse.json(
      {
        success: true,
        message: '2FA has been verified and activated on your account.',
        data: {
          status: 'ACTIVE',
          method: 'TOTP', // or 'SMS' depending on setup
          activatedAt: new Date().toISOString(),
          backupCodesRemaining: 10,
        },
      },
      { status: 200 }
    );
  } catch (error) {
    console.error('2FA verification error:', error);
    return NextResponse.json(
      {
        success: false,
        error: 'INTERNAL_ERROR',
        message: 'An error occurred while verifying 2FA',
      },
      { status: 500 }
    );
  }
}
