/**
 * POST /api/auth/logout
 * Session destruction and cookie clearing
 */

import { NextRequest, NextResponse } from 'next/server';
import { verifySessionFromRequest, formatAuthError } from '@/lib/auth/middleware';

export const dynamic = 'force-dynamic';

export async function POST(request: NextRequest) {
  try {
    // Verify session exists
    const sessionVerification = await verifySessionFromRequest({
      cookies: {
        alshaya_session:
          request.cookies.get('alshaya_session')?.value || '',
      },
      headers: Object.fromEntries(request.headers.entries()),
    });

    const ipAddress =
      request.headers.get('x-forwarded-for') ||
      request.headers.get('x-real-ip') ||
      'unknown';

    // TODO: Implement session destruction
    // In production, you would:
    // 1. Delete session from database
    // 2. Log activity
    // 3. Invalidate tokens
    // 4. Clear related data

    const response = NextResponse.json(
      {
        success: true,
        message: 'Logged out successfully',
      },
      { status: 200 }
    );

    // Clear session cookie
    response.cookies.set('alshaya_session', '', {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict',
      maxAge: 0,
      path: '/',
    });

    // Clear other auth-related cookies if applicable
    response.cookies.set('csrf_token', '', {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict',
      maxAge: 0,
      path: '/',
    });

    return response;
  } catch (error) {
    console.error('Logout error:', error);
    return NextResponse.json(
      {
        success: false,
        error: 'INTERNAL_ERROR',
        message: 'An error occurred during logout',
      },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  // Allow GET for convenience (some apps prefer this)
  // In production, consider if this is a security issue
  return POST(request);
}
