/**
 * GET /api/auth/session
 * Get current session information and user details
 */

import { NextRequest, NextResponse } from 'next/server';
import { authenticateRequest, formatAuthError } from '@/lib/auth/middleware';

export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest) {
  try {
    // Verify authentication
    const auth = await authenticateRequest({
      cookies: {
        alshaya_session:
          request.cookies.get('alshaya_session')?.value || '',
      },
      headers: Object.fromEntries(request.headers.entries()),
      method: 'GET',
    });

    if (!auth.valid || !auth.context) {
      const error = auth.error || {
        code: 'UNAUTHORIZED',
        message: 'Authentication required',
        statusCode: 401,
      };
      return NextResponse.json(
        formatAuthError(error).body,
        { status: formatAuthError(error).status }
      );
    }

    const { user, sessionToken, isAuthenticated } = auth.context;

    // TODO: Implement session retrieval
    // In production, you would:
    // 1. Get session details from database
    // 2. Get user permissions from cache or database
    // 3. Get active device sessions
    // 4. Calculate remaining session time
    // 5. Include user preferences if applicable

    const sessionExpiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);

    return NextResponse.json(
      {
        success: true,
        data: {
          isAuthenticated,
          user: {
            id: user.id,
            email: user.email,
            role: user.role,
            permissions: user.permissions || {},
            assignedBranch: user.assignedBranch || null,
            avatar: user.avatar || null,
          },
          session: {
            token: sessionToken.substring(0, 20) + '...', // Don't expose full token
            createdAt: new Date(Date.now() - 1 * 60 * 60 * 1000).toISOString(), // 1 hour ago
            expiresAt: sessionExpiresAt.toISOString(),
            remainingTime: Math.floor(
              (sessionExpiresAt.getTime() - Date.now()) / 1000
            ),
          },
          activeSessions: 1,
          lastActivity: new Date().toISOString(),
        },
      },
      { status: 200 }
    );
  } catch (error) {
    console.error('Get session error:', error);
    return NextResponse.json(
      {
        success: false,
        error: 'INTERNAL_ERROR',
        message: 'An error occurred while retrieving session information',
      },
      { status: 500 }
    );
  }
}
