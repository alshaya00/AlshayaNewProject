import { NextRequest } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/prisma';
import { requireAuth } from '@/lib/auth/middleware';
import { validateCSRFToken } from '@/lib/auth/csrf';
import { standardResponse, errorResponse } from '@/lib/api/response';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

const createSnapshotSchema = z.object({
  name: z.string().min(1).max(255),
  snapshotType: z.enum(['MANUAL', 'AUTOMATIC', 'PRE_MERGE', 'PRE_IMPORT', 'SCHEDULED_BACKUP']),
  metadata: z.record(z.any()).optional(),
});

const listSchema = z.object({
  page: z.string().transform(Number).default('1'),
  limit: z.string().transform(Number).default('50'),
  type: z.string().optional(),
});

export async function GET(request: NextRequest) {
  try {
    const user = await requireAuth(request);
    const params = listSchema.parse(
      Object.fromEntries(request.nextUrl.searchParams)
    );

    const page = Math.max(1, params.page);
    const limit = Math.min(500, Math.max(1, params.limit));
    const skip = (page - 1) * limit;

    const where: any = {};
    if (params.type) {
      where.snapshotType = params.type;
    }

    const [snapshots, total] = await Promise.all([
      prisma.treeSnapshot.findMany({
        where,
        skip,
        take: limit,
        select: {
          id: true,
          name: true,
          snapshotType: true,
          createdAt: true,
          createdBy: true,
          metadata: true,
        },
        orderBy: { createdAt: 'desc' },
      }),
      prisma.treeSnapshot.count({ where }),
    ]);

    return standardResponse({
      snapshots,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Error fetching snapshots:', error);
    return errorResponse('Failed to fetch snapshots', 500);
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await requireAuth(request);
    await validateCSRFToken(request);

    const body = createSnapshotSchema.parse(await request.json());

    const snapshot = await prisma.treeSnapshot.create({
      data: {
        name: body.name,
        snapshotType: body.snapshotType,
        createdBy: user.id,
        metadata: body.metadata ? JSON.stringify(body.metadata) : null,
      },
    });

    return standardResponse(snapshot, 201);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return errorResponse('Validation error', 400, error.errors);
    }
    console.error('Error creating snapshot:', error);
    return errorResponse('Failed to create snapshot', 500);
  }
}
