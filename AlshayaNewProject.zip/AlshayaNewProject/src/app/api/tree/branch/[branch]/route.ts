import { NextRequest } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/prisma';
import { requireAuth } from '@/lib/auth/middleware';
import { standardResponse, errorResponse } from '@/lib/api/response';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

const querySchema = z.object({
  includeDeceased: z.string().transform(v => v === 'true').default('true'),
  stats: z.string().transform(v => v === 'true').default('false'),
});

export async function GET(
  request: NextRequest,
  { params }: { params: { branch: string } }
) {
  try {
    const user = await requireAuth(request);
    const branchId = params.branch;
    const query = querySchema.parse(
      Object.fromEntries(request.nextUrl.searchParams)
    );

    const root = await prisma.familyMember.findUnique({
      where: { id: branchId },
      select: {
        id: true,
        firstName: true,
        fullNameAr: true,
        generation: true,
        gender: true,
        birthYear: true,
        status: true,
        deletedAt: true,
      },
    });

    if (!root) {
      return errorResponse('Branch root not found', 404);
    }

    if (root.deletedAt) {
      return errorResponse('Branch has been deleted', 410);
    }

    // Get all descendants
    const descendants: any[] = [];

    async function collectDescendants(memberId: string, depth: number = 0) {
      const children = await prisma.familyMember.findMany({
        where: {
          fatherId: memberId,
          deletedAt: null,
        },
        select: {
          id: true,
          firstName: true,
          fullNameAr: true,
          gender: true,
          birthYear: true,
          generation: true,
          status: true,
          photoUrl: true,
        },
      });

      for (const child of children) {
        if (!query.includeDeceased && child.status === 'DECEASED') continue;

        descendants.push({
          ...child,
          depth,
        });

        await collectDescendants(child.id, depth + 1);
      }
    }

    await collectDescendants(branchId);

    const result: any = {
      branchRoot: root,
      members: descendants,
      totalMembers: descendants.length + 1,
    };

    if (query.stats) {
      const males = descendants.filter(m => m.gender === 'MALE').length;
      const females = descendants.filter(m => m.gender === 'FEMALE').length;
      const deceased = descendants.filter(m => m.status === 'DECEASED').length;
      const generations = new Set(descendants.map(m => m.generation));

      result.statistics = {
        totalMembers: descendants.length + 1,
        males,
        females,
        living: descendants.length + 1 - deceased,
        deceased,
        generationSpan: Math.max(...[root.generation, ...Array.from(generations)]) -
          root.generation + 1,
      };
    }

    return standardResponse(result);
  } catch (error) {
    console.error('Error fetching branch:', error);
    return errorResponse('Failed to fetch branch data', 500);
  }
}
