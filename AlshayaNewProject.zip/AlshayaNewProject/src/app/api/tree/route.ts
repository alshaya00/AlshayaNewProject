import { NextRequest } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/prisma';
import { requireAuth } from '@/lib/auth/middleware';
import { standardResponse, errorResponse } from '@/lib/api/response';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

const querySchema = z.object({
  format: z.enum(['d3', 'hierarchical', 'flat']).default('d3'),
  maxDepth: z.string().transform(Number).default('20'),
  includeDeceased: z.string().transform(v => v === 'true').default('true'),
  includePhotos: z.string().transform(v => v === 'true').default('false'),
});

interface D3Node {
  id: string;
  name: string;
  gender: string;
  generation: number;
  photoUrl?: string | null;
  children: D3Node[];
}

async function buildD3Tree(
  rootId: string,
  maxDepth: number = 20,
  includeDeceased: boolean = true,
  includePhotos: boolean = false,
  depth: number = 0
): Promise<D3Node | null> {
  if (depth > maxDepth) return null;

  const member = await prisma.familyMember.findUnique({
    where: { id: rootId },
    select: {
      id: true,
      firstName: true,
      gender: true,
      generation: true,
      photoUrl: true,
      status: true,
      deletedAt: true,
    },
  });

  if (!member || member.deletedAt) return null;

  if (!includeDeceased && member.status === 'DECEASED') {
    return null;
  }

  const children = await prisma.familyMember.findMany({
    where: {
      fatherId: rootId,
      deletedAt: null,
    },
    select: {
      id: true,
      firstName: true,
      gender: true,
      generation: true,
      photoUrl: true,
      status: true,
    },
    orderBy: { firstName: 'asc' },
  });

  const childNodes: D3Node[] = [];
  for (const child of children) {
    if (!includeDeceased && child.status === 'DECEASED') continue;

    const childNode = await buildD3Tree(
      child.id,
      maxDepth,
      includeDeceased,
      includePhotos,
      depth + 1
    );
    if (childNode) {
      childNodes.push(childNode);
    }
  }

  const node: D3Node = {
    id: member.id,
    name: member.firstName,
    gender: member.gender,
    generation: member.generation,
    children: childNodes,
  };

  if (includePhotos && member.photoUrl) {
    node.photoUrl = member.photoUrl;
  }

  return node;
}

export async function GET(request: NextRequest) {
  try {
    const user = await requireAuth(request);
    const params = querySchema.parse(
      Object.fromEntries(request.nextUrl.searchParams)
    );

    // Get root member (generation 1)
    const roots = await prisma.familyMember.findMany({
      where: {
        generation: 1,
        deletedAt: null,
      },
      select: { id: true },
      take: 1,
    });

    if (roots.length === 0) {
      return errorResponse('No root member found', 404);
    }

    const rootId = roots[0].id;

    if (params.format === 'd3') {
      const tree = await buildD3Tree(
        rootId,
        params.maxDepth,
        params.includeDeceased,
        params.includePhotos
      );

      if (!tree) {
        return errorResponse('Failed to build tree', 500);
      }

      return standardResponse({
        format: 'D3',
        data: tree,
        generatedAt: new Date(),
      });
    } else if (params.format === 'hierarchical') {
      const allMembers = await prisma.familyMember.findMany({
        where: { deletedAt: null },
        select: {
          id: true,
          firstName: true,
          generation: true,
          fatherId: true,
          gender: true,
          photoUrl: true,
          status: true,
        },
      });

      const byGeneration = new Map<number, any[]>();
      for (const member of allMembers) {
        if (!params.includeDeceased && member.status === 'DECEASED') continue;
        if (!byGeneration.has(member.generation)) {
          byGeneration.set(member.generation, []);
        }
        byGeneration.get(member.generation)!.push(member);
      }

      const hierarchical = Array.from({ length: 20 }).map((_, i) => ({
        generation: i + 1,
        members: byGeneration.get(i + 1) || [],
      }));

      return standardResponse({
        format: 'Hierarchical',
        data: hierarchical,
        generatedAt: new Date(),
      });
    } else {
      // Flat format
      const allMembers = await prisma.familyMember.findMany({
        where: { deletedAt: null },
        select: {
          id: true,
          firstName: true,
          generation: true,
          fatherId: true,
          gender: true,
          photoUrl: true,
          status: true,
        },
      });

      return standardResponse({
        format: 'Flat',
        data: allMembers.filter(
          m => params.includeDeceased || m.status !== 'DECEASED'
        ),
        generatedAt: new Date(),
      });
    }
  } catch (error) {
    if (error instanceof z.ZodError) {
      return errorResponse('Validation error', 400, error.errors);
    }
    console.error('Error fetching tree:', error);
    return errorResponse('Failed to fetch tree data', 500);
  }
}
