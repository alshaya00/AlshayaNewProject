import { NextRequest } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireAuth } from '@/lib/auth/middleware';
import { standardResponse, errorResponse } from '@/lib/api/response';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

export async function GET(request: NextRequest) {
  try {
    const user = await requireAuth(request);

    const [
      totalMembers,
      livingCount,
      deceasedCount,
      maleCount,
      femaleCount,
      generationStats,
      branchStats,
    ] = await Promise.all([
      prisma.familyMember.count({ where: { deletedAt: null } }),
      prisma.familyMember.count({
        where: { deletedAt: null, status: 'LIVING' },
      }),
      prisma.familyMember.count({
        where: { deletedAt: null, status: 'DECEASED' },
      }),
      prisma.familyMember.count({
        where: { deletedAt: null, gender: 'MALE' },
      }),
      prisma.familyMember.count({
        where: { deletedAt: null, gender: 'FEMALE' },
      }),
      prisma.familyMember.groupBy({
        by: ['generation'],
        _count: { id: true },
        where: { deletedAt: null },
      }),
      prisma.familyMember.groupBy({
        by: ['lineageBranchName'],
        _count: { id: true },
        where: { deletedAt: null },
      }),
    ]);

    // Get generation info
    const generationData = generationStats.map(g => ({
      generation: g.generation,
      count: g._count.id,
    }));

    // Get branch info
    const branchData = branchStats
      .filter(b => b.lineageBranchName)
      .map(b => ({
        branch: b.lineageBranchName,
        count: b._count.id,
      }));

    // Get depth info
    const maxGeneration = Math.max(...generationData.map(g => g.generation), 1);

    // Get sons/daughters count for specific members
    const parentStats = await prisma.familyMember.findMany({
      where: {
        deletedAt: null,
        OR: [
          { sonsCount: { gt: 0 } },
          { daughtersCount: { gt: 0 } },
        ],
      },
      select: {
        id: true,
        firstName: true,
        sonsCount: true,
        daughtersCount: true,
      },
      take: 10,
    });

    return standardResponse({
      summary: {
        totalMembers,
        living: livingCount,
        deceased: deceasedCount,
        male: maleCount,
        female: femaleCount,
        ratio: {
          maleToFemale: (maleCount / femaleCount).toFixed(2),
          livingToDeceased: (livingCount / (deceasedCount || 1)).toFixed(2),
        },
      },
      genealogy: {
        generations: maxGeneration,
        byGeneration: generationData,
        byBranch: branchData,
      },
      topParents: parentStats.map(p => ({
        id: p.id,
        name: p.firstName,
        sons: p.sonsCount,
        daughters: p.daughtersCount,
        totalChildren: p.sonsCount + p.daughtersCount,
      })),
      timestamp: new Date(),
    });
  } catch (error) {
    console.error('Error calculating statistics:', error);
    return errorResponse('Failed to calculate statistics', 500);
  }
}
