import { NextRequest } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireAuth } from '@/lib/auth/middleware';
import { standardResponse, errorResponse } from '@/lib/api/response';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

interface IntegrityIssue {
  type: string;
  severity: 'ERROR' | 'WARNING' | 'INFO';
  memberId: string;
  memberName: string;
  description: string;
  suggestion: string;
}

export async function GET(request: NextRequest) {
  try {
    const user = await requireAuth(request);
    const issues: IntegrityIssue[] = [];

    const allMembers = await prisma.familyMember.findMany({
      where: { deletedAt: null },
      select: {
        id: true,
        firstName: true,
        generation: true,
        fatherId: true,
        status: true,
      },
    });

    const memberMap = new Map(allMembers.map(m => [m.id, m]));

    // Check for cycles
    const visited = new Set<string>();
    const recursionStack = new Set<string>();

    function hasCycle(id: string): boolean {
      if (recursionStack.has(id)) {
        return true;
      }

      if (visited.has(id)) {
        return false;
      }

      visited.add(id);
      recursionStack.add(id);

      const member = memberMap.get(id);
      if (member && member.fatherId) {
        if (hasCycle(member.fatherId)) {
          return true;
        }
      }

      recursionStack.delete(id);
      return false;
    }

    for (const member of allMembers) {
      if (hasCycle(member.id)) {
        issues.push({
          type: 'CYCLE_DETECTED',
          severity: 'ERROR',
          memberId: member.id,
          memberName: member.firstName,
          description: 'Member has a circular parent-child relationship',
          suggestion: 'Review and correct the parent reference',
        });
      }
    }

    // Check for orphans (no father but generation > 1)
    for (const member of allMembers) {
      if (!member.fatherId && member.generation > 1) {
        issues.push({
          type: 'ORPHAN',
          severity: 'WARNING',
          memberId: member.id,
          memberName: member.firstName,
          description: `Generation ${member.generation} member has no father`,
          suggestion: 'Set appropriate father or adjust generation level',
        });
      }
    }

    // Check for invalid father references
    for (const member of allMembers) {
      if (member.fatherId && !memberMap.has(member.fatherId)) {
        issues.push({
          type: 'INVALID_REFERENCE',
          severity: 'ERROR',
          memberId: member.id,
          memberName: member.firstName,
          description: `Father with ID ${member.fatherId} does not exist`,
          suggestion: 'Clear the invalid father reference',
        });
      }
    }

    // Check for generation inconsistencies
    for (const member of allMembers) {
      if (member.fatherId) {
        const father = memberMap.get(member.fatherId);
        if (father && father.generation >= member.generation) {
          issues.push({
            type: 'GENERATION_MISMATCH',
            severity: 'WARNING',
            memberId: member.id,
            memberName: member.firstName,
            description: `Generation ${member.generation} but father is generation ${father.generation}`,
            suggestion: 'Adjust member generation to be father generation + 1',
          });
        }
      }
    }

    // Check for deceased ancestors
    for (const member of allMembers) {
      if (member.fatherId) {
        const father = memberMap.get(member.fatherId);
        if (father && father.status === 'DECEASED' && member.status === 'LIVING') {
          // This is actually valid - just informational
          issues.push({
            type: 'DECEASED_ANCESTOR',
            severity: 'INFO',
            memberId: member.id,
            memberName: member.firstName,
            description: 'Member has a deceased father',
            suggestion: 'No action needed - this is valid',
          });
        }
      }
    }

    const stats = {
      total: issues.length,
      errors: issues.filter(i => i.severity === 'ERROR').length,
      warnings: issues.filter(i => i.severity === 'WARNING').length,
      info: issues.filter(i => i.severity === 'INFO').length,
    };

    return standardResponse({
      status: stats.errors === 0 ? 'HEALTHY' : 'ISSUES_FOUND',
      statistics: stats,
      issues: issues.sort((a, b) => {
        const severityOrder = { ERROR: 0, WARNING: 1, INFO: 2 };
        return severityOrder[a.severity] - severityOrder[b.severity];
      }),
      timestamp: new Date(),
    });
  } catch (error) {
    console.error('Error checking tree integrity:', error);
    return errorResponse('Failed to check tree integrity', 500);
  }
}
