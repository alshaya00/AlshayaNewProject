import { NextRequest } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/prisma';
import { requireAuth } from '@/lib/auth/middleware';
import { validateCSRFToken } from '@/lib/auth/csrf';
import { standardResponse, errorResponse } from '@/lib/api/response';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

const createEventSchema = z.object({
  title: z.string().min(1).max(255),
  description: z.string().optional(),
  startDate: z.string().datetime(),
  endDate: z.string().datetime().optional(),
  location: z.string().optional(),
  organizerId: z.string(),
  attendeeIds: z.array(z.string()).optional(),
});

const listSchema = z.object({
  page: z.string().transform(Number).default('1'),
  limit: z.string().transform(Number).default('50'),
  startDate: z.string().optional(),
  endDate: z.string().optional(),
});

export async function GET(request: NextRequest) {
  try {
    const user = await requireAuth(request);
    const params = listSchema.parse(
      Object.fromEntries(request.nextUrl.searchParams)
    );

    const page = Math.max(1, params.page);
    const limit = Math.min(500, Math.max(1, params.limit));
    const skip = (page - 1) * limit;

    const where: any = {};
    if (params.startDate || params.endDate) {
      where.startDate = {};
      if (params.startDate) {
        where.startDate.gte = new Date(params.startDate);
      }
      if (params.endDate) {
        where.startDate.lte = new Date(params.endDate);
      }
    }

    const [events, total] = await Promise.all([
      prisma.gathering.findMany({
        where,
        skip,
        take: limit,
        select: {
          id: true,
          title: true,
          description: true,
          startDate: true,
          endDate: true,
          location: true,
          organizerId: true,
          createdAt: true,
        },
        orderBy: { startDate: 'asc' },
      }),
      prisma.gathering.count({ where }),
    ]);

    return standardResponse({
      data: events,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Error fetching events:', error);
    return errorResponse('Failed to fetch events', 500);
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await requireAuth(request);
    await validateCSRFToken(request);

    const body = createEventSchema.parse(await request.json());

    // Validate organizer exists
    const organizer = await prisma.familyMember.findUnique({
      where: { id: body.organizerId },
    });

    if (!organizer) {
      return errorResponse('Organizer not found', 404);
    }

    const event = await prisma.gathering.create({
      data: {
        title: body.title,
        description: body.description,
        startDate: new Date(body.startDate),
        endDate: body.endDate ? new Date(body.endDate) : null,
        location: body.location,
        organizerId: body.organizerId,
      },
    });

    // Add attendees if provided
    if (body.attendeeIds && body.attendeeIds.length > 0) {
      await Promise.all(
        body.attendeeIds.map(attendeeId =>
          prisma.gatheringAttendee.create({
            data: {
              gatheringId: event.id,
              memberId: attendeeId,
              rsvpStatus: 'PENDING',
            },
          })
        )
      );
    }

    return standardResponse(event, 201);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return errorResponse('Validation error', 400, error.errors);
    }
    console.error('Error creating event:', error);
    return errorResponse('Failed to create event', 500);
  }
}
