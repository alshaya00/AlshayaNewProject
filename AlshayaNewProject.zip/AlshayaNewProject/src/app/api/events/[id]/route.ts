import { NextRequest } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/prisma';
import { requireAuth } from '@/lib/auth/middleware';
import { validateCSRFToken } from '@/lib/auth/csrf';
import { standardResponse, errorResponse } from '@/lib/api/response';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

const updateEventSchema = z.object({
  title: z.string().min(1).max(255).optional(),
  description: z.string().optional(),
  startDate: z.string().datetime().optional(),
  endDate: z.string().datetime().optional(),
  location: z.string().optional(),
});

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = await requireAuth(request);

    const event = await prisma.gathering.findUnique({
      where: { id: params.id },
      include: {
        organizer: {
          select: {
            id: true,
            firstName: true,
            fullNameAr: true,
          },
        },
        attendees: {
          include: {
            member: {
              select: {
                id: true,
                firstName: true,
                fullNameAr: true,
                gender: true,
              },
            },
          },
        },
      },
    });

    if (!event) {
      return errorResponse('Event not found', 404);
    }

    return standardResponse(event);
  } catch (error) {
    console.error('Error fetching event:', error);
    return errorResponse('Failed to fetch event', 500);
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = await requireAuth(request);
    await validateCSRFToken(request);

    const body = updateEventSchema.parse(await request.json());

    const event = await prisma.gathering.findUnique({
      where: { id: params.id },
    });

    if (!event) {
      return errorResponse('Event not found', 404);
    }

    const updated = await prisma.gathering.update({
      where: { id: params.id },
      data: {
        title: body.title,
        description: body.description,
        startDate: body.startDate ? new Date(body.startDate) : undefined,
        endDate: body.endDate ? new Date(body.endDate) : undefined,
        location: body.location,
      },
    });

    return standardResponse(updated);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return errorResponse('Validation error', 400, error.errors);
    }
    console.error('Error updating event:', error);
    return errorResponse('Failed to update event', 500);
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = await requireAuth(request);
    await validateCSRFToken(request);

    const event = await prisma.gathering.findUnique({
      where: { id: params.id },
    });

    if (!event) {
      return errorResponse('Event not found', 404);
    }

    // Delete attendees first
    await prisma.gatheringAttendee.deleteMany({
      where: { gatheringId: params.id },
    });

    await prisma.gathering.delete({
      where: { id: params.id },
    });

    return standardResponse({ message: 'Event deleted' });
  } catch (error) {
    console.error('Error deleting event:', error);
    return errorResponse('Failed to delete event', 500);
  }
}
