import { NextRequest } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/prisma';
import { requireAuth } from '@/lib/auth/middleware';
import { standardResponse, errorResponse } from '@/lib/api/response';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

const listSchema = z.object({
  page: z.string().transform(Number).default('1'),
  limit: z.string().transform(Number).default('50'),
  unreadOnly: z.string().transform(v => v === 'true').default('false'),
});

export async function GET(request: NextRequest) {
  try {
    const user = await requireAuth(request);
    const params = listSchema.parse(
      Object.fromEntries(request.nextUrl.searchParams)
    );

    const page = Math.max(1, params.page);
    const limit = Math.min(500, Math.max(1, params.limit));
    const skip = (page - 1) * limit;

    const where: any = { userId: user.id };
    if (params.unreadOnly) {
      where.readAt = null;
    }

    const [notifications, total, unreadCount] = await Promise.all([
      prisma.notification.findMany({
        where,
        skip,
        take: limit,
        select: {
          id: true,
          title: true,
          message: true,
          type: true,
          read: true,
          createdAt: true,
        },
        orderBy: { createdAt: 'desc' },
      }),
      prisma.notification.count({ where }),
      prisma.notification.count({
        where: { userId: user.id, read: false },
      }),
    ]);

    return standardResponse({
      data: notifications,
      unreadCount,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Error fetching notifications:', error);
    return errorResponse('Failed to fetch notifications', 500);
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await requireAuth(request);

    const body = z.object({
      notificationId: z.string(),
      action: z.enum(['read', 'unread', 'delete']),
    }).parse(await request.json());

    const notification = await prisma.notification.findUnique({
      where: { id: body.notificationId },
    });

    if (!notification) {
      return errorResponse('Notification not found', 404);
    }

    if (notification.userId !== user.id) {
      return errorResponse('Unauthorized', 403);
    }

    if (body.action === 'read') {
      const updated = await prisma.notification.update({
        where: { id: body.notificationId },
        data: { read: true },
      });
      return standardResponse(updated);
    } else if (body.action === 'unread') {
      const updated = await prisma.notification.update({
        where: { id: body.notificationId },
        data: { read: false },
      });
      return standardResponse(updated);
    } else if (body.action === 'delete') {
      await prisma.notification.delete({
        where: { id: body.notificationId },
      });
      return standardResponse({ message: 'Notification deleted' });
    }

    return errorResponse('Invalid action', 400);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return errorResponse('Validation error', 400, error.errors);
    }
    console.error('Error processing notification:', error);
    return errorResponse('Failed to process notification', 500);
  }
}
