import { NextRequest } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/prisma';
import { requireAuth } from '@/lib/auth/middleware';
import { validateCSRFToken } from '@/lib/auth/csrf';
import { standardResponse, errorResponse } from '@/lib/api/response';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

const preferencesSchema = z.object({
  emailNotifications: z.boolean().optional(),
  smsNotifications: z.boolean().optional(),
  pushNotifications: z.boolean().optional(),
  newMemberAdded: z.boolean().optional(),
  memberUpdated: z.boolean().optional(),
  journalPublished: z.boolean().optional(),
  eventCreated: z.boolean().optional(),
  treeUpdated: z.boolean().optional(),
  dailyDigest: z.boolean().optional(),
  weeklyReport: z.boolean().optional(),
});

export async function GET(request: NextRequest) {
  try {
    const user = await requireAuth(request);

    // Get or create user preferences
    let preferences = await prisma.notificationPreference.findUnique({
      where: { userId: user.id },
    });

    if (!preferences) {
      preferences = await prisma.notificationPreference.create({
        data: {
          userId: user.id,
          emailNotifications: true,
          smsNotifications: true,
          pushNotifications: true,
          newMemberAdded: true,
          memberUpdated: true,
          journalPublished: true,
          eventCreated: true,
          treeUpdated: true,
          dailyDigest: false,
          weeklyReport: true,
        },
      });
    }

    return standardResponse(preferences);
  } catch (error) {
    console.error('Error fetching preferences:', error);
    return errorResponse('Failed to fetch preferences', 500);
  }
}

export async function PUT(request: NextRequest) {
  try {
    const user = await requireAuth(request);
    await validateCSRFToken(request);

    const body = preferencesSchema.parse(await request.json());

    const preferences = await prisma.notificationPreference.upsert({
      where: { userId: user.id },
      create: {
        userId: user.id,
        ...body,
      },
      update: body,
    });

    return standardResponse(preferences);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return errorResponse('Validation error', 400, error.errors);
    }
    console.error('Error updating preferences:', error);
    return errorResponse('Failed to update preferences', 500);
  }
}
