'use client';

import React, { useState, useEffect } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';

export default function VerifyEmailPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const token = searchParams.get('token');
  const email = searchParams.get('email');

  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    const verifyEmail = async () => {
      if (!token) {
        setError('رابط التحقق غير صحيح');
        setIsLoading(false);
        return;
      }

      try {
        // TODO: Implement actual email verification
        // const response = await fetch('/api/auth/verify-email', {
        //   method: 'POST',
        //   headers: { 'Content-Type': 'application/json' },
        //   body: JSON.stringify({ token }),
        // });

        // Mock success
        await new Promise(resolve => setTimeout(resolve, 1500));
        setSuccess(true);
      } catch (err) {
        setError('فشل التحقق من البريد الإلكتروني');
      } finally {
        setIsLoading(false);
      }
    };

    verifyEmail();
  }, [token]);

  return (
    <div className="min-h-screen flex flex-col">
      <header className="py-6 px-4 border-b border-slate-700">
        <div className="max-w-7xl mx-auto">
          <Link href="/" className="text-2xl font-bold text-white hover:text-slate-200">
            آل شايع
          </Link>
        </div>
      </header>

      <main className="flex-1 flex items-center justify-center px-4 py-12">
        <div className="w-full max-w-md">
          <div className="bg-slate-800 rounded-xl shadow-xl p-8 border border-slate-700">
            {isLoading ? (
              <div className="text-center space-y-6">
                <div className="w-20 h-20 mx-auto rounded-full bg-blue-900 flex items-center justify-center">
                  <svg className="w-10 h-10 text-blue-400 animate-spin" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" className="opacity-25" />
                    <path fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" className="opacity-75" />
                  </svg>
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-white mb-2">جاري التحقق</h2>
                  <p className="text-slate-400">يرجى الانتظار...</p>
                </div>
              </div>
            ) : error ? (
              <div className="space-y-6">
                <div className="text-center">
                  <div className="w-20 h-20 mx-auto rounded-full bg-red-900 flex items-center justify-center mb-4">
                    <svg className="w-10 h-10 text-red-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                  </div>
                  <h2 className="text-2xl font-bold text-white mb-2">فشل التحقق</h2>
                  <p className="text-red-400">{error}</p>
                </div>

                <div className="space-y-3">
                  <Link
                    href="/login"
                    className="w-full py-3 px-4 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 transition-colors text-center block"
                  >
                    تسجيل الدخول
                  </Link>
                  <Link
                    href="/register"
                    className="w-full py-3 px-4 border border-slate-600 text-slate-300 font-medium rounded-lg hover:bg-slate-700 transition-colors text-center block"
                  >
                    التسجيل مرة أخرى
                  </Link>
                </div>
              </div>
            ) : success ? (
              <div className="space-y-6">
                <div className="text-center">
                  <div className="w-20 h-20 mx-auto rounded-full bg-green-900 flex items-center justify-center mb-4">
                    <svg className="w-10 h-10 text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                  </div>
                  <h2 className="text-2xl font-bold text-white mb-2">تم التحقق بنجاح</h2>
                  <p className="text-slate-400 mb-2">تم تأكيد بريدك الإلكتروني</p>
                  {email && <p className="text-slate-500 text-sm">{email}</p>}
                </div>

                <button
                  onClick={() => router.push('/login')}
                  className="w-full py-3 px-4 bg-green-600 text-white font-medium rounded-lg hover:bg-green-700 transition-colors"
                >
                  انتقل إلى تسجيل الدخول
                </button>
              </div>
            ) : null}
          </div>
        </div>
      </main>

      <footer className="py-6 text-center text-slate-500 text-sm border-t border-slate-700">
        <p>شجرة عائلة آل شايع</p>
      </footer>
    </div>
  );
}
