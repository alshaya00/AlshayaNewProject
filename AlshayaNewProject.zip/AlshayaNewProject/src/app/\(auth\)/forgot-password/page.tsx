'use client';

import React, { useState } from 'react';
import Link from 'next/link';

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsLoading(true);

    try {
      // TODO: Implement actual password reset request
      // const response = await fetch('/api/auth/forgot-password', {
      //   method: 'POST',
      //   headers: { 'Content-Type': 'application/json' },
      //   body: JSON.stringify({ email }),
      // });

      // Mock success
      await new Promise(resolve => setTimeout(resolve, 1000));
      setSubmitted(true);
    } catch (err) {
      setError('فشل الطلب. يرجى المحاولة لاحقاً');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <header className="py-6 px-4 border-b border-slate-700">
        <div className="max-w-7xl mx-auto">
          <Link href="/" className="text-2xl font-bold text-white hover:text-slate-200">
            آل شايع
          </Link>
        </div>
      </header>

      <main className="flex-1 flex items-center justify-center px-4 py-12">
        <div className="w-full max-w-md">
          <div className="bg-slate-800 rounded-xl shadow-xl p-8 border border-slate-700">
            <div className="text-center mb-8">
              <div className="w-20 h-20 mx-auto mb-4 rounded-full bg-orange-900 flex items-center justify-center">
                <svg className="w-10 h-10 text-orange-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z" />
                </svg>
              </div>
              <h2 className="text-2xl font-bold text-white">استعادة كلمة المرور</h2>
              <p className="text-slate-400 mt-2">أدخل بريدك الإلكتروني لاستعادة حسابك</p>
            </div>

            {submitted ? (
              <div className="space-y-6">
                <div className="p-4 bg-green-900/30 border border-green-700 rounded-lg text-center">
                  <p className="text-green-400 font-medium">تم إرسال الرابط بنجاح</p>
                  <p className="text-green-300 text-sm mt-2">
                    تحقق من بريدك الإلكتروني واتبع الخطوات المرفقة لاستعادة كلمة المرور
                  </p>
                </div>

                <Link
                  href="/login"
                  className="w-full py-3 px-4 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 transition-colors text-center block"
                >
                  العودة إلى تسجيل الدخول
                </Link>

                <button
                  onClick={() => {
                    setSubmitted(false);
                    setEmail('');
                  }}
                  className="w-full py-3 px-4 border border-slate-600 text-slate-300 font-medium rounded-lg hover:bg-slate-700 transition-colors"
                >
                  حاول مرة أخرى ببريد مختلف
                </button>
              </div>
            ) : (
              <>
                {error && (
                  <div className="mb-6 p-4 bg-red-900/30 border border-red-700 rounded-lg">
                    <p className="text-red-400">{error}</p>
                  </div>
                )}

                <form onSubmit={handleSubmit} className="space-y-5">
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-slate-300 mb-2">
                      البريد الإلكتروني
                    </label>
                    <input
                      type="email"
                      id="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full px-4 py-3 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                      placeholder="example@email.com"
                      required
                      dir="ltr"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={isLoading}
                    className="w-full py-3 px-4 bg-orange-600 text-white font-medium rounded-lg hover:bg-orange-700 disabled:opacity-50 transition-colors"
                  >
                    {isLoading ? 'جاري الإرسال...' : 'إرسال رابط الاستعادة'}
                  </button>
                </form>

                <p className="text-center mt-6 text-slate-400">
                  تذكرت كلمة المرور؟{' '}
                  <Link href="/login" className="text-orange-400 hover:text-orange-300 font-medium">
                    تسجيل الدخول
                  </Link>
                </p>
              </>
            )}
          </div>
        </div>
      </main>

      <footer className="py-6 text-center text-slate-500 text-sm border-t border-slate-700">
        <p>شجرة عائلة آل شايع</p>
      </footer>
    </div>
  );
}
