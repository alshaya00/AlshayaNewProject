'use client';

import React, { useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';

export default function ResetPasswordPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const token = searchParams.get('token');

  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (password !== confirmPassword) {
      setError('كلمات المرور غير متطابقة');
      return;
    }

    if (password.length < 8) {
      setError('كلمة المرور يجب أن تكون 8 أحرف على الأقل');
      return;
    }

    setIsLoading(true);

    try {
      // TODO: Implement actual password reset
      // const response = await fetch('/api/auth/reset-password', {
      //   method: 'POST',
      //   headers: { 'Content-Type': 'application/json' },
      //   body: JSON.stringify({ token, password }),
      // });

      // Mock success
      await new Promise(resolve => setTimeout(resolve, 1000));
      setSuccess(true);
    } catch (err) {
      setError('فشل تحديث كلمة المرور. يرجى المحاولة لاحقاً');
    } finally {
      setIsLoading(false);
    }
  };

  if (!token) {
    return (
      <div className="min-h-screen flex flex-col">
        <header className="py-6 px-4 border-b border-slate-700">
          <div className="max-w-7xl mx-auto">
            <Link href="/" className="text-2xl font-bold text-white">
              آل شايع
            </Link>
          </div>
        </header>

        <main className="flex-1 flex items-center justify-center px-4">
          <div className="text-center">
            <div className="w-20 h-20 mx-auto mb-4 rounded-full bg-red-900 flex items-center justify-center">
              <svg className="w-10 h-10 text-red-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <h2 className="text-2xl font-bold text-white mb-2">رابط غير صحيح</h2>
            <p className="text-slate-400 mb-6">الرابط المرسل غير صحيح أو انتهت صلاحيته</p>
            <Link href="/forgot-password" className="text-blue-400 hover:text-blue-300">
              طلب رابط جديد
            </Link>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <header className="py-6 px-4 border-b border-slate-700">
        <div className="max-w-7xl mx-auto">
          <Link href="/" className="text-2xl font-bold text-white hover:text-slate-200">
            آل شايع
          </Link>
        </div>
      </header>

      <main className="flex-1 flex items-center justify-center px-4 py-12">
        <div className="w-full max-w-md">
          <div className="bg-slate-800 rounded-xl shadow-xl p-8 border border-slate-700">
            <div className="text-center mb-8">
              <div className="w-20 h-20 mx-auto mb-4 rounded-full bg-purple-900 flex items-center justify-center">
                <svg className="w-10 h-10 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                </svg>
              </div>
              <h2 className="text-2xl font-bold text-white">تعيين كلمة مرور جديدة</h2>
              <p className="text-slate-400 mt-2">أدخل كلمة مرور قوية وآمنة</p>
            </div>

            {success ? (
              <div className="space-y-6">
                <div className="p-4 bg-green-900/30 border border-green-700 rounded-lg text-center">
                  <p className="text-green-400 font-medium">تم تحديث كلمة المرور بنجاح</p>
                  <p className="text-green-300 text-sm mt-2">يمكنك الآن تسجيل الدخول بكلمة المرور الجديدة</p>
                </div>

                <Link
                  href="/login"
                  className="w-full py-3 px-4 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 transition-colors text-center block"
                >
                  تسجيل الدخول
                </Link>
              </div>
            ) : (
              <>
                {error && (
                  <div className="mb-6 p-4 bg-red-900/30 border border-red-700 rounded-lg">
                    <p className="text-red-400">{error}</p>
                  </div>
                )}

                <form onSubmit={handleSubmit} className="space-y-5">
                  <div>
                    <label htmlFor="password" className="block text-sm font-medium text-slate-300 mb-2">
                      كلمة المرور الجديدة
                    </label>
                    <input
                      type="password"
                      id="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full px-4 py-3 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                      placeholder="••••••••"
                      required
                      dir="ltr"
                    />
                    <p className="text-xs text-slate-400 mt-1">يجب أن تكون 8 أحرف على الأقل</p>
                  </div>

                  <div>
                    <label htmlFor="confirmPassword" className="block text-sm font-medium text-slate-300 mb-2">
                      تأكيد كلمة المرور
                    </label>
                    <input
                      type="password"
                      id="confirmPassword"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      className="w-full px-4 py-3 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                      placeholder="••••••••"
                      required
                      dir="ltr"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={isLoading}
                    className="w-full py-3 px-4 bg-purple-600 text-white font-medium rounded-lg hover:bg-purple-700 disabled:opacity-50 transition-colors"
                  >
                    {isLoading ? 'جاري التحديث...' : 'تحديث كلمة المرور'}
                  </button>
                </form>

                <p className="text-center mt-6 text-slate-400">
                  تذكرت كلمة المرور؟{' '}
                  <Link href="/login" className="text-purple-400 hover:text-purple-300 font-medium">
                    تسجيل الدخول
                  </Link>
                </p>
              </>
            )}
          </div>
        </div>
      </main>

      <footer className="py-6 text-center text-slate-500 text-sm border-t border-slate-700">
        <p>شجرة عائلة آل شايع</p>
      </footer>
    </div>
  );
}
