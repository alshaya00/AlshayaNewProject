'use client';

import { useEffect } from 'react';
import Link from 'next/link';

interface ErrorPageProps {
  error: Error & { digest?: string };
  reset: () => void;
}

export default function ErrorPage({ error, reset }: ErrorPageProps) {
  useEffect(() => {
    console.error(error);
  }, [error]);

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 px-4">
      <div className="text-center max-w-md">
        <div className="w-20 h-20 rounded-full bg-red-900/20 flex items-center justify-center mx-auto mb-6">
          <svg className="w-10 h-10 text-red-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M12 9v2m0 4v2m0 4v2M9 3h6a3 3 0 013 3v18a3 3 0 01-3 3H9a3 3 0 01-3-3V6a3 3 0 013-3z"
            />
          </svg>
        </div>

        <h1 className="text-3xl font-bold text-white mb-2">حدث خطأ</h1>

        <p className="text-slate-400 mb-2">
          عذراً، حدث خطأ غير متوقع. يرجى المحاولة مرة أخرى.
        </p>

        {error.message && (
          <p className="text-sm text-red-400/70 mb-6 bg-red-900/10 rounded p-3 font-mono">
            {error.message}
          </p>
        )}

        <div className="flex flex-col gap-3">
          <button
            onClick={reset}
            className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium"
          >
            حاول مرة أخرى
          </button>

          <Link
            href="/"
            className="px-6 py-2 bg-slate-800 text-white rounded-lg hover:bg-slate-700 transition-colors font-medium"
          >
            الرجوع للصفحة الرئيسية
          </Link>
        </div>
      </div>
    </div>
  );
}
