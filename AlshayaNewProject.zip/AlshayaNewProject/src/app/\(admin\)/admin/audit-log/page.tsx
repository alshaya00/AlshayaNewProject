import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Audit Log',
  description: 'View system audit logs',
};

export default function AuditLogPage() {
  return (
    <div className="w-full">
      <header className="bg-gradient-to-r from-slate-900 to-slate-950 border-b border-slate-800 p-6">
        <h1 className="text-3xl font-bold text-white mb-2">سجل التدقيق</h1>
        <p className="text-slate-500">تتبع جميع العمليات والتغييرات في النظام</p>
      </header>

      <main className="p-6">
        <div className="mb-6 flex gap-4">
          <input
            type="text"
            placeholder="بحث في السجلات..."
            className="flex-1 px-4 py-2 bg-slate-900 border border-slate-800 rounded-lg text-white placeholder-slate-600 focus:ring-2 focus:ring-blue-500"
          />
          <select className="px-4 py-2 bg-slate-900 border border-slate-800 rounded-lg text-white focus:ring-2 focus:ring-blue-500">
            <option>جميع الأنواع</option>
            <option>إنشاء</option>
            <option>تعديل</option>
            <option>حذف</option>
            <option>تسجيل دخول</option>
          </select>
        </div>

        <div className="bg-slate-900 rounded-lg border border-slate-800 overflow-hidden">
          <table className="w-full">
            <thead className="bg-slate-800">
              <tr>
                <th className="px-6 py-3 text-right text-sm font-semibold text-white">الإجراء</th>
                <th className="px-6 py-3 text-right text-sm font-semibold text-white">المستخدم</th>
                <th className="px-6 py-3 text-right text-sm font-semibold text-white">التفاصيل</th>
                <th className="px-6 py-3 text-right text-sm font-semibold text-white">الوقت</th>
              </tr>
            </thead>
            <tbody>
              {[
                { action: 'إضافة عضو', user: 'محمد علي', details: 'تم إضافة فاطمة الشايع', time: '2024-03-08 14:30' },
                { action: 'تعديل ملف', user: 'علي الشايع', details: 'تم تحديث معلومات الملف الشخصي', time: '2024-03-08 13:45' },
                { action: 'تسجيل دخول', user: 'نور الشايع', details: 'تسجيل دخول من جهاز جديد', time: '2024-03-08 12:20' },
                { action: 'حذف صورة', user: 'فاطمة الشايع', details: 'تم حذف صورة من المعرض', time: '2024-03-08 11:15' },
                { action: 'إضافة دفتر', user: 'محمد علي', details: 'تم إضافة دفتر جديد', time: '2024-03-08 10:00' },
              ].map((log, i) => (
                <tr key={i} className="border-t border-slate-800 hover:bg-slate-800/50">
                  <td className="px-6 py-4">
                    <span className="inline-block px-3 py-1 bg-blue-900/30 text-blue-400 rounded-full text-xs">
                      {log.action}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-white">{log.user}</td>
                  <td className="px-6 py-4 text-slate-400">{log.details}</td>
                  <td className="px-6 py-4 text-slate-500">{log.time}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </main>
    </div>
  );
}
