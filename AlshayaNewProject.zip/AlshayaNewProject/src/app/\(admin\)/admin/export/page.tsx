import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Export Data',
  description: 'Export family data and records',
};

export default function ExportPage() {
  return (
    <div className="w-full">
      <header className="bg-gradient-to-r from-slate-900 to-slate-950 border-b border-slate-800 p-6">
        <h1 className="text-3xl font-bold text-white mb-2">تصدير البيانات</h1>
        <p className="text-slate-500">تصدير أعضاء وبيانات العائلة</p>
      </header>

      <main className="p-6 max-w-4xl">
        <form className="space-y-6">
          <div className="bg-slate-900 rounded-lg border border-slate-800 p-6">
            <h2 className="text-lg font-semibold text-white mb-4">ما الذي تريد تصديره؟</h2>
            <div className="space-y-3">
              {[
                { label: 'جميع الأعضاء', value: 'all_members' },
                { label: 'أعضاء نشطين فقط', value: 'active_members' },
                { label: 'البيانات الشاملة', value: 'full_data' },
                { label: 'الصور والوسائط', value: 'media' },
                { label: 'الدفاتر والقصص', value: 'journals' },
              ].map((option) => (
                <label key={option.value} className="flex items-center gap-3 cursor-pointer">
                  <input
                    type="radio"
                    name="export_type"
                    value={option.value}
                    defaultChecked={option.value === 'all_members'}
                    className="w-4 h-4 bg-slate-800 border-slate-700 rounded text-blue-600"
                  />
                  <span className="text-white">{option.label}</span>
                </label>
              ))}
            </div>
          </div>

          <div className="bg-slate-900 rounded-lg border border-slate-800 p-6">
            <h2 className="text-lg font-semibold text-white mb-4">اختر صيغة التصدير</h2>
            <div className="grid grid-cols-3 gap-4">
              {[
                { format: 'CSV', ext: '.csv' },
                { format: 'Excel', ext: '.xlsx' },
                { format: 'JSON', ext: '.json' },
              ].map((option) => (
                <label key={option.format} className="cursor-pointer">
                  <input type="radio" name="format" value={option.format} defaultChecked={option.format === 'CSV'} className="sr-only" />
                  <div className="p-4 rounded-lg border-2 border-slate-700 hover:border-blue-600 text-center">
                    <p className="font-medium text-white">{option.format}</p>
                    <p className="text-xs text-slate-500 mt-1">{option.ext}</p>
                  </div>
                </label>
              ))}
            </div>
          </div>

          <div className="bg-slate-900 rounded-lg border border-slate-800 p-6">
            <h2 className="text-lg font-semibold text-white mb-4">الخيارات</h2>
            <div className="space-y-3">
              <label className="flex items-center gap-3">
                <input
                  type="checkbox"
                  defaultChecked
                  className="w-4 h-4 bg-slate-800 border-slate-700 rounded text-blue-600"
                />
                <span className="text-white">تضمين المعلومات الشخصية</span>
              </label>

              <label className="flex items-center gap-3">
                <input
                  type="checkbox"
                  className="w-4 h-4 bg-slate-800 border-slate-700 rounded text-blue-600"
                />
                <span className="text-white">تضمين معلومات الاتصال</span>
              </label>

              <label className="flex items-center gap-3">
                <input
                  type="checkbox"
                  defaultChecked
                  className="w-4 h-4 bg-slate-800 border-slate-700 rounded text-blue-600"
                />
                <span className="text-white">تضمين الروابط العائلية</span>
              </label>

              <label className="flex items-center gap-3">
                <input
                  type="checkbox"
                  className="w-4 h-4 bg-slate-800 border-slate-700 rounded text-blue-600"
                />
                <span className="text-white">ضغط الملف (ZIP)</span>
              </label>
            </div>
          </div>

          <div className="flex gap-4">
            <button
              type="submit"
              className="px-8 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              تصدير الآن
            </button>
            <button
              type="reset"
              className="px-8 py-3 bg-slate-800 text-white rounded-lg hover:bg-slate-700 transition-colors"
            >
              إلغاء
            </button>
          </div>
        </form>
      </main>
    </div>
  );
}
