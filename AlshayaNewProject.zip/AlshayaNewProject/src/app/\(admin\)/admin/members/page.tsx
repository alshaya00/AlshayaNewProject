import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Member Management',
  description: 'Manage family members',
};

export default function MembersAdminPage() {
  return (
    <div className="w-full">
      <header className="bg-gradient-to-r from-slate-900 to-slate-950 border-b border-slate-800 p-6">
        <h1 className="text-3xl font-bold text-white mb-2">إدارة الأعضاء</h1>
        <p className="text-slate-500">إدارة أعضاء الشجرة العائلية</p>
      </header>

      <main className="p-6">
        <div className="mb-6 flex gap-4">
          <input
            type="text"
            placeholder="بحث عن عضو..."
            className="flex-1 px-4 py-2 bg-slate-900 border border-slate-800 rounded-lg text-white placeholder-slate-600 focus:ring-2 focus:ring-blue-500"
          />
          <button className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
            تصدير البيانات
          </button>
        </div>

        <div className="bg-slate-900 rounded-lg border border-slate-800 overflow-hidden">
          <table className="w-full">
            <thead className="bg-slate-800">
              <tr>
                <th className="px-6 py-3 text-right text-sm font-semibold text-white">الاسم</th>
                <th className="px-6 py-3 text-right text-sm font-semibold text-white">تاريخ الميلاد</th>
                <th className="px-6 py-3 text-right text-sm font-semibold text-white">الفرع</th>
                <th className="px-6 py-3 text-right text-sm font-semibold text-white">آخر تحديث</th>
                <th className="px-6 py-3 text-right text-sm font-semibold text-white">الإجراءات</th>
              </tr>
            </thead>
            <tbody>
              {[1, 2, 3, 4, 5].map((i) => (
                <tr key={i} className="border-t border-slate-800 hover:bg-slate-800/50">
                  <td className="px-6 py-4 text-white">محمد علي الشايع</td>
                  <td className="px-6 py-4 text-slate-400">1985-05-15</td>
                  <td className="px-6 py-4 text-slate-400">الفرع الأول</td>
                  <td className="px-6 py-4 text-slate-400">2024-03-01</td>
                  <td className="px-6 py-4">
                    <div className="flex gap-2">
                      <button className="text-blue-400 hover:text-blue-300 text-sm">عرض</button>
                      <button className="text-slate-500 hover:text-slate-300 text-sm">حذف</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </main>
    </div>
  );
}
