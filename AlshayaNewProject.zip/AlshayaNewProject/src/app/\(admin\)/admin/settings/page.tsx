import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'System Settings',
  description: 'Configure system settings',
};

export default function SettingsPage() {
  return (
    <div className="w-full">
      <header className="bg-gradient-to-r from-slate-900 to-slate-950 border-b border-slate-800 p-6">
        <h1 className="text-3xl font-bold text-white mb-2">إعدادات النظام</h1>
        <p className="text-slate-500">تكوين النظام والإعدادات العامة</p>
      </header>

      <main className="p-6 max-w-4xl">
        <form className="space-y-6">
          <div className="bg-slate-900 rounded-lg border border-slate-800 p-6">
            <h2 className="text-lg font-semibold text-white mb-4">إعدادات عامة</h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm text-slate-400 mb-2">اسم التطبيق</label>
                <input
                  type="text"
                  defaultValue="شجرة عائلة آل شايع"
                  className="w-full px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white focus:ring-2 focus:ring-blue-500"
                  dir="rtl"
                />
              </div>

              <div>
                <label className="block text-sm text-slate-400 mb-2">وصف التطبيق</label>
                <textarea
                  defaultValue="تطبيق شامل لإدارة شجرة العائلة والسجلات الجينية"
                  rows={3}
                  className="w-full px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white focus:ring-2 focus:ring-blue-500"
                  dir="rtl"
                />
              </div>
            </div>
          </div>

          <div className="bg-slate-900 rounded-lg border border-slate-800 p-6">
            <h2 className="text-lg font-semibold text-white mb-4">إعدادات البريد الإلكتروني</h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm text-slate-400 mb-2">خادم SMTP</label>
                <input
                  type="text"
                  defaultValue="smtp.gmail.com"
                  className="w-full px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white focus:ring-2 focus:ring-blue-500"
                  dir="ltr"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm text-slate-400 mb-2">البريد من</label>
                  <input
                    type="email"
                    defaultValue="noreply@alshaya.family"
                    className="w-full px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white focus:ring-2 focus:ring-blue-500"
                    dir="ltr"
                  />
                </div>

                <div>
                  <label className="block text-sm text-slate-400 mb-2">كلمة مرور SMTP</label>
                  <input
                    type="password"
                    placeholder="••••••••"
                    className="w-full px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white focus:ring-2 focus:ring-blue-500"
                    dir="ltr"
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="bg-slate-900 rounded-lg border border-slate-800 p-6">
            <h2 className="text-lg font-semibold text-white mb-4">إعدادات الأمان</h2>
            <div className="space-y-4">
              <label className="flex items-center gap-3">
                <input
                  type="checkbox"
                  defaultChecked
                  className="w-4 h-4 bg-slate-800 border-slate-700 rounded text-blue-600 focus:ring-blue-500"
                />
                <span className="text-white">تفعيل المصادقة الثنائية</span>
              </label>

              <label className="flex items-center gap-3">
                <input
                  type="checkbox"
                  defaultChecked
                  className="w-4 h-4 bg-slate-800 border-slate-700 rounded text-blue-600 focus:ring-blue-500"
                />
                <span className="text-white">تطلب تأكيد البريد الإلكتروني</span>
              </label>

              <label className="flex items-center gap-3">
                <input
                  type="checkbox"
                  className="w-4 h-4 bg-slate-800 border-slate-700 rounded text-blue-600 focus:ring-blue-500"
                />
                <span className="text-white">السماح بتسجيل مستخدمين جدد</span>
              </label>
            </div>
          </div>

          <div className="flex gap-4">
            <button
              type="submit"
              className="px-8 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              حفظ الإعدادات
            </button>
            <button
              type="reset"
              className="px-8 py-3 bg-slate-800 text-white rounded-lg hover:bg-slate-700 transition-colors"
            >
              إلغاء
            </button>
          </div>
        </form>
      </main>
    </div>
  );
}
