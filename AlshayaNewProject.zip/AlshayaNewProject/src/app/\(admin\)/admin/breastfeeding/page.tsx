import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Milk Kinship',
  description: 'Manage milk kinship relationships',
};

export default function BreastfeedingPage() {
  return (
    <div className="w-full">
      <header className="bg-gradient-to-r from-slate-900 to-slate-950 border-b border-slate-800 p-6">
        <h1 className="text-3xl font-bold text-white mb-2">علاقات الرضاعة</h1>
        <p className="text-slate-500">إدارة علاقات الحمض النووي من خلال الرضاعة</p>
      </header>

      <main className="p-6">
        <div className="mb-6 flex gap-4">
          <input
            type="text"
            placeholder="بحث عن علاقة..."
            className="flex-1 px-4 py-2 bg-slate-900 border border-slate-800 rounded-lg text-white placeholder-slate-600 focus:ring-2 focus:ring-blue-500"
          />
          <button className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
            + علاقة جديدة
          </button>
        </div>

        <div className="bg-slate-900 rounded-lg border border-slate-800 overflow-hidden">
          <table className="w-full">
            <thead className="bg-slate-800">
              <tr>
                <th className="px-6 py-3 text-right text-sm font-semibold text-white">المرضع</th>
                <th className="px-6 py-3 text-right text-sm font-semibold text-white">الطفل</th>
                <th className="px-6 py-3 text-right text-sm font-semibold text-white">التاريخ</th>
                <th className="px-6 py-3 text-right text-sm font-semibold text-white">الحالة</th>
                <th className="px-6 py-3 text-right text-sm font-semibold text-white">الإجراءات</th>
              </tr>
            </thead>
            <tbody>
              {[
                { nursing: 'فاطمة الشايع', child: 'محمد علي', date: '1990-05-15', status: 'مؤكد' },
                { nursing: 'نور الشايع', child: 'علي الشايع', date: '1992-03-20', status: 'قيد المراجعة' },
                { nursing: 'ليلى الشايع', child: 'سارة الشايع', date: '1995-08-10', status: 'مؤكد' },
              ].map((relation, i) => (
                <tr key={i} className="border-t border-slate-800 hover:bg-slate-800/50">
                  <td className="px-6 py-4 text-white">{relation.nursing}</td>
                  <td className="px-6 py-4 text-white">{relation.child}</td>
                  <td className="px-6 py-4 text-slate-400">{relation.date}</td>
                  <td className="px-6 py-4">
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                      relation.status === 'مؤكد'
                        ? 'bg-green-900/30 text-green-400'
                        : 'bg-yellow-900/30 text-yellow-400'
                    }`}>
                      {relation.status}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex gap-2">
                      <button className="text-blue-400 hover:text-blue-300 text-sm">عرض</button>
                      <button className="text-slate-500 hover:text-slate-300 text-sm">حذف</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="mt-6 bg-blue-900/20 border border-blue-800 rounded-lg p-4">
          <p className="text-sm text-blue-300">
            يتم استخدام علاقات الرضاعة لتحديد الروابط العائلية الشرعية وفقاً للشريعة الإسلامية.
          </p>
        </div>
      </main>
    </div>
  );
}
