import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Feature Flags',
  description: 'Manage feature flags',
};

export default function FeatureFlagsPage() {
  return (
    <div className="w-full">
      <header className="bg-gradient-to-r from-slate-900 to-slate-950 border-b border-slate-800 p-6">
        <h1 className="text-3xl font-bold text-white mb-2">إدارة الميزات</h1>
        <p className="text-slate-500">تفعيل أو تعطيل الميزات في النظام</p>
      </header>

      <main className="p-6 max-w-4xl">
        <div className="space-y-4">
          {[
            { name: 'شجرة العائلة التفاعلية', enabled: true, description: 'عرض وتفاعل مع شجرة العائلة' },
            { name: 'معرض الصور', enabled: true, description: 'تحميل وعرض الصور العائلية' },
            { name: 'الدفاتر والقصص', enabled: true, description: 'كتابة وقراءة دفاتر العائلة' },
            { name: 'الأحداث العائلية', enabled: false, description: 'إدارة وإعلان الأحداث العائلية' },
            { name: 'الحمض النووي (DNA)', enabled: false, description: 'ميزة تطابق الحمض النووي' },
            { name: 'التصدير المتقدم', enabled: true, description: 'تصدير البيانات بصيغ متعددة' },
          ].map((feature, i) => (
            <div key={i} className="bg-slate-900 rounded-lg border border-slate-800 p-6 flex items-start justify-between">
              <div>
                <h3 className="font-semibold text-white">{feature.name}</h3>
                <p className="text-sm text-slate-500 mt-1">{feature.description}</p>
              </div>
              <label className="flex items-center gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  defaultChecked={feature.enabled}
                  className="w-5 h-5 bg-slate-800 border-slate-700 rounded text-blue-600 focus:ring-blue-500"
                />
              </label>
            </div>
          ))}
        </div>

        <div className="mt-8 flex gap-4">
          <button className="px-8 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
            حفظ التغييرات
          </button>
          <button className="px-8 py-3 bg-slate-800 text-white rounded-lg hover:bg-slate-700 transition-colors">
            إلغاء
          </button>
        </div>
      </main>
    </div>
  );
}
