import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Import Data',
  description: 'Bulk import family data',
};

export default function ImportPage() {
  return (
    <div className="w-full">
      <header className="bg-gradient-to-r from-slate-900 to-slate-950 border-b border-slate-800 p-6">
        <h1 className="text-3xl font-bold text-white mb-2">استيراد البيانات</h1>
        <p className="text-slate-500">استيراد أعضاء وبيانات جديدة من ملفات</p>
      </header>

      <main className="p-6 max-w-4xl">
        <form className="space-y-6">
          <div className="bg-slate-900 rounded-lg border border-slate-800 p-6">
            <h2 className="text-lg font-semibold text-white mb-4">اختر صيغة الملف</h2>
            <div className="grid grid-cols-3 gap-4">
              {['CSV', 'Excel', 'JSON'].map((format) => (
                <label key={format} className="cursor-pointer">
                  <input type="radio" name="format" value={format} className="sr-only" />
                  <div className="p-4 rounded-lg border-2 border-slate-700 hover:border-blue-600 text-center">
                    <p className="font-medium text-white">{format}</p>
                  </div>
                </label>
              ))}
            </div>
          </div>

          <div className="bg-slate-900 rounded-lg border border-slate-800 p-6">
            <h2 className="text-lg font-semibold text-white mb-4">رفع الملف</h2>
            <div className="border-2 border-dashed border-slate-700 rounded-lg p-8 text-center hover:border-blue-600 transition-colors cursor-pointer">
              <svg className="w-12 h-12 text-slate-500 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 16v-4m0 0V8m0 4h4m-4 0H8m4-12a9 9 0 1 0 0 18 9 9 0 0 0 0-18z" />
              </svg>
              <p className="text-slate-400 mb-2">اسحب الملف أو انقر للاختيار</p>
              <input type="file" className="hidden" accept=".csv,.xlsx,.json" />
              <p className="text-xs text-slate-600">CSV, Excel, أو JSON</p>
            </div>
          </div>

          <div className="bg-slate-900 rounded-lg border border-slate-800 p-6">
            <h2 className="text-lg font-semibold text-white mb-4">خيارات الاستيراد</h2>
            <div className="space-y-3">
              <label className="flex items-center gap-3">
                <input
                  type="checkbox"
                  defaultChecked
                  className="w-4 h-4 bg-slate-800 border-slate-700 rounded text-blue-600"
                />
                <span className="text-white">تحديث الأعضاء الموجودين</span>
              </label>

              <label className="flex items-center gap-3">
                <input
                  type="checkbox"
                  className="w-4 h-4 bg-slate-800 border-slate-700 rounded text-blue-600"
                />
                <span className="text-white">إرسال تنبيهات البريد الإلكتروني</span>
              </label>

              <label className="flex items-center gap-3">
                <input
                  type="checkbox"
                  className="w-4 h-4 bg-slate-800 border-slate-700 rounded text-blue-600"
                />
                <span className="text-white">محاولة معالجة الأخطاء تلقائياً</span>
              </label>
            </div>
          </div>

          <div className="bg-blue-900/20 border border-blue-800 rounded-lg p-4">
            <p className="text-sm text-blue-300">
              تأكد من أن الملف يحتوي على الأعمدة الصحيحة: الاسم، تاريخ الميلاد، البريد الإلكتروني، إلخ.
            </p>
          </div>

          <div className="flex gap-4">
            <button
              type="submit"
              className="px-8 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
            >
              استيراد البيانات
            </button>
            <button
              type="reset"
              className="px-8 py-3 bg-slate-800 text-white rounded-lg hover:bg-slate-700 transition-colors"
            >
              إلغاء
            </button>
          </div>
        </form>
      </main>
    </div>
  );
}
