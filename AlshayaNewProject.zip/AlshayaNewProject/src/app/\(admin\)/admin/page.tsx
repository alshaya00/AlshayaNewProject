import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Admin Dashboard',
  description: 'System administration dashboard',
};

export default function AdminPage() {
  return (
    <div className="w-full">
      <header className="bg-gradient-to-r from-slate-900 to-slate-950 border-b border-slate-800 p-6">
        <h1 className="text-3xl font-bold text-white mb-2">لوحة تحكم المسؤول</h1>
        <p className="text-slate-500">إدارة النظام والمستخدمين والبيانات</p>
      </header>

      <main className="p-6">
        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-slate-900 rounded-lg p-6 border border-slate-800">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-500 text-sm">إجمالي المستخدمين</p>
                <p className="text-3xl font-bold text-white mt-1">248</p>
              </div>
              <div className="w-12 h-12 rounded-full bg-blue-900/30 flex items-center justify-center">
                <svg className="w-6 h-6 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3.634a1 1 0 01-.952-1.405l2.697-7.894A6 6 0 0112 13a6 6 0 015.621 3.701l2.697 7.894a1 1 0 01-.952 1.405zm0 0h5.366a1 1 0 00.952-1.405l-2.697-7.894a6 6 0 10-5.621-3.701" />
                </svg>
              </div>
            </div>
            <p className="text-xs text-slate-600 mt-4">+12 هذا الشهر</p>
          </div>

          <div className="bg-slate-900 rounded-lg p-6 border border-slate-800">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-500 text-sm">إجمالي الأعضاء</p>
                <p className="text-3xl font-bold text-white mt-1">1,245</p>
              </div>
              <div className="w-12 h-12 rounded-full bg-green-900/30 flex items-center justify-center">
                <svg className="w-6 h-6 text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.856-1.487M15 6a3 3 0 11-6 0 3 3 0 016 0zM6 20h12a6 6 0 00-6-6 6 6 0 00-6 6z" />
                </svg>
              </div>
            </div>
            <p className="text-xs text-slate-600 mt-4">+45 هذا الشهر</p>
          </div>

          <div className="bg-slate-900 rounded-lg p-6 border border-slate-800">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-500 text-sm">الأنشطة اليومية</p>
                <p className="text-3xl font-bold text-white mt-1">347</p>
              </div>
              <div className="w-12 h-12 rounded-full bg-purple-900/30 flex items-center justify-center">
                <svg className="w-6 h-6 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
              </div>
            </div>
            <p className="text-xs text-slate-600 mt-4">نشاط صحي</p>
          </div>

          <div className="bg-slate-900 rounded-lg p-6 border border-slate-800">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-500 text-sm">مساحة البيانات</p>
                <p className="text-3xl font-bold text-white mt-1">842 GB</p>
              </div>
              <div className="w-12 h-12 rounded-full bg-orange-900/30 flex items-center justify-center">
                <svg className="w-6 h-6 text-orange-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4" />
                </svg>
              </div>
            </div>
            <p className="text-xs text-slate-600 mt-4">من 1 TB</p>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="bg-slate-900 rounded-lg border border-slate-800 p-6">
            <h2 className="text-xl font-bold text-white mb-4">الإجراءات السريعة</h2>
            <div className="space-y-2">
              <a href="/admin/users" className="block p-4 rounded-lg bg-slate-800 hover:bg-slate-700 transition-colors group">
                <p className="font-medium text-white group-hover:text-blue-400">إدارة المستخدمين</p>
                <p className="text-xs text-slate-500 mt-1">عرض وإدارة حسابات المستخدمين</p>
              </a>

              <a href="/admin/members" className="block p-4 rounded-lg bg-slate-800 hover:bg-slate-700 transition-colors group">
                <p className="font-medium text-white group-hover:text-green-400">إدارة الأعضاء</p>
                <p className="text-xs text-slate-500 mt-1">إدارة أعضاء الشجرة العائلية</p>
              </a>

              <a href="/admin/audit-log" className="block p-4 rounded-lg bg-slate-800 hover:bg-slate-700 transition-colors group">
                <p className="font-medium text-white group-hover:text-purple-400">سجل التدقيق</p>
                <p className="text-xs text-slate-500 mt-1">عرض جميع العمليات والتغييرات</p>
              </a>
            </div>
          </div>

          <div className="bg-slate-900 rounded-lg border border-slate-800 p-6">
            <h2 className="text-xl font-bold text-white mb-4">حالة النظام</h2>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-slate-400">خادم API</span>
                <span className="inline-block px-3 py-1 bg-green-900/30 text-green-400 rounded-full text-xs font-medium">متصل</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">قاعدة البيانات</span>
                <span className="inline-block px-3 py-1 bg-green-900/30 text-green-400 rounded-full text-xs font-medium">متصل</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">خدمة البريد الإلكتروني</span>
                <span className="inline-block px-3 py-1 bg-green-900/30 text-green-400 rounded-full text-xs font-medium">متصل</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">التخزين السحابي</span>
                <span className="inline-block px-3 py-1 bg-green-900/30 text-green-400 rounded-full text-xs font-medium">متصل</span>
              </div>
            </div>
          </div>
        </div>

        {/* Recent Activity */}
        <div className="mt-8 bg-slate-900 rounded-lg border border-slate-800 p-6">
          <h2 className="text-xl font-bold text-white mb-4">النشاط الأخير</h2>
          <div className="space-y-3">
            {[1, 2, 3, 4, 5].map((i) => (
              <div key={i} className="flex items-start gap-3 pb-3 border-b border-slate-800 last:border-b-0">
                <div className="w-2 h-2 rounded-full bg-blue-500 mt-2 flex-shrink-0" />
                <div className="flex-1">
                  <p className="text-slate-300">تم إضافة عضو جديد إلى النظام</p>
                  <p className="text-xs text-slate-600 mt-1">قبل ساعة</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
}
