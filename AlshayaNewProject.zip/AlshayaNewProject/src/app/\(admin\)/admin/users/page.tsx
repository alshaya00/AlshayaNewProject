import type { Metadata } from 'next';
import Link from 'next/link';

export const metadata: Metadata = {
  title: 'User Management',
  description: 'Manage system users',
};

export default function UsersPage() {
  return (
    <div className="w-full">
      <header className="bg-gradient-to-r from-slate-900 to-slate-950 border-b border-slate-800 p-6">
        <h1 className="text-3xl font-bold text-white mb-2">إدارة المستخدمين</h1>
        <p className="text-slate-500">عرض وإدارة جميع مستخدمي النظام</p>
      </header>

      <main className="p-6">
        <div className="mb-6 flex gap-4">
          <input
            type="text"
            placeholder="بحث عن مستخدم..."
            className="flex-1 px-4 py-2 bg-slate-900 border border-slate-800 rounded-lg text-white placeholder-slate-600 focus:ring-2 focus:ring-blue-500"
          />
          <select className="px-4 py-2 bg-slate-900 border border-slate-800 rounded-lg text-white focus:ring-2 focus:ring-blue-500">
            <option>جميع الأدوار</option>
            <option>مسؤول فائق</option>
            <option>مسؤول</option>
            <option>مستخدم</option>
          </select>
        </div>

        <div className="bg-slate-900 rounded-lg border border-slate-800 overflow-hidden">
          <table className="w-full">
            <thead className="bg-slate-800">
              <tr>
                <th className="px-6 py-3 text-right text-sm font-semibold text-white">الاسم</th>
                <th className="px-6 py-3 text-right text-sm font-semibold text-white">البريد الإلكتروني</th>
                <th className="px-6 py-3 text-right text-sm font-semibold text-white">الدور</th>
                <th className="px-6 py-3 text-right text-sm font-semibold text-white">الحالة</th>
                <th className="px-6 py-3 text-right text-sm font-semibold text-white">الإجراءات</th>
              </tr>
            </thead>
            <tbody>
              {[1, 2, 3, 4, 5].map((i) => (
                <tr key={i} className="border-t border-slate-800 hover:bg-slate-800/50">
                  <td className="px-6 py-4 text-white">محمد علي الشايع</td>
                  <td className="px-6 py-4 text-slate-400">mohammed@example.com</td>
                  <td className="px-6 py-4">
                    <span className="px-3 py-1 bg-blue-900/30 text-blue-400 rounded-full text-xs">مسؤول</span>
                  </td>
                  <td className="px-6 py-4">
                    <span className="px-3 py-1 bg-green-900/30 text-green-400 rounded-full text-xs">نشط</span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex gap-2">
                      <Link href={`/admin/users/${i}`} className="text-blue-400 hover:text-blue-300 text-sm">
                        عرض
                      </Link>
                      <button className="text-slate-500 hover:text-slate-300 text-sm">
                        تعديل
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </main>
    </div>
  );
}
