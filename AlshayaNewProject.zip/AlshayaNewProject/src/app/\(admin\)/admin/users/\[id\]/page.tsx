import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'User Details',
  description: 'View and manage user details',
};

interface UserDetailPageProps {
  params: {
    id: string;
  };
}

export default function UserDetailPage({ params }: UserDetailPageProps) {
  return (
    <div className="w-full">
      <header className="bg-gradient-to-r from-slate-900 to-slate-950 border-b border-slate-800 p-6">
        <h1 className="text-3xl font-bold text-white mb-2">محمد علي الشايع</h1>
        <p className="text-slate-500">معرف المستخدم: {params.id}</p>
      </header>

      <main className="p-6 max-w-4xl">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-slate-900 rounded-lg border border-slate-800 p-6">
            <h2 className="text-lg font-semibold text-white mb-4">معلومات الحساب</h2>
            <div className="space-y-3">
              <div>
                <p className="text-slate-600 text-sm">البريد الإلكتروني</p>
                <p className="text-white">mohammed@example.com</p>
              </div>
              <div>
                <p className="text-slate-600 text-sm">رقم الجوال</p>
                <p className="text-white">+966501234567</p>
              </div>
              <div>
                <p className="text-slate-600 text-sm">الدور</p>
                <p className="text-white">مسؤول</p>
              </div>
              <div>
                <p className="text-slate-600 text-sm">الحالة</p>
                <p className="text-green-400">نشط</p>
              </div>
            </div>
          </div>

          <div className="bg-slate-900 rounded-lg border border-slate-800 p-6">
            <h2 className="text-lg font-semibold text-white mb-4">النشاط</h2>
            <div className="space-y-3">
              <div>
                <p className="text-slate-600 text-sm">آخر تسجيل دخول</p>
                <p className="text-white">2024-03-08 14:30</p>
              </div>
              <div>
                <p className="text-slate-600 text-sm">تاريخ الانضمام</p>
                <p className="text-white">2023-01-15</p>
              </div>
              <div>
                <p className="text-slate-600 text-sm">عدد تسجيلات الدخول</p>
                <p className="text-white">247</p>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-6 flex gap-4">
          <button className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
            تعديل
          </button>
          <button className="px-6 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors">
            حظر
          </button>
        </div>
      </main>
    </div>
  );
}
