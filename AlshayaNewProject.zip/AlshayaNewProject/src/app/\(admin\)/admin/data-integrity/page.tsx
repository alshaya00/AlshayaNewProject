import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Data Integrity',
  description: 'Monitor data integrity and database health',
};

export default function DataIntegrityPage() {
  return (
    <div className="w-full">
      <header className="bg-gradient-to-r from-slate-900 to-slate-950 border-b border-slate-800 p-6">
        <h1 className="text-3xl font-bold text-white mb-2">سلامة البيانات</h1>
        <p className="text-slate-500">مراقبة صحة قاعدة البيانات والتحقق من السلامة</p>
      </header>

      <main className="p-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-slate-900 rounded-lg border border-slate-800 p-6">
            <p className="text-slate-600 text-sm">إجمالي السجلات</p>
            <p className="text-3xl font-bold text-white mt-2">12,547</p>
            <p className="text-xs text-slate-500 mt-2">سجل مفعل</p>
          </div>

          <div className="bg-slate-900 rounded-lg border border-slate-800 p-6">
            <p className="text-slate-600 text-sm">الأخطاء المكتشفة</p>
            <p className="text-3xl font-bold text-green-400 mt-2">0</p>
            <p className="text-xs text-slate-500 mt-2">لا توجد مشاكل</p>
          </div>

          <div className="bg-slate-900 rounded-lg border border-slate-800 p-6">
            <p className="text-slate-600 text-sm">آخر فحص</p>
            <p className="text-lg font-bold text-white mt-2">2024-03-08</p>
            <p className="text-xs text-slate-500 mt-2">قبل ساعتين</p>
          </div>

          <div className="bg-slate-900 rounded-lg border border-slate-800 p-6">
            <p className="text-slate-600 text-sm">حالة قاعدة البيانات</p>
            <p className="text-lg font-bold text-green-400 mt-2">صحية</p>
            <p className="text-xs text-slate-500 mt-2">استجابة سريعة</p>
          </div>
        </div>

        <div className="bg-slate-900 rounded-lg border border-slate-800 p-6 mb-6">
          <h2 className="text-lg font-semibold text-white mb-4">الفحوصات الأخيرة</h2>
          <div className="space-y-3">
            {[
              { test: 'فحص الأرقام الأجنبية', status: 'نجح', time: '14:30' },
              { test: 'فحص السجلات المكررة', status: 'نجح', time: '14:25' },
              { test: 'فحص البيانات المفقودة', status: 'نجح', time: '14:20' },
              { test: 'فحص الأداء', status: 'تنبيه', time: '14:15' },
              { test: 'فحص النسخ الاحتياطية', status: 'نجح', time: '14:10' },
            ].map((check, i) => (
              <div key={i} className="flex items-center justify-between p-3 rounded-lg bg-slate-800">
                <span className="text-white">{check.test}</span>
                <div className="flex items-center gap-3">
                  <span className={`text-xs font-medium ${
                    check.status === 'نجح' ? 'text-green-400' : 'text-yellow-400'
                  }`}>
                    {check.status}
                  </span>
                  <span className="text-xs text-slate-500">{check.time}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="flex gap-4">
          <button className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
            فحص الآن
          </button>
          <button className="px-6 py-2 bg-slate-800 text-white rounded-lg hover:bg-slate-700 transition-colors">
            إعادة محاولة الفحص الأخير
          </button>
        </div>
      </main>
    </div>
  );
}
