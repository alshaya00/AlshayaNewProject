import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Announcements',
  description: 'Manage system announcements',
};

export default function AnnouncementsPage() {
  return (
    <div className="w-full">
      <header className="bg-gradient-to-r from-slate-900 to-slate-950 border-b border-slate-800 p-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-white mb-2">الإعلانات</h1>
            <p className="text-slate-500">إدارة إعلانات النظام</p>
          </div>
          <button className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
            + إعلان جديد
          </button>
        </div>
      </header>

      <main className="p-6">
        <div className="space-y-4">
          {[
            { title: 'صيانة مخطط لها', description: 'سيتم صيانة النظام الخميس من 2-4 صباحاً', active: true, date: '2024-03-15' },
            { title: 'ميزة جديدة: الحمض النووي', description: 'أطلقنا ميزة تطابق الحمض النووي الجديدة', active: true, date: '2024-03-10' },
            { title: 'تحديث الأمان', description: 'تم تحديث بروتوكولات الأمان والحماية', active: false, date: '2024-03-05' },
          ].map((announcement, i) => (
            <div key={i} className="bg-slate-900 rounded-lg border border-slate-800 p-6">
              <div className="flex items-start justify-between mb-3">
                <div>
                  <h3 className="font-semibold text-white">{announcement.title}</h3>
                  <p className="text-sm text-slate-400 mt-1">{announcement.description}</p>
                </div>
                <div className="flex gap-2">
                  <button className="text-blue-400 hover:text-blue-300 text-sm">تعديل</button>
                  <button className="text-red-400 hover:text-red-300 text-sm">حذف</button>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-600">{announcement.date}</span>
                <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                  announcement.active
                    ? 'bg-green-900/30 text-green-400'
                    : 'bg-slate-800 text-slate-400'
                }`}>
                  {announcement.active ? 'نشط' : 'معطل'}
                </span>
              </div>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}
