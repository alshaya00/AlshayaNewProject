export default function AdminLoading() {
  return (
    <div className="w-full">
      <header className="bg-gradient-to-r from-slate-900 to-slate-950 border-b border-slate-800 p-6">
        <div className="max-w-7xl">
          <div className="h-8 bg-slate-800 rounded animate-pulse w-1/4 mb-3" />
          <div className="h-4 bg-slate-800 rounded animate-pulse w-1/3" />
        </div>
      </header>

      <main className="p-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="bg-slate-900 rounded-lg p-6 border border-slate-800">
              <div className="h-4 bg-slate-800 rounded animate-pulse w-1/2 mb-3" />
              <div className="h-8 bg-slate-800 rounded animate-pulse w-2/3" />
              <div className="h-3 bg-slate-800 rounded animate-pulse w-1/3 mt-4" />
            </div>
          ))}
        </div>

        <div className="h-96 bg-slate-900 rounded-lg border border-slate-800 animate-pulse" />
      </main>
    </div>
  );
}
