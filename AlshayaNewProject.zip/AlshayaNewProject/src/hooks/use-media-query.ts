'use client';

import { useEffect, useState } from 'react';

/**
 * Hook to detect media queries
 * @param query - Media query string
 */
export function useMediaQuery(query: string): boolean {
  const [matches, setMatches] = useState(false);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
    const media = window.matchMedia(query);

    if (media.matches !== matches) {
      setMatches(media.matches);
    }

    const listener = () => setMatches(media.matches);

    media.addEventListener('change', listener);
    return () => media.removeEventListener('change', listener);
  }, [matches, query]);

  return mounted ? matches : false;
}

/**
 * Common breakpoints for responsive design
 */
export const breakpoints = {
  xs: '(max-width: 640px)',
  sm: '(min-width: 640px)',
  md: '(min-width: 768px)',
  lg: '(min-width: 1024px)',
  xl: '(min-width: 1280px)',
  '2xl': '(min-width: 1536px)',
} as const;

/**
 * Hook to detect if screen is mobile (xs breakpoint)
 */
export function useIsMobile(): boolean {
  return useMediaQuery(breakpoints.xs);
}

/**
 * Hook to detect if screen is tablet or larger (sm breakpoint)
 */
export function useIsTabletOrLarger(): boolean {
  return useMediaQuery(breakpoints.sm);
}

/**
 * Hook to detect if screen is tablet (md breakpoint)
 */
export function useIsTablet(): boolean {
  return useMediaQuery(breakpoints.md);
}

/**
 * Hook to detect if screen is desktop (lg breakpoint)
 */
export function useIsDesktop(): boolean {
  return useMediaQuery(breakpoints.lg);
}

/**
 * Hook to detect if screen is large desktop (xl breakpoint)
 */
export function useIsLargeDesktop(): boolean {
  return useMediaQuery(breakpoints.xl);
}

/**
 * Hook to detect if screen is extra large (2xl breakpoint)
 */
export function useIsExtraLargeDesktop(): boolean {
  return useMediaQuery(breakpoints['2xl']);
}

/**
 * Hook to detect if prefers reduced motion
 */
export function usePrefersReducedMotion(): boolean {
  return useMediaQuery('(prefers-reduced-motion: reduce)');
}

/**
 * Hook to detect if prefers dark mode
 */
export function usePrefersDarkMode(): boolean {
  return useMediaQuery('(prefers-color-scheme: dark)');
}

/**
 * Hook to detect if prefers light mode
 */
export function usePrefersLightMode(): boolean {
  return useMediaQuery('(prefers-color-scheme: light)');
}

/**
 * Hook to get current breakpoint
 */
export function useCurrentBreakpoint(): keyof typeof breakpoints | null {
  const xs = useMediaQuery(breakpoints.xs);
  const sm = useMediaQuery(breakpoints.sm);
  const md = useMediaQuery(breakpoints.md);
  const lg = useMediaQuery(breakpoints.lg);
  const xl = useMediaQuery(breakpoints.xl);
  const xxl = useMediaQuery(breakpoints['2xl']);

  if (xxl) return '2xl';
  if (xl) return 'xl';
  if (lg) return 'lg';
  if (md) return 'md';
  if (sm) return 'sm';
  if (xs) return 'xs';

  return null;
}
