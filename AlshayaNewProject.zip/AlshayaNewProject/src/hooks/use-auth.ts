'use client';

import { useContext } from 'react';
import { useAuth as useAuthFromContext } from '@/providers/auth-provider';
import type { PermissionKey, UserRole } from '@/lib/auth';

/**
 * Hook to access authentication context
 * Must be used within AuthProvider
 */
export function useAuth() {
  return useAuthFromContext();
}

/**
 * Hook to check if user has a specific permission
 */
export function usePermission(permission: PermissionKey): boolean {
  const { hasPermission } = useAuth();
  return hasPermission(permission);
}

/**
 * Hook to check if user has a specific role
 */
export function useUserRole(): UserRole | null {
  const { user } = useAuth();
  return user?.role || null;
}

/**
 * Hook to get auth header for API calls
 */
export function useAuthHeader() {
  const { getAuthHeader } = useAuth();
  return getAuthHeader();
}

/**
 * Hook to check if user is authenticated
 */
export function useIsAuthenticated(): boolean {
  const { isAuthenticated } = useAuth();
  return isAuthenticated;
}

/**
 * Hook to check if user is loading
 */
export function useIsLoading(): boolean {
  const { isLoading } = useAuth();
  return isLoading;
}

/**
 * Hook to get current user
 */
export function useCurrentUser() {
  const { user } = useAuth();
  return user;
}
