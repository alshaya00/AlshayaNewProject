'use client';

import { useEffect, useState, useRef, useCallback } from 'react';

/**
 * Hook to debounce a value
 * @param value - The value to debounce
 * @param delay - Delay in milliseconds
 */
export function useDebounce<T>(value: T, delay: number = 500): T {
  const [debouncedValue, setDebouncedValue] = useState<T>(value);

  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedValue(value);
    }, delay);

    return () => clearTimeout(handler);
  }, [value, delay]);

  return debouncedValue;
}

/**
 * Hook to debounce a callback function
 * @param callback - The callback function to debounce
 * @param delay - Delay in milliseconds
 */
export function useDebouncedCallback<T extends (...args: never[]) => void>(
  callback: T,
  delay: number = 500
): (...args: Parameters<T>) => void {
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);

  return useCallback(
    (...args: Parameters<T>) => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }

      timeoutRef.current = setTimeout(() => {
        callback(...args);
      }, delay);
    },
    [callback, delay]
  );
}

/**
 * Hook to debounce async function
 * @param callback - The async function to debounce
 * @param delay - Delay in milliseconds
 */
export function useDebouncedAsyncCallback<
  T extends (...args: never[]) => Promise<void>,
>(callback: T, delay: number = 500) {
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const debouncedCallback = useCallback(
    async (...args: Parameters<T>) => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }

      timeoutRef.current = setTimeout(async () => {
        setIsLoading(true);
        try {
          await callback(...args);
        } finally {
          setIsLoading(false);
        }
      }, delay);
    },
    [callback, delay]
  );

  return { debouncedCallback, isLoading };
}

/**
 * Hook to debounce search input
 */
export function useSearchDebounce(
  initialValue: string = '',
  delay: number = 500
) {
  const [searchValue, setSearchValue] = useState(initialValue);
  const [debouncedSearchValue, setDebouncedSearchValue] = useState(initialValue);

  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedSearchValue(searchValue);
    }, delay);

    return () => clearTimeout(handler);
  }, [searchValue, delay]);

  return {
    searchValue,
    setSearchValue,
    debouncedSearchValue,
  };
}
