'use client';

import { useContext, useEffect, useState } from 'react';
import { useLocale as useLocaleFromContext } from '@/providers/locale-provider';
import { useTranslations } from '@/lib/i18n/use-translations';
import * as format from '@/lib/i18n/format';
import * as arabicUtils from '@/lib/i18n/arabic-utils';

/**
 * Hook to access locale context
 * Must be used within LocaleProvider
 */
export function useLocale() {
  return useLocaleFromContext();
}

/**
 * Hook to access translations
 */
export function useTranslation() {
  const { locale } = useLocale();
  return useTranslations({ locale });
}

/**
 * Hook for number formatting
 */
export function useNumberFormatter() {
  const { locale } = useLocale();

  return {
    formatNumber: (value: number, options?: Intl.NumberFormatOptions) =>
      format.formatNumber(value, locale, options),
    formatCurrency: (value: number, currency?: string, options?: Intl.NumberFormatOptions) =>
      format.formatCurrency(value, locale, currency, options),
    formatPercent: (value: number, fractionDigits?: number) =>
      format.formatPercent(value, locale, fractionDigits),
  };
}

/**
 * Hook for date formatting
 */
export function useDateFormatter() {
  const { locale } = useLocale();

  return {
    formatDate: (date: Date | string | number, options?: Intl.DateTimeFormatOptions) =>
      format.formatDate(date, locale, options),
    formatShortDate: (date: Date | string | number) =>
      format.formatShortDate(date, locale),
    formatLongDate: (date: Date | string | number) =>
      format.formatLongDate(date, locale),
    formatDateTime: (date: Date | string | number, options?: Intl.DateTimeFormatOptions) =>
      format.formatDateTime(date, locale, options),
    formatTime: (date: Date | string | number, options?: Intl.DateTimeFormatOptions) =>
      format.formatTime(date, locale, options),
    formatRelativeTime: (date: Date | string | number, now?: Date) =>
      format.formatRelativeTime(date, locale, now),
  };
}

/**
 * Hook for text direction and RTL utilities
 */
export function useDirection() {
  const { locale, direction } = useLocale();

  return {
    direction,
    isRTL: direction === 'rtl',
    isLTR: direction === 'ltr',
    getMarginStart: (value: string | number) =>
      direction === 'rtl' ? { marginRight: value } : { marginLeft: value },
    getMarginEnd: (value: string | number) =>
      direction === 'rtl' ? { marginLeft: value } : { marginRight: value },
    getPaddingStart: (value: string | number) =>
      direction === 'rtl' ? { paddingRight: value } : { paddingLeft: value },
    getPaddingEnd: (value: string | number) =>
      direction === 'rtl' ? { paddingLeft: value } : { paddingRight: value },
    getInsetStart: (value: string | number) =>
      direction === 'rtl' ? { right: value } : { left: value },
    getInsetEnd: (value: string | number) =>
      direction === 'rtl' ? { left: value } : { right: value },
  };
}

/**
 * Hook for Arabic utilities
 */
export function useArabicUtils() {
  const { locale } = useLocale();

  return {
    isArabicText: arabicUtils.isArabicText,
    hasArabicText: arabicUtils.hasArabicText,
    getTextLanguage: arabicUtils.getTextLanguage,
    convertToArabicNumerals: arabicUtils.convertToArabicNumerals,
    convertToEnglishNumerals: arabicUtils.convertToEnglishNumerals,
    removeDiacritics: arabicUtils.removeDiacritics,
    hasDiacritics: arabicUtils.hasDiacritics,
    gregorianToHijri: arabicUtils.gregorianToHijri,
    hijriToGregorian: arabicUtils.hijriToGregorian,
    formatHijriDate: (date: arabicUtils.HijriDate) =>
      arabicUtils.formatHijriDate(date, locale),
    normalizeArabicText: arabicUtils.normalizeArabicText,
    parseArabicName: arabicUtils.parseArabicName,
    formatArabicName: arabicUtils.formatArabicName,
    getArabicFamilyTerm: arabicUtils.getArabicFamilyTerm,
  };
}

/**
 * Hook to listen to locale change events
 */
export function useLocaleChange(callback: (locale: string, direction: string) => void) {
  const { locale } = useLocale();

  useEffect(() => {
    const handleLocaleChange = (event: Event) => {
      const customEvent = event as CustomEvent<{ locale: string; direction: string }>;
      callback(customEvent.detail.locale, customEvent.detail.direction);
    };

    window.addEventListener('localechange', handleLocaleChange);
    return () => window.removeEventListener('localechange', handleLocaleChange);
  }, [callback]);
}

/**
 * Hook to format file sizes
 */
export function useFileSizeFormatter() {
  const { locale } = useLocale();

  return {
    formatFileSize: (bytes: number) => format.formatFileSize(bytes, locale),
  };
}

/**
 * Hook to format lists
 */
export function useListFormatter() {
  const { locale } = useLocale();

  return {
    formatList: (items: string[], type?: 'conjunction' | 'disjunction') =>
      format.formatList(items, locale, type),
  };
}

/**
 * Hook to format phone numbers
 */
export function usePhoneFormatter() {
  const { locale } = useLocale();

  return {
    formatPhoneNumber: (phone: string) => format.formatPhoneNumber(phone, locale),
  };
}
