'use client';

import { useContext } from 'react';
import { useFeatureFlag, useIsFlagEnabled } from '@/providers/feature-flag-provider';

/**
 * Hook to access feature flag context
 */
export function useFeatureFlags() {
  return useFeatureFlag();
}

/**
 * Hook to check if a feature flag is enabled
 * @param featureName - Name of the feature flag
 * @param fallback - Value to return while loading
 */
export function useIsFlagEnabled(
  featureName: string,
  fallback: boolean = false
): boolean {
  return useIsFlagEnabled(featureName, { fallback });
}

/**
 * Hook to check multiple feature flags
 */
export function useAreMultipleFlagsEnabled(
  featureNames: string[],
  fallback: boolean = false
): Record<string, boolean> {
  const { isFeatureEnabled, isLoading } = useFeatureFlags();

  const result: Record<string, boolean> = {};

  featureNames.forEach((name) => {
    result[name] = isLoading ? fallback : isFeatureEnabled(name);
  });

  return result;
}

/**
 * Hook to render component conditionally based on feature flag
 */
export function useFeatureComponent(
  featureName: string,
  fallback: boolean = false
): {
  isEnabled: boolean;
  isLoading: boolean;
} {
  const { isFeatureEnabled, isLoading } = useFeatureFlags();

  return {
    isEnabled: isLoading ? fallback : isFeatureEnabled(featureName),
    isLoading,
  };
}

/**
 * Hook to refetch feature flags
 */
export function useRefreshFeatureFlags() {
  const { refetchFlags } = useFeatureFlags();
  return refetchFlags;
}

/**
 * Hook to get all feature flags
 */
export function useAllFeatureFlags() {
  const { flags } = useFeatureFlags();
  return flags;
}
