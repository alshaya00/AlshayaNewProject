'use client';

import { useEffect, useState, useCallback } from 'react';

/**
 * Hook for safe localStorage access with SSR support
 * @param key - Storage key
 * @param initialValue - Initial value if not found
 */
export function useLocalStorage<T>(
  key: string,
  initialValue: T
): [T, (value: T | ((val: T) => T)) => void] {
  const [storedValue, setStoredValue] = useState<T>(initialValue);
  const [isMounted, setIsMounted] = useState(false);

  // Initialize from localStorage on mount
  useEffect(() => {
    setIsMounted(true);
    try {
      const item = window.localStorage.getItem(key);
      if (item) {
        setStoredValue(JSON.parse(item) as T);
      }
    } catch (error) {
      console.error(`Error reading from localStorage [${key}]:`, error);
    }
  }, [key]);

  // Update localStorage when value changes
  const setValue = useCallback(
    (value: T | ((val: T) => T)) => {
      try {
        const valueToStore = value instanceof Function ? value(storedValue) : value;
        setStoredValue(valueToStore);

        if (typeof window !== 'undefined') {
          window.localStorage.setItem(key, JSON.stringify(valueToStore));

          // Dispatch event for other tabs/windows
          window.dispatchEvent(
            new StorageEvent('storage', {
              key,
              newValue: JSON.stringify(valueToStore),
              oldValue: JSON.stringify(storedValue),
              storageArea: window.localStorage,
              url: window.location.href,
            })
          );
        }
      } catch (error) {
        console.error(`Error writing to localStorage [${key}]:`, error);
      }
    },
    [key, storedValue]
  );

  // Listen for changes from other tabs
  useEffect(() => {
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === key && e.newValue) {
        try {
          setStoredValue(JSON.parse(e.newValue) as T);
        } catch (error) {
          console.error(`Error parsing storage event [${key}]:`, error);
        }
      }
    };

    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, [key]);

  return isMounted ? [storedValue, setValue] : [initialValue, setValue];
}

/**
 * Hook for localStorage with string values (no JSON parsing)
 */
export function useLocalStorageString(
  key: string,
  initialValue: string = ''
): [string, (value: string) => void] {
  const [value, setValue] = useState(initialValue);
  const [isMounted, setIsMounted] = useState(false);

  useEffect(() => {
    setIsMounted(true);
    const item = window.localStorage.getItem(key);
    if (item) {
      setValue(item);
    }
  }, [key]);

  const setStringValue = useCallback(
    (newValue: string) => {
      setValue(newValue);
      window.localStorage.setItem(key, newValue);
    },
    [key]
  );

  return isMounted ? [value, setStringValue] : [initialValue, setStringValue];
}

/**
 * Hook to remove item from localStorage
 */
export function useRemoveLocalStorage(key: string): () => void {
  return useCallback(() => {
    try {
      window.localStorage.removeItem(key);
    } catch (error) {
      console.error(`Error removing from localStorage [${key}]:`, error);
    }
  }, [key]);
}

/**
 * Hook to clear all localStorage
 */
export function useClearLocalStorage(): () => void {
  return useCallback(() => {
    try {
      window.localStorage.clear();
    } catch (error) {
      console.error('Error clearing localStorage:', error);
    }
  }, []);
}

/**
 * Hook to get localStorage key by index
 */
export function useGetLocalStorageKey(index: number): string | null {
  const [key, setKey] = useState<string | null>(null);

  useEffect(() => {
    try {
      const key = window.localStorage.key(index);
      setKey(key);
    } catch (error) {
      console.error(`Error getting localStorage key at index ${index}:`, error);
    }
  }, [index]);

  return key;
}

/**
 * Hook to get localStorage length
 */
export function useGetLocalStorageLength(): number {
  const [length, setLength] = useState(0);

  useEffect(() => {
    try {
      setLength(window.localStorage.length);
    } catch (error) {
      console.error('Error getting localStorage length:', error);
    }
  }, []);

  return length;
}
