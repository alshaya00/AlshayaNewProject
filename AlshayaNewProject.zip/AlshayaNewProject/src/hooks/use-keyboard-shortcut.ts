'use client';

import { useEffect, useCallback, useRef } from 'react';

interface KeyboardModifiers {
  ctrlKey?: boolean;
  shiftKey?: boolean;
  altKey?: boolean;
  metaKey?: boolean;
}

interface KeyboardShortcutOptions extends KeyboardModifiers {
  onKeyDown?: (event: KeyboardEvent) => void;
  preventDefault?: boolean;
  stopPropagation?: boolean;
  targetElement?: HTMLElement | Window;
}

/**
 * Hook to bind keyboard shortcuts
 * @param key - Key to listen for (e.g., 'Enter', 'Escape', 'a', '/')
 * @param callback - Callback when shortcut is pressed
 * @param options - Options for modifiers and behavior
 */
export function useKeyboardShortcut(
  key: string,
  callback: () => void,
  options: KeyboardShortcutOptions = {}
): void {
  const {
    ctrlKey = false,
    shiftKey = false,
    altKey = false,
    metaKey = false,
    preventDefault = true,
    stopPropagation = true,
    targetElement = typeof window !== 'undefined' ? window : null,
  } = options;

  const callbackRef = useRef(callback);

  useEffect(() => {
    callbackRef.current = callback;
  }, [callback]);

  useEffect(() => {
    if (!targetElement) return;

    const handleKeyDown = (event: KeyboardEvent) => {
      const keyMatches = event.key.toLowerCase() === key.toLowerCase();
      const ctrlMatches =
        (event.ctrlKey || event.metaKey) === (ctrlKey || metaKey);
      const shiftMatches = event.shiftKey === shiftKey;
      const altMatches = event.altKey === altKey;

      if (keyMatches && ctrlMatches && shiftMatches && altMatches) {
        if (preventDefault) {
          event.preventDefault();
        }
        if (stopPropagation) {
          event.stopPropagation();
        }
        callbackRef.current();
      }
    };

    targetElement.addEventListener('keydown', handleKeyDown as EventListener);

    return () => {
      targetElement.removeEventListener('keydown', handleKeyDown as EventListener);
    };
  }, [key, ctrlKey, shiftKey, altKey, metaKey, preventDefault, stopPropagation, targetElement]);
}

/**
 * Hook for common shortcuts
 */
export function useCommonShortcuts() {
  return {
    useEnterKey: (callback: () => void) => {
      useKeyboardShortcut('Enter', callback);
    },
    useEscapeKey: (callback: () => void) => {
      useKeyboardShortcut('Escape', callback);
    },
    useCtrlS: (callback: () => void) => {
      useKeyboardShortcut('s', callback, { ctrlKey: true });
    },
    useCtrlC: (callback: () => void) => {
      useKeyboardShortcut('c', callback, { ctrlKey: true });
    },
    useCtrlV: (callback: () => void) => {
      useKeyboardShortcut('v', callback, { ctrlKey: true });
    },
    useCtrlZ: (callback: () => void) => {
      useKeyboardShortcut('z', callback, { ctrlKey: true });
    },
    useCtrlY: (callback: () => void) => {
      useKeyboardShortcut('y', callback, { ctrlKey: true });
    },
    useCtrlA: (callback: () => void) => {
      useKeyboardShortcut('a', callback, { ctrlKey: true });
    },
    useSlash: (callback: () => void) => {
      useKeyboardShortcut('/', callback);
    },
    useArrowUp: (callback: () => void) => {
      useKeyboardShortcut('ArrowUp', callback);
    },
    useArrowDown: (callback: () => void) => {
      useKeyboardShortcut('ArrowDown', callback);
    },
    useArrowLeft: (callback: () => void) => {
      useKeyboardShortcut('ArrowLeft', callback);
    },
    useArrowRight: (callback: () => void) => {
      useKeyboardShortcut('ArrowRight', callback);
    },
  };
}

/**
 * Hook for global keyboard shortcuts registry
 */
export function useKeyboardShortcutsRegistry() {
  const shortcutsRef = useRef<Map<string, () => void>>(new Map());

  const registerShortcut = useCallback(
    (
      key: string,
      callback: () => void,
      options: KeyboardShortcutOptions = {}
    ) => {
      const shortcutKey = `${options.ctrlKey ? 'ctrl+' : ''}${options.shiftKey ? 'shift+' : ''}${options.altKey ? 'alt+' : ''}${options.metaKey ? 'meta+' : ''}${key}`;

      shortcutsRef.current.set(shortcutKey, callback);

      // Use the useKeyboardShortcut hook
      useKeyboardShortcut(key, callback, options);

      // Return unregister function
      return () => {
        shortcutsRef.current.delete(shortcutKey);
      };
    },
    []
  );

  const unregisterShortcut = useCallback((shortcutKey: string) => {
    shortcutsRef.current.delete(shortcutKey);
  }, []);

  const getShortcuts = useCallback(() => {
    return Array.from(shortcutsRef.current.entries());
  }, []);

  return {
    registerShortcut,
    unregisterShortcut,
    getShortcuts,
  };
}

/**
 * Hook to listen to multiple key combinations
 */
export function useMultipleKeys(
  keys: string[],
  callback: () => void,
  options: KeyboardShortcutOptions = {}
): void {
  const pressedKeysRef = useRef<Set<string>>(new Set());

  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      pressedKeysRef.current.add(event.key.toLowerCase());

      // Check if all required keys are pressed
      const allPressed = keys.every((key) =>
        pressedKeysRef.current.has(key.toLowerCase())
      );

      if (allPressed) {
        if (options.preventDefault) {
          event.preventDefault();
        }
        if (options.stopPropagation) {
          event.stopPropagation();
        }
        callback();
      }
    };

    const handleKeyUp = (event: KeyboardEvent) => {
      pressedKeysRef.current.delete(event.key.toLowerCase());
    };

    const targetElement = options.targetElement || (typeof window !== 'undefined' ? window : null);

    if (targetElement) {
      targetElement.addEventListener('keydown', handleKeyDown as EventListener);
      targetElement.addEventListener('keyup', handleKeyUp as EventListener);

      return () => {
        targetElement.removeEventListener('keydown', handleKeyDown as EventListener);
        targetElement.removeEventListener('keyup', handleKeyUp as EventListener);
      };
    }
  }, [keys, callback, options]);
}
