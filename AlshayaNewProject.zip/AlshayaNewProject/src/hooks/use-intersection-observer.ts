'use client';

import { useEffect, useRef, useState, useCallback } from 'react';

interface UseIntersectionObserverOptions extends IntersectionObserverInit {
  onEnter?: () => void;
  onLeave?: () => void;
}

/**
 * Hook for Intersection Observer API
 * Useful for lazy loading, infinite scroll, etc.
 */
export function useIntersectionObserver<T extends HTMLElement>(
  options: UseIntersectionObserverOptions = {}
) {
  const ref = useRef<T>(null);
  const [isVisible, setIsVisible] = useState(false);

  const { onEnter, onLeave, ...observerOptions } = options;

  useEffect(() => {
    const observer = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) {
        setIsVisible(true);
        onEnter?.();
      } else {
        setIsVisible(false);
        onLeave?.();
      }
    }, observerOptions);

    if (ref.current) {
      observer.observe(ref.current);
    }

    return () => {
      if (ref.current) {
        observer.unobserve(ref.current);
      }
      observer.disconnect();
    };
  }, [observerOptions, onEnter, onLeave]);

  return { ref, isVisible };
}

/**
 * Hook for lazy loading with Intersection Observer
 * Automatically unobserves after element becomes visible
 */
export function useLazyLoad<T extends HTMLElement>(
  callback?: () => void,
  options?: IntersectionObserverInit
) {
  const ref = useRef<T>(null);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) {
        setIsLoaded(true);
        callback?.();
        if (ref.current) {
          observer.unobserve(ref.current);
        }
      }
    }, options);

    if (ref.current) {
      observer.observe(ref.current);
    }

    return () => {
      if (ref.current) {
        observer.unobserve(ref.current);
      }
      observer.disconnect();
    };
  }, [callback, options]);

  return { ref, isLoaded };
}

/**
 * Hook for infinite scroll
 */
export function useInfiniteScroll(
  onLoadMore: () => void,
  options?: IntersectionObserverInit
) {
  const ref = useRef<HTMLDivElement>(null);
  const [hasMore, setHasMore] = useState(true);

  useEffect(() => {
    if (!hasMore) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          onLoadMore();
        }
      },
      {
        threshold: 0.1,
        ...options,
      }
    );

    if (ref.current) {
      observer.observe(ref.current);
    }

    return () => {
      if (ref.current) {
        observer.unobserve(ref.current);
      }
      observer.disconnect();
    };
  }, [onLoadMore, hasMore, options]);

  return { ref, hasMore, setHasMore };
}

/**
 * Hook to observe multiple elements
 */
export function useMultipleIntersectionObserver(
  refs: React.RefObject<HTMLElement>[],
  callback?: (index: number, isVisible: boolean) => void,
  options?: IntersectionObserverInit
) {
  const [visibilityMap, setVisibilityMap] = useState<Record<number, boolean>>({});

  useEffect(() => {
    const observer = new IntersectionObserver(([entry]) => {
      const index = refs.findIndex((ref) => ref.current === entry.target);

      if (index !== -1) {
        const isVisible = entry.isIntersecting;
        setVisibilityMap((prev) => ({
          ...prev,
          [index]: isVisible,
        }));
        callback?.(index, isVisible);
      }
    }, options);

    refs.forEach((ref) => {
      if (ref.current) {
        observer.observe(ref.current);
      }
    });

    return () => {
      refs.forEach((ref) => {
        if (ref.current) {
          observer.unobserve(ref.current);
        }
      });
      observer.disconnect();
    };
  }, [refs, callback, options]);

  return visibilityMap;
}

/**
 * Hook to detect when element enters or leaves viewport
 */
export function useElementVisibility<T extends HTMLElement>(
  options: IntersectionObserverInit = { threshold: 0 }
) {
  const ref = useRef<T>(null);
  const [isInViewport, setIsInViewport] = useState(false);
  const [hasBeenInViewport, setHasBeenInViewport] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(([entry]) => {
      setIsInViewport(entry.isIntersecting);
      if (entry.isIntersecting) {
        setHasBeenInViewport(true);
      }
    }, options);

    if (ref.current) {
      observer.observe(ref.current);
    }

    return () => {
      if (ref.current) {
        observer.unobserve(ref.current);
      }
      observer.disconnect();
    };
  }, [options]);

  return { ref, isInViewport, hasBeenInViewport };
}
