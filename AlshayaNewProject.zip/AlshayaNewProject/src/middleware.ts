import { NextRequest, NextResponse } from 'next/server';
import { jwtVerify } from 'jose';

const supportedLocales = ['ar', 'en'];
const defaultLocale = 'ar';

const secret = new TextEncoder().encode(
  process.env.NEXTAUTH_SECRET || 'default-secret-key-change-in-production'
);

export async function middleware(request: NextRequest) {
  const pathname = request.nextUrl.pathname;

  // Check if locale is in the pathname
  const localeMatch = pathname.match(/^\/(ar|en)(?:\/|$)/);
  const locale = localeMatch?.[1] || defaultLocale;

  // Redirect to locale if missing
  if (!localeMatch) {
    const newPathname = `/${locale}${pathname === '/' ? '' : pathname}`;
    return NextResponse.redirect(new URL(newPathname, request.url));
  }

  // Protected routes that require authentication
  const protectedRoutes = [
    '/dashboard',
    '/members',
    '/tree',
    '/admin',
    '/settings',
    '/profile',
  ];

  const isProtectedRoute = protectedRoutes.some((route) =>
    pathname.includes(route)
  );

  if (isProtectedRoute) {
    const token = request.cookies.get('auth-token')?.value;

    if (!token) {
      const loginUrl = new URL(`/${locale}/login`, request.url);
      loginUrl.searchParams.set('redirect', pathname);
      return NextResponse.redirect(loginUrl);
    }

    try {
      await jwtVerify(token, secret);
    } catch (error) {
      const loginUrl = new URL(`/${locale}/login`, request.url);
      loginUrl.searchParams.set('redirect', pathname);
      loginUrl.searchParams.set('error', 'session_expired');
      const response = NextResponse.redirect(loginUrl);
      response.cookies.delete('auth-token');
      return response;
    }
  }

  // Clone request headers and set locale
  const requestHeaders = new Headers(request.headers);
  requestHeaders.set('x-locale', locale);

  return NextResponse.next({
    request: {
      headers: requestHeaders,
    },
  });
}

export const config = {
  matcher: [
    '/((?!_next|api|static|public|favicon\\.ico|robots\\.txt|sitemap\\.xml).*)',
  ],
};
