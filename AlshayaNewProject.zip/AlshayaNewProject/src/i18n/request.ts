import { headers } from 'next/headers';
import { normalizeLocale, type Locale } from './config';

export async function getLocaleFromRequest(): Promise<Locale> {
  const headersList = await headers();
  const acceptLanguage = headersList.get('accept-language');

  if (!acceptLanguage) {
    return 'ar';
  }

  // Parse Accept-Language header
  const locales = acceptLanguage.split(',').map((lang) => {
    const parts = lang.trim().split(';');
    const locale = parts[0].split('-')[0].toLowerCase();
    const quality = parts[1] ? parseFloat(parts[1].replace('q=', '')) : 1;
    return { locale, quality };
  });

  // Sort by quality (descending)
  locales.sort((a, b) => b.quality - a.quality);

  // Find first matching locale
  for (const { locale } of locales) {
    if (locale === 'ar' || locale === 'en') {
      return normalizeLocale(locale);
    }
  }

  return 'ar';
}
