import * as React from 'react';
import { cn } from '@/lib/utils';
import { Button } from './ui/button';

interface EmptyStateProps {
  icon?: React.ReactNode;
  title: string;
  description?: string;
  actionLabel?: string;
  onAction?: () => void;
  actionHref?: string;
  secondaryActionLabel?: string;
  onSecondaryAction?: () => void;
  className?: string;
}

const EmptyState = React.forwardRef<HTMLDivElement, EmptyStateProps>(
  (
    {
      icon,
      title,
      description,
      actionLabel,
      onAction,
      actionHref,
      secondaryActionLabel,
      onSecondaryAction,
      className,
    },
    ref
  ) => {
    return (
      <div
        ref={ref}
        className={cn(
          'flex flex-col items-center justify-center py-12 px-4 text-center',
          className
        )}
      >
        {icon && (
          <div className="mb-4 text-text-muted opacity-50">
            {icon}
          </div>
        )}

        <h3 className="text-2xl font-semibold text-text mb-2">
          {title}
        </h3>

        {description && (
          <p className="text-text-muted mb-6 max-w-sm">
            {description}
          </p>
        )}

        {(actionLabel || secondaryActionLabel) && (
          <div className="flex gap-3 flex-wrap justify-center">
            {actionLabel && (
              actionHref ? (
                <a href={actionHref}>
                  <Button variant="primary">{actionLabel}</Button>
                </a>
              ) : (
                <Button variant="primary" onClick={onAction}>
                  {actionLabel}
                </Button>
              )
            )}
            {secondaryActionLabel && (
              <Button variant="secondary" onClick={onSecondaryAction}>
                {secondaryActionLabel}
              </Button>
            )}
          </div>
        )}
      </div>
    );
  }
);

EmptyState.displayName = 'EmptyState';

export { EmptyState };
export type { EmptyStateProps };
