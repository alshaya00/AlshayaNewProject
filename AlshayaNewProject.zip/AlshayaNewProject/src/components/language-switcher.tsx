import * as React from 'react';
import { cn } from '@/lib/utils';
import { Button } from './ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuTrigger,
  DropdownMenuItem,
  DropdownMenuCheckboxItem,
} from './ui/dropdown-menu';

interface LanguageSwitcherProps {
  currentLanguage?: 'ar' | 'en';
  onLanguageChange?: (language: 'ar' | 'en') => void;
  variant?: 'button' | 'dropdown' | 'inline';
  className?: string;
}

const LanguageSwitcher = React.forwardRef<HTMLDivElement, LanguageSwitcherProps>(
  (
    {
      currentLanguage = 'en',
      onLanguageChange,
      variant = 'dropdown',
      className,
    },
    ref
  ) => {
    const languages = [
      { code: 'ar', label: 'العربية', nativeLabel: 'Arabic' },
      { code: 'en', label: 'English', nativeLabel: 'English' },
    ] as const;

    const currentLang = languages.find((l) => l.code === currentLanguage);

    if (variant === 'inline') {
      return (
        <div ref={ref} className={cn('flex items-center gap-2', className)}>
          {languages.map((lang) => (
            <button
              key={lang.code}
              onClick={() => onLanguageChange?.(lang.code)}
              className={cn(
                'px-3 py-1.5 text-sm font-medium rounded transition-colors',
                currentLanguage === lang.code
                  ? 'bg-cyan-500 text-navy'
                  : 'bg-navy-light text-text hover:bg-navy'
              )}
            >
              {lang.label}
            </button>
          ))}
        </div>
      );
    }

    if (variant === 'button') {
      return (
        <button
          ref={ref as any}
          onClick={() =>
            onLanguageChange?.(currentLanguage === 'ar' ? 'en' : 'ar')
          }
          className={cn(
            'px-4 py-2 rounded-lg border-2 border-cyan-500 bg-navy text-cyan-500 hover:bg-navy-light transition-colors font-medium',
            className
          )}
        >
          {currentLang?.label}
        </button>
      );
    }

    // dropdown variant (default)
    return (
      <div ref={ref} className={className}>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="secondary" size="sm">
              {currentLang?.label}
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            {languages.map((lang) => (
              <DropdownMenuCheckboxItem
                key={lang.code}
                checked={currentLanguage === lang.code}
                onCheckedChange={() => onLanguageChange?.(lang.code)}
              >
                <div className="flex flex-col">
                  <span className="font-medium">{lang.label}</span>
                  <span className="text-xs text-text-muted">{lang.nativeLabel}</span>
                </div>
              </DropdownMenuCheckboxItem>
            ))}
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    );
  }
);

LanguageSwitcher.displayName = 'LanguageSwitcher';

export { LanguageSwitcher };
export type { LanguageSwitcherProps };
