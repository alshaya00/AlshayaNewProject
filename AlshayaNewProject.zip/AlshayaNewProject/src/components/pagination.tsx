import * as React from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from './ui/button';

interface PaginationProps {
  currentPage: number;
  totalPages: number;
  onPageChange: (page: number) => void;
  siblingCount?: number;
  disabled?: boolean;
}

const Pagination = React.forwardRef<HTMLDivElement, PaginationProps>(
  ({ currentPage, totalPages, onPageChange, siblingCount = 1, disabled = false }, ref) => {
    const getPageNumbers = () => {
      const pages: (number | string)[] = [];
      const leftSibling = Math.max(1, currentPage - siblingCount);
      const rightSibling = Math.min(totalPages, currentPage + siblingCount);

      if (leftSibling > 2) {
        pages.push(1);
        if (leftSibling > 3) pages.push('...');
      }

      for (let i = leftSibling; i <= rightSibling; i++) {
        pages.push(i);
      }

      if (rightSibling < totalPages - 1) {
        if (rightSibling < totalPages - 2) pages.push('...');
        pages.push(totalPages);
      }

      return pages;
    };

    const pages = getPageNumbers();

    return (
      <div
        ref={ref}
        className="flex items-center justify-center gap-2"
      >
        <Button
          variant="ghost"
          size="sm"
          onClick={() => onPageChange(currentPage - 1)}
          disabled={disabled || currentPage === 1}
          aria-label="Previous page"
        >
          <ChevronLeft className="h-4 w-4" />
        </Button>

        <div className="flex gap-1">
          {pages.map((page, index) => (
            <React.Fragment key={index}>
              {page === '...' ? (
                <span className="px-2 py-1 text-text-muted">...</span>
              ) : (
                <Button
                  variant={page === currentPage ? 'primary' : 'ghost'}
                  size="sm"
                  onClick={() => onPageChange(page as number)}
                  disabled={disabled}
                  className={cn(
                    'w-10 h-10 p-0',
                    page === currentPage && 'opacity-100'
                  )}
                >
                  {page}
                </Button>
              )}
            </React.Fragment>
          ))}
        </div>

        <Button
          variant="ghost"
          size="sm"
          onClick={() => onPageChange(currentPage + 1)}
          disabled={disabled || currentPage === totalPages}
          aria-label="Next page"
        >
          <ChevronRight className="h-4 w-4" />
        </Button>

        <span className="ms-4 text-sm text-text-muted">
          Page {currentPage} of {totalPages}
        </span>
      </div>
    );
  }
);

Pagination.displayName = 'Pagination';

export { Pagination };
export type { PaginationProps };
