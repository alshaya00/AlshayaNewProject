import * as React from 'react';
import { ChevronUp, ChevronDown } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from './ui/button';

interface Column<T> {
  key: keyof T;
  label: string;
  sortable?: boolean;
  width?: string;
  render?: (value: T[keyof T], row: T) => React.ReactNode;
}

interface DataTableProps<T> {
  columns: Column<T>[];
  data: T[];
  onSort?: (key: keyof T, direction: 'asc' | 'desc') => void;
  sortKey?: keyof T;
  sortDirection?: 'asc' | 'desc';
  onRowClick?: (row: T) => void;
  striped?: boolean;
  hoverable?: boolean;
}

const DataTable = React.forwardRef<
  HTMLTableElement,
  DataTableProps<any>
>(
  (
    {
      columns,
      data,
      onSort,
      sortKey,
      sortDirection = 'asc',
      onRowClick,
      striped = true,
      hoverable = true,
    },
    ref
  ) => {
    return (
      <div className="w-full overflow-x-auto rounded-lg border-2 border-navy-light">
        <table
          ref={ref}
          className="w-full text-sm text-text"
        >
          <thead>
            <tr className="border-b-2 border-navy-light bg-navy-light">
              {columns.map((column) => (
                <th
                  key={String(column.key)}
                  className={cn(
                    'px-4 py-3 text-start font-semibold',
                    column.width && `w-[${column.width}]`
                  )}
                >
                  <div className="flex items-center gap-2">
                    <span>{column.label}</span>
                    {column.sortable && onSort && (
                      <button
                        onClick={() =>
                          onSort(
                            column.key,
                            sortKey === column.key && sortDirection === 'asc'
                              ? 'desc'
                              : 'asc'
                          )
                        }
                        className="inline-flex items-center justify-center h-4 w-4 hover:bg-navy rounded transition-colors"
                      >
                        {sortKey === column.key ? (
                          sortDirection === 'asc' ? (
                            <ChevronUp className="h-3 w-3 text-cyan-500" />
                          ) : (
                            <ChevronDown className="h-3 w-3 text-cyan-500" />
                          )
                        ) : (
                          <ChevronUp className="h-3 w-3 opacity-30" />
                        )}
                      </button>
                    )}
                  </div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {data.map((row, index) => (
              <tr
                key={index}
                onClick={() => onRowClick?.(row)}
                className={cn(
                  'border-b-2 border-navy-light transition-colors',
                  striped && index % 2 === 0 && 'bg-navy/50',
                  hoverable && 'hover:bg-navy-light cursor-pointer'
                )}
              >
                {columns.map((column) => (
                  <td
                    key={String(column.key)}
                    className="px-4 py-3"
                  >
                    {column.render
                      ? column.render(row[column.key], row)
                      : String(row[column.key])}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
        {data.length === 0 && (
          <div className="px-4 py-8 text-center text-text-muted">
            No data available
          </div>
        )}
      </div>
    );
  }
);

DataTable.displayName = 'DataTable';

export { DataTable };
export type { DataTableProps, Column };
