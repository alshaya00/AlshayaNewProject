import * as React from 'react';
import { Search, X } from 'lucide-react';
import { cn, debounce } from '@/lib/utils';
import { Input } from './ui/input';
import { Button } from './ui/button';

interface SearchInputProps {
  placeholder?: string;
  onSearch?: (value: string) => void;
  onSuggestionsChange?: (suggestions: string[]) => void;
  suggestions?: string[];
  debounceMs?: number;
  disabled?: boolean;
  autoComplete?: boolean;
}

const SearchInput = React.forwardRef<HTMLInputElement, SearchInputProps>(
  (
    {
      placeholder = 'Search...',
      onSearch,
      onSuggestionsChange,
      suggestions = [],
      debounceMs = 300,
      disabled = false,
      autoComplete = true,
    },
    ref
  ) => {
    const [value, setValue] = React.useState('');
    const [showSuggestions, setShowSuggestions] = React.useState(false);
    const [filteredSuggestions, setFilteredSuggestions] = React.useState<string[]>([]);

    const debouncedSearch = React.useMemo(
      () =>
        debounce((searchValue: string) => {
          onSearch?.(searchValue);
          if (autoComplete && suggestions.length > 0) {
            const filtered = suggestions.filter((s) =>
              s.toLowerCase().includes(searchValue.toLowerCase())
            );
            setFilteredSuggestions(filtered);
            onSuggestionsChange?.(filtered);
          }
        }, debounceMs),
      [onSearch, onSuggestionsChange, suggestions, debounceMs, autoComplete]
    );

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const newValue = e.target.value;
      setValue(newValue);
      setShowSuggestions(newValue.length > 0);
      debouncedSearch(newValue);
    };

    const handleSuggestionClick = (suggestion: string) => {
      setValue(suggestion);
      setShowSuggestions(false);
      onSearch?.(suggestion);
    };

    const handleClear = () => {
      setValue('');
      setShowSuggestions(false);
      onSearch?.('');
    };

    return (
      <div className="relative w-full">
        <div className="relative">
          <Search className="absolute inset-y-0 ps-3 h-5 w-5 text-text-muted flex items-center pointer-events-none" />
          <input
            ref={ref}
            type="text"
            value={value}
            onChange={handleChange}
            placeholder={placeholder}
            disabled={disabled}
            className={cn(
              'w-full ps-10 pe-10 py-2 rounded-lg border-2 border-navy-light bg-navy text-text placeholder-text-muted transition-colors focus:outline-none focus:border-cyan-500 focus:ring-2 focus:ring-cyan-500/20 disabled:opacity-50 disabled:cursor-not-allowed'
            )}
          />
          {value && (
            <button
              onClick={handleClear}
              className="absolute inset-y-0 pe-3 flex items-center hover:text-text transition-colors"
            >
              <X className="h-4 w-4 text-text-muted" />
            </button>
          )}
        </div>

        {showSuggestions && filteredSuggestions.length > 0 && (
          <div className="absolute top-full mt-2 w-full bg-navy border-2 border-navy-light rounded-lg shadow-lg z-50">
            {filteredSuggestions.map((suggestion, index) => (
              <button
                key={index}
                onClick={() => handleSuggestionClick(suggestion)}
                className="w-full text-start px-4 py-2 hover:bg-navy-light transition-colors first:rounded-t-lg last:rounded-b-lg text-text"
              >
                {suggestion}
              </button>
            ))}
          </div>
        )}
      </div>
    );
  }
);

SearchInput.displayName = 'SearchInput';

export { SearchInput };
export type { SearchInputProps };
