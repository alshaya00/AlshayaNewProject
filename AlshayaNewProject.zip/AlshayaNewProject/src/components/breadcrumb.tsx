import * as React from 'react';
import { ChevronRight } from 'lucide-react';
import { cn } from '@/lib/utils';

interface BreadcrumbItem {
  label: string;
  href?: string;
  onClick?: () => void;
  current?: boolean;
}

interface BreadcrumbProps {
  items: BreadcrumbItem[];
  separator?: React.ReactNode;
  className?: string;
}

const Breadcrumb = React.forwardRef<HTMLNavElement, BreadcrumbProps>(
  ({ items, separator = <ChevronRight className="h-4 w-4 text-text-muted mx-2" />, className }, ref) => {
    return (
      <nav
        ref={ref}
        className={cn('flex items-center gap-0 text-sm', className)}
        aria-label="Breadcrumb"
      >
        <ol className="flex items-center gap-0">
          {items.map((item, index) => (
            <li key={index} className="flex items-center">
              {item.href ? (
                <a
                  href={item.href}
                  className={cn(
                    'hover:text-cyan-400 transition-colors',
                    item.current ? 'text-text font-semibold' : 'text-text-muted'
                  )}
                  aria-current={item.current ? 'page' : undefined}
                >
                  {item.label}
                </a>
              ) : (
                <button
                  onClick={item.onClick}
                  className={cn(
                    'hover:text-cyan-400 transition-colors cursor-pointer',
                    item.current ? 'text-text font-semibold' : 'text-text-muted'
                  )}
                  aria-current={item.current ? 'page' : undefined}
                >
                  {item.label}
                </button>
              )}
              {index < items.length - 1 && separator}
            </li>
          ))}
        </ol>
      </nav>
    );
  }
);

Breadcrumb.displayName = 'Breadcrumb';

export { Breadcrumb };
export type { BreadcrumbProps, BreadcrumbItem };
