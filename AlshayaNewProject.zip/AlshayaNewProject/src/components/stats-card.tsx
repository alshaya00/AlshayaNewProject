import * as React from 'react';
import { TrendingUp, TrendingDown } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';

interface StatsCardProps {
  title: string;
  value: string | number;
  description?: string;
  icon?: React.ReactNode;
  trend?: {
    value: number;
    direction: 'up' | 'down';
    label?: string;
  };
  color?: 'cyan' | 'green' | 'blue' | 'purple' | 'orange' | 'red';
  className?: string;
}

const colorClasses = {
  cyan: 'text-cyan-400',
  green: 'text-green-400',
  blue: 'text-blue-400',
  purple: 'text-purple-400',
  orange: 'text-orange-400',
  red: 'text-red-400',
};

const bgColorClasses = {
  cyan: 'bg-cyan-500/10',
  green: 'bg-green-500/10',
  blue: 'bg-blue-500/10',
  purple: 'bg-purple-500/10',
  orange: 'bg-orange-500/10',
  red: 'bg-red-500/10',
};

const StatsCard = React.forwardRef<HTMLDivElement, StatsCardProps>(
  (
    {
      title,
      value,
      description,
      icon,
      trend,
      color = 'cyan',
      className,
    },
    ref
  ) => {
    return (
      <Card ref={ref} className={className}>
        <CardHeader className="flex flex-row items-center justify-between space-y-0">
          <div>
            <CardTitle className="text-sm font-medium">{title}</CardTitle>
            {description && (
              <CardDescription className="mt-1">{description}</CardDescription>
            )}
          </div>
          {icon && (
            <div
              className={cn(
                'rounded-lg p-2.5',
                bgColorClasses[color]
              )}
            >
              {icon}
            </div>
          )}
        </CardHeader>
        <CardContent>
          <div className="flex items-end gap-2">
            <div className="text-2xl font-bold text-text">{value}</div>
            {trend && (
              <div className="flex items-center gap-1 text-xs font-semibold">
                {trend.direction === 'up' ? (
                  <TrendingUp className="h-4 w-4 text-green-400" />
                ) : (
                  <TrendingDown className="h-4 w-4 text-red-400" />
                )}
                <span className={trend.direction === 'up' ? 'text-green-400' : 'text-red-400'}>
                  {trend.value}% {trend.label}
                </span>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    );
  }
);

StatsCard.displayName = 'StatsCard';

export { StatsCard };
export type { StatsCardProps };
