import * as React from 'react';
import { cn } from '@/lib/utils';

interface TextareaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  label?: string;
  error?: string;
  helperText?: string;
  characterCount?: boolean;
  maxChars?: number;
}

const Textarea = React.forwardRef<HTMLTextAreaElement, TextareaProps>(
  (
    {
      className,
      label,
      error,
      helperText,
      characterCount = false,
      maxChars = 500,
      value,
      onChange,
      ...props
    },
    ref
  ) => {
    const [count, setCount] = React.useState(0);

    const handleChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
      const text = e.target.value;
      setCount(text.length);
      onChange?.(e);
    };

    const textareaId = props.id || `textarea-${Math.random().toString(36).slice(2, 9)}`;

    React.useEffect(() => {
      if (typeof value === 'string') {
        setCount(value.length);
      }
    }, [value]);

    return (
      <div className="w-full">
        {label && (
          <label
            htmlFor={textareaId}
            className="block text-sm font-medium text-text mb-2"
          >
            {label}
          </label>
        )}
        <textarea
          ref={ref}
          id={textareaId}
          className={cn(
            'w-full px-4 py-2 rounded-lg border-2 border-navy-light bg-navy text-text placeholder-text-muted transition-colors focus:outline-none focus:border-cyan-500 focus:ring-2 focus:ring-cyan-500/20 disabled:opacity-50 disabled:cursor-not-allowed resize-vertical min-h-[120px]',
            error && 'border-red-500 focus:border-red-500 focus:ring-red-500/20',
            className
          )}
          value={value}
          onChange={handleChange}
          maxLength={characterCount ? maxChars : undefined}
          {...props}
        />
        <div className="flex justify-between items-center mt-2">
          <div>
            {error && <p className="text-sm text-red-500">{error}</p>}
            {helperText && !error && (
              <p className="text-sm text-text-muted">{helperText}</p>
            )}
          </div>
          {characterCount && (
            <p className="text-sm text-text-muted">
              {count} / {maxChars}
            </p>
          )}
        </div>
      </div>
    );
  }
);

Textarea.displayName = 'Textarea';

export { Textarea };
export type { TextareaProps };
