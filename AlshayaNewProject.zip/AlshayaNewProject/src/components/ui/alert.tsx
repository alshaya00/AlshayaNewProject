import * as React from 'react';
import { AlertCircle, CheckCircle, Info } from 'lucide-react';
import { cn } from '@/lib/utils';

interface AlertProps extends React.HTMLAttributes<HTMLDivElement> {
  variant?: 'info' | 'success' | 'warning' | 'error';
  title?: string;
  description?: string;
}

const Alert = React.forwardRef<HTMLDivElement, AlertProps>(
  ({ className, variant = 'info', title, description, children, ...props }, ref) => {
    const variants = {
      info: 'bg-blue-900/20 border-blue-600 text-blue-400',
      success: 'bg-green-900/20 border-green-600 text-green-400',
      warning: 'bg-amber-900/20 border-amber-600 text-amber-400',
      error: 'bg-red-900/20 border-red-600 text-red-400',
    };

    const icons = {
      info: <Info className="h-5 w-5" />,
      success: <CheckCircle className="h-5 w-5" />,
      warning: <AlertCircle className="h-5 w-5" />,
      error: <AlertCircle className="h-5 w-5" />,
    };

    return (
      <div
        ref={ref}
        role="alert"
        className={cn(
          'rounded-lg border-2 p-4 flex gap-3',
          variants[variant],
          className
        )}
        {...props}
      >
        <div className="flex-shrink-0">{icons[variant]}</div>
        <div className="flex-1">
          {title && <h3 className="font-semibold mb-1">{title}</h3>}
          {description && <p className="text-sm opacity-90">{description}</p>}
          {children}
        </div>
      </div>
    );
  }
);

Alert.displayName = 'Alert';

export { Alert };
export type { AlertProps };
