import * as React from 'react';
import * as SelectPrimitive from '@radix-ui/react-select';
import { ChevronDown } from 'lucide-react';
import { cn } from '@/lib/utils';

interface SelectOption {
  value: string;
  label: string;
}

interface SelectProps {
  options: SelectOption[];
  value?: string;
  onValueChange?: (value: string) => void;
  placeholder?: string;
  searchable?: boolean;
  disabled?: boolean;
  label?: string;
  error?: string;
}

const Select = React.forwardRef<HTMLDivElement, SelectProps>(
  (
    {
      options,
      value,
      onValueChange,
      placeholder = 'Select an option',
      searchable = false,
      disabled = false,
      label,
      error,
    },
    ref
  ) => {
    return (
      <div ref={ref} className="w-full">
        {label && (
          <label className="block text-sm font-medium text-text mb-2">
            {label}
          </label>
        )}
        <SelectPrimitive.Root
          value={value}
          onValueChange={onValueChange}
          disabled={disabled}
        >
          <SelectPrimitive.Trigger
            className={cn(
              'flex items-center justify-between w-full px-4 py-2 rounded-lg border-2 border-navy-light bg-navy text-text placeholder-text-muted transition-colors focus:outline-none focus:border-cyan-500 focus:ring-2 focus:ring-cyan-500/20 disabled:opacity-50 disabled:cursor-not-allowed',
              error && 'border-red-500 focus:border-red-500 focus:ring-red-500/20'
            )}
          >
            <SelectPrimitive.Value placeholder={placeholder} />
            <ChevronDown className="h-4 w-4 opacity-50" aria-hidden="true" />
          </SelectPrimitive.Trigger>

          <SelectPrimitive.Content
            position="popper"
            sideOffset={8}
            className="bg-navy border-2 border-navy-light rounded-lg shadow-lg z-50"
          >
            <SelectPrimitive.Viewport className="p-1">
              {options.map((option) => (
                <SelectPrimitive.Item
                  key={option.value}
                  value={option.value}
                  className="flex items-center justify-between px-4 py-2 text-text hover:bg-navy-light focus:bg-navy-light focus:outline-none cursor-pointer transition-colors"
                >
                  <SelectPrimitive.ItemText>{option.label}</SelectPrimitive.ItemText>
                  <SelectPrimitive.ItemIndicator>
                    <span className="h-2 w-2 rounded-full bg-cyan-500" />
                  </SelectPrimitive.ItemIndicator>
                </SelectPrimitive.Item>
              ))}
            </SelectPrimitive.Viewport>
          </SelectPrimitive.Content>
        </SelectPrimitive.Root>
        {error && <p className="mt-1 text-sm text-red-500">{error}</p>}
      </div>
    );
  }
);

Select.displayName = 'Select';

export { Select };
export type { SelectProps, SelectOption };
