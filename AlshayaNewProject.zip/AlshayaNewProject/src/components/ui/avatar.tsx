import * as React from 'react';
import * as AvatarPrimitive from '@radix-ui/react-avatar';
import { getInitials } from '@/lib/utils';
import { cn } from '@/lib/utils';

interface AvatarProps extends React.ComponentPropsWithoutRef<typeof AvatarPrimitive.Root> {
  src?: string;
  alt?: string;
  fallback?: string;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  initials?: string;
}

const Avatar = React.forwardRef<
  React.ElementRef<typeof AvatarPrimitive.Root>,
  AvatarProps
>(({ className, size = 'md', src, alt, fallback, initials, ...props }, ref) => {
  const sizes = {
    xs: 'h-6 w-6 text-xs',
    sm: 'h-8 w-8 text-sm',
    md: 'h-10 w-10 text-base',
    lg: 'h-12 w-12 text-lg',
    xl: 'h-16 w-16 text-xl',
  };

  const displayInitials = initials || (fallback ? getInitials(fallback) : '?');

  return (
    <AvatarPrimitive.Root
      ref={ref}
      className={cn(
        'relative inline-flex items-center justify-center rounded-full border-2 border-cyan-500 bg-navy text-text overflow-hidden',
        sizes[size],
        className
      )}
      {...props}
    >
      {src && (
        <AvatarPrimitive.Image
          src={src}
          alt={alt || 'Avatar'}
          className="h-full w-full object-cover"
        />
      )}
      <AvatarPrimitive.Fallback className="flex items-center justify-center font-semibold bg-navy-light text-text">
        {displayInitials}
      </AvatarPrimitive.Fallback>
    </AvatarPrimitive.Root>
  );
});

Avatar.displayName = 'Avatar';

export { Avatar };
export type { AvatarProps };
