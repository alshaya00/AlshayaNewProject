import * as React from 'react';
import * as SwitchPrimitive from '@radix-ui/react-switch';
import { cn } from '@/lib/utils';

interface SwitchProps extends React.ComponentPropsWithoutRef<typeof SwitchPrimitive.Root> {
  label?: string;
  description?: string;
}

const Switch = React.forwardRef<
  React.ElementRef<typeof SwitchPrimitive.Root>,
  SwitchProps
>(({ className, label, description, ...props }, ref) => (
  <div className="flex items-center justify-between">
    {(label || description) && (
      <div className="flex flex-col gap-1">
        {label && <label className="text-sm font-medium text-text">{label}</label>}
        {description && (
          <p className="text-sm text-text-muted">{description}</p>
        )}
      </div>
    )}
    <SwitchPrimitive.Root
      ref={ref}
      className={cn(
        'peer inline-flex h-6 w-11 shrink-0 cursor-pointer items-center rounded-full border-2 border-transparent transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-500 focus-visible:ring-offset-2 focus-visible:ring-offset-navy disabled:cursor-not-allowed disabled:opacity-50 bg-navy-light data-[state=checked]:bg-cyan-500 data-[state=checked]:border-cyan-600',
        className
      )}
      {...props}
    >
      <SwitchPrimitive.Thumb className="pointer-events-none block h-5 w-5 rounded-full bg-white shadow-lg transition-transform data-[state=checked]:translate-x-5 rtl:data-[state=checked]:translate-x-[-5px]" />
    </SwitchPrimitive.Root>
  </div>
));

Switch.displayName = 'Switch';

export { Switch };
export type { SwitchProps };
