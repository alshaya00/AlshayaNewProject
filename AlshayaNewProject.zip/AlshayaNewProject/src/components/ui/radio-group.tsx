import * as React from 'react';
import * as RadioGroupPrimitive from '@radix-ui/react-radio-group';
import { cn } from '@/lib/utils';

interface RadioOption {
  value: string;
  label: string;
  disabled?: boolean;
}

interface RadioGroupProps extends React.ComponentPropsWithoutRef<typeof RadioGroupPrimitive.Root> {
  options: RadioOption[];
  label?: string;
  error?: string;
  direction?: 'horizontal' | 'vertical';
}

const RadioGroup = React.forwardRef<
  React.ElementRef<typeof RadioGroupPrimitive.Root>,
  RadioGroupProps
>(
  (
    { className, options, label, error, direction = 'vertical', ...props },
    ref
  ) => (
    <div className="w-full">
      {label && (
        <label className="block text-sm font-medium text-text mb-2">
          {label}
        </label>
      )}
      <RadioGroupPrimitive.Root
        ref={ref}
        className={cn(
          'flex gap-4',
          direction === 'vertical' && 'flex-col',
          className
        )}
        {...props}
      >
        {options.map((option) => (
          <div key={option.value} className="flex items-center">
            <RadioGroupPrimitive.Item
              value={option.value}
              disabled={option.disabled}
              id={option.value}
              className="h-5 w-5 rounded-full border-2 border-navy-light bg-navy text-cyan-500 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-500 focus-visible:ring-offset-2 focus-visible:ring-offset-navy disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <RadioGroupPrimitive.Indicator className="flex items-center justify-center">
                <div className="h-2 w-2 rounded-full bg-cyan-500" />
              </RadioGroupPrimitive.Indicator>
            </RadioGroupPrimitive.Item>
            <label
              htmlFor={option.value}
              className="ms-2 text-sm font-medium text-text cursor-pointer select-none disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {option.label}
            </label>
          </div>
        ))}
      </RadioGroupPrimitive.Root>
      {error && <p className="mt-1 text-sm text-red-500">{error}</p>}
    </div>
  )
);

RadioGroup.displayName = 'RadioGroup';

export { RadioGroup };
export type { RadioGroupProps, RadioOption };
