import * as React from 'react';
import * as ToastPrimitives from '@radix-ui/react-toast';
import { X, AlertCircle, CheckCircle, Info } from 'lucide-react';
import { cn } from '@/lib/utils';

const ToastProvider = ToastPrimitives.Provider;

const ToastViewport = React.forwardRef<
  React.ElementRef<typeof ToastPrimitives.Viewport>,
  React.ComponentPropsWithoutRef<typeof ToastPrimitives.Viewport>
>(({ className, ...props }, ref) => (
  <ToastPrimitives.Viewport
    ref={ref}
    className={cn('fixed top-0 z-[100] flex max-h-screen w-full flex-col-reverse p-4 sm:bottom-0 sm:end-0 sm:top-auto sm:max-w-[420px]', className)}
    {...props}
  />
));
ToastViewport.displayName = ToastPrimitives.Viewport.displayName;

interface ToastProps extends React.ComponentPropsWithoutRef<typeof ToastPrimitives.Root> {
  type?: 'default' | 'success' | 'error' | 'info';
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
}

const Toast = React.forwardRef<React.ElementRef<typeof ToastPrimitives.Root>, ToastProps>(
  ({ className, type = 'default', open, onOpenChange, ...props }, ref) => {
    const bgColor = {
      default: 'bg-navy border-navy-light',
      success: 'bg-green-900/20 border-green-600',
      error: 'bg-red-900/20 border-red-600',
      info: 'bg-blue-900/20 border-blue-600',
    };

    const textColor = {
      default: 'text-text',
      success: 'text-green-400',
      error: 'text-red-400',
      info: 'text-blue-400',
    };

    const iconColor = {
      default: '',
      success: 'text-green-400',
      error: 'text-red-400',
      info: 'text-blue-400',
    };

    return (
      <ToastPrimitives.Root
        ref={ref}
        open={open}
        onOpenChange={onOpenChange}
        className={cn(
          'group pointer-events-auto relative flex w-full items-center justify-between rounded-lg border-2 p-4 shadow-lg transition-all data-[swipe=cancel]:translate-x-0 data-[swipe=end]:translate-x-[var(--radix-toast-swipe-end-x)] data-[swipe=move]:translate-x-[var(--radix-toast-swipe-move-x)] data-[swipe=move]:transition-none data-[state=open]:animate-in data-[state=closed]:animate-out data-[swipe=end]:animate-out data-[state=closed]:fade-out-80 data-[state=closed]:slide-out-to-end-full data-[state=open]:slide-in-from-top-full data-[state=open]:sm:slide-in-from-bottom-full',
          bgColor[type],
          className
        )}
        {...props}
      >
        <div className="flex items-center gap-3 flex-1">
          {type === 'success' && <CheckCircle className={cn('h-4 w-4', iconColor[type])} />}
          {type === 'error' && <AlertCircle className={cn('h-4 w-4', iconColor[type])} />}
          {type === 'info' && <Info className={cn('h-4 w-4', iconColor[type])} />}
          <ToastPrimitives.Description className={cn('text-sm', textColor[type])}>
            {/* Content will be added via children */}
          </ToastPrimitives.Description>
        </div>
        <ToastPrimitives.Close className="opacity-70 hover:opacity-100">
          <X className="h-4 w-4" />
        </ToastPrimitives.Close>
      </ToastPrimitives.Root>
    );
  }
);
Toast.displayName = ToastPrimitives.Root.displayName;

const ToastAction = React.forwardRef<
  React.ElementRef<typeof ToastPrimitives.Action>,
  React.ComponentPropsWithoutRef<typeof ToastPrimitives.Action>
>(({ className, ...props }, ref) => (
  <ToastPrimitives.Action
    ref={ref}
    className={cn(
      'inline-flex h-8 shrink-0 items-center justify-center rounded-md border bg-transparent px-3 text-sm font-medium ring-offset-navy transition-colors hover:bg-navy-light focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 group-[.destructive]:border-red-600 group-[.destructive]:text-red-500 group-[.destructive]:hover:border-red-700 group-[.destructive]:hover:bg-red-600 group-[.destructive]:hover:text-white group-[.destructive]:focus:ring-red-500',
      className
    )}
    {...props}
  />
));
ToastAction.displayName = ToastPrimitives.Action.displayName;

const ToastClose = React.forwardRef<
  React.ElementRef<typeof ToastPrimitives.Close>,
  React.ComponentPropsWithoutRef<typeof ToastPrimitives.Close>
>(({ className, ...props }, ref) => (
  <ToastPrimitives.Close
    ref={ref}
    className={cn('opacity-70 hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:ring-offset-2 focus:ring-offset-navy', className)}
    {...props}
  >
    <X className="h-4 w-4" />
  </ToastPrimitives.Close>
));
ToastClose.displayName = ToastPrimitives.Close.displayName;

type ToastActionElement = React.ReactElement<any>;

export {
  type ToastActionElement,
  ToastProvider,
  ToastViewport,
  Toast,
  ToastAction,
  ToastClose,
};
