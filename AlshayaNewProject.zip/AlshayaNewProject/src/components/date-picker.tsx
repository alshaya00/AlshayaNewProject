import * as React from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from './ui/button';
import { Input } from './ui/input';

interface DatePickerProps {
  value?: Date;
  onChange?: (date: Date) => void;
  disabled?: boolean;
  label?: string;
  error?: string;
  minDate?: Date;
  maxDate?: Date;
  locale?: 'ar' | 'en';
  includeHijri?: boolean;
  className?: string;
}

const DatePicker = React.forwardRef<HTMLDivElement, DatePickerProps>(
  (
    {
      value,
      onChange,
      disabled = false,
      label,
      error,
      minDate,
      maxDate,
      locale = 'en',
      includeHijri = false,
      className,
    },
    ref
  ) => {
    const [open, setOpen] = React.useState(false);
    const [month, setMonth] = React.useState(value?.getMonth() ?? new Date().getMonth());
    const [year, setYear] = React.useState(value?.getFullYear() ?? new Date().getFullYear());

    const daysInMonth = (m: number, y: number) => {
      return new Date(y, m + 1, 0).getDate();
    };

    const firstDayOfMonth = (m: number, y: number) => {
      return new Date(y, m, 1).getDay();
    };

    const isDateDisabled = (date: Date) => {
      if (minDate && date < minDate) return true;
      if (maxDate && date > maxDate) return true;
      return false;
    };

    const handleDateClick = (day: number) => {
      const newDate = new Date(year, month, day);
      onChange?.(newDate);
      setOpen(false);
    };

    const handlePrevMonth = () => {
      if (month === 0) {
        setMonth(11);
        setYear(year - 1);
      } else {
        setMonth(month - 1);
      }
    };

    const handleNextMonth = () => {
      if (month === 11) {
        setMonth(0);
        setYear(year + 1);
      } else {
        setMonth(month + 1);
      }
    };

    const formatDate = (date: Date) => {
      const options: Intl.DateTimeFormatOptions = {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
      };
      return new Intl.DateTimeFormat(locale === 'ar' ? 'ar-SA' : 'en-US', options).format(date);
    };

    const monthNames = locale === 'ar'
      ? ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر']
      : ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

    const dayNames = locale === 'ar'
      ? ['ح', 'ن', 'ث', 'ر', 'خ', 'ج', 'س']
      : ['S', 'M', 'T', 'W', 'T', 'F', 'S'];

    const days: (number | null)[] = [];
    const totalDays = daysInMonth(month, year);
    const firstDay = firstDayOfMonth(month, year);

    for (let i = 0; i < firstDay; i++) {
      days.push(null);
    }
    for (let i = 1; i <= totalDays; i++) {
      days.push(i);
    }

    return (
      <div ref={ref} className={cn('w-full', className)}>
        {label && (
          <label className="block text-sm font-medium text-text mb-2">
            {label}
          </label>
        )}

        <div className="relative">
          <button
            onClick={() => setOpen(!open)}
            disabled={disabled}
            className={cn(
              'w-full px-4 py-2 rounded-lg border-2 border-navy-light bg-navy text-text placeholder-text-muted transition-colors focus:outline-none focus:border-cyan-500 focus:ring-2 focus:ring-cyan-500/20 disabled:opacity-50 disabled:cursor-not-allowed text-start',
              error && 'border-red-500 focus:border-red-500 focus:ring-red-500/20'
            )}
          >
            {value ? formatDate(value) : 'Select date'}
          </button>

          {open && (
            <div className="absolute top-full mt-2 w-full bg-navy border-2 border-navy-light rounded-lg shadow-lg z-50 p-4">
              <div className="flex items-center justify-between mb-4">
                <button
                  onClick={handlePrevMonth}
                  className="p-1 hover:bg-navy-light rounded transition-colors"
                >
                  <ChevronLeft className="h-4 w-4" />
                </button>
                <div className="text-sm font-semibold text-text">
                  {monthNames[month]} {year}
                </div>
                <button
                  onClick={handleNextMonth}
                  className="p-1 hover:bg-navy-light rounded transition-colors"
                >
                  <ChevronRight className="h-4 w-4" />
                </button>
              </div>

              <div className="grid grid-cols-7 gap-1 text-xs text-center mb-2">
                {dayNames.map((day, i) => (
                  <div key={i} className="text-text-muted font-semibold">
                    {day}
                  </div>
                ))}
              </div>

              <div className="grid grid-cols-7 gap-1">
                {days.map((day, i) => (
                  <button
                    key={i}
                    onClick={() => day && handleDateClick(day)}
                    disabled={!day || isDateDisabled(new Date(year, month, day))}
                    className={cn(
                      'aspect-square rounded text-sm font-medium transition-colors',
                      !day && 'invisible',
                      day && !isDateDisabled(new Date(year, month, day)) && 'hover:bg-navy-light cursor-pointer text-text',
                      day && isDateDisabled(new Date(year, month, day)) && 'opacity-50 cursor-not-allowed',
                      day && value?.getDate() === day && value.getMonth() === month && value.getFullYear() === year && 'bg-cyan-500 text-navy font-bold'
                    )}
                  >
                    {day}
                  </button>
                ))}
              </div>

              <button
                onClick={() => setOpen(false)}
                className="w-full mt-4 px-3 py-2 text-sm font-medium bg-navy-light hover:bg-navy rounded transition-colors"
              >
                Close
              </button>
            </div>
          )}
        </div>

        {error && <p className="mt-1 text-sm text-red-500">{error}</p>}
      </div>
    );
  }
);

DatePicker.displayName = 'DatePicker';

export { DatePicker };
export type { DatePickerProps };
