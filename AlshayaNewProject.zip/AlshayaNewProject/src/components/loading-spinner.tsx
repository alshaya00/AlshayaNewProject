import * as React from 'react';
import { cn } from '@/lib/utils';

interface LoadingSpinnerProps {
  size?: 'sm' | 'md' | 'lg';
  label?: string;
  fullScreen?: boolean;
  className?: string;
}

const LoadingSpinner = React.forwardRef<HTMLDivElement, LoadingSpinnerProps>(
  ({ size = 'md', label, fullScreen = false, className }, ref) => {
    const sizes = {
      sm: 'h-6 w-6',
      md: 'h-10 w-10',
      lg: 'h-16 w-16',
    };

    const spinner = (
      <div className={cn('flex flex-col items-center justify-center gap-4', className)}>
        <div className={cn('relative', sizes[size])}>
          <svg
            className="animate-spin h-full w-full text-cyan-500"
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 24 24"
            aria-hidden="true"
          >
            <circle
              className="opacity-25"
              cx="12"
              cy="12"
              r="10"
              stroke="currentColor"
              strokeWidth="4"
            />
            <path
              className="opacity-75"
              fill="currentColor"
              d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
            />
          </svg>
        </div>
        {label && <p className="text-sm text-text-muted">{label}</p>}
      </div>
    );

    if (fullScreen) {
      return (
        <div
          ref={ref}
          className="fixed inset-0 flex items-center justify-center bg-navy/80 backdrop-blur-sm z-50"
        >
          {spinner}
        </div>
      );
    }

    return (
      <div ref={ref} className="flex items-center justify-center">
        {spinner}
      </div>
    );
  }
);

LoadingSpinner.displayName = 'LoadingSpinner';

export { LoadingSpinner };
export type { LoadingSpinnerProps };
