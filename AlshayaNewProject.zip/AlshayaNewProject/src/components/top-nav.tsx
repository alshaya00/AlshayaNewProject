import * as React from 'react';
import { Bell, Settings, LogOut } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Avatar } from './ui/avatar';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuTrigger,
  DropdownMenuItem,
  DropdownMenuSeparator,
} from './ui/dropdown-menu';

interface TopNavProps {
  title?: string;
  showNotifications?: boolean;
  notificationCount?: number;
  userMenuItems?: Array<{
    label: string;
    icon?: React.ReactNode;
    onClick: () => void;
    variant?: 'default' | 'danger';
  }>;
  userInfo?: {
    name: string;
    email?: string;
    avatar?: string;
  };
  onNotificationClick?: () => void;
  className?: string;
}

const TopNav = React.forwardRef<HTMLDivElement, TopNavProps>(
  (
    {
      title = 'Dashboard',
      showNotifications = true,
      notificationCount = 0,
      userMenuItems = [],
      userInfo = { name: 'User' },
      onNotificationClick,
      className,
    },
    ref
  ) => {
    return (
      <nav
        ref={ref}
        className={cn(
          'bg-navy border-b-2 border-navy-light sticky top-0 z-20 px-6 py-4',
          className
        )}
      >
        <div className="flex items-center justify-between gap-4">
          <h1 className="text-2xl font-bold text-text">{title}</h1>

          <div className="flex items-center gap-4">
            {showNotifications && (
              <button
                onClick={onNotificationClick}
                className="relative p-2 text-text-muted hover:text-text transition-colors rounded-lg hover:bg-navy-light"
              >
                <Bell className="h-5 w-5" />
                {notificationCount > 0 && (
                  <span className="absolute top-1 end-1 h-2 w-2 bg-red-500 rounded-full" />
                )}
              </button>
            )}

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="flex items-center gap-2 p-2 hover:bg-navy-light rounded-lg transition-colors">
                  <Avatar
                    src={userInfo.avatar}
                    fallback={userInfo.name}
                    size="sm"
                  />
                  <div className="hidden sm:block text-start">
                    <p className="text-sm font-medium text-text">{userInfo.name}</p>
                    {userInfo.email && (
                      <p className="text-xs text-text-muted">{userInfo.email}</p>
                    )}
                  </div>
                </button>
              </DropdownMenuTrigger>

              <DropdownMenuContent align="end" className="w-56">
                {userMenuItems.map((item, index) => (
                  <React.Fragment key={index}>
                    <DropdownMenuItem
                      onClick={item.onClick}
                      className={cn(
                        item.variant === 'danger' && 'text-red-500 hover:bg-red-900/20'
                      )}
                    >
                      {item.icon && <span className="me-2">{item.icon}</span>}
                      {item.label}
                    </DropdownMenuItem>
                    {index === Math.max(0, userMenuItems.length - 2) && (
                      <DropdownMenuSeparator />
                    )}
                  </React.Fragment>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </nav>
    );
  }
);

TopNav.displayName = 'TopNav';

export { TopNav };
export type { TopNavProps };
