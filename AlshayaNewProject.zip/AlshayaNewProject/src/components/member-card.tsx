import * as React from 'react';
import { Mail, Phone, MapPin } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Card, CardContent, CardHeader } from './ui/card';
import { Avatar } from './ui/avatar';
import { Badge } from './ui/badge';

interface MemberCardProps {
  name: string;
  relation?: string;
  email?: string;
  phone?: string;
  location?: string;
  avatar?: string;
  status?: 'active' | 'pending' | 'inactive';
  gender?: 'male' | 'female';
  children?: number;
  onClick?: () => void;
  onEdit?: () => void;
  onDelete?: () => void;
  className?: string;
}

const MemberCard = React.forwardRef<HTMLDivElement, MemberCardProps>(
  (
    {
      name,
      relation,
      email,
      phone,
      location,
      avatar,
      status = 'active',
      gender,
      children = 0,
      onClick,
      onEdit,
      onDelete,
      className,
    },
    ref
  ) => {
    const statusColors = {
      active: 'success',
      pending: 'warning',
      inactive: 'neutral',
    } as const;

    const genderColor = gender === 'male' ? 'bg-blue-500/10 text-blue-400' : 'bg-pink-500/10 text-pink-400';

    return (
      <Card
        ref={ref}
        onClick={onClick}
        className={cn(
          'cursor-pointer hover:shadow-xl hover:border-cyan-500 transition-all',
          className
        )}
      >
        <CardHeader className="pb-3">
          <div className="flex items-start justify-between gap-4">
            <Avatar src={avatar} fallback={name} size="lg" />
            <Badge variant={statusColors[status]} size="sm">
              {status}
            </Badge>
          </div>
        </CardHeader>

        <CardContent className="space-y-3">
          <div>
            <h3 className="text-lg font-semibold text-text">{name}</h3>
            {relation && (
              <p className="text-sm text-text-muted">{relation}</p>
            )}
          </div>

          {gender && (
            <div className={cn('inline-block px-2 py-1 rounded text-xs font-medium', genderColor)}>
              {gender === 'male' ? 'Male' : 'Female'}
            </div>
          )}

          <div className="space-y-2 text-sm">
            {email && (
              <div className="flex items-center gap-2 text-text-muted hover:text-text transition-colors">
                <Mail className="h-4 w-4" />
                <a href={`mailto:${email}`} className="truncate">{email}</a>
              </div>
            )}
            {phone && (
              <div className="flex items-center gap-2 text-text-muted hover:text-text transition-colors">
                <Phone className="h-4 w-4" />
                <a href={`tel:${phone}`}>{phone}</a>
              </div>
            )}
            {location && (
              <div className="flex items-center gap-2 text-text-muted">
                <MapPin className="h-4 w-4" />
                <span className="truncate">{location}</span>
              </div>
            )}
          </div>

          {children > 0 && (
            <div className="text-xs text-text-muted">
              <strong>{children}</strong> {children === 1 ? 'child' : 'children'}
            </div>
          )}

          {(onEdit || onDelete) && (
            <div className="flex gap-2 pt-3 border-t-2 border-navy-light">
              {onEdit && (
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onEdit();
                  }}
                  className="flex-1 px-3 py-1.5 text-sm font-medium bg-cyan-500 text-navy rounded hover:bg-cyan-400 transition-colors"
                >
                  Edit
                </button>
              )}
              {onDelete && (
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onDelete();
                  }}
                  className="flex-1 px-3 py-1.5 text-sm font-medium border-2 border-red-600 text-red-400 rounded hover:bg-red-900/20 transition-colors"
                >
                  Delete
                </button>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    );
  }
);

MemberCard.displayName = 'MemberCard';

export { MemberCard };
export type { MemberCardProps };
