// Tree component TypeScript definitions

import type { FamilyMember } from '@/lib/types';

export interface TreeNode extends FamilyMember {
  children?: TreeNode[];
  expanded?: boolean;
  level?: number;
  _x?: number;
  _y?: number;
}

export interface D3TreeNode {
  x: number;
  y: number;
  data: TreeNode;
  parent: D3TreeNode | null;
  children?: D3TreeNode[];
  depth: number;
}

export interface TreeLink {
  source: D3TreeNode;
  target: D3TreeNode;
}

export type TreeLayout = 'vertical' | 'horizontal' | 'radial';

export type ColorMode = 'generation' | 'lineage' | 'gender';

export interface TreeDimensions {
  width: number;
  height: number;
}

export interface TreeTooltip {
  x: number;
  y: number;
  node: TreeNode | null;
}

export interface TreeSearchResult {
  nodeId: string;
  node: TreeNode;
  matchType: 'name' | 'id' | 'phone' | 'city';
  matchScore: number;
}

export interface TreeFilterOptions {
  generations?: number[];
  branches?: string[];
  genders?: ('Male' | 'Female')[];
  status?: string[];
  hasPhoto?: boolean;
  livingOnly?: boolean;
}

export interface ExportOptions {
  format: 'png' | 'svg' | 'json';
  width?: number;
  height?: number;
  scale?: number;
  backgroundColor?: string;
}

export interface TreeState {
  zoom: number;
  panX: number;
  panY: number;
  selectedNodeId?: string;
  highlightedNodeId?: string;
  hoveredNodeId?: string;
  searchQuery?: string;
  colorMode: ColorMode;
  layout: TreeLayout;
  filters: TreeFilterOptions;
}
