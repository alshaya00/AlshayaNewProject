'use client';

import React from 'react';
import { Layers, GitBranch, Users } from 'lucide-react';
import type { ColorMode } from './types';

interface ColorEntry {
  label: string;
  color: string;
  gradient?: [string, string];
}

interface TreeLegendProps {
  colorMode: ColorMode;
  generationColors?: Record<number, ColorEntry>;
  lineageColors?: ColorEntry[];
  genderColors?: Record<string, { color: string; label: string }>;
  branches?: { id: string; name: string }[];
  className?: string;
  position?: 'bottom-left' | 'bottom-right' | 'top-left' | 'top-right';
}

const defaultGenderColors = {
  Male: { color: '#3b82f6', label: 'ذكر' },
  Female: { color: '#ec4899', label: 'أنثى' },
};

/**
 * TreeLegend - Displays color legend for tree visualization
 * Shows generation, lineage, or gender color coding
 */
export const TreeLegend = React.memo(({
  colorMode,
  generationColors = {
    1: { label: 'الجيل 1', color: '#dc2626' },
    2: { label: 'الجيل 2', color: '#f59e0b' },
    3: { label: 'الجيل 3', color: '#10b981' },
    4: { label: 'الجيل 4', color: '#0ea5e9' },
    5: { label: 'الجيل 5', color: '#8b5cf6' },
    6: { label: 'الجيل 6', color: '#ec4899' },
    7: { label: 'الجيل 7', color: '#14b8a6' },
    8: { label: 'الجيل 8+', color: '#6b7280' },
  },
  lineageColors = [],
  genderColors = defaultGenderColors,
  branches = [],
  className = '',
  position = 'bottom-left',
}: TreeLegendProps) => {
  const positionClasses = {
    'bottom-left': 'bottom-4 left-4',
    'bottom-right': 'bottom-4 right-4',
    'top-left': 'top-4 left-4',
    'top-right': 'top-4 right-4',
  };

  return (
    <div className={`absolute ${positionClasses[position]} z-20 pointer-events-auto ${className}`}>
      <div className="bg-white/95 backdrop-blur-sm rounded-xl shadow-lg border p-4">
        {/* Header */}
        <p className="text-xs font-semibold text-gray-600 mb-3 flex items-center gap-1.5">
          {colorMode === 'generation' && (
            <>
              <Layers size={14} />
              مفتاح الأجيال
            </>
          )}
          {colorMode === 'lineage' && (
            <>
              <GitBranch size={14} />
              مفتاح السلالات
            </>
          )}
          {colorMode === 'gender' && (
            <>
              <Users size={14} />
              مفتاح النوع
            </>
          )}
        </p>

        {/* Generation Colors */}
        {colorMode === 'generation' && (
          <div className="flex flex-wrap gap-2">
            {Object.entries(generationColors).map(([gen, entry]) => (
              <div
                key={gen}
                className="flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium text-white shadow-sm hover:shadow-md transition-shadow"
                style={{
                  background: entry.gradient
                    ? `linear-gradient(135deg, ${entry.gradient[0]}, ${entry.gradient[1]})`
                    : entry.color,
                }}
              >
                <div className="w-2 h-2 bg-white/50 rounded-full" />
                {entry.label}
              </div>
            ))}
          </div>
        )}

        {/* Lineage Colors */}
        {colorMode === 'lineage' && (
          <div className="flex flex-wrap gap-2">
            {lineageColors.length > 0 ? (
              lineageColors.map((color, index) => (
                <div
                  key={index}
                  className="flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium text-white shadow-sm"
                  style={{
                    background: color.gradient
                      ? `linear-gradient(135deg, ${color.gradient[0]}, ${color.gradient[1]})`
                      : color.color,
                  }}
                >
                  <div className="w-2 h-2 bg-white/50 rounded-full" />
                  {branches[index]?.name || color.label}
                </div>
              ))
            ) : (
              <p className="text-xs text-gray-500">لا توجد بيانات سلالات</p>
            )}
          </div>
        )}

        {/* Gender Colors */}
        {colorMode === 'gender' && (
          <div className="flex flex-wrap gap-2">
            {Object.entries(genderColors).map(([gender, entry]) => (
              <div
                key={gender}
                className="flex items-center gap-2"
              >
                <div
                  className="w-4 h-4 rounded-full shadow-sm border-2 border-white"
                  style={{ backgroundColor: entry.color }}
                />
                <span className="text-xs font-medium text-gray-700">{entry.label}</span>
              </div>
            ))}
          </div>
        )}

        {/* Status indicators */}
        {colorMode === 'generation' && (
          <div className="mt-3 pt-3 border-t border-gray-200">
            <p className="text-xs font-semibold text-gray-600 mb-2">الحالة</p>
            <div className="flex gap-4">
              <div className="flex items-center gap-1.5">
                <div className="w-3 h-3 rounded-full bg-green-500" />
                <span className="text-xs text-gray-600">حي</span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="w-3 h-3 rounded-full bg-gray-400" />
                <span className="text-xs text-gray-600">متوفى</span>
              </div>
            </div>
          </div>
        )}

        {/* Relationship types */}
        <div className="mt-3 pt-3 border-t border-gray-200">
          <p className="text-xs font-semibold text-gray-600 mb-2">أنواع العلاقات</p>
          <div className="space-y-1.5">
            <div className="flex items-center gap-2">
              <svg className="w-6 h-6" viewBox="0 0 24 24">
                <line x1="12" y1="0" x2="12" y2="24" stroke="#3b82f6" strokeWidth="2" />
              </svg>
              <span className="text-xs text-gray-600">أب</span>
            </div>
            <div className="flex items-center gap-2">
              <svg className="w-6 h-6" viewBox="0 0 24 24">
                <line x1="12" y1="0" x2="12" y2="24" stroke="#ec4899" strokeWidth="2" />
              </svg>
              <span className="text-xs text-gray-600">أم</span>
            </div>
            <div className="flex items-center gap-2">
              <svg className="w-6 h-6" viewBox="0 0 24 24">
                <line
                  x1="12"
                  y1="0"
                  x2="12"
                  y2="24"
                  stroke="#f59e0b"
                  strokeWidth="2"
                  strokeDasharray="4 4"
                />
              </svg>
              <span className="text-xs text-gray-600">علاقة رضاعة</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
});

TreeLegend.displayName = 'TreeLegend';

/**
 * CompactTreeLegend - Minimal legend for constrained spaces
 */
interface CompactTreeLegendProps {
  colorMode: ColorMode;
  onlyShowStatus?: boolean;
}

export const CompactTreeLegend = React.memo(({
  colorMode,
  onlyShowStatus = false,
}: CompactTreeLegendProps) => {
  return (
    <div className="bg-white/90 rounded-lg px-3 py-2 text-xs">
      <div className="flex items-center gap-3">
        {!onlyShowStatus && (
          <>
            {colorMode === 'generation' && (
              <span className="flex items-center gap-1">
                <Layers size={12} />
                أجيال
              </span>
            )}
            {colorMode === 'lineage' && (
              <span className="flex items-center gap-1">
                <GitBranch size={12} />
                سلالات
              </span>
            )}
            {colorMode === 'gender' && (
              <span className="flex items-center gap-1">
                <Users size={12} />
                نوع
              </span>
            )}
            <div className="w-px h-4 bg-gray-300" />
          </>
        )}

        <div className="flex items-center gap-1.5">
          <div className="w-2 h-2 rounded-full bg-green-500" />
          <span>حي</span>
        </div>
        <div className="flex items-center gap-1.5">
          <div className="w-2 h-2 rounded-full bg-gray-400" />
          <span>متوفى</span>
        </div>
      </div>
    </div>
  );
});

CompactTreeLegend.displayName = 'CompactTreeLegend';
