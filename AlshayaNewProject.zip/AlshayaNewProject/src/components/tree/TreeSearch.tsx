'use client';

import React, { useState } from 'react';
import { Search, X, ChevronUp, ChevronDown } from 'lucide-react';
import type { FamilyMember } from '@/lib/types';
import { useTreeSearch } from './hooks/useTreeData';

interface TreeSearchProps {
  members: FamilyMember[];
  onResultSelect?: (member: FamilyMember) => void;
  onResultHighlight?: (memberId: string | null) => void;
  placeholder?: string;
  className?: string;
}

/**
 * TreeSearch - Search component for finding members in the tree
 */
export const TreeSearch = React.memo(({
  members,
  onResultSelect,
  onResultHighlight,
  placeholder = 'ابحث عن عضو...',
  className = '',
}: TreeSearchProps) => {
  const {
    searchQuery,
    setSearchQuery,
    searchResults,
    currentResult,
    selectedResultIndex,
    goToNextResult,
    goToPreviousResult,
    clearSearch,
    hasResults,
    resultCount,
  } = useTreeSearch(members);

  const [isOpen, setIsOpen] = useState(false);

  const handleSelect = (member: FamilyMember) => {
    onResultSelect?.(member);
    onResultHighlight?.(member.id);
  };

  const handleClear = () => {
    clearSearch();
    onResultHighlight?.(null);
    setIsOpen(false);
  };

  return (
    <div className={`relative ${className}`}>
      {/* Search input */}
      <div className="relative">
        <div className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">
          <Search size={18} />
        </div>

        <input
          type="text"
          value={searchQuery}
          onChange={(e) => {
            setSearchQuery(e.target.value);
            setIsOpen(true);
          }}
          onFocus={() => searchQuery && setIsOpen(true)}
          placeholder={placeholder}
          className="w-full pl-10 pr-10 py-2 text-sm border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
          dir="rtl"
        />

        {searchQuery && (
          <button
            onClick={handleClear}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
            aria-label="Clear search"
          >
            <X size={18} />
          </button>
        )}
      </div>

      {/* Results count */}
      {hasResults && searchQuery && (
        <div className="mt-1 px-2 text-xs text-gray-500">
          {resultCount} نتيجة {selectedResultIndex + 1} من {resultCount}
        </div>
      )}

      {/* Results dropdown */}
      {isOpen && hasResults && (
        <div className="absolute top-full left-0 right-0 mt-1 bg-white border border-gray-300 rounded-lg shadow-lg z-50 max-h-64 overflow-y-auto">
          <div className="divide-y">
            {searchResults.map((result, index) => (
              <button
                key={result.id}
                onClick={() => {
                  handleSelect(result);
                  setIsOpen(false);
                }}
                className={`w-full text-right px-4 py-2 hover:bg-indigo-50 transition-colors ${
                  selectedResultIndex === index ? 'bg-indigo-100' : ''
                }`}
              >
                <div className="font-medium text-sm text-gray-900">
                  {result.firstName}
                  {result.fatherName && ` بن ${result.fatherName}`}
                </div>
                <div className="text-xs text-gray-500 mt-0.5">
                  {result.fullNameAr && <div>{result.fullNameAr}</div>}
                  <div>ج{result.generation} • {result.id}</div>
                </div>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* No results message */}
      {isOpen && searchQuery && !hasResults && (
        <div className="absolute top-full left-0 right-0 mt-1 bg-white border border-gray-300 rounded-lg shadow-lg z-50 p-4 text-center">
          <p className="text-sm text-gray-500">لا توجد نتائج</p>
        </div>
      )}

      {/* Navigation buttons */}
      {currentResult && (
        <div className="mt-2 flex gap-1">
          <button
            onClick={goToPreviousResult}
            className="flex-1 py-1 px-2 text-xs bg-gray-100 hover:bg-gray-200 rounded transition-colors flex items-center justify-center gap-1"
            title="Previous result"
          >
            <ChevronUp size={14} />
          </button>
          <button
            onClick={goToNextResult}
            className="flex-1 py-1 px-2 text-xs bg-gray-100 hover:bg-gray-200 rounded transition-colors flex items-center justify-center gap-1"
            title="Next result"
          >
            <ChevronDown size={14} />
          </button>
        </div>
      )}
    </div>
  );
});

TreeSearch.displayName = 'TreeSearch';

/**
 * InlineTreeSearch - Compact search for embedding in tree controls
 */
interface InlineTreeSearchProps {
  members: FamilyMember[];
  onSearch?: (query: string) => void;
  onSelect?: (member: FamilyMember) => void;
}

export const InlineTreeSearch = React.memo(({
  members,
  onSearch,
  onSelect,
}: InlineTreeSearchProps) => {
  const [query, setQuery] = useState('');

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setQuery(value);
    onSearch?.(value);
  };

  return (
    <div className="relative">
      <input
        type="text"
        value={query}
        onChange={handleChange}
        placeholder="بحث..."
        className="w-full pl-8 pr-3 py-1.5 text-sm bg-white border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
        dir="rtl"
      />
      <Search size={16} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-400" />
      {query && (
        <button
          onClick={() => setQuery('')}
          className="absolute right-2.5 top-1/2 -translate-y-1/2"
        >
          <X size={16} className="text-gray-400 hover:text-gray-600" />
        </button>
      )}
    </div>
  );
});

InlineTreeSearch.displayName = 'InlineTreeSearch';
