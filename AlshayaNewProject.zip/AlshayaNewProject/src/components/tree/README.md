# Family Tree Visualization Engine

A complete, production-ready D3.js interactive family tree visualization system for the Alshaya family genealogy application.

## Features

### Core Visualization
- **Interactive D3.js Tree**: Full hierarchical family tree with smooth animations
- **Multiple Layouts**: Vertical, horizontal, and radial tree layouts
- **Zoom & Pan**: Mouse wheel zoom with smooth constraints (0.1x to 3x)
- **Touch Support**: Full touch gesture support for mobile devices
- **Responsive Design**: Automatically adapts to container size and mobile screens

### Node Display
- **Photo Avatars**: Display family member photos with fallback to initials
- **Generation Badges**: Color-coded generation indicators
- **Status Indicators**: Visual markers for living/deceased members
- **Children Count**: Badge showing number of children
- **Hover Effects**: Enhanced visual feedback on interaction
- **Click Selection**: Select nodes to view detailed information

### Relationship Visualization
- **Father-Child Connections**: Solid primary color lines
- **Mother-Child Connections**: Solid secondary color lines
- **Milk Kinship**: Dashed orange lines (علاقات الرضاعة)
- **Orthogonal Routing**: Clean, organized connection paths
- **Bezier Curves**: Optional smooth curved connections
- **Connection Dots**: Visual anchors at connection points

### Color Modes
- **Generation-Based**: Color by generation level (8 distinct colors)
- **Lineage-Based**: Color by generation 2 branch family
- **Gender-Based**: Color by male (blue) / female (pink)
- **Custom Gradients**: Beautiful gradient fills for visual depth

### Interactive Controls
- **Zoom Controls**: In/out/reset/fit-to-screen buttons
- **Layout Switcher**: Toggle between vertical/horizontal layouts
- **Color Mode Switcher**: Toggle between generation/lineage/gender coloring
- **Search Functionality**: Fuzzy search with Arabic support
- **Filter Panel**: Generation, gender, status filtering
- **Export Options**: PNG/SVG/JSON export formats
- **Fullscreen Mode**: Maximize visualization

### Data Management
- **Hierarchical Transform**: Converts flat member data to tree structure
- **Incremental Loading**: Virtual rendering for 10,000+ node trees
- **Search Highlighting**: Visual highlight of search results
- **Node Expansion**: Collapse/expand family branches
- **Path Calculation**: Get ancestor/descendant chains

## Architecture

### Components

#### `FamilyTree.tsx`
Main container component that orchestrates the entire visualization.
```tsx
<FamilyTree
  members={familyMembers}
  onSelectMember={(member) => console.log(member)}
  highlightedId="member-id"
  currentUserId="current-user-id"
  height={700}
  showControls={true}
  showLegend={true}
  defaultLayout="vertical"
  defaultColorMode="generation"
/>
```

#### `TreeNode.tsx`
Individual node rendering with avatar, name, and metadata.
- Photo thumbnail or initials
- Name display (Arabic primary, English secondary)
- Generation badge
- Children count indicator
- Status indicator (living/deceased)

#### `TreeLink.tsx`
Connection lines between parent and child nodes.
- Multiple routing styles: orthogonal, bezier, straight
- Relationship type styling: father, mother, milk-kinship
- Animated drawing effects
- Depth shadows for visual hierarchy

#### `TreeControls.tsx`
Complete control panel UI with:
- Zoom controls (in/out/reset/fit)
- Layout selector
- Color mode switcher
- Search interface
- Filter panel
- Export options
- Fullscreen toggle

#### `TreeLegend.tsx`
Color legend showing:
- Generation color mapping
- Lineage branch colors
- Gender indicators
- Relationship types
- Status indicators

#### `TreeSearch.tsx`
Search and filtering with:
- Real-time search results
- Fuzzy matching with Arabic support
- Result navigation
- Highlight on selection

#### `TreeMiniMap.tsx`
Overview map showing:
- Entire tree at thumbnail scale
- Viewport indicator rectangle
- Click-to-navigate functionality
- Zoom percentage display

### Hooks

#### `useTreeData()`
Manages tree data fetching and transformation.
```tsx
const {
  treeData,      // Hierarchical tree structure
  members,       // Flat array of members
  memberMap,     // Map for quick lookup
  loading,       // Loading state
  error,         // Error state
  refetch,       // Refetch function
  getMemberById,
  getDescendants,
} = useTreeData({ memberId: 'branch-head' });
```

#### `useTreeZoom()`
Handles D3 zoom behavior.
```tsx
const {
  currentZoom,
  zoomIn,
  zoomOut,
  resetZoom,
  fitToScreen,
  zoomToNode,
  panToPoint,
} = useTreeZoom(svgRef, gRef, nodes);
```

#### `useTreeLayout()`
Calculates node positions and layout.
```tsx
const {
  nodes,
  links,
  bounds,
  dimensions,
  root,
  leaves,
  getNodeById,
  getPathToNode,
  getSiblings,
  getChildren,
} = useTreeLayout(treeData, 'vertical');
```

### Utilities

#### `tree-helpers.ts`
Core utility functions:

- **Data Transformation**
  - `buildTreeHierarchy()` - Convert flat to hierarchical
  - `filterTreeNodes()` - Apply filters to nodes
  - `searchTreeNodes()` - Fuzzy search with scoring

- **Layout Calculation**
  - `calculateTreeLayout()` - Generate node positions
  - `calculateGenerationGap()` - Calculate spacing
  - `calculateNodesBounds()` - Get tree dimensions
  - `calculateFitTransform()` - Auto-zoom to fit

- **Path Generation**
  - `generateLinkPath()` - Orthogonal SVG paths
  - `generateBezierPath()` - Smooth curved paths

- **Graph Operations**
  - `getAncestors()` - Get parent chain
  - `getDescendants()` - Get all children
  - `getNodePath()` - Path from root to node
  - `wouldCreateCycle()` - Cycle detection

- **Export Functions**
  - `exportTreeAsSVG()` - SVG string export
  - `exportTreeAsPNG()` - PNG image export
  - `exportTreeAsJSON()` - JSON data export

## Usage Examples

### Basic Implementation
```tsx
import { FamilyTree } from '@/components/tree';
import type { FamilyMember } from '@/lib/types';

export default function FamilyTreePage() {
  const [members, setMembers] = useState<FamilyMember[]>([]);

  useEffect(() => {
    fetch('/api/family-members')
      .then(res => res.json())
      .then(setMembers);
  }, []);

  return (
    <FamilyTree
      members={members}
      onSelectMember={(member) => console.log('Selected:', member)}
      height={700}
    />
  );
}
```

### With Search and Selection
```tsx
import { FamilyTree, TreeSearch } from '@/components/tree';

export default function AdvancedFamilyTree() {
  const [selected, setSelected] = useState<FamilyMember | null>(null);
  const [search, setSearch] = useState('');

  return (
    <div className="space-y-4">
      <TreeSearch
        members={members}
        onResultSelect={setSelected}
      />

      <FamilyTree
        members={members}
        onSelectMember={setSelected}
        highlightedId={selected?.id}
      />

      {selected && (
        <MemberDetails member={selected} />
      )}
    </div>
  );
}
```

### Custom Colors
```tsx
const customColors = {
  1: {
    primary: '#1f2937',
    secondary: '#9ca3af',
    gradient: ['#1f2937', '#111827'] as [string, string],
  },
  // ... more generations
};

// Modify GENERATION_COLORS in FamilyTree.tsx
```

## Performance Optimization

### For Large Trees (10,000+ nodes)
1. **Use Incremental Loading**
   ```tsx
   const { visibleNodes, toggleNode, expandAll } = useIncrementalTreeData();
   ```

2. **Virtual Rendering**
   - Only render visible nodes within viewport
   - Implement node virtualization for huge datasets

3. **Memoization**
   - Components use React.memo for expensive calculations
   - Hooks cache computed values with useMemo

4. **Lazy Loading**
   - Fetch branch data on demand
   - Stream nodes for initial render

### Mobile Optimization
- Responsive node sizes
- Touch-friendly controls
- Reduced shadow/filter effects
- Optimized initial zoom level

## Type Definitions

All TypeScript types are defined in `types.ts`:

```typescript
interface TreeNode extends FamilyMember {
  children?: TreeNode[];
  expanded?: boolean;
  level?: number;
}

type TreeLayout = 'vertical' | 'horizontal' | 'radial';
type ColorMode = 'generation' | 'lineage' | 'gender';

interface TreeFilterOptions {
  generations?: number[];
  branches?: string[];
  genders?: ('Male' | 'Female')[];
  status?: string[];
  hasPhoto?: boolean;
  livingOnly?: boolean;
}
```

## Browser Support

- Chrome/Edge 90+
- Firefox 88+
- Safari 14+
- Mobile Safari (iOS 14+)
- Chrome Mobile (Android 5+)

## Dependencies

- `d3`: ^7.8.0 - Graph visualization and layout
- `react`: ^18.0.0 - UI framework
- `next`: ^14.0.0 - React framework
- `lucide-react`: ^latest - Icons

## Accessibility

- Keyboard navigation support
- ARIA labels on all interactive elements
- Arabic (RTL) text support
- High contrast mode compatible
- Screen reader friendly

## Future Enhancements

- [ ] Animated tree transitions
- [ ] Collapsible generation groups
- [ ] Print-optimized layout
- [ ] Advanced filtering UI
- [ ] Timeline view (generations over time)
- [ ] Comparison view (multiple branches)
- [ ] Integration with family stories/journals
- [ ] Custom node templates
- [ ] Data import/export enhancements
- [ ] Real-time collaboration features

## Troubleshooting

### Tree not rendering
- Check if `members` array is populated
- Verify SVG ref is properly connected
- Check browser console for D3 errors

### Performance issues
- Reduce node count with filters
- Implement virtual rendering for large trees
- Disable animations on mobile
- Use simpler layout modes

### Styling issues
- Verify Tailwind CSS is properly configured
- Check for CSS conflicts with parent components
- Ensure SVG filters are loading
- Test in different browsers

## License

Part of the Alshaya Family Tree application
