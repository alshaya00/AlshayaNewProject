// Custom hook for D3 zoom behavior

import { useEffect, useRef, useCallback, useState } from 'react';
import * as d3 from 'd3';
import type { D3TreeNode } from '../types';

interface UseTreeZoomOptions {
  minZoom?: number;
  maxZoom?: number;
  enableWheel?: boolean;
  enablePan?: boolean;
  enableDblClick?: boolean;
}

export function useTreeZoom(
  svgRef: React.RefObject<SVGSVGElement>,
  gRef: React.RefObject<SVGGElement>,
  nodes: D3TreeNode[] = [],
  options: UseTreeZoomOptions = {}
) {
  const {
    minZoom = 0.1,
    maxZoom = 3,
    enableWheel = true,
    enablePan = true,
    enableDblClick = true
  } = options;

  const zoomRef = useRef<d3.ZoomBehavior<SVGSVGElement, unknown> | null>(null);
  const [currentZoom, setCurrentZoom] = useState(1);
  const [panX, setPanX] = useState(0);
  const [panY, setPanY] = useState(0);

  // Initialize zoom behavior
  useEffect(() => {
    if (!svgRef.current || !gRef.current) return;

    const svg = d3.select(svgRef.current);
    const g = d3.select(gRef.current);

    // Create zoom behavior
    const zoom = d3.zoom<SVGSVGElement, unknown>()
      .scaleExtent([minZoom, maxZoom]);

    if (enablePan) {
      zoom.on('zoom', (event) => {
        g.attr('transform', event.transform);
        setCurrentZoom(event.transform.k);
        setPanX(event.transform.x);
        setPanY(event.transform.y);
      });
    }

    zoomRef.current = zoom;
    svg.call(zoom);

    // Set initial transform
    const initialTransform = d3.zoomIdentity.translate(400, 100).scale(0.7);
    svg.call(zoom.transform, initialTransform);

    return () => {
      svg.on('.zoom', null);
    };
  }, [minZoom, maxZoom, enablePan]);

  // Zoom in
  const zoomIn = useCallback(() => {
    if (!svgRef.current || !zoomRef.current) return;
    const svg = d3.select(svgRef.current);
    svg.transition().duration(300).call(zoomRef.current.scaleBy, 1.3);
  }, []);

  // Zoom out
  const zoomOut = useCallback(() => {
    if (!svgRef.current || !zoomRef.current) return;
    const svg = d3.select(svgRef.current);
    svg.transition().duration(300).call(zoomRef.current.scaleBy, 0.7);
  }, []);

  // Reset zoom and pan
  const resetZoom = useCallback(() => {
    if (!svgRef.current || !zoomRef.current) return;
    const svg = d3.select(svgRef.current);
    const resetTransform = d3.zoomIdentity.translate(400, 100).scale(0.7);
    svg.transition().duration(500).call(zoomRef.current.transform, resetTransform);
  }, []);

  // Fit to screen
  const fitToScreen = useCallback((viewportWidth: number, viewportHeight: number) => {
    if (!svgRef.current || !zoomRef.current || nodes.length === 0) return;

    let minX = Infinity,
      maxX = -Infinity,
      minY = Infinity,
      maxY = -Infinity;

    nodes.forEach(node => {
      minX = Math.min(minX, node.x - 80);
      maxX = Math.max(maxX, node.x + 80);
      minY = Math.min(minY, node.y - 50);
      maxY = Math.max(maxY, node.y + 50);
    });

    const treeWidth = maxX - minX;
    const treeHeight = maxY - minY;
    const scale = Math.min(
      (viewportWidth - 100) / treeWidth,
      (viewportHeight - 150) / treeHeight,
      1
    ) * 0.9;

    const centerX = (minX + maxX) / 2;
    const centerY = (minY + maxY) / 2;

    const svg = d3.select(svgRef.current);
    const fitTransform = d3.zoomIdentity
      .translate(viewportWidth / 2 - centerX * scale, viewportHeight / 2 - centerY * scale)
      .scale(scale);

    svg.transition().duration(500).call(zoomRef.current.transform, fitTransform);
  }, [nodes]);

  // Zoom to node
  const zoomToNode = useCallback(
    (node: D3TreeNode, viewportWidth: number, viewportHeight: number, scale: number = 1.5) => {
      if (!svgRef.current || !zoomRef.current) return;

      const svg = d3.select(svgRef.current);
      const zoomTransform = d3.zoomIdentity
        .translate(viewportWidth / 2 - node.x * scale, viewportHeight / 2 - node.y * scale)
        .scale(scale);

      svg.transition().duration(500).call(zoomRef.current.transform, zoomTransform);
    },
    []
  );

  // Pan to point
  const panToPoint = useCallback((x: number, y: number, duration: number = 300) => {
    if (!svgRef.current || !zoomRef.current) return;

    const svg = d3.select(svgRef.current);
    const currentTransform = d3.zoomTransform(svgRef.current);
    const newTransform = d3.zoomIdentity
      .translate(x, y)
      .scale(currentTransform.k);

    svg.transition().duration(duration).call(zoomRef.current.transform, newTransform);
  }, []);

  // Get current transform
  const getTransform = useCallback((): d3.ZoomTransform | null => {
    if (!svgRef.current) return null;
    return d3.zoomTransform(svgRef.current);
  }, []);

  // Set transform directly
  const setTransform = useCallback((transform: d3.ZoomTransform, duration: number = 300) => {
    if (!svgRef.current || !zoomRef.current) return;
    const svg = d3.select(svgRef.current);
    svg.transition().duration(duration).call(zoomRef.current.transform, transform);
  }, []);

  // Double-click to zoom
  useEffect(() => {
    if (!svgRef.current || !enableDblClick) return;

    const handleDblClick = (event: MouseEvent) => {
      if (!zoomRef.current) return;

      const svg = d3.select(svgRef.current!);
      const zoomBy = event.shiftKey ? 0.5 : 2;
      svg.transition().duration(300).call(zoomRef.current.scaleBy, zoomBy);
    };

    svgRef.current.addEventListener('dblclick', handleDblClick);
    return () => {
      svgRef.current?.removeEventListener('dblclick', handleDblClick);
    };
  }, [enableDblClick]);

  return {
    currentZoom,
    panX,
    panY,
    zoomIn,
    zoomOut,
    resetZoom,
    fitToScreen,
    zoomToNode,
    panToPoint,
    getTransform,
    setTransform,
  };
}

/**
 * Hook for synchronized zoom across multiple views
 */
export function useSyncedZoom(
  primarySvgRef: React.RefObject<SVGSVGElement>,
  secondarySvgRefs: React.RefObject<SVGSVGElement>[] = []
) {
  const primaryZoomRef = useRef<d3.ZoomBehavior<SVGSVGElement, unknown> | null>(null);
  const secondaryZoomRefs = useRef<d3.ZoomBehavior<SVGSVGElement, unknown>[]>([]);

  useEffect(() => {
    if (!primarySvgRef.current) return;

    const svg = d3.select(primarySvgRef.current);

    const zoom = d3.zoom<SVGSVGElement, unknown>()
      .scaleExtent([0.1, 3])
      .on('zoom', (event) => {
        // Update primary
        svg.select('g').attr('transform', event.transform);

        // Update secondaries
        secondarySvgRefs.forEach(ref => {
          if (ref.current) {
            d3.select(ref.current)
              .select('g')
              .attr('transform', event.transform);
          }
        });
      });

    primaryZoomRef.current = zoom;
    svg.call(zoom);

    return () => {
      svg.on('.zoom', null);
    };
  }, [secondarySvgRefs]);

  return {
    primaryZoomRef,
  };
}
