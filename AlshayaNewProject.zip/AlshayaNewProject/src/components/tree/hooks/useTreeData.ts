// Custom hook for fetching and managing tree data

import { useEffect, useState, useCallback, useMemo } from 'react';
import type { FamilyMember } from '@/lib/types';
import type { TreeNode } from '../types';
import { buildTreeHierarchy } from '../utils/tree-helpers';

interface UseTreeDataOptions {
  memberId?: string;
  includeDescendantsOnly?: boolean;
  cacheTime?: number;
}

export function useTreeData(options: UseTreeDataOptions = {}) {
  const [treeData, setTreeData] = useState<TreeNode | null>(null);
  const [members, setMembers] = useState<FamilyMember[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  // Fetch tree data from API
  const fetchTreeData = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);

      const url = options.memberId
        ? `/api/family-members?branchHeadId=${options.memberId}`
        : '/api/family-members';

      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        throw new Error(`Failed to fetch tree data: ${response.statusText}`);
      }

      const data = await response.json();
      const memberArray = Array.isArray(data) ? data : data.members || [];

      setMembers(memberArray);

      // Build hierarchical tree
      const root = buildTreeHierarchy(memberArray, options.memberId);
      setTreeData(root);
    } catch (err) {
      const error = err instanceof Error ? err : new Error('Unknown error occurred');
      setError(error);
      console.error('Error fetching tree data:', error);
    } finally {
      setLoading(false);
    }
  }, [options.memberId]);

  // Fetch data on mount
  useEffect(() => {
    fetchTreeData();
  }, [fetchTreeData]);

  // Get member by ID
  const getMemberById = useCallback((id: string): FamilyMember | undefined => {
    return members.find(m => m.id === id);
  }, [members]);

  // Get descendants of a member
  const getDescendants = useCallback((memberId: string): FamilyMember[] => {
    const descendants: FamilyMember[] = [];
    const memberMap = new Map(members.map(m => [m.id, m]));

    const findDescendants = (id: string) => {
      const children = members.filter(m => m.fatherId === id);
      children.forEach(child => {
        descendants.push(child);
        findDescendants(child.id);
      });
    };

    findDescendants(memberId);
    return descendants;
  }, [members]);

  // Refetch data
  const refetch = useCallback(async () => {
    await fetchTreeData();
  }, [fetchTreeData]);

  // Memoized members map for quick lookup
  const memberMap = useMemo(() => {
    const map = new Map<string, FamilyMember>();
    members.forEach(member => {
      map.set(member.id, member);
    });
    return map;
  }, [members]);

  return {
    treeData,
    members,
    memberMap,
    loading,
    error,
    refetch,
    getMemberById,
    getDescendants,
  };
}

/**
 * Hook for incremental tree loading (virtual rendering for large trees)
 */
export function useIncrementalTreeData(options: UseTreeDataOptions = {}) {
  const { treeData, members, memberMap, loading, error, refetch } = useTreeData(options);
  const [expandedNodes, setExpandedNodes] = useState<Set<string>>(new Set());
  const [visibleNodes, setVisibleNodes] = useState<TreeNode[]>([]);

  // Toggle node expansion
  const toggleNode = useCallback((nodeId: string) => {
    setExpandedNodes(prev => {
      const next = new Set(prev);
      if (next.has(nodeId)) {
        next.delete(nodeId);
      } else {
        next.add(nodeId);
      }
      return next;
    });
  }, []);

  // Expand all nodes
  const expandAll = useCallback(() => {
    if (!treeData) return;

    const allNodeIds = new Set<string>();
    const traverse = (node: TreeNode) => {
      allNodeIds.add(node.id);
      if (node.children) {
        node.children.forEach(traverse);
      }
    };

    traverse(treeData);
    setExpandedNodes(allNodeIds);
  }, [treeData]);

  // Collapse all nodes except root
  const collapseAll = useCallback(() => {
    setExpandedNodes(new Set());
  }, []);

  // Calculate visible nodes based on expanded state
  useEffect(() => {
    if (!treeData) {
      setVisibleNodes([]);
      return;
    }

    const visible: TreeNode[] = [];
    const traverse = (node: TreeNode) => {
      visible.push(node);
      if (expandedNodes.has(node.id) && node.children) {
        node.children.forEach(traverse);
      }
    };

    traverse(treeData);
    setVisibleNodes(visible);
  }, [treeData, expandedNodes]);

  return {
    treeData,
    members,
    memberMap,
    loading,
    error,
    refetch,
    expandedNodes,
    visibleNodes,
    toggleNode,
    expandAll,
    collapseAll,
    isExpanded: (nodeId: string) => expandedNodes.has(nodeId),
  };
}

/**
 * Hook for tree search functionality
 */
export function useTreeSearch(members: FamilyMember[]) {
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<FamilyMember[]>([]);
  const [selectedResultIndex, setSelectedResultIndex] = useState(0);

  // Perform search
  useEffect(() => {
    if (!searchQuery.trim()) {
      setSearchResults([]);
      setSelectedResultIndex(0);
      return;
    }

    const lowerQuery = searchQuery.toLowerCase();
    const results = members.filter(member => {
      const firstName = member.firstName.toLowerCase();
      const fullNameAr = member.fullNameAr?.toLowerCase() || '';
      const fullNameEn = member.fullNameEn?.toLowerCase() || '';
      const id = member.id.toLowerCase();

      return (
        firstName.includes(lowerQuery) ||
        fullNameAr.includes(lowerQuery) ||
        fullNameEn.includes(lowerQuery) ||
        id.includes(lowerQuery)
      );
    });

    setSearchResults(results);
    setSelectedResultIndex(0);
  }, [searchQuery, members]);

  // Get current selected result
  const currentResult = useMemo(() => {
    return searchResults[selectedResultIndex] || null;
  }, [searchResults, selectedResultIndex]);

  // Navigate results
  const goToNextResult = useCallback(() => {
    if (searchResults.length === 0) return;
    setSelectedResultIndex(prev => (prev + 1) % searchResults.length);
  }, [searchResults]);

  const goToPreviousResult = useCallback(() => {
    if (searchResults.length === 0) return;
    setSelectedResultIndex(prev => (prev - 1 + searchResults.length) % searchResults.length);
  }, [searchResults]);

  // Clear search
  const clearSearch = useCallback(() => {
    setSearchQuery('');
    setSearchResults([]);
    setSelectedResultIndex(0);
  }, []);

  return {
    searchQuery,
    setSearchQuery,
    searchResults,
    currentResult,
    selectedResultIndex,
    goToNextResult,
    goToPreviousResult,
    clearSearch,
    hasResults: searchResults.length > 0,
    resultCount: searchResults.length,
  };
}
