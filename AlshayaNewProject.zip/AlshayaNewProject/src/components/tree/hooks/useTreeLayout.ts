// Custom hook for tree layout calculations

import { useMemo, useCallback } from 'react';
import * as d3 from 'd3';
import type { TreeNode, D3TreeNode, TreeLink, TreeLayout } from '../types';
import { calculateTreeLayout } from '../utils/tree-helpers';

interface UseTreeLayoutOptions {
  isMobile?: boolean;
  padding?: number;
  nodeSize?: number;
  generationGap?: number;
}

export function useTreeLayout(
  treeData: TreeNode | null,
  layout: TreeLayout = 'vertical',
  options: UseTreeLayoutOptions = {}
) {
  const { isMobile = false, nodeSize = 110, generationGap = 160 } = options;

  // Calculate nodes and links
  const { nodes, links } = useMemo(() => {
    if (!treeData) return { nodes: [], links: [] };

    return calculateTreeLayout(treeData, layout, isMobile);
  }, [treeData, layout, isMobile]);

  // Calculate bounds
  const bounds = useMemo(() => {
    if (nodes.length === 0) {
      return { minX: 0, maxX: 0, minY: 0, maxY: 0 };
    }

    let minX = Infinity,
      maxX = -Infinity,
      minY = Infinity,
      maxY = -Infinity;

    nodes.forEach(node => {
      const padding = 80;
      minX = Math.min(minX, node.x - padding);
      maxX = Math.max(maxX, node.x + padding);
      minY = Math.min(minY, node.y - 50);
      maxY = Math.max(maxY, node.y + 50);
    });

    return { minX, maxX, minY, maxY };
  }, [nodes]);

  // Calculate dimensions
  const dimensions = useMemo(() => {
    return {
      width: bounds.maxX - bounds.minX,
      height: bounds.maxY - bounds.minY,
      minX: bounds.minX,
      maxX: bounds.maxX,
      minY: bounds.minY,
      maxY: bounds.maxY,
    };
  }, [bounds]);

  // Find root node
  const root = useMemo(() => {
    return nodes.find(n => !n.parent) || null;
  }, [nodes]);

  // Find leaf nodes
  const leaves = useMemo(() => {
    return nodes.filter(n => !n.children || n.children.length === 0);
  }, [nodes]);

  // Get node by ID
  const getNodeById = useCallback(
    (id: string): D3TreeNode | undefined => {
      return nodes.find(n => n.data.id === id);
    },
    [nodes]
  );

  // Get path from root to node
  const getPathToNode = useCallback(
    (nodeId: string): D3TreeNode[] => {
      const node = getNodeById(nodeId);
      if (!node) return [];

      const path: D3TreeNode[] = [];
      let current: D3TreeNode | null = node;

      while (current) {
        path.unshift(current);
        current = current.parent;
      }

      return path;
    },
    [getNodeById]
  );

  // Check for node overlap
  const hasOverlap = useCallback((): boolean => {
    const minDistance = isMobile ? 80 : 110;

    for (let i = 0; i < nodes.length; i++) {
      for (let j = i + 1; j < nodes.length; j++) {
        const dx = nodes[i].x - nodes[j].x;
        const dy = nodes[i].y - nodes[j].y;
        const distance = Math.sqrt(dx * dx + dy * dy);

        if (distance < minDistance) {
          return true;
        }
      }
    }

    return false;
  }, [nodes, isMobile]);

  // Adjust layout to prevent overlap
  const adjustLayout = useCallback((): D3TreeNode[] => {
    if (!hasOverlap()) return nodes;

    const adjusted = JSON.parse(JSON.stringify(nodes)) as D3TreeNode[];
    const minDistance = isMobile ? 80 : 110;
    const maxIterations = 10;
    let iteration = 0;

    while (hasOverlap() && iteration < maxIterations) {
      for (let i = 0; i < adjusted.length; i++) {
        for (let j = i + 1; j < adjusted.length; j++) {
          const dx = adjusted[i].x - adjusted[j].x;
          const dy = adjusted[i].y - adjusted[j].y;
          const distance = Math.sqrt(dx * dx + dy * dy);

          if (distance < minDistance) {
            const angle = Math.atan2(dy, dx);
            const push = (minDistance - distance) / 2 + 1;

            adjusted[i].x += Math.cos(angle) * push;
            adjusted[j].x -= Math.cos(angle) * push;
          }
        }
      }
      iteration++;
    }

    return adjusted;
  }, [nodes, isMobile, hasOverlap]);

  // Get sibling nodes
  const getSiblings = useCallback(
    (nodeId: string): D3TreeNode[] => {
      const node = getNodeById(nodeId);
      if (!node || !node.parent) return [];

      const parent = node.parent;
      return (parent.children || []).filter(n => n.data.id !== nodeId);
    },
    [getNodeById]
  );

  // Get children nodes
  const getChildren = useCallback(
    (nodeId: string): D3TreeNode[] => {
      const node = getNodeById(nodeId);
      if (!node) return [];

      return node.children || [];
    },
    [getNodeById]
  );

  // Calculate center point
  const centerPoint = useMemo(() => {
    return {
      x: (bounds.minX + bounds.maxX) / 2,
      y: (bounds.minY + bounds.maxY) / 2,
    };
  }, [bounds]);

  return {
    nodes,
    links,
    bounds,
    dimensions,
    root,
    leaves,
    centerPoint,
    hasOverlap: hasOverlap(),
    getNodeById,
    getPathToNode,
    getSiblings,
    getChildren,
    adjustLayout,
  };
}

/**
 * Hook for layout switching with animation
 */
export function useAnimatedLayout(
  treeData: TreeNode | null,
  currentLayout: TreeLayout,
  isMobile: boolean = false
) {
  const { nodes: verticalNodes, links: verticalLinks } = useMemo(() => {
    if (!treeData) return { nodes: [], links: [] };
    return calculateTreeLayout(treeData, 'vertical', isMobile);
  }, [treeData, isMobile]);

  const { nodes: horizontalNodes, links: horizontalLinks } = useMemo(() => {
    if (!treeData) return { nodes: [], links: [] };
    return calculateTreeLayout(treeData, 'horizontal', isMobile);
  }, [treeData, isMobile]);

  // Get current layout nodes and links
  const { nodes, links } = useMemo(() => {
    if (currentLayout === 'vertical') {
      return { nodes: verticalNodes, links: verticalLinks };
    } else if (currentLayout === 'horizontal') {
      return { nodes: horizontalNodes, links: horizontalLinks };
    }
    return { nodes: verticalNodes, links: verticalLinks };
  }, [currentLayout, verticalNodes, verticalLinks, horizontalNodes, horizontalLinks]);

  return {
    nodes,
    links,
    availableLayouts: ['vertical', 'horizontal', 'radial'] as const,
  };
}

/**
 * Hook for hierarchical layout with proper generation spacing
 */
export function useHierarchicalLayout(
  treeData: TreeNode | null,
  isMobile: boolean = false
) {
  const layout = useTreeLayout(treeData, 'vertical', { isMobile });
  const { nodes } = layout;

  // Group nodes by generation
  const nodesByGeneration = useMemo(() => {
    const groups = new Map<number, D3TreeNode[]>();

    nodes.forEach(node => {
      const gen = node.data.generation;
      if (!groups.has(gen)) {
        groups.set(gen, []);
      }
      groups.get(gen)!.push(node);
    });

    return groups;
  }, [nodes]);

  // Calculate generation heights
  const generationHeights = useMemo(() => {
    const heights = new Map<number, { minY: number; maxY: number }>();

    nodesByGeneration.forEach((nodesInGen, gen) => {
      let minY = Infinity,
        maxY = -Infinity;

      nodesInGen.forEach(node => {
        minY = Math.min(minY, node.y - 50);
        maxY = Math.max(maxY, node.y + 50);
      });

      heights.set(gen, { minY, maxY });
    });

    return heights;
  }, [nodesByGeneration]);

  return {
    ...layout,
    nodesByGeneration,
    generationHeights,
  };
}
