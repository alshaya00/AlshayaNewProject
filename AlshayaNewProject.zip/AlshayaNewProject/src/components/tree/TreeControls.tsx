'use client';

import React, { useState } from 'react';
import {
  ZoomIn,
  ZoomOut,
  Home,
  Maximize2,
  Search,
  Filter,
  Download,
  Maximize,
  Minimize,
  Eye,
  GitBranch,
} from 'lucide-react';
import type { TreeLayout, ColorMode, TreeFilterOptions, ExportOptions } from './types';

interface TreeControlsProps {
  onZoomIn?: () => void;
  onZoomOut?: () => void;
  onResetView?: () => void;
  onFitToScreen?: () => void;
  onSearch?: (query: string) => void;
  onFilterChange?: (filters: TreeFilterOptions) => void;
  onLayoutChange?: (layout: TreeLayout) => void;
  onColorModeChange?: (mode: ColorMode) => void;
  onExport?: (options: ExportOptions) => void;
  onFullscreen?: () => void;
  currentZoom?: number;
  currentLayout?: TreeLayout;
  currentColorMode?: ColorMode;
  isFullscreen?: boolean;
  isLoading?: boolean;
}

/**
 * TreeControls - Control panel for tree visualization
 * Includes zoom, search, filters, layout, and export options
 */
export const TreeControls = React.memo(({
  onZoomIn,
  onZoomOut,
  onResetView,
  onFitToScreen,
  onSearch,
  onFilterChange,
  onLayoutChange,
  onColorModeChange,
  onExport,
  onFullscreen,
  currentZoom = 1,
  currentLayout = 'vertical',
  currentColorMode = 'generation',
  isFullscreen = false,
  isLoading = false,
}: TreeControlsProps) => {
  const [showFilters, setShowFilters] = useState(false);
  const [showExport, setShowExport] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [filters, setFilters] = useState<TreeFilterOptions>({
    livingOnly: false,
  });

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    const query = e.target.value;
    setSearchQuery(query);
    onSearch?.(query);
  };

  const handleFilterChange = (key: keyof TreeFilterOptions, value: any) => {
    const newFilters = { ...filters, [key]: value };
    setFilters(newFilters);
    onFilterChange?.(newFilters);
  };

  const handleExport = (format: 'png' | 'svg' | 'json') => {
    onExport?.({
      format,
      scale: 2,
      backgroundColor: '#ffffff',
    });
    setShowExport(false);
  };

  return (
    <div className="tree-controls absolute top-0 left-0 right-0 bottom-0 pointer-events-none z-20">
      {/* Top toolbar */}
      <div className="absolute top-4 left-4 flex gap-2 items-start pointer-events-auto">
        {/* Zoom controls */}
        <div className="bg-white/95 backdrop-blur-sm rounded-xl shadow-lg border p-2 flex flex-col gap-1">
          <button
            onClick={onZoomIn}
            disabled={isLoading}
            className="p-2.5 hover:bg-green-50 rounded-lg transition-all duration-200 active:scale-95 disabled:opacity-50"
            title="تكبير"
            aria-label="Zoom in"
          >
            <ZoomIn size={20} className="text-gray-600" />
          </button>
          <button
            onClick={onZoomOut}
            disabled={isLoading}
            className="p-2.5 hover:bg-green-50 rounded-lg transition-all duration-200 active:scale-95 disabled:opacity-50"
            title="تصغير"
            aria-label="Zoom out"
          >
            <ZoomOut size={20} className="text-gray-600" />
          </button>
          <div className="w-full h-px bg-gray-200" />
          <button
            onClick={onResetView}
            disabled={isLoading}
            className="p-2.5 hover:bg-blue-50 rounded-lg transition-all duration-200 active:scale-95 disabled:opacity-50"
            title="إعادة ضبط"
            aria-label="Reset view"
          >
            <Home size={20} className="text-gray-600" />
          </button>
          <button
            onClick={onFitToScreen}
            disabled={isLoading}
            className="p-2.5 hover:bg-purple-50 rounded-lg transition-all duration-200 active:scale-95 disabled:opacity-50"
            title="ملائمة الشاشة"
            aria-label="Fit to screen"
          >
            <Maximize2 size={20} className="text-gray-600" />
          </button>
        </div>

        {/* Layout controls */}
        <div className="bg-white/95 backdrop-blur-sm rounded-xl shadow-lg border p-2 flex gap-1">
          {(['vertical', 'horizontal'] as const).map(layout => (
            <button
              key={layout}
              onClick={() => onLayoutChange?.(layout)}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all ${
                currentLayout === layout
                  ? 'bg-indigo-100 text-indigo-700'
                  : 'hover:bg-gray-50 text-gray-600'
              }`}
              title={`${layout} layout`}
            >
              {layout === 'vertical' ? '⬇️' : '⬅️'}
            </button>
          ))}
        </div>

        {/* Color mode toggle */}
        <div className="bg-white/95 backdrop-blur-sm rounded-xl shadow-lg border p-2 flex gap-1">
          {(['generation', 'lineage', 'gender'] as const).map(mode => (
            <button
              key={mode}
              onClick={() => onColorModeChange?.(mode)}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all ${
                currentColorMode === mode
                  ? 'bg-indigo-100 text-indigo-700'
                  : 'hover:bg-gray-50 text-gray-600'
              }`}
              title={`${mode} color mode`}
            >
              {mode === 'generation' ? '🎨' : mode === 'lineage' ? '🌳' : '👥'}
            </button>
          ))}
        </div>
      </div>

      {/* Top right controls */}
      <div className="absolute top-4 right-4 flex gap-2 items-start pointer-events-auto">
        {/* Zoom percentage */}
        <div className="bg-white/95 backdrop-blur-sm px-4 py-2 rounded-xl shadow-lg border text-sm font-medium text-gray-700">
          {Math.round(currentZoom * 100)}%
        </div>

        {/* Search button */}
        <button
          onClick={() => {}}
          className="p-2.5 bg-white/95 backdrop-blur-sm hover:bg-gray-50 rounded-xl shadow-lg border transition-all"
          title="بحث"
          aria-label="Search"
        >
          <Search size={20} className="text-gray-600" />
        </button>

        {/* Filter button */}
        <button
          onClick={() => setShowFilters(!showFilters)}
          className={`p-2.5 rounded-xl shadow-lg border transition-all ${
            showFilters
              ? 'bg-indigo-100 text-indigo-600'
              : 'bg-white/95 backdrop-blur-sm hover:bg-gray-50 text-gray-600'
          }`}
          title="تصفية"
          aria-label="Filters"
        >
          <Filter size={20} />
        </button>

        {/* Export button */}
        <button
          onClick={() => setShowExport(!showExport)}
          className={`p-2.5 rounded-xl shadow-lg border transition-all ${
            showExport
              ? 'bg-green-100 text-green-600'
              : 'bg-white/95 backdrop-blur-sm hover:bg-gray-50 text-gray-600'
          }`}
          title="تصدير"
          aria-label="Export"
        >
          <Download size={20} />
        </button>

        {/* Fullscreen button */}
        <button
          onClick={onFullscreen}
          className="p-2.5 bg-white/95 backdrop-blur-sm hover:bg-gray-50 rounded-xl shadow-lg border transition-all text-gray-600"
          title={isFullscreen ? 'Exit fullscreen' : 'Fullscreen'}
          aria-label="Toggle fullscreen"
        >
          {isFullscreen ? <Minimize size={20} /> : <Maximize size={20} />}
        </button>
      </div>

      {/* Filters panel */}
      {showFilters && (
        <div className="absolute top-20 right-4 bg-white rounded-xl shadow-2xl border p-4 w-64 pointer-events-auto z-50">
          <h3 className="font-semibold text-gray-800 mb-4 flex items-center gap-2">
            <Filter size={18} />
            الفلاتر
          </h3>

          <div className="space-y-3">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={filters.livingOnly || false}
                onChange={(e) => handleFilterChange('livingOnly', e.target.checked)}
                className="rounded"
              />
              <span className="text-sm text-gray-700">الأحياء فقط</span>
            </label>

            {/* Generation filter */}
            <div>
              <label className="text-sm font-medium text-gray-700 block mb-2">الأجيال</label>
              <div className="flex gap-1 flex-wrap">
                {[1, 2, 3, 4, 5, 6].map(gen => (
                  <button
                    key={gen}
                    onClick={() => {
                      const gens = filters.generations || [];
                      const updated = gens.includes(gen)
                        ? gens.filter(g => g !== gen)
                        : [...gens, gen];
                      handleFilterChange('generations', updated.length > 0 ? updated : undefined);
                    }}
                    className={`px-2 py-1 text-xs rounded transition-all ${
                      (filters.generations || []).includes(gen)
                        ? 'bg-indigo-100 text-indigo-700 font-medium'
                        : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                    }`}
                  >
                    ج{gen}
                  </button>
                ))}
              </div>
            </div>

            <button
              onClick={() => setShowFilters(false)}
              className="w-full mt-4 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-all text-sm font-medium"
            >
              تم
            </button>
          </div>
        </div>
      )}

      {/* Export panel */}
      {showExport && (
        <div className="absolute top-20 right-4 bg-white rounded-xl shadow-2xl border p-4 w-56 pointer-events-auto z-50">
          <h3 className="font-semibold text-gray-800 mb-4 flex items-center gap-2">
            <Download size={18} />
            تصدير
          </h3>

          <div className="space-y-2">
            <button
              onClick={() => handleExport('png')}
              className="w-full px-4 py-2 text-left hover:bg-gray-50 rounded-lg transition-all text-sm"
            >
              📸 PNG (صورة)
            </button>
            <button
              onClick={() => handleExport('svg')}
              className="w-full px-4 py-2 text-left hover:bg-gray-50 rounded-lg transition-all text-sm"
            >
              🎨 SVG (متجه)
            </button>
            <button
              onClick={() => handleExport('json')}
              className="w-full px-4 py-2 text-left hover:bg-gray-50 rounded-lg transition-all text-sm"
            >
              📋 JSON (بيانات)
            </button>
            <button
              onClick={() => setShowExport(false)}
              className="w-full mt-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-all text-sm"
            >
              إغلاق
            </button>
          </div>
        </div>
      )}

      {/* Instructions */}
      <div className="absolute top-4 left-1/2 -translate-x-1/2 bg-white/95 backdrop-blur-sm px-4 py-2 rounded-xl shadow-lg border text-xs text-gray-600 font-medium pointer-events-auto">
        🖱️ سحب للتحريك • 🔍 تمرير للتكبير • 👆 انقر لعرض التفاصيل
      </div>

      {/* Loading indicator */}
      {isLoading && (
        <div className="absolute inset-0 bg-black/10 rounded-xl flex items-center justify-center pointer-events-auto">
          <div className="bg-white rounded-xl shadow-lg p-4 flex items-center gap-2">
            <div className="w-4 h-4 bg-indigo-600 rounded-full animate-bounce" />
            <span className="text-sm text-gray-700">جاري التحميل...</span>
          </div>
        </div>
      )}
    </div>
  );
});

TreeControls.displayName = 'TreeControls';
