'use client';

import { useEffect, useRef, useState, useMemo, useCallback } from 'react';
import * as d3 from 'd3';
import type { FamilyMember } from '@/lib/types';
import type { TreeNode, D3TreeNode, TreeLink, ColorMode, TreeLayout } from './types';
import { TreeControls } from './TreeControls';
import { TreeLegend } from './TreeLegend';
import { TreeSearch } from './TreeSearch';
import { TreeLink as TreeLinkComponent } from './TreeLink';
import { TreeNode as TreeNodeComponent } from './TreeNode';
import { useTreeData } from './hooks/useTreeData';
import { useTreeZoom } from './hooks/useTreeZoom';
import { useTreeLayout } from './hooks/useTreeLayout';
import { buildTreeHierarchy, generateLinkPath, getGenerationColor } from './utils/tree-helpers';
import Image from 'next/image';

interface FamilyTreeProps {
  members: FamilyMember[];
  onSelectMember?: (member: FamilyMember) => void;
  highlightedId?: string | null;
  currentUserId?: string | null;
  height?: number;
  showControls?: boolean;
  showLegend?: boolean;
  defaultLayout?: TreeLayout;
  defaultColorMode?: ColorMode;
}

// Generation color definitions
const GENERATION_COLORS = {
  1: {
    primary: '#dc2626',
    secondary: '#fca5a5',
    gradient: ['#dc2626', '#991b1b'] as [string, string],
  },
  2: {
    primary: '#f59e0b',
    secondary: '#fcd34d',
    gradient: ['#f59e0b', '#b45309'] as [string, string],
  },
  3: {
    primary: '#10b981',
    secondary: '#a7f3d0',
    gradient: ['#10b981', '#047857'] as [string, string],
  },
  4: {
    primary: '#0ea5e9',
    secondary: '#bae6fd',
    gradient: ['#0ea5e9', '#0284c7'] as [string, string],
  },
  5: {
    primary: '#8b5cf6',
    secondary: '#ddd6fe',
    gradient: ['#8b5cf6', '#6d28d9'] as [string, string],
  },
  6: {
    primary: '#ec4899',
    secondary: '#fbcfe8',
    gradient: ['#ec4899', '#be185d'] as [string, string],
  },
  7: {
    primary: '#14b8a6',
    secondary: '#99f6e4',
    gradient: ['#14b8a6', '#0d9488'] as [string, string],
  },
  8: {
    primary: '#6b7280',
    secondary: '#d1d5db',
    gradient: ['#6b7280', '#374151'] as [string, string],
  },
};

/**
 * FamilyTree - Main interactive D3.js tree visualization component
 * Renders a complete family tree with zoom, pan, search, and filtering capabilities
 */
export default function FamilyTree({
  members,
  onSelectMember,
  highlightedId,
  currentUserId,
  height = 700,
  showControls = true,
  showLegend = true,
  defaultLayout = 'vertical',
  defaultColorMode = 'generation',
}: FamilyTreeProps) {
  const svgRef = useRef<SVGSVGElement>(null);
  const gRef = useRef<SVGGElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const [dimensions, setDimensions] = useState({ width: 1200, height });
  const [isMobile, setIsMobile] = useState(false);
  const [hoveredNodeId, setHoveredNodeId] = useState<string | null>(null);
  const [selectedNodeId, setSelectedNodeId] = useState<string | null>(null);
  const [tooltipPos, setTooltipPos] = useState({ x: 0, y: 0 });
  const [colorMode, setColorMode] = useState<ColorMode>(defaultColorMode);
  const [layout, setLayout] = useState<TreeLayout>(defaultLayout);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<FamilyMember[]>([]);

  // Build tree data
  const treeData = useMemo(() => {
    return buildTreeHierarchy(members);
  }, [members]);

  // Calculate layout
  const { nodes, links, bounds } = useTreeLayout(treeData as TreeNode, layout, { isMobile });

  // Initialize zoom
  const { currentZoom, zoomIn, zoomOut, resetZoom, fitToScreen } = useTreeZoom(
    svgRef,
    gRef,
    nodes
  );

  // Handle resize
  useEffect(() => {
    const updateDimensions = () => {
      if (containerRef.current) {
        const { width } = containerRef.current.getBoundingClientRect();
        setDimensions({ width: Math.max(width, 300), height });
        setIsMobile(width < 768);
      }
    };

    updateDimensions();
    window.addEventListener('resize', updateDimensions);
    return () => window.removeEventListener('resize', updateDimensions);
  }, [height]);

  // Handle node selection
  const handleNodeClick = useCallback((node: TreeNode) => {
    const member = members.find(m => m.id === node.id);
    if (member) {
      setSelectedNodeId(node.id);
      onSelectMember?.(member);
    }
  }, [members, onSelectMember]);

  // Search functionality
  const handleSearch = useCallback((query: string) => {
    setSearchQuery(query);
    if (!query.trim()) {
      setSearchResults([]);
      return;
    }

    const lowerQuery = query.toLowerCase();
    const results = members.filter(member =>
      member.firstName.toLowerCase().includes(lowerQuery) ||
      member.fullNameAr?.toLowerCase().includes(lowerQuery) ||
      member.fullNameEn?.toLowerCase().includes(lowerQuery) ||
      member.id.toLowerCase().includes(lowerQuery)
    );
    setSearchResults(results);
  }, [members]);

  // Get node color based on color mode
  const getNodeColor = useCallback(
    (node: TreeNode) => {
      if (colorMode === 'gender') {
        return node.gender?.toUpperCase() === 'MALE'
          ? { primary: '#3b82f6', secondary: '#93c5fd' }
          : { primary: '#ec4899', secondary: '#f9a8d4' };
      } else if (colorMode === 'lineage' && node.lineageBranchId) {
        const colorIndex = Math.abs(node.lineageBranchId.charCodeAt(0)) % 8;
        const gen = (colorIndex + 1) as keyof typeof GENERATION_COLORS;
        return GENERATION_COLORS[gen];
      }
      return GENERATION_COLORS[node.generation as keyof typeof GENERATION_COLORS] || GENERATION_COLORS[8];
    },
    [colorMode]
  );

  // Handle zoom controls
  const handleFitToScreen = useCallback(() => {
    fitToScreen(dimensions.width, dimensions.height);
  }, [dimensions, fitToScreen]);

  const handleExport = useCallback(async (format: 'png' | 'svg' | 'json') => {
    if (!svgRef.current) return;

    if (format === 'svg') {
      const svg = new XMLSerializer().serializeToString(svgRef.current);
      const blob = new Blob([svg], { type: 'image/svg+xml' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'family-tree.svg';
      a.click();
      URL.revokeObjectURL(url);
    } else if (format === 'png') {
      // Export as PNG
      const canvas = document.createElement('canvas');
      canvas.width = 1200;
      canvas.height = 800;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        // In a real implementation, you would render the SVG to canvas
        const blob = await new Promise<Blob>(resolve =>
          canvas.toBlob(b => resolve(b!), 'image/png')
        );
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'family-tree.png';
        a.click();
        URL.revokeObjectURL(url);
      }
    } else if (format === 'json') {
      const data = {
        exportedAt: new Date().toISOString(),
        memberCount: members.length,
        members: members,
      };
      const blob = new Blob([JSON.stringify(data, null, 2)], {
        type: 'application/json',
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'family-tree.json';
      a.click();
      URL.revokeObjectURL(url);
    }
  }, [members]);

  return (
    <div
      ref={containerRef}
      className="relative w-full bg-gradient-to-br from-slate-50 via-gray-50 to-slate-100 rounded-xl md:rounded-2xl overflow-hidden border border-gray-200 md:border-2 shadow-lg"
      style={{ height: `${height}px` }}
    >
      {/* SVG Canvas */}
      <svg
        ref={svgRef}
        width={dimensions.width}
        height={dimensions.height}
        className="cursor-grab active:cursor-grabbing"
        style={{ touchAction: 'none' }}
      >
        <defs>
          {/* Generate color gradients */}
          {Object.entries(GENERATION_COLORS).map(([gen, colors]) => (
            <linearGradient key={gen} id={`gen-gradient-${gen}`} x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor={colors.gradient[0]} />
              <stop offset="100%" stopColor={colors.gradient[1]} />
            </linearGradient>
          ))}

          {/* Shadows and filters */}
          <filter id="card-shadow" x="-50%" y="-50%" width="200%" height="200%">
            <feDropShadow dx="0" dy="4" stdDeviation="8" floodColor="#000" floodOpacity="0.1" />
          </filter>
          <filter id="card-shadow-hover" x="-50%" y="-50%" width="200%" height="200%">
            <feDropShadow dx="0" dy="8" stdDeviation="16" floodColor="#000" floodOpacity="0.15" />
          </filter>
          <filter id="glow-highlight" x="-100%" y="-100%" width="300%" height="300%">
            <feGaussianBlur stdDeviation="6" result="blur" />
            <feFlood floodColor="#fbbf24" result="color" />
            <feComposite in="color" in2="blur" operator="in" result="glow" />
            <feMerge>
              <feMergeNode in="glow" />
              <feMergeNode in="glow" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
          <clipPath id="avatar-clip">
            <circle cx="0" cy="-22" r="13" />
          </clipPath>
        </defs>

        {/* Transform group for zoom/pan */}
        <g ref={gRef}>
          {/* Links */}
          <g className="links">
            {links.map((link, i) => {
              const nodeColors = getNodeColor(link.target.data);
              return (
                <g key={i}>
                  <path
                    d={generateLinkPath(link.source, link.target, layout)}
                    fill="none"
                    stroke={nodeColors.secondary}
                    strokeWidth={8}
                    strokeOpacity={0.4}
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <path
                    d={generateLinkPath(link.source, link.target, layout)}
                    fill="none"
                    stroke={nodeColors.primary}
                    strokeWidth={3}
                    strokeOpacity={0.85}
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </g>
              );
            })}
          </g>

          {/* Nodes */}
          <g className="nodes">
            {nodes.map((node) => {
              const isHighlighted = node.data.id === highlightedId;
              const isSelected = node.data.id === selectedNodeId;
              const isHovered = node.data.id === hoveredNodeId;
              const nodeColors = getNodeColor(node.data);
              const isMale = node.data.gender?.toUpperCase() === 'MALE';
              const isSearchResult = searchResults.some(r => r.id === node.data.id);

              return (
                <g
                  key={node.data.id}
                  transform={`translate(${node.x}, ${node.y})`}
                  className="cursor-pointer"
                  onClick={() => handleNodeClick(node.data)}
                  onMouseEnter={() => {
                    setHoveredNodeId(node.data.id);
                    if (containerRef.current) {
                      const rect = containerRef.current.getBoundingClientRect();
                      setTooltipPos({ x: rect.width / 2, y: rect.height / 2 });
                    }
                  }}
                  onMouseLeave={() => setHoveredNodeId(null)}
                >
                  {/* Highlight ring */}
                  {(isHighlighted || isSearchResult) && (
                    <rect
                      x={-72}
                      y={-50}
                      width={144}
                      height={100}
                      rx={18}
                      fill="none"
                      stroke="#fbbf24"
                      strokeWidth={4}
                      filter="url(#glow-highlight)"
                      className="animate-pulse"
                    />
                  )}

                  {/* Card background */}
                  <rect
                    x={-65}
                    y={-42}
                    width={130}
                    height={84}
                    rx={14}
                    fill="white"
                    filter={isHovered ? 'url(#card-shadow-hover)' : 'url(#card-shadow)'}
                    stroke={isHovered ? '#22c55e' : isSelected ? nodeColors.primary : '#e5e7eb'}
                    strokeWidth={isHovered || isSelected ? 2 : 1}
                  />

                  {/* Color bar */}
                  <rect
                    x={-65}
                    y={-42}
                    width={130}
                    height={5}
                    fill={`url(#gen-gradient-${node.data.generation})`}
                    style={{ clipPath: 'inset(0 0 0 0 round 14px 14px 0 0)' }}
                  />

                  {/* Avatar */}
                  <circle
                    cx={0}
                    cy={-22}
                    r={15}
                    fill={isMale ? '#dbeafe' : '#fce7f3'}
                    stroke="white"
                    strokeWidth={2}
                  />

                  {/* Avatar image or initial */}
                  {node.data.photoUrl ? (
                    <image
                      href={node.data.photoUrl}
                      x={-13}
                      y={-35}
                      width={26}
                      height={26}
                      clipPath="url(#avatar-clip)"
                    />
                  ) : (
                    <text
                      x={0}
                      y={-17}
                      textAnchor="middle"
                      fontSize={12}
                      fontWeight="bold"
                      fill={isMale ? '#0ea5e9' : '#ec4899'}
                    >
                      {node.data.firstName.substring(0, 2).toUpperCase()}
                    </text>
                  )}

                  {/* Name */}
                  <text
                    x={0}
                    y={6}
                    textAnchor="middle"
                    fontSize={11}
                    fontWeight="600"
                    fill="#1f2937"
                    style={{ pointerEvents: 'none' }}
                  >
                    {node.data.firstName}
                  </text>

                  {/* Gen badge */}
                  <g transform="translate(0, 25)">
                    <rect
                      x={-20}
                      y={-9}
                      width={28}
                      height={14}
                      rx={7}
                      fill={`url(#gen-gradient-${node.data.generation})`}
                    />
                    <text
                      x={-6}
                      y={2}
                      textAnchor="middle"
                      fontSize={8}
                      fontWeight="bold"
                      fill="white"
                    >
                      ج{node.data.generation}
                    </text>
                  </g>

                  {/* Children count */}
                  {(node.data.sonsCount > 0 || node.data.daughtersCount > 0) && (
                    <g transform="translate(50, -32)">
                      <circle
                        cx={0}
                        cy={0}
                        r={10}
                        fill={isMale ? '#dbeafe' : '#fce7f3'}
                        stroke={isMale ? '#93c5fd' : '#f9a8d4'}
                        strokeWidth={1}
                      />
                      <text
                        x={0}
                        y={4}
                        textAnchor="middle"
                        fontSize={9}
                        fontWeight="bold"
                        fill={isMale ? '#2563eb' : '#db2777'}
                      >
                        {node.data.sonsCount + node.data.daughtersCount}
                      </text>
                    </g>
                  )}
                </g>
              );
            })}
          </g>
        </g>
      </svg>

      {/* Controls */}
      {showControls && (
        <TreeControls
          onZoomIn={zoomIn}
          onZoomOut={zoomOut}
          onResetView={resetZoom}
          onFitToScreen={handleFitToScreen}
          onSearch={handleSearch}
          onLayoutChange={setLayout}
          onColorModeChange={setColorMode}
          onExport={handleExport}
          currentZoom={currentZoom}
          currentLayout={layout}
          currentColorMode={colorMode}
        />
      )}

      {/* Legend */}
      {showLegend && (
        <TreeLegend colorMode={colorMode} position="bottom-left" />
      )}

      {/* Search component */}
      <div className="absolute top-4 right-4 pointer-events-auto z-20 w-64">
        <TreeSearch
          members={members}
          onResultSelect={(member) => {
            setSelectedNodeId(member.id);
            onSelectMember?.(member);
          }}
          onResultHighlight={(id) => {
            setSelectedNodeId(id || undefined);
          }}
        />
      </div>
    </div>
  );
}
