// Utility functions for tree operations and transformations

import * as d3 from 'd3';
import type { FamilyMember } from '@/lib/types';
import type { TreeNode, D3TreeNode, TreeLink, TreeFilterOptions } from '../types';

/**
 * Transform flat family member data into hierarchical tree structure
 */
export function buildTreeHierarchy(members: FamilyMember[], rootId?: string): TreeNode | null {
  const memberMap = new Map<string, TreeNode>();

  // Create nodes with children array
  members.forEach(member => {
    memberMap.set(member.id, {
      ...member,
      children: []
    });
  });

  let root: TreeNode | null = null;

  // Build parent-child relationships
  memberMap.forEach(node => {
    if (node.fatherId && memberMap.has(node.fatherId)) {
      const parent = memberMap.get(node.fatherId)!;
      if (!parent.children) parent.children = [];
      parent.children.push(node);
    } else if (!node.fatherId) {
      root = node;
    }
  });

  // Sort children by birth year
  const sortChildren = (node: TreeNode) => {
    if (node.children) {
      node.children.sort((a, b) => (a.birthYear || 0) - (b.birthYear || 0));
      node.children.forEach(sortChildren);
    }
  };

  if (root) {
    sortChildren(root);
  } else if (rootId && memberMap.has(rootId)) {
    root = memberMap.get(rootId)!;
    sortChildren(root);
  }

  return root;
}

/**
 * Calculate D3 tree layout with proper spacing
 */
export function calculateTreeLayout(
  treeData: TreeNode,
  layout: 'vertical' | 'horizontal' | 'radial' = 'vertical',
  isMobile: boolean = false
): { nodes: D3TreeNode[]; links: TreeLink[] } {
  if (!treeData) return { nodes: [], links: [] };

  const hierarchy = d3.hierarchy<TreeNode>(treeData);

  let layoutFunc: d3.TreeLayout<TreeNode>;

  if (layout === 'vertical') {
    const nodeWidth = isMobile ? 90 : 110;
    const generationGap = isMobile ? 140 : 160;
    layoutFunc = d3.tree<TreeNode>()
      .nodeSize([nodeWidth, generationGap])
      .separation((a, b) => {
        if (a.parent === b.parent) return 1.0;
        return 1.2;
      });
  } else if (layout === 'horizontal') {
    const nodeHeight = isMobile ? 90 : 110;
    const generationGap = isMobile ? 140 : 160;
    layoutFunc = d3.tree<TreeNode>()
      .nodeSize([generationGap, nodeHeight])
      .separation((a, b) => {
        if (a.parent === b.parent) return 1.0;
        return 1.2;
      });
  } else {
    // Radial layout - cluster layout works better
    layoutFunc = d3.tree<TreeNode>()
      .nodeSize([1, 1]);
  }

  const root = layoutFunc(hierarchy);
  const nodes = root.descendants() as unknown as D3TreeNode[];
  const links = root.links() as unknown as TreeLink[];

  return { nodes, links };
}

/**
 * Generate SVG path for tree links with orthogonal routing
 */
export function generateLinkPath(source: D3TreeNode, target: D3TreeNode, layout: 'vertical' | 'horizontal' = 'vertical'): string {
  if (layout === 'vertical') {
    const sourceY = source.y + 40;
    const targetY = target.y - 40;
    const midY = source.y + 70;
    return `M ${source.x} ${sourceY}
            L ${source.x} ${midY}
            L ${target.x} ${midY}
            L ${target.x} ${targetY}`;
  } else {
    const sourceX = source.x + 40;
    const targetX = target.x - 40;
    const midX = source.x + 70;
    return `M ${sourceX} ${source.y}
            L ${midX} ${source.y}
            L ${midX} ${target.y}
            L ${targetX} ${target.y}`;
  }
}

/**
 * Generate curved Bezier path for smooth connections
 */
export function generateBezierPath(source: D3TreeNode, target: D3TreeNode, layout: 'vertical' | 'horizontal' = 'vertical'): string {
  if (layout === 'vertical') {
    const sourceY = source.y + 40;
    const targetY = target.y - 40;
    const midY = (sourceY + targetY) / 2;
    return `M ${source.x} ${sourceY}
            C ${source.x} ${midY}
              ${target.x} ${midY}
              ${target.x} ${targetY}`;
  } else {
    const sourceX = source.x + 40;
    const targetX = target.x - 40;
    const midX = (sourceX + targetX) / 2;
    return `M ${sourceX} ${source.y}
            C ${midX} ${source.y}
              ${midX} ${target.y}
              ${targetX} ${target.y}`;
  }
}

/**
 * Filter tree nodes based on criteria
 */
export function filterTreeNodes(nodes: TreeNode[], filters: TreeFilterOptions): TreeNode[] {
  return nodes.filter(node => {
    if (filters.generations && !filters.generations.includes(node.generation)) {
      return false;
    }
    if (filters.branches && node.branch && !filters.branches.includes(node.branch)) {
      return false;
    }
    if (filters.genders && !filters.genders.includes(node.gender)) {
      return false;
    }
    if (filters.status && !filters.status.includes(node.status)) {
      return false;
    }
    if (filters.hasPhoto && !node.photoUrl) {
      return false;
    }
    if (filters.livingOnly && node.deathYear) {
      return false;
    }
    return true;
  });
}

/**
 * Search tree nodes by various criteria with fuzzy matching
 */
export function searchTreeNodes(nodes: TreeNode[], query: string): TreeNode[] {
  if (!query.trim()) return [];

  const lowerQuery = query.toLowerCase();
  const results: TreeNode[] = [];

  const normalizeArabic = (str: string) => {
    return str
      .replace(/ا/g, 'ا')
      .replace(/أ/g, 'ا')
      .replace(/إ/g, 'ا')
      .replace(/آ/g, 'ا');
  };

  const calculateSimilarity = (source: string, target: string): number => {
    source = normalizeArabic(source.toLowerCase());
    target = normalizeArabic(target.toLowerCase());

    if (source === target) return 1;
    if (source.includes(target) || target.includes(source)) return 0.8;

    let match = 0;
    for (let i = 0; i < Math.min(source.length, target.length); i++) {
      if (source[i] === target[i]) match++;
    }
    return match / Math.max(source.length, target.length);
  };

  nodes.forEach(node => {
    let score = 0;

    // Match on first name
    if (node.firstName) {
      const similarity = calculateSimilarity(node.firstName, query);
      score = Math.max(score, similarity * 1.0);
    }

    // Match on full Arabic name
    if (node.fullNameAr) {
      const similarity = calculateSimilarity(node.fullNameAr, query);
      score = Math.max(score, similarity * 0.9);
    }

    // Match on full English name
    if (node.fullNameEn) {
      const similarity = calculateSimilarity(node.fullNameEn.toLowerCase(), lowerQuery);
      score = Math.max(score, similarity * 0.9);
    }

    // Exact ID match
    if (node.id.includes(query)) {
      score = Math.max(score, 0.95);
    }

    // Phone number match
    if (node.phone && node.phone.includes(query)) {
      score = Math.max(score, 0.8);
    }

    // City match
    if (node.city && calculateSimilarity(node.city, query) > 0.6) {
      score = Math.max(score, 0.6);
    }

    if (score > 0.4) {
      results.push(node);
    }
  });

  return results.sort((a, b) => {
    const scoreA = calculateSimilarity(a.firstName, query);
    const scoreB = calculateSimilarity(b.firstName, query);
    return scoreB - scoreA;
  });
}

/**
 * Get all ancestors of a node
 */
export function getAncestors(nodeId: string, members: Map<string, TreeNode>): TreeNode[] {
  const ancestors: TreeNode[] = [];
  let current = members.get(nodeId);

  while (current && current.fatherId) {
    const parent = members.get(current.fatherId);
    if (parent) {
      ancestors.push(parent);
      current = parent;
    } else {
      break;
    }
  }

  return ancestors;
}

/**
 * Get all descendants of a node
 */
export function getDescendants(node: TreeNode): TreeNode[] {
  const descendants: TreeNode[] = [];

  const traverse = (n: TreeNode) => {
    if (n.children) {
      n.children.forEach(child => {
        descendants.push(child);
        traverse(child);
      });
    }
  };

  traverse(node);
  return descendants;
}

/**
 * Calculate bounds of all nodes
 */
export function calculateNodesBounds(nodes: D3TreeNode[]): {
  minX: number;
  maxX: number;
  minY: number;
  maxY: number;
} {
  let minX = Infinity;
  let maxX = -Infinity;
  let minY = Infinity;
  let maxY = -Infinity;

  nodes.forEach(node => {
    minX = Math.min(minX, node.x - 80);
    maxX = Math.max(maxX, node.x + 80);
    minY = Math.min(minY, node.y - 50);
    maxY = Math.max(maxY, node.y + 50);
  });

  return { minX, maxX, minY, maxY };
}

/**
 * Calculate optimal zoom and pan to fit all nodes in view
 */
export function calculateFitTransform(
  nodes: D3TreeNode[],
  viewportWidth: number,
  viewportHeight: number,
  padding: number = 100
): d3.ZoomTransform {
  if (nodes.length === 0) {
    return d3.zoomIdentity.translate(viewportWidth / 2, viewportHeight / 2).scale(1);
  }

  const bounds = calculateNodesBounds(nodes);
  const treeWidth = bounds.maxX - bounds.minX;
  const treeHeight = bounds.maxY - bounds.minY;

  const scale = Math.min(
    (viewportWidth - padding) / treeWidth,
    (viewportHeight - padding) / treeHeight,
    1
  ) * 0.9;

  const centerX = (bounds.minX + bounds.maxX) / 2;
  const centerY = (bounds.minY + bounds.maxY) / 2;

  return d3.zoomIdentity
    .translate(viewportWidth / 2 - centerX * scale, viewportHeight / 2 - centerY * scale)
    .scale(scale);
}

/**
 * Export tree as SVG string
 */
export function exportTreeAsSVG(svgElement: SVGSVGElement): string {
  const serializer = new XMLSerializer();
  return serializer.serializeToString(svgElement);
}

/**
 * Export tree as PNG (requires canvas)
 */
export async function exportTreeAsPNG(
  svgElement: SVGSVGElement,
  width: number = 1200,
  height: number = 800,
  scale: number = 2
): Promise<Blob> {
  return new Promise((resolve, reject) => {
    const canvas = document.createElement('canvas');
    canvas.width = width * scale;
    canvas.height = height * scale;

    const ctx = canvas.getContext('2d');
    if (!ctx) {
      reject(new Error('Could not get canvas context'));
      return;
    }

    // Fill background
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Draw SVG on canvas
    const svgString = new XMLSerializer().serializeToString(svgElement);
    const img = new Image();

    img.onload = () => {
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      canvas.toBlob(
        blob => {
          if (blob) {
            resolve(blob);
          } else {
            reject(new Error('Could not create blob'));
          }
        },
        'image/png'
      );
    };

    img.onerror = () => reject(new Error('Could not load SVG image'));
    img.src = 'data:image/svg+xml;base64,' + btoa(svgString);
  });
}

/**
 * Get generation color
 */
export function getGenerationColor(
  generation: number,
  colors: Record<number, { primary: string; secondary: string; gradient: [string, string] }>
): { primary: string; secondary: string; gradient: [string, string] } {
  return colors[generation] || colors[8];
}

/**
 * Calculate generation gaps for proper spacing
 */
export function calculateGenerationGap(generation: number, baseGap: number = 160): number {
  // Increase gap for deeper generations to prevent overlap
  return baseGap + (generation - 1) * 20;
}

/**
 * Check if tree would create a cycle when changing parent
 */
export function wouldCreateCycle(
  nodeId: string,
  newParentId: string,
  memberMap: Map<string, TreeNode>
): boolean {
  if (nodeId === newParentId) return true;

  const ancestors = getAncestors(newParentId, memberMap);
  return ancestors.some(a => a.id === nodeId);
}

/**
 * Export tree data to JSON
 */
export function exportTreeAsJSON(root: TreeNode): string {
  const sanitize = (node: TreeNode) => ({
    id: node.id,
    firstName: node.firstName,
    fatherName: node.fatherName,
    fullNameAr: node.fullNameAr,
    generation: node.generation,
    gender: node.gender,
    birthYear: node.birthYear,
    children: node.children?.map(sanitize) || []
  });

  return JSON.stringify(sanitize(root), null, 2);
}

/**
 * Get node path from root to node
 */
export function getNodePath(nodeId: string, memberMap: Map<string, TreeNode>): TreeNode[] {
  const path: TreeNode[] = [];
  let current = memberMap.get(nodeId);

  while (current) {
    path.unshift(current);
    if (current.fatherId) {
      current = memberMap.get(current.fatherId);
    } else {
      break;
    }
  }

  return path;
}
