'use client';

import React from 'react';
import type { D3TreeNode } from './types';
import { generateLinkPath, generateBezierPath } from './utils/tree-helpers';

interface TreeLinkProps {
  source: D3TreeNode;
  target: D3TreeNode;
  layout?: 'vertical' | 'horizontal';
  style?: 'orthogonal' | 'bezier' | 'straight';
  primaryColor?: string;
  secondaryColor?: string;
  strokeWidth?: number;
  animated?: boolean;
  relationshipType?: 'father' | 'mother' | 'milk-kinship';
}

const relationshipStyles = {
  'father': { dashArray: 'none', opacity: 0.85 },
  'mother': { dashArray: 'none', opacity: 0.75 },
  'milk-kinship': { dashArray: '8 4', opacity: 0.6 },
};

/**
 * TreeLink - Renders connection lines between tree nodes
 * Supports multiple line styles and relationship types
 */
export const TreeLink = React.memo(({
  source,
  target,
  layout = 'vertical',
  style = 'orthogonal',
  primaryColor = '#3b82f6',
  secondaryColor = '#93c5fd',
  strokeWidth = 3,
  animated = false,
  relationshipType = 'father',
}: TreeLinkProps) => {
  // Calculate path based on style
  const getPath = (): string => {
    if (style === 'bezier') {
      return generateBezierPath(source, target, layout);
    } else if (style === 'straight') {
      if (layout === 'vertical') {
        return `M ${source.x} ${source.y + 40} L ${target.x} ${target.y - 40}`;
      } else {
        return `M ${source.x + 40} ${source.y} L ${target.x - 40} ${target.y}`;
      }
    }
    return generateLinkPath(source, target, layout);
  };

  const path = getPath();
  const relStyle = relationshipStyles[relationshipType];

  return (
    <g className="tree-link">
      {/* Shadow/glow line for depth */}
      <path
        d={path}
        fill="none"
        stroke={secondaryColor}
        strokeWidth={strokeWidth + 4}
        strokeOpacity={0.3}
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeDasharray={relStyle.dashArray}
        pointerEvents="none"
      />

      {/* Main visible line */}
      <path
        d={path}
        fill="none"
        stroke={primaryColor}
        strokeWidth={strokeWidth}
        strokeOpacity={relStyle.opacity}
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeDasharray={relStyle.dashArray}
        pointerEvents="none"
        className={animated ? 'animate-pulse' : ''}
      />

      {/* Connection dots */}
      <circle
        cx={source.x}
        cy={layout === 'vertical' ? source.y + 40 : source.x + 40}
        r={3}
        fill={primaryColor}
        opacity={relStyle.opacity}
      />
      <circle
        cx={target.x}
        cy={layout === 'vertical' ? target.y - 40 : target.x - 40}
        r={3}
        fill={primaryColor}
        opacity={relStyle.opacity}
      />
    </g>
  );
});

TreeLink.displayName = 'TreeLink';

/**
 * TreeLinkGroup - Renders multiple tree links efficiently
 */
interface TreeLinkGroupProps {
  links: Array<{
    source: D3TreeNode;
    target: D3TreeNode;
    primaryColor?: string;
    secondaryColor?: string;
    relationshipType?: 'father' | 'mother' | 'milk-kinship';
  }>;
  layout?: 'vertical' | 'horizontal';
  style?: 'orthogonal' | 'bezier' | 'straight';
  strokeWidth?: number;
  animated?: boolean;
}

export const TreeLinkGroup = React.memo(({
  links,
  layout = 'vertical',
  style = 'orthogonal',
  strokeWidth = 3,
  animated = false,
}: TreeLinkGroupProps) => {
  return (
    <g className="tree-links">
      {links.map((link, index) => (
        <TreeLink
          key={`link-${link.source.data.id}-${link.target.data.id}`}
          source={link.source}
          target={link.target}
          layout={layout}
          style={style}
          primaryColor={link.primaryColor}
          secondaryColor={link.secondaryColor}
          strokeWidth={strokeWidth}
          animated={animated}
          relationshipType={link.relationshipType}
        />
      ))}
    </g>
  );
});

TreeLinkGroup.displayName = 'TreeLinkGroup';
