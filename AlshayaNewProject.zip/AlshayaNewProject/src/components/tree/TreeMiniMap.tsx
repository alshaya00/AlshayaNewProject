'use client';

import React, { useEffect, useRef, useState } from 'react';
import * as d3 from 'd3';
import type { D3TreeNode } from './types';

interface TreeMiniMapProps {
  nodes: D3TreeNode[];
  viewportWidth: number;
  viewportHeight: number;
  currentZoom: number;
  currentPanX: number;
  currentPanY: number;
  onNavigate?: (x: number, y: number, zoom: number) => void;
  width?: number;
  height?: number;
  position?: 'top-left' | 'top-right' | 'bottom-left' | 'bottom-right';
}

/**
 * TreeMiniMap - Shows overview of entire tree with viewport indicator
 */
export const TreeMiniMap = React.memo(({
  nodes,
  viewportWidth,
  viewportHeight,
  currentZoom,
  currentPanX,
  currentPanY,
  onNavigate,
  width = 200,
  height = 160,
  position = 'top-right',
}: TreeMiniMapProps) => {
  const svgRef = useRef<SVGSVGElement>(null);
  const [bounds, setBounds] = useState({ minX: 0, maxX: 0, minY: 0, maxY: 0 });

  // Calculate bounds
  useEffect(() => {
    if (nodes.length === 0) return;

    let minX = Infinity,
      maxX = -Infinity,
      minY = Infinity,
      maxY = -Infinity;

    nodes.forEach(node => {
      minX = Math.min(minX, node.x - 80);
      maxX = Math.max(maxX, node.x + 80);
      minY = Math.min(minY, node.y - 50);
      maxY = Math.max(maxY, node.y + 50);
    });

    setBounds({ minX, maxX, minY, maxY });
  }, [nodes]);

  const positionClasses = {
    'top-left': 'top-4 left-4',
    'top-right': 'top-4 right-4',
    'bottom-left': 'bottom-4 left-4',
    'bottom-right': 'bottom-4 right-4',
  };

  const treeWidth = bounds.maxX - bounds.minX;
  const treeHeight = bounds.maxY - bounds.minY;
  const scale = Math.min(width / treeWidth, height / treeHeight) * 0.9;

  // Calculate viewport indicator rectangle
  const viewportRect = {
    x: (currentPanX - bounds.minX) * scale,
    y: (currentPanY - bounds.minY) * scale,
    width: (viewportWidth / currentZoom) * scale,
    height: (viewportHeight / currentZoom) * scale,
  };

  const handleClick = (e: React.MouseEvent<SVGSVGElement>) => {
    if (!svgRef.current) return;

    const rect = svgRef.current.getBoundingClientRect();
    const x = (e.clientX - rect.left) / scale + bounds.minX;
    const y = (e.clientY - rect.top) / scale + bounds.minY;

    onNavigate?.(x, y, currentZoom);
  };

  return (
    <div
      className={`absolute ${positionClasses[position]} z-20 bg-white/95 backdrop-blur-sm rounded-xl shadow-lg border p-2 pointer-events-auto`}
    >
      <div className="text-xs font-semibold text-gray-600 mb-2 px-2">خريطة</div>
      <svg
        ref={svgRef}
        width={width}
        height={height}
        className="border rounded-lg cursor-pointer hover:opacity-80 transition-opacity"
        onClick={handleClick}
      >
        {/* Background */}
        <rect width={width} height={height} fill="#f9fafb" />

        {/* Mini nodes */}
        {nodes.map(node => {
          const miniX = (node.x - bounds.minX) * scale;
          const miniY = (node.y - bounds.minY) * scale;
          const nodeSize = 1.5;

          return (
            <circle
              key={node.data.id}
              cx={miniX}
              cy={miniY}
              r={nodeSize}
              fill="#d1d5db"
              opacity={0.6}
            />
          );
        })}

        {/* Viewport indicator */}
        <rect
          x={Math.max(0, viewportRect.x)}
          y={Math.max(0, viewportRect.y)}
          width={Math.min(width, viewportRect.width)}
          height={Math.min(height, viewportRect.height)}
          fill="none"
          stroke="#3b82f6"
          strokeWidth={2}
          pointerEvents="none"
        />
      </svg>
      <div className="text-xs text-gray-500 mt-2 px-2">
        {Math.round(currentZoom * 100)}%
      </div>
    </div>
  );
});

TreeMiniMap.displayName = 'TreeMiniMap';

/**
 * CompactMiniMap - Minimal version for tight spaces
 */
interface CompactMiniMapProps {
  nodes: D3TreeNode[];
  viewportWidth: number;
  viewportHeight: number;
  currentZoom: number;
  onNavigate?: (x: number, y: number, zoom: number) => void;
}

export const CompactMiniMap = React.memo(({
  nodes,
  viewportWidth,
  viewportHeight,
  currentZoom,
  onNavigate,
}: CompactMiniMapProps) => {
  const svgRef = useRef<SVGSVGElement>(null);

  if (nodes.length === 0) return null;

  let minX = Infinity,
    maxX = -Infinity,
    minY = Infinity,
    maxY = -Infinity;

  nodes.forEach(node => {
    minX = Math.min(minX, node.x - 80);
    maxX = Math.max(maxX, node.x + 80);
    minY = Math.min(minY, node.y - 50);
    maxY = Math.max(maxY, node.y + 50);
  });

  const treeWidth = maxX - minX;
  const treeHeight = maxY - minY;
  const mapSize = 80;
  const scale = (mapSize * 0.85) / Math.max(treeWidth, treeHeight);

  return (
    <svg
      ref={svgRef}
      width={mapSize}
      height={mapSize}
      className="border border-gray-300 rounded bg-gray-50 cursor-pointer hover:opacity-75 transition-opacity"
      onClick={(e) => {
        if (!svgRef.current) return;
        const rect = svgRef.current.getBoundingClientRect();
        const x = (e.clientX - rect.left) / scale + minX;
        const y = (e.clientY - rect.top) / scale + minY;
        onNavigate?.(x, y, currentZoom);
      }}
    >
      <rect width={mapSize} height={mapSize} fill="#f9fafb" />

      {nodes.map(node => (
        <circle
          key={node.data.id}
          cx={(node.x - minX) * scale + (mapSize - treeWidth * scale) / 2}
          cy={(node.y - minY) * scale + (mapSize - treeHeight * scale) / 2}
          r={1}
          fill="#9ca3af"
          opacity={0.5}
        />
      ))}

      <rect
        x={(mapSize - (viewportWidth / currentZoom) * scale) / 2}
        y={(mapSize - (viewportHeight / currentZoom) * scale) / 2}
        width={(viewportWidth / currentZoom) * scale}
        height={(viewportHeight / currentZoom) * scale}
        fill="none"
        stroke="#3b82f6"
        strokeWidth={1}
        pointerEvents="none"
      />
    </svg>
  );
});

CompactMiniMap.displayName = 'CompactMiniMap';
