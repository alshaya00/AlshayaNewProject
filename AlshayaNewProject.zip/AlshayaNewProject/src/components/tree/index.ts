// Export all tree components and utilities

// Main component
export { default as FamilyTree } from './FamilyTree';

// UI Components
export { TreeControls } from './TreeControls';
export { TreeLegend, CompactTreeLegend } from './TreeLegend';
export { TreeSearch, InlineTreeSearch } from './TreeSearch';
export { TreeLink, TreeLinkGroup } from './TreeLink';
export { TreeNode, TreeNodeGroup } from './TreeNode';
export { TreeMiniMap, CompactMiniMap } from './TreeMiniMap';

// Hooks
export {
  useTreeData,
  useIncrementalTreeData,
  useTreeSearch,
} from './hooks/useTreeData';
export { useTreeZoom, useSyncedZoom } from './hooks/useTreeZoom';
export {
  useTreeLayout,
  useAnimatedLayout,
  useHierarchicalLayout,
} from './hooks/useTreeLayout';

// Utilities
export {
  buildTreeHierarchy,
  calculateTreeLayout,
  generateLinkPath,
  generateBezierPath,
  filterTreeNodes,
  searchTreeNodes,
  getAncestors,
  getDescendants,
  calculateNodesBounds,
  calculateFitTransform,
  exportTreeAsSVG,
  exportTreeAsPNG,
  getGenerationColor,
  calculateGenerationGap,
  wouldCreateCycle,
  exportTreeAsJSON,
  getNodePath,
} from './utils/tree-helpers';

// Types
export type {
  TreeNode,
  D3TreeNode,
  TreeLink,
  TreeLayout,
  ColorMode,
  TreeDimensions,
  TreeTooltip,
  TreeSearchResult,
  TreeFilterOptions,
  ExportOptions,
  TreeState,
} from './types';
