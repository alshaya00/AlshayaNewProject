'use client';

import React, { useMemo } from 'react';
import Image from 'next/image';
import type { TreeNode as TreeNodeType } from './types';

interface TreeNodeProps {
  node: TreeNodeType;
  x: number;
  y: number;
  isSelected?: boolean;
  isHighlighted?: boolean;
  isHovered?: boolean;
  color?: string;
  gradientId?: string;
  onClick?: (node: TreeNodeType) => void;
  onMouseEnter?: (node: TreeNodeType) => void;
  onMouseLeave?: () => void;
  showChildren?: boolean;
  childrenCount?: number;
}

const defaultColors = {
  primary: '#3b82f6',
  secondary: '#93c5fd',
};

/**
 * TreeNode - Individual node component with avatar, name, and metadata
 */
export const TreeNode = React.memo(({
  node,
  x,
  y,
  isSelected = false,
  isHighlighted = false,
  isHovered = false,
  color = defaultColors.primary,
  gradientId = 'default-gradient',
  onClick,
  onMouseEnter,
  onMouseLeave,
  showChildren = true,
  childrenCount,
}: TreeNodeProps) => {
  const isMale = node.gender?.toUpperCase() === 'MALE';
  const childCount = childrenCount || node.sonsCount + node.daughtersCount;

  const cardWidth = 130;
  const cardHeight = 84;

  const isDeceased = node.deathYear && node.deathYear > 0;

  // Determine status indicator
  const statusInfo = useMemo(() => {
    if (isDeceased) {
      return { emoji: '†', color: '#9ca3af', label: 'deceased' };
    }
    return { emoji: '●', color: '#10b981', label: 'living' };
  }, [isDeceased]);

  return (
    <g
      transform={`translate(${x}, ${y})`}
      className="tree-node cursor-pointer"
      onClick={() => onClick?.(node)}
      onMouseEnter={() => onMouseEnter?.(node)}
      onMouseLeave={onMouseLeave}
      style={{ transition: 'transform 0.2s ease-out' }}
    >
      {/* Highlight ring for searched member */}
      {isHighlighted && (
        <rect
          x={-(cardWidth / 2) - 6}
          y={-(cardHeight / 2) - 6}
          width={cardWidth + 12}
          height={cardHeight + 12}
          rx={18}
          fill="none"
          stroke="#fbbf24"
          strokeWidth={4}
          filter="url(#glow-highlight)"
          className="animate-pulse"
        />
      )}

      {/* Selection indicator */}
      {isSelected && (
        <rect
          x={-(cardWidth / 2) - 4}
          y={-(cardHeight / 2) - 4}
          width={cardWidth + 8}
          height={cardHeight + 8}
          rx={16}
          fill="none"
          stroke={color}
          strokeWidth={3}
        />
      )}

      {/* Card background */}
      <rect
        x={-(cardWidth / 2)}
        y={-(cardHeight / 2)}
        width={cardWidth}
        height={cardHeight}
        rx={14}
        fill="white"
        stroke={isHovered ? '#22c55e' : isSelected ? color : '#e5e7eb'}
        strokeWidth={isHovered || isSelected ? 2 : 1}
        filter={isHovered ? 'url(#card-shadow-hover)' : 'url(#card-shadow)'}
        opacity={isDeceased ? 0.7 : 1}
      />

      {/* Color accent bar (generation/lineage) */}
      <rect
        x={-(cardWidth / 2)}
        y={-(cardHeight / 2)}
        width={cardWidth}
        height={5}
        fill={`url(#${gradientId})`}
        style={{ clipPath: `inset(0 0 0 0 round 14px 14px 0 0)` }}
      />

      {/* Avatar circle */}
      <circle
        cx={0}
        cy={-22}
        r={15}
        fill={isDeceased ? '#d1d5db' : isMale ? '#dbeafe' : '#fce7f3'}
        stroke="white"
        strokeWidth={2}
        opacity={isDeceased ? 0.6 : 1}
      />

      {/* Avatar image or initials */}
      {node.photoUrl ? (
        <image
          href={node.photoUrl}
          x={-13}
          y={-35}
          width={26}
          height={26}
          clipPath="url(#avatar-clip)"
          opacity={isDeceased ? 0.6 : 1}
        />
      ) : (
        <text
          x={0}
          y={-17}
          textAnchor="middle"
          fontSize={12}
          fontWeight="bold"
          fill={isMale ? '#0ea5e9' : '#ec4899'}
          opacity={isDeceased ? 0.6 : 1}
        >
          {node.firstName.substring(0, 2).toUpperCase()}
        </text>
      )}

      {/* Status indicator */}
      <circle
        cx={8}
        cy={-29}
        r={3.5}
        fill={statusInfo.color}
        stroke="white"
        strokeWidth={1}
      />

      {/* Name text */}
      <text
        x={0}
        y={6}
        textAnchor="middle"
        fontSize={11}
        fontWeight="600"
        fill={isDeceased ? '#9ca3af' : '#1f2937'}
        style={{ pointerEvents: 'none', textDecoration: isDeceased ? 'line-through' : 'none' }}
      >
        {node.firstName}
      </text>

      {/* Generation badge */}
      <g transform="translate(0, 25)">
        <rect
          x={-20}
          y={-9}
          width={28}
          height={14}
          rx={7}
          fill={`url(#${gradientId})`}
        />
        <text
          x={-6}
          y={2}
          textAnchor="middle"
          fontSize={8}
          fontWeight="bold"
          fill="white"
        >
          ج{node.generation}
        </text>
      </g>

      {/* Children count indicator */}
      {showChildren && childCount > 0 && (
        <g transform="translate(50, -32)">
          <circle
            cx={0}
            cy={0}
            r={10}
            fill={isMale ? '#dbeafe' : '#fce7f3'}
            stroke={isMale ? '#93c5fd' : '#f9a8d4'}
            strokeWidth={1}
          />
          <text
            x={0}
            y={4}
            textAnchor="middle"
            fontSize={9}
            fontWeight="bold"
            fill={isMale ? '#2563eb' : '#db2777'}
          >
            {childCount}
          </text>
        </g>
      )}
    </g>
  );
});

TreeNode.displayName = 'TreeNode';

/**
 * TreeNodeGroup - Renders multiple tree nodes efficiently
 */
interface TreeNodeGroupProps {
  nodes: Array<{
    node: TreeNodeType;
    x: number;
    y: number;
    isSelected?: boolean;
    isHighlighted?: boolean;
    isHovered?: boolean;
    color?: string;
    gradientId?: string;
  }>;
  onNodeClick?: (node: TreeNodeType) => void;
  onNodeMouseEnter?: (node: TreeNodeType) => void;
  onNodeMouseLeave?: () => void;
}

export const TreeNodeGroup = React.memo(({
  nodes,
  onNodeClick,
  onNodeMouseEnter,
  onNodeMouseLeave,
}: TreeNodeGroupProps) => {
  return (
    <g className="tree-nodes">
      {nodes.map((nodeData) => (
        <TreeNode
          key={nodeData.node.id}
          node={nodeData.node}
          x={nodeData.x}
          y={nodeData.y}
          isSelected={nodeData.isSelected}
          isHighlighted={nodeData.isHighlighted}
          isHovered={nodeData.isHovered}
          color={nodeData.color}
          gradientId={nodeData.gradientId}
          onClick={onNodeClick}
          onMouseEnter={onNodeMouseEnter}
          onMouseLeave={onNodeMouseLeave}
        />
      ))}
    </g>
  );
});

TreeNodeGroup.displayName = 'TreeNodeGroup';
