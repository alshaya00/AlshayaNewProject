import * as React from 'react';
import { AlertCircle } from 'lucide-react';
import { Button } from './ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from './ui/dialog';

interface ConfirmDialogProps {
  title: string;
  description?: string;
  confirmLabel?: string;
  cancelLabel?: string;
  isDangerous?: boolean;
  onConfirm: () => void | Promise<void>;
  onCancel?: () => void;
  trigger?: React.ReactNode;
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
  loading?: boolean;
}

const ConfirmDialog = React.forwardRef<HTMLDivElement, ConfirmDialogProps>(
  (
    {
      title,
      description,
      confirmLabel = 'Confirm',
      cancelLabel = 'Cancel',
      isDangerous = false,
      onConfirm,
      onCancel,
      trigger,
      open,
      onOpenChange,
      loading = false,
    },
    ref
  ) => {
    const [isLoading, setIsLoading] = React.useState(false);

    const handleConfirm = async () => {
      setIsLoading(true);
      try {
        await onConfirm();
        onOpenChange?.(false);
      } catch (error) {
        console.error('Confirmation error:', error);
      } finally {
        setIsLoading(false);
      }
    };

    const handleCancel = () => {
      onCancel?.();
      onOpenChange?.(false);
    };

    return (
      <Dialog open={open} onOpenChange={onOpenChange}>
        {trigger && <DialogTrigger asChild>{trigger}</DialogTrigger>}
        <DialogContent ref={ref} showCloseButton={!isDangerous}>
          <DialogHeader>
            <div className="flex items-center gap-3">
              {isDangerous && (
                <AlertCircle className="h-6 w-6 text-red-500 flex-shrink-0" />
              )}
              <DialogTitle>{title}</DialogTitle>
            </div>
            {description && <DialogDescription>{description}</DialogDescription>}
          </DialogHeader>
          <DialogFooter>
            <Button
              variant="ghost"
              onClick={handleCancel}
              disabled={isLoading || loading}
            >
              {cancelLabel}
            </Button>
            <Button
              variant={isDangerous ? 'danger' : 'primary'}
              onClick={handleConfirm}
              disabled={isLoading || loading}
              loading={isLoading || loading}
            >
              {confirmLabel}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    );
  }
);

ConfirmDialog.displayName = 'ConfirmDialog';

export { ConfirmDialog };
export type { ConfirmDialogProps };
