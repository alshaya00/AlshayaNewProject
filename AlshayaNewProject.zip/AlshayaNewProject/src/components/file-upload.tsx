import * as React from 'react';
import { Upload, X, File } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from './ui/button';

interface FileUploadProps {
  onFilesSelected: (files: File[]) => void;
  accept?: string;
  maxFiles?: number;
  maxSize?: number; // in bytes
  multiple?: boolean;
  disabled?: boolean;
  showPreview?: boolean;
  className?: string;
}

const FileUpload = React.forwardRef<HTMLDivElement, FileUploadProps>(
  (
    {
      onFilesSelected,
      accept = 'image/*',
      maxFiles = 5,
      maxSize = 5 * 1024 * 1024, // 5MB
      multiple = true,
      disabled = false,
      showPreview = true,
      className,
    },
    ref
  ) => {
    const [files, setFiles] = React.useState<File[]>([]);
    const [previews, setPreviews] = React.useState<string[]>([]);
    const [error, setError] = React.useState<string>('');
    const inputRef = React.useRef<HTMLInputElement>(null);

    const handleFiles = (selectedFiles: FileList | null) => {
      if (!selectedFiles) return;

      setError('');
      const newFiles = Array.from(selectedFiles);
      const validFiles: File[] = [];

      for (const file of newFiles) {
        if (files.length + validFiles.length >= maxFiles) {
          setError(`Maximum ${maxFiles} files allowed`);
          break;
        }

        if (file.size > maxSize) {
          setError(`File ${file.name} exceeds maximum size of ${maxSize / 1024 / 1024}MB`);
          continue;
        }

        validFiles.push(file);
      }

      if (validFiles.length > 0) {
        const updatedFiles = [...files, ...validFiles];
        setFiles(updatedFiles);
        onFilesSelected(updatedFiles);

        if (showPreview && accept.includes('image')) {
          validFiles.forEach((file) => {
            const reader = new FileReader();
            reader.onload = (e) => {
              setPreviews((prev) => [...prev, e.target?.result as string]);
            };
            reader.readAsDataURL(file);
          });
        }
      }
    };

    const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
      e.preventDefault();
      e.stopPropagation();
      if (!disabled) {
        handleFiles(e.dataTransfer.files);
      }
    };

    const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
      e.preventDefault();
      e.stopPropagation();
    };

    const removeFile = (index: number) => {
      const newFiles = files.filter((_, i) => i !== index);
      setFiles(newFiles);
      onFilesSelected(newFiles);

      if (previews[index]) {
        setPreviews((prev) => prev.filter((_, i) => i !== index));
      }
    };

    return (
      <div ref={ref} className={cn('w-full', className)}>
        <div
          onDrop={handleDrop}
          onDragOver={handleDragOver}
          className={cn(
            'border-2 border-dashed border-navy-light rounded-lg p-8 text-center transition-colors',
            disabled ? 'opacity-50 cursor-not-allowed' : 'hover:border-cyan-500 cursor-pointer'
          )}
          onClick={() => !disabled && inputRef.current?.click()}
        >
          <Upload className="h-8 w-8 mx-auto mb-2 text-cyan-500" />
          <p className="text-sm font-medium text-text mb-1">
            Click to upload or drag and drop
          </p>
          <p className="text-xs text-text-muted">
            {accept} • Max {maxSize / 1024 / 1024}MB per file • Max {maxFiles} files
          </p>
        </div>

        <input
          ref={inputRef}
          type="file"
          accept={accept}
          multiple={multiple}
          disabled={disabled}
          onChange={(e) => handleFiles(e.target.files)}
          className="hidden"
          aria-label="File upload"
        />

        {error && <p className="mt-2 text-sm text-red-500">{error}</p>}

        {files.length > 0 && (
          <div className="mt-4 space-y-2">
            <p className="text-sm font-medium text-text">
              {files.length} file{files.length !== 1 ? 's' : ''} selected
            </p>

            {showPreview && previews.length > 0 && (
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mt-4">
                {previews.map((preview, index) => (
                  <div
                    key={index}
                    className="relative rounded-lg overflow-hidden border-2 border-navy-light"
                  >
                    <img
                      src={preview}
                      alt={`Preview ${index}`}
                      className="w-full h-32 object-cover"
                    />
                    <button
                      onClick={() => removeFile(index)}
                      className="absolute top-1 end-1 bg-red-600 rounded-full p-1 hover:bg-red-700 transition-colors"
                    >
                      <X className="h-3 w-3 text-white" />
                    </button>
                  </div>
                ))}
              </div>
            )}

            {(!showPreview || !accept.includes('image')) && (
              <ul className="space-y-2">
                {files.map((file, index) => (
                  <li
                    key={index}
                    className="flex items-center justify-between p-2 bg-navy-light rounded"
                  >
                    <div className="flex items-center gap-2">
                      <File className="h-4 w-4 text-text-muted" />
                      <span className="text-sm text-text truncate">{file.name}</span>
                    </div>
                    <button
                      onClick={() => removeFile(index)}
                      className="text-red-500 hover:text-red-700 transition-colors"
                    >
                      <X className="h-4 w-4" />
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </div>
        )}
      </div>
    );
  }
);

FileUpload.displayName = 'FileUpload';

export { FileUpload };
export type { FileUploadProps };
