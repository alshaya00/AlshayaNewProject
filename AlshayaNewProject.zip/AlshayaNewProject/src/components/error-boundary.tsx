import * as React from 'react';
import { AlertCircle } from 'lucide-react';
import { Button } from './ui/button';

interface ErrorBoundaryProps {
  children: React.ReactNode;
  fallback?: React.ReactNode;
  onError?: (error: Error, errorInfo: React.ErrorInfo) => void;
}

interface ErrorBoundaryState {
  hasError: boolean;
  error: Error | null;
}

class ErrorBoundary extends React.Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = {
      hasError: false,
      error: null,
    };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return {
      hasError: true,
      error,
    };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error('Error caught by boundary:', error, errorInfo);
    this.props.onError?.(error, errorInfo);
  }

  reset = () => {
    this.setState({ hasError: false, error: null });
  };

  render() {
    if (this.state.hasError) {
      if (this.props.fallback) {
        return this.props.fallback;
      }

      return (
        <div className="flex flex-col items-center justify-center py-12 px-4 text-center">
          <div className="mb-4 text-red-400">
            <AlertCircle className="h-12 w-12 mx-auto" />
          </div>

          <h2 className="text-2xl font-semibold text-text mb-2">
            Something went wrong
          </h2>

          <p className="text-text-muted mb-6 max-w-sm">
            {this.state.error?.message || 'An unexpected error occurred'}
          </p>

          <div className="flex gap-3">
            <Button variant="primary" onClick={this.reset}>
              Try again
            </Button>
            <Button
              variant="secondary"
              onClick={() => window.location.href = '/'}
            >
              Go home
            </Button>
          </div>

          {process.env.NODE_ENV === 'development' && (
            <details className="mt-8 w-full max-w-2xl text-start">
              <summary className="cursor-pointer text-sm text-text-muted hover:text-text">
                Error details
              </summary>
              <pre className="mt-4 p-4 bg-navy-light rounded text-xs text-text-muted overflow-auto">
                {this.state.error?.stack}
              </pre>
            </details>
          )}
        </div>
      );
    }

    return this.props.children;
  }
}

export { ErrorBoundary };
export type { ErrorBoundaryProps };
