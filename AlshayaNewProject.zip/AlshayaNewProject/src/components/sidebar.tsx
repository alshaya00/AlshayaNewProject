import * as React from 'react';
import { Menu, X } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from './ui/button';

interface SidebarItem {
  id: string;
  label: string;
  icon?: React.ReactNode;
  href?: string;
  onClick?: () => void;
  active?: boolean;
  badge?: string | number;
}

interface SidebarProps {
  items: SidebarItem[];
  onItemClick?: (id: string) => void;
  defaultOpen?: boolean;
  collapsible?: boolean;
  className?: string;
}

const Sidebar = React.forwardRef<HTMLDivElement, SidebarProps>(
  (
    {
      items,
      onItemClick,
      defaultOpen = true,
      collapsible = true,
      className,
    },
    ref
  ) => {
    const [isOpen, setIsOpen] = React.useState(defaultOpen);

    return (
      <>
        {collapsible && (
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsOpen(!isOpen)}
            className="fixed top-4 start-4 z-40 md:hidden"
          >
            {isOpen ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
          </Button>
        )}

        <aside
          ref={ref}
          className={cn(
            'bg-navy border-e-2 border-navy-light transition-all duration-300',
            collapsible && !isOpen && '-translate-x-full md:translate-x-0',
            'fixed md:static h-screen md:h-auto',
            'w-64 md:w-auto',
            'z-30',
            className
          )}
        >
          <nav className="p-4 space-y-2">
            {items.map((item) => (
              <button
                key={item.id}
                onClick={() => {
                  onItemClick?.(item.id);
                  item.onClick?.();
                  if (collapsible && window.innerWidth < 768) {
                    setIsOpen(false);
                  }
                }}
                className={cn(
                  'w-full flex items-center gap-3 px-4 py-2 rounded-lg transition-colors text-start',
                  item.active
                    ? 'bg-cyan-500 text-navy font-semibold'
                    : 'text-text hover:bg-navy-light'
                )}
              >
                {item.icon && <span className="flex-shrink-0">{item.icon}</span>}
                <span className="flex-1">{item.label}</span>
                {item.badge && (
                  <span className="bg-cyan-500 text-navy text-xs font-semibold px-2 py-1 rounded-full">
                    {item.badge}
                  </span>
                )}
              </button>
            ))}
          </nav>
        </aside>

        {collapsible && isOpen && (
          <div
            className="fixed inset-0 bg-black/50 z-20 md:hidden"
            onClick={() => setIsOpen(false)}
          />
        )}
      </>
    );
  }
);

Sidebar.displayName = 'Sidebar';

export { Sidebar };
export type { SidebarProps, SidebarItem };
