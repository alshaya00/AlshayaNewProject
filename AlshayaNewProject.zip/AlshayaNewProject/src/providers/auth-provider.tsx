'use client';

import React, { createContext, useContext, useState, useEffect, useCallback, ReactNode, useRef } from 'react';
import { useRouter } from 'next/navigation';
import {
  SessionUser,
  AuthSession,
  PermissionKey,
  UserRole,
  getStoredSession,
  storeSession,
  clearStoredSession,
  userHasPermission,
  userCanActOnBranch,
  isSessionValid,
  getPermissionsForRole,
} from '@/lib/auth';

const SESSION_TIMEOUT_MS = 30 * 60 * 1000;
const ACTIVITY_CHECK_INTERVAL_MS = 60 * 1000;
const LAST_ACTIVITY_KEY = 'alshaya_last_activity';

interface AuthContextType {
  user: SessionUser | null;
  session: AuthSession | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  isGuest: boolean;
  login: (email: string, password: string, rememberMe?: boolean) => Promise<{ success: boolean; error?: string; requires2FA?: boolean; user?: { role: string } }>;
  logout: () => Promise<void>;
  register: (data: RegisterData) => Promise<{ success: boolean; error?: string }>;
  refreshUser: () => Promise<void>;
  setSessionFromOAuth: (data: { user: SessionUser; token: string; expiresAt: string }) => void;
  verify2FA: (email: string, code: string, isBackupCode?: boolean, rememberMe?: boolean) => Promise<{ success: boolean; error?: string }>;
  hasPermission: (permission: PermissionKey) => boolean;
  canActOnBranch: (targetBranch: string | null | undefined, permission: PermissionKey) => boolean;
  canAssignRole: (role: UserRole) => boolean;
  getAuthHeader: () => { Authorization: string } | Record<string, never>;
}

interface RegisterData {
  email: string;
  password: string;
  nameArabic: string;
  nameEnglish?: string;
  phone?: string;
  claimedRelation: string;
  relatedMemberId?: string;
  relationshipType?: string;
  message?: string;
}

const defaultContext: AuthContextType = {
  user: null,
  session: null,
  isLoading: true,
  isAuthenticated: false,
  isGuest: true,
  login: async () => ({ success: false, error: 'Context not initialized' }),
  logout: async () => {},
  register: async () => ({ success: false, error: 'Context not initialized' }),
  refreshUser: async () => {},
  setSessionFromOAuth: () => {},
  verify2FA: async () => ({ success: false, error: 'Context not initialized' }),
  hasPermission: () => false,
  canActOnBranch: () => false,
  canAssignRole: () => false,
  getAuthHeader: () => ({}),
};

const AuthContext = createContext<AuthContextType>(defaultContext);

interface AuthProviderProps {
  children: ReactNode;
}

export function AuthProvider({ children }: AuthProviderProps) {
  const [session, setSession] = useState<AuthSession | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const router = useRouter();
  const activityCheckIntervalRef = useRef<NodeJS.Timeout | null>(null);

  const user = session?.user ?? null;
  const isAuthenticated = !!user && user.status === 'ACTIVE';
  const isGuest = !user || user.role === 'GUEST';

  const updateLastActivity = useCallback(() => {
    if (typeof window !== 'undefined') {
      localStorage.setItem(LAST_ACTIVITY_KEY, Date.now().toString());
    }
  }, []);

  const getLastActivity = useCallback((): number => {
    if (typeof window === 'undefined') return Date.now();
    const stored = localStorage.getItem(LAST_ACTIVITY_KEY);
    return stored ? parseInt(stored, 10) : Date.now();
  }, []);

  const checkInactivityTimeout = useCallback(async () => {
    if (!isAuthenticated) return;

    const lastActivity = getLastActivity();
    const now = Date.now();
    const inactiveDuration = now - lastActivity;

    if (inactiveDuration >= SESSION_TIMEOUT_MS) {
      localStorage.removeItem(LAST_ACTIVITY_KEY);
      clearStoredSession();
      setSession(null);

      if (session?.token) {
        fetch('/api/auth/logout', {
          method: 'POST',
          headers: { Authorization: `Bearer ${session.token}` },
        }).catch(() => {});
      }

      router.push('/login?timeout=true');
    }
  }, [isAuthenticated, getLastActivity, session, router]);

  useEffect(() => {
    if (!isAuthenticated) {
      if (activityCheckIntervalRef.current) {
        clearInterval(activityCheckIntervalRef.current);
        activityCheckIntervalRef.current = null;
      }
      return;
    }

    updateLastActivity();

    const handleActivity = () => {
      updateLastActivity();
    };

    const events = ['mousemove', 'keypress', 'click', 'scroll', 'touchstart'];
    events.forEach(event => {
      window.addEventListener(event, handleActivity, { passive: true });
    });

    activityCheckIntervalRef.current = setInterval(checkInactivityTimeout, ACTIVITY_CHECK_INTERVAL_MS);

    return () => {
      events.forEach(event => {
        window.removeEventListener(event, handleActivity);
      });
      if (activityCheckIntervalRef.current) {
        clearInterval(activityCheckIntervalRef.current);
        activityCheckIntervalRef.current = null;
      }
    };
  }, [isAuthenticated, updateLastActivity, checkInactivityTimeout]);

  useEffect(() => {
    const initSession = () => {
      try {
        const stored = getStoredSession();
        if (stored && isSessionValid(stored)) {
          setSession(stored);
          updateLastActivity();
          validateSessionWithServer(stored.token);
        }
      } catch (error) {
        console.error('Failed to initialize session:', error);
        clearStoredSession();
      } finally {
        setIsLoading(false);
      }
    };

    initSession();
  }, [updateLastActivity]);

  const validateSessionWithServer = async (token: string) => {
    try {
      const response = await fetch('/api/auth/me', {
        headers: { Authorization: `Bearer ${token}` },
      });

      if (!response.ok) {
        clearStoredSession();
        setSession(null);
        return;
      }

      const data = await response.json();
      if (data.user) {
        setSession((prev) =>
          prev
            ? {
                ...prev,
                user: {
                  ...data.user,
                  permissions: getPermissionsForRole(data.user.role),
                },
              }
            : null
        );
      }
    } catch {
      console.warn('Could not validate session with server');
    }
  };

  const login = useCallback(
    async (
      email: string,
      password: string,
      rememberMe: boolean = false
    ): Promise<{ success: boolean; error?: string; requires2FA?: boolean; user?: { role: string } }> => {
      try {
        const response = await fetch('/api/auth/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email, password, rememberMe }),
        });

        const data = await response.json();

        if (!response.ok) {
          return {
            success: false,
            error: data.messageAr || data.message || 'Login failed',
          };
        }

        if (data.requires2FA) {
          return { success: false, requires2FA: true };
        }

        if (data.success && data.user && data.token) {
          const newSession: AuthSession = {
            user: {
              ...data.user,
              permissions: getPermissionsForRole(data.user.role),
            },
            token: data.token,
            expiresAt: new Date(data.expiresAt),
          };

          storeSession(newSession, rememberMe);
          setSession(newSession);

          return { success: true, user: { role: data.user.role } };
        }

        return { success: false, error: data.message || 'Login failed' };
      } catch (error) {
        console.error('Login error:', error);
        return { success: false, error: 'Network error. Please try again.' };
      }
    },
    []
  );

  const logout = useCallback(async () => {
    try {
      const token = session?.token;
      if (token) {
        await fetch('/api/auth/logout', {
          method: 'POST',
          headers: { Authorization: `Bearer ${token}` },
        }).catch(() => {});
      }
    } finally {
      clearStoredSession();
      setSession(null);
    }
  }, [session]);

  const register = useCallback(
    async (data: RegisterData): Promise<{ success: boolean; error?: string }> => {
      try {
        const response = await fetch('/api/auth/register', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(data),
        });

        const result = await response.json();

        if (!response.ok) {
          return {
            success: false,
            error: result.messageAr || result.message || 'Registration failed',
          };
        }

        return { success: true };
      } catch (error) {
        console.error('Registration error:', error);
        return { success: false, error: 'Network error. Please try again.' };
      }
    },
    []
  );

  const setSessionFromOAuth = useCallback(
    (data: { user: SessionUser; token: string; expiresAt: string }) => {
      const newSession: AuthSession = {
        user: {
          ...data.user,
          permissions: getPermissionsForRole(data.user.role),
        },
        token: data.token,
        expiresAt: new Date(data.expiresAt),
      };

      storeSession(newSession, true);
      setSession(newSession);
    },
    []
  );

  const verify2FA = useCallback(
    async (
      email: string,
      code: string,
      isBackupCode: boolean = false,
      rememberMe: boolean = false
    ): Promise<{ success: boolean; error?: string }> => {
      try {
        const response = await fetch('/api/auth/2fa/verify', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email, code, isBackupCode, rememberMe }),
        });

        const data = await response.json();

        if (!response.ok) {
          return {
            success: false,
            error: data.messageAr || data.message || '2FA verification failed',
          };
        }

        if (data.success && data.user && data.token) {
          const newSession: AuthSession = {
            user: {
              ...data.user,
              permissions: getPermissionsForRole(data.user.role),
            },
            token: data.token,
            expiresAt: new Date(data.expiresAt),
          };

          storeSession(newSession, rememberMe);
          setSession(newSession);

          return { success: true };
        }

        return { success: false, error: data.message || '2FA verification failed' };
      } catch (error) {
        console.error('2FA verification error:', error);
        return { success: false, error: 'Network error. Please try again.' };
      }
    },
    []
  );

  const refreshUser = useCallback(async () => {
    if (!session?.token) return;

    try {
      const response = await fetch('/api/auth/me', {
        headers: { Authorization: `Bearer ${session.token}` },
      });

      if (response.ok) {
        const data = await response.json();
        if (data.user) {
          setSession((prev) =>
            prev
              ? {
                  ...prev,
                  user: {
                    ...data.user,
                    permissions: getPermissionsForRole(data.user.role),
                  },
                }
              : null
          );
        }
      }
    } catch (error) {
      console.error('Failed to refresh user:', error);
    }
  }, [session]);

  const hasPermission = useCallback(
    (permission: PermissionKey): boolean => {
      return userHasPermission(user, permission);
    },
    [user]
  );

  const canActOnBranch = useCallback(
    (targetBranch: string | null | undefined, permission: PermissionKey): boolean => {
      return userCanActOnBranch(user, targetBranch, permission);
    },
    [user]
  );

  const canAssignRole = useCallback(
    (role: UserRole): boolean => {
      if (!user) return false;

      switch (user.role) {
        case 'SUPER_ADMIN':
          return true;
        case 'ADMIN':
          return role !== 'SUPER_ADMIN';
        case 'BRANCH_LEADER':
          return role === 'MEMBER';
        default:
          return false;
      }
    },
    [user]
  );

  const getAuthHeader = useCallback((): { Authorization: string } | Record<string, never> => {
    if (session?.token) {
      return { Authorization: `Bearer ${session.token}` };
    }
    return {};
  }, [session]);

  const value: AuthContextType = {
    user,
    session,
    isLoading,
    isAuthenticated,
    isGuest,
    login,
    logout,
    register,
    refreshUser,
    setSessionFromOAuth,
    verify2FA,
    hasPermission,
    canActOnBranch,
    canAssignRole,
    getAuthHeader,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}

export function usePermission(permission: PermissionKey): boolean {
  const { hasPermission } = useAuth();
  return hasPermission(permission);
}

export function useRequireAuth() {
  const auth = useAuth();

  useEffect(() => {
    if (!auth.isLoading && !auth.isAuthenticated) {
      console.warn('Authentication required');
    }
  }, [auth.isLoading, auth.isAuthenticated]);

  return auth;
}

export function useRequireRole(requiredRoles: UserRole[]) {
  const auth = useAuth();

  const hasRequiredRole = auth.user ? requiredRoles.includes(auth.user.role) : false;

  useEffect(() => {
    if (!auth.isLoading && auth.isAuthenticated && !hasRequiredRole) {
      console.warn('Insufficient permissions');
    }
  }, [auth.isLoading, auth.isAuthenticated, hasRequiredRole]);

  return { ...auth, hasRequiredRole };
}
