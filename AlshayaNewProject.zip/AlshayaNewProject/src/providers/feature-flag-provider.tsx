'use client';

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useState,
  type ReactNode,
} from 'react';

interface FeatureFlag {
  name: string;
  enabled: boolean;
  description?: string;
  rolloutPercentage?: number;
}

interface FeatureFlagContextType {
  flags: Record<string, FeatureFlag>;
  isLoading: boolean;
  error: Error | null;
  isFeatureEnabled: (featureName: string) => boolean;
  getFlagValue: (featureName: string) => FeatureFlag | null;
  refetchFlags: () => Promise<void>;
}

const FeatureFlagContext = createContext<FeatureFlagContextType | undefined>(
  undefined
);

const DEFAULT_FLAGS: Record<string, FeatureFlag> = {
  'family-tree-v2': {
    name: 'family-tree-v2',
    enabled: false,
    description: 'New family tree interface',
  },
  'advanced-analytics': {
    name: 'advanced-analytics',
    enabled: false,
    description: 'Advanced analytics features',
  },
  'dark-mode': {
    name: 'dark-mode',
    enabled: true,
    description: 'Dark mode support',
  },
  'multi-language': {
    name: 'multi-language',
    enabled: true,
    description: 'Multi-language support',
  },
  'real-time-sync': {
    name: 'real-time-sync',
    enabled: false,
    description: 'Real-time data synchronization',
  },
};

interface FeatureFlagProviderProps {
  children: ReactNode;
  fetchUrl?: string;
}

export function FeatureFlagProvider({
  children,
  fetchUrl = '/api/feature-flags',
}: FeatureFlagProviderProps) {
  const [flags, setFlags] = useState<Record<string, FeatureFlag>>(DEFAULT_FLAGS);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  const refetchFlags = useCallback(async () => {
    setIsLoading(true);
    setError(null);

    try {
      const response = await fetch(fetchUrl);

      if (!response.ok) {
        throw new Error(`Failed to fetch feature flags: ${response.statusText}`);
      }

      const data = await response.json();
      setFlags(data.flags || DEFAULT_FLAGS);
    } catch (err) {
      const error = err instanceof Error ? err : new Error('Unknown error');
      setError(error);
      console.error('Error fetching feature flags:', error);
      // Keep using default flags if fetch fails
      setFlags(DEFAULT_FLAGS);
    } finally {
      setIsLoading(false);
    }
  }, [fetchUrl]);

  useEffect(() => {
    refetchFlags();

    // Refetch flags periodically (every 5 minutes)
    const interval = setInterval(refetchFlags, 5 * 60 * 1000);

    return () => clearInterval(interval);
  }, [refetchFlags]);

  const isFeatureEnabled = useCallback(
    (featureName: string): boolean => {
      const flag = flags[featureName];
      if (!flag) {
        console.warn(`Feature flag not found: ${featureName}`);
        return false;
      }

      if (flag.rolloutPercentage !== undefined) {
        // Simple percentage-based rollout
        const hash = featureName
          .split('')
          .reduce((acc, char) => acc + char.charCodeAt(0), 0);
        const percentage = (hash % 100) + 1;
        return percentage <= flag.rolloutPercentage;
      }

      return flag.enabled;
    },
    [flags]
  );

  const getFlagValue = useCallback(
    (featureName: string): FeatureFlag | null => {
      return flags[featureName] || null;
    },
    [flags]
  );

  const value: FeatureFlagContextType = {
    flags,
    isLoading,
    error,
    isFeatureEnabled,
    getFlagValue,
    refetchFlags,
  };

  return (
    <FeatureFlagContext.Provider value={value}>
      {children}
    </FeatureFlagContext.Provider>
  );
}

export function useFeatureFlag() {
  const context = useContext(FeatureFlagContext);
  if (context === undefined) {
    throw new Error('useFeatureFlag must be used within a FeatureFlagProvider');
  }
  return context;
}

interface UseFeatureFlagProps {
  fallback?: boolean;
}

export function useIsFlagEnabled(
  featureName: string,
  { fallback = false }: UseFeatureFlagProps = {}
): boolean {
  const { isFeatureEnabled, isLoading } = useFeatureFlag();

  if (isLoading) {
    return fallback;
  }

  return isFeatureEnabled(featureName);
}
