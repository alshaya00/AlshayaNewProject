'use client';

import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import type { Locale } from '@/i18n/config';
import { defaultLocale, isValidLocale, localeDirections } from '@/i18n/config';

interface LocaleContextType {
  locale: Locale;
  direction: 'rtl' | 'ltr';
  setLocale: (locale: Locale) => void;
  toggleLocale: () => void;
}

const LocaleContext = createContext<LocaleContextType | undefined>(undefined);

const STORAGE_KEY = 'alshaya_locale';

interface LocaleProviderProps {
  children: ReactNode;
  defaultLocaleValue?: Locale;
}

export function LocaleProvider({
  children,
  defaultLocaleValue = defaultLocale,
}: LocaleProviderProps) {
  const [locale, setLocaleState] = useState<Locale>(defaultLocaleValue);
  const [direction, setDirection] = useState<'rtl' | 'ltr'>('rtl');

  useEffect(() => {
    // Load locale from localStorage or use default
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored && isValidLocale(stored)) {
      setLocaleState(stored);
    } else {
      setLocaleState(defaultLocaleValue);
    }
  }, [defaultLocaleValue]);

  useEffect(() => {
    // Update direction based on locale
    const newDirection = localeDirections[locale];
    setDirection(newDirection);

    // Update HTML attributes
    const html = document.documentElement;
    html.setAttribute('lang', locale);
    html.setAttribute('dir', newDirection);

    // Update body class
    html.classList.remove('ar', 'en');
    html.classList.add(locale);

    // Save to localStorage
    localStorage.setItem(STORAGE_KEY, locale);

    // Dispatch custom event for other components
    window.dispatchEvent(
      new CustomEvent('localechange', { detail: { locale, direction: newDirection } })
    );
  }, [locale]);

  const setLocale = (newLocale: Locale) => {
    if (!isValidLocale(newLocale)) {
      console.warn(`Invalid locale: ${newLocale}`);
      return;
    }
    setLocaleState(newLocale);
  };

  const toggleLocale = () => {
    setLocale(locale === 'ar' ? 'en' : 'ar');
  };

  const value: LocaleContextType = {
    locale,
    direction,
    setLocale,
    toggleLocale,
  };

  return (
    <LocaleContext.Provider value={value}>
      {children}
    </LocaleContext.Provider>
  );
}

export function useLocale() {
  const context = useContext(LocaleContext);
  if (context === undefined) {
    throw new Error('useLocale must be used within a LocaleProvider');
  }
  return context;
}
