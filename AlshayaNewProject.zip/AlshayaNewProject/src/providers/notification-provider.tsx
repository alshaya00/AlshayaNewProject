'use client';

import {
  createContext,
  useCallback,
  useContext,
  useState,
  type ReactNode,
  useId,
} from 'react';

export type NotificationType = 'success' | 'error' | 'warning' | 'info';

export interface Notification {
  id: string;
  type: NotificationType;
  message: string;
  description?: string;
  duration?: number;
  onClose?: () => void;
}

interface NotificationContextType {
  notifications: Notification[];
  showNotification: (
    type: NotificationType,
    message: string,
    description?: string,
    duration?: number
  ) => string;
  showSuccess: (message: string, description?: string, duration?: number) => string;
  showError: (message: string, description?: string, duration?: number) => string;
  showWarning: (message: string, description?: string, duration?: number) => string;
  showInfo: (message: string, description?: string, duration?: number) => string;
  closeNotification: (id: string) => void;
  clearAll: () => void;
}

const NotificationContext = createContext<NotificationContextType | undefined>(
  undefined
);

const DEFAULT_DURATION = 5000; // 5 seconds

interface NotificationProviderProps {
  children: ReactNode;
  maxNotifications?: number;
}

export function NotificationProvider({
  children,
  maxNotifications = 5,
}: NotificationProviderProps) {
  const [notifications, setNotifications] = useState<Notification[]>([]);

  const showNotification = useCallback(
    (
      type: NotificationType,
      message: string,
      description?: string,
      duration: number = DEFAULT_DURATION
    ): string => {
      const id = `notification-${Date.now()}-${Math.random()}`;

      const notification: Notification = {
        id,
        type,
        message,
        description,
        duration,
      };

      setNotifications((prev) => {
        let updated = [...prev, notification];

        // Keep only the last maxNotifications
        if (updated.length > maxNotifications) {
          updated = updated.slice(-maxNotifications);
        }

        return updated;
      });

      // Auto-close after duration
      if (duration > 0) {
        setTimeout(() => {
          closeNotification(id);
        }, duration);
      }

      return id;
    },
    [maxNotifications]
  );

  const showSuccess = useCallback(
    (message: string, description?: string, duration?: number): string => {
      return showNotification('success', message, description, duration);
    },
    [showNotification]
  );

  const showError = useCallback(
    (message: string, description?: string, duration?: number): string => {
      return showNotification('error', message, description, duration);
    },
    [showNotification]
  );

  const showWarning = useCallback(
    (message: string, description?: string, duration?: number): string => {
      return showNotification('warning', message, description, duration);
    },
    [showNotification]
  );

  const showInfo = useCallback(
    (message: string, description?: string, duration?: number): string => {
      return showNotification('info', message, description, duration);
    },
    [showNotification]
  );

  const closeNotification = useCallback((id: string) => {
    setNotifications((prev) => prev.filter((n) => n.id !== id));
  }, []);

  const clearAll = useCallback(() => {
    setNotifications([]);
  }, []);

  const value: NotificationContextType = {
    notifications,
    showNotification,
    showSuccess,
    showError,
    showWarning,
    showInfo,
    closeNotification,
    clearAll,
  };

  return (
    <NotificationContext.Provider value={value}>
      {children}
    </NotificationContext.Provider>
  );
}

export function useNotification() {
  const context = useContext(NotificationContext);
  if (context === undefined) {
    throw new Error('useNotification must be used within a NotificationProvider');
  }
  return context;
}
