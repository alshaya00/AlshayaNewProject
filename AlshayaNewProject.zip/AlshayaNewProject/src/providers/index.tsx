'use client';

import { ReactNode } from 'react';
import { AuthProvider } from './auth-provider';
import { QueryProvider } from './query-provider';
import { ThemeProvider } from './theme-provider';
import { LocaleProvider } from './locale-provider';
import { FeatureFlagProvider } from './feature-flag-provider';
import { NotificationProvider } from './notification-provider';

interface ProvidersProps {
  children: ReactNode;
}

/**
 * Combined providers wrapper
 * Nests all providers in the correct order for dependencies
 *
 * Order matters:
 * 1. LocaleProvider - Sets up i18n/locale context early
 * 2. ThemeProvider - Sets up theme context
 * 3. QueryProvider - Sets up React Query
 * 4. FeatureFlagProvider - Feature flag management
 * 5. AuthProvider - Authentication and authorization
 * 6. NotificationProvider - Toast notifications
 */
export function Providers({ children }: ProvidersProps) {
  return (
    <LocaleProvider>
      <ThemeProvider>
        <QueryProvider>
          <FeatureFlagProvider>
            <AuthProvider>
              <NotificationProvider>
                {children}
              </NotificationProvider>
            </AuthProvider>
          </FeatureFlagProvider>
        </QueryProvider>
      </ThemeProvider>
    </LocaleProvider>
  );
}
