#!/bin/bash
set -e

# Generate and update TypeScript types
# Regenerates Prisma Client types and validates schema

echo "═══════════════════════════════════════════════════════════"
echo "🔧 Generating TypeScript types..."
echo "═══════════════════════════════════════════════════════════"
echo ""

# Generate Prisma Client
echo "Generating Prisma Client..."
npm run db:generate

# Run TypeScript check
echo ""
echo "🔍 Running TypeScript type check..."
npm run type-check

# Generate API types if available
if [ -f "scripts/generate-api-types.ts" ]; then
  echo ""
  echo "📡 Generating API types..."
  npx tsx scripts/generate-api-types.ts || true
fi

# Generate GraphQL types if available
if [ -f "src/graphql/schema.graphql" ]; then
  echo ""
  echo "📊 Generating GraphQL types..."
  npm run codegen || true
fi

echo ""
echo "═══════════════════════════════════════════════════════════"
echo "✅ Type generation complete!"
echo "═══════════════════════════════════════════════════════════"
echo ""
