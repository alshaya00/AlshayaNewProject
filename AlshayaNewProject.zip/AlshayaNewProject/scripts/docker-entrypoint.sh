#!/bin/sh
set -e

# Docker entrypoint script for Next.js application
# Handles database migrations and application startup

echo "🚀 Starting Alshaya Family Tree Application..."

# Wait for database to be ready
echo "⏳ Waiting for PostgreSQL..."
while ! nc -z postgres 5432; do
  sleep 1
done
echo "✅ PostgreSQL is ready"

# Wait for Redis to be ready
echo "⏳ Waiting for Redis..."
while ! nc -z redis 6379; do
  sleep 1
done
echo "✅ Redis is ready"

# Generate Prisma Client if needed
echo "🔧 Generating Prisma Client..."
npm run db:generate

# Run database migrations
echo "📊 Running database migrations..."
npm run db:migrate || {
  echo "⚠️  Migrations failed, attempting push..."
  npm run db:push
}

# Seed database if needed (only in development)
if [ "$NODE_ENV" = "development" ]; then
  echo "🌱 Seeding database..."
  npm run db:seed || true
fi

# Run health check
echo "🏥 Running health check..."
sleep 2
wget -O- http://localhost:3000/health || {
  echo "⚠️  Health check failed, but continuing..."
}

echo "✅ Application is ready!"
echo "📍 Server running on http://0.0.0.0:${PORT:-3000}"

# Execute the main process
exec "$@"
