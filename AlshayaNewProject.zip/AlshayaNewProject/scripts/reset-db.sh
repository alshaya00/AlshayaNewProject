#!/bin/bash
set -e

# Database reset script for development
# WARNING: This will delete all data!

echo "═══════════════════════════════════════════════════════════"
echo "⚠️  WARNING: This will delete all database data!"
echo "═══════════════════════════════════════════════════════════"
echo ""

read -p "Are you sure you want to reset the database? (type 'yes' to confirm): " confirmation

if [ "$confirmation" != "yes" ]; then
  echo "Reset cancelled."
  exit 0
fi

echo ""
echo "🔄 Resetting database..."

# Check if using Docker Compose
if [ -f "docker-compose.yml" ] && command -v docker-compose &> /dev/null; then
  echo "Stopping containers..."
  docker-compose down -v || true

  echo "Starting fresh containers..."
  docker-compose up -d postgres redis

  echo "⏳ Waiting for PostgreSQL..."
  sleep 5
fi

# Reset Prisma
echo ""
echo "🔧 Resetting Prisma migrations..."
npm run db:generate

echo "Resetting database schema..."
npm run db:push -- --force-reset || npm run db:migrate -- reset || true

# Seed database
echo ""
echo "🌱 Seeding database..."
npm run db:seed

echo ""
echo "═══════════════════════════════════════════════════════════"
echo "✅ Database reset complete!"
echo "═══════════════════════════════════════════════════════════"
echo ""
echo "You can now start the application:"
echo "  npm run dev"
echo ""
