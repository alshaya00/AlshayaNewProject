#!/bin/bash
set -e

# Project setup script for Alshaya Family Tree Application
# Handles installation, database setup, and initial configuration

echo "═══════════════════════════════════════════════════════════"
echo "🚀 Setting up Alshaya Family Tree Application"
echo "═══════════════════════════════════════════════════════════"

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
  echo "❌ Node.js is not installed. Please install Node.js 18+ first."
  exit 1
fi

echo "✅ Node.js version: $(node --version)"
echo "✅ npm version: $(npm --version)"

# Create .env.local if it doesn't exist
if [ ! -f .env.local ]; then
  echo ""
  echo "📝 Creating .env.local file..."
  cp .env.example .env.local 2>/dev/null || cat > .env.local << 'EOF'
# Database
DATABASE_URL="postgresql://postgres:postgres@localhost:5432/alshaya_family_tree"

# Redis
REDIS_URL="redis://localhost:6379"

# Authentication
NEXTAUTH_SECRET="your-secret-key-change-in-production"
NEXTAUTH_URL="http://localhost:3000"
JWT_SECRET="your-jwt-secret-change-in-production"

# Email
SMTP_HOST="localhost"
SMTP_PORT="1025"
SMTP_USER=""
SMTP_PASSWORD=""
SMTP_FROM="noreply@alshaya.local"

# S3/Cloud Storage (optional)
AWS_REGION=""
AWS_ACCESS_KEY_ID=""
AWS_SECRET_ACCESS_KEY=""
AWS_S3_BUCKET=""
EOF
  echo "✅ Created .env.local (update with your settings)"
else
  echo "✅ .env.local already exists"
fi

# Install dependencies
echo ""
echo "📦 Installing dependencies..."
npm ci

# Generate Prisma Client
echo ""
echo "🔧 Generating Prisma Client..."
npm run db:generate

# Run TypeScript check
echo ""
echo "🔍 Running TypeScript check..."
npm run type-check

# Check if Docker is running for database setup
if command -v docker &> /dev/null && docker ps &> /dev/null; then
  echo ""
  echo "🐳 Docker is running. Setting up containers..."

  # Check if containers are already running
  if ! docker ps | grep -q alshaya_postgres; then
    echo "Starting Docker containers..."
    docker-compose up -d postgres redis

    echo "⏳ Waiting for PostgreSQL to be ready..."
    sleep 5
  fi

  # Run migrations
  echo ""
  echo "📊 Running database migrations..."
  npm run db:push

  # Seed database
  echo ""
  echo "🌱 Seeding database (optional)..."
  npm run db:seed || true

  echo ""
  echo "✅ Database setup complete!"
else
  echo ""
  echo "⚠️  Docker is not running. Database setup skipped."
  echo "To set up the database:"
  echo "  1. Start Docker"
  echo "  2. Run: docker-compose up -d"
  echo "  3. Run: npm run db:push"
  echo "  4. Run: npm run db:seed (optional)"
fi

# Run ESLint
echo ""
echo "🎨 Running ESLint..."
npm run lint --fix || true

# Format code
echo ""
echo "✨ Formatting code..."
npm run format || true

echo ""
echo "═══════════════════════════════════════════════════════════"
echo "✅ Setup complete!"
echo "═══════════════════════════════════════════════════════════"
echo ""
echo "Next steps:"
echo "  1. Update .env.local with your configuration"
echo "  2. Start Docker containers: docker-compose up -d"
echo "  3. Run development server: npm run dev"
echo "  4. Open browser: http://localhost:3000"
echo ""
